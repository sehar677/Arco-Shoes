import {
  TrainingCenter,
  Instructor,
  Scheme,
  Contribution,
  Notice,
  AppSetting,
} from '../types';

export const DEFAULT_TRAINING_CENTERS: TrainingCenter[] = [];

export const DEFAULT_SCHEMES: Scheme[] = [];

export const DEFAULT_INSTRUCTORS: Instructor[] = [];

export const DEFAULT_CONTRIBUTIONS: Contribution[] = [];

export const DEFAULT_NOTICES: Notice[] = [];

export const DEFAULT_SETTINGS: AppSetting = {
  id: 'general',
  targetAmount: 0,
  appName: "J&K ITI EMPLOYEE'S UNITED FRONT",
  isSeeded: false,
  updatedAt: new Date().toISOString(),
};

