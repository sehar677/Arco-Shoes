import React from 'react';
import { TrainingCenter, Instructor, Scheme, Contribution, ItiAggregatedData } from '../types';
import { ItiContributionTable } from '../components/ItiContributionTable';
import { formatCurrency, formatNumber } from '../utils/format';
import { IndianRupee, Layers, Building2, TrendingUp } from 'lucide-react';

interface ContributionsPageProps {
  trainingCenters: TrainingCenter[];
  instructors: Instructor[];
  schemes: Scheme[];
  contributions: Contribution[];
  aggregatedItis: ItiAggregatedData[];
}

export const ContributionsPage: React.FC<ContributionsPageProps> = ({
  trainingCenters,
  instructors,
  schemes,
  contributions,
  aggregatedItis,
}) => {
  const totalRemitted = contributions.reduce((sum, c) => sum + (c.amount || 0), 0);
  const contributingItisCount = new Set(contributions.filter((c) => (c.amount || 0) > 0).map((c) => c.itiId)).size;
  const totalSchemeTarget = schemes.reduce((sum, s) => sum + (s.targetAmount || 0), 0);

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
                Financial Tracking &amp; Remittances • Directorate of Skill Development J&amp;K
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-[#0F2942] uppercase tracking-tight">
              EVENTS &amp; CONTRIBUTIONS
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-3xl">
              Consolidated financial remittances, event allocations, and event-wise contribution tracking across all 50 Government Industrial Training Institutes in Jammu &amp; Kashmir.
            </p>
          </div>

          {/* Quick Metrics Bar */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-emerald-50 border border-emerald-200 px-4 py-2.5 rounded-xl shadow-2xs">
              <span className="text-[10px] uppercase font-bold text-emerald-800 block">Total Remitted</span>
              <span className="text-lg sm:text-xl font-black text-emerald-900 font-mono">
                {formatCurrency(totalRemitted)}
              </span>
            </div>
            <div className="bg-blue-50 border border-blue-200 px-4 py-2.5 rounded-xl shadow-2xs">
              <span className="text-[10px] uppercase font-bold text-blue-800 block">Contributing ITIs</span>
              <span className="text-lg sm:text-xl font-black text-blue-900">
                {contributingItisCount} / {trainingCenters.length}
              </span>
            </div>
            <div className="bg-amber-50 border border-amber-200 px-4 py-2.5 rounded-xl shadow-2xs">
              <span className="text-[10px] uppercase font-bold text-amber-800 block">Active Events</span>
              <span className="text-lg sm:text-xl font-black text-amber-900">
                {schemes.length}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Events & Contributions Section with Event Dropdown & Reactive Filtering */}
      <section aria-label="Events & Contributions Table">
        <ItiContributionTable
          data={aggregatedItis}
          trainingCenters={trainingCenters}
          instructors={instructors}
          schemes={schemes}
          contributions={contributions}
          title="EVENTS & CONTRIBUTIONS"
          subtitle="Select any event from the dropdown to filter active remittances, or view consolidated contributions across all 50 ITIs"
        />
      </section>
    </div>
  );
};
