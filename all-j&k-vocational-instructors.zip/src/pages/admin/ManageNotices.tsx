import React, { useState, useMemo } from 'react';
import { Notice } from '../../types';
import { addNotice, updateNotice, deleteNotice } from '../../services/db';
import { ConfirmModal } from '../../components/ConfirmModal';
import { formatDate } from '../../utils/format';
import {
  Plus,
  Edit2,
  Trash2,
  Bell,
  AlertCircle,
  Calendar,
  X,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Eye,
  ExternalLink,
  Sparkles,
  FileText,
  Building2,
  Star,
} from 'lucide-react';

interface ManageNoticesProps {
  notices: Notice[];
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const ManageNotices: React.FC<ManageNoticesProps> = ({ notices, onNotify }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingNotice, setEditingNotice] = useState<Notice | null>(null);
  const [previewNotice, setPreviewNotice] = useState<Notice | null>(null);

  // Filter & Search states
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<'Notice' | 'Event' | 'Notification' | 'Circular' | 'Meeting'>('Notice');
  const [publishDate, setPublishDate] = useState(new Date().toISOString().split('T')[0]);
  const [eventDate, setEventDate] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState('');
  const [publishedBy, setPublishedBy] = useState('Directorate of Skill Development J&K');
  const [isImportant, setIsImportant] = useState(false);
  const [status, setStatus] = useState<'Published' | 'Draft'>('Published');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Delete modal state
  const [deleteTarget, setDeleteTarget] = useState<Notice | null>(null);

  const handleOpenAdd = () => {
    setEditingNotice(null);
    setTitle('');
    setDescription('');
    setCategory('Notice');
    setPublishDate(new Date().toISOString().split('T')[0]);
    setEventDate('');
    setAttachmentUrl('');
    setPublishedBy('Directorate of Skill Development J&K');
    setIsImportant(false);
    setStatus('Published');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (n: Notice) => {
    setEditingNotice(n);
    setTitle(n.title || '');
    setDescription(n.description || '');
    setCategory(n.category || 'Notice');
    setPublishDate(n.publishDate || new Date().toISOString().split('T')[0]);
    setEventDate(n.eventDate || '');
    setAttachmentUrl(n.attachmentUrl || '');
    setPublishedBy(n.publishedBy || 'Directorate of Skill Development J&K');
    setIsImportant(Boolean(n.isImportant));
    setStatus(n.status || 'Published');
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      onNotify('error', 'Notice Title is required.');
      return;
    }
    if (!description.trim()) {
      onNotify('error', 'Notice Description / Directives content is required.');
      return;
    }

    setIsSubmitting(true);
    try {
      const noticePayload = {
        title: title.trim(),
        description: description.trim(),
        category,
        publishDate: publishDate || new Date().toISOString().split('T')[0],
        eventDate: eventDate.trim() ? eventDate.trim() : '',
        attachmentUrl: attachmentUrl.trim() ? attachmentUrl.trim() : '',
        publishedBy: publishedBy.trim() || 'Directorate of Skill Development J&K',
        isImportant: Boolean(isImportant),
        status,
      };

      if (editingNotice && editingNotice.id) {
        await updateNotice(editingNotice.id, noticePayload);
        onNotify('success', `Notice "${title.trim()}" updated successfully.`);
      } else {
        await addNotice(noticePayload);
        onNotify('success', `Notice "${title.trim()}" published successfully.`);
      }
      setIsModalOpen(false);
      setEditingNotice(null);
    } catch (err: any) {
      console.error('Error saving notice:', err);
      onNotify('error', err?.message || 'Failed to save notice. Please check all fields.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleStatus = async (notice: Notice) => {
    const newStatus = notice.status === 'Published' ? 'Draft' : 'Published';
    try {
      await updateNotice(notice.id, { status: newStatus });
      onNotify('success', `Notice status changed to "${newStatus}".`);
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to toggle notice status.');
    }
  };

  const handleTogglePriority = async (notice: Notice) => {
    const newPriority = !notice.isImportant;
    try {
      await updateNotice(notice.id, { isImportant: newPriority });
      onNotify('info', `Notice marked as ${newPriority ? 'Important Priority' : 'Normal Priority'}.`);
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to update priority.');
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteNotice(deleteTarget.id);
      onNotify('success', `Notice "${deleteTarget.title}" deleted.`);
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to delete notice.');
    } finally {
      setDeleteTarget(null);
    }
  };

  // Filtered and Sorted notices list
  const filteredNotices = useMemo(() => {
    return notices.filter((n) => {
      const matchSearch =
        n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        n.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (n.publishedBy && n.publishedBy.toLowerCase().includes(searchTerm.toLowerCase()));

      if (!matchSearch) return false;

      if (categoryFilter !== 'All' && n.category !== categoryFilter) return false;
      if (statusFilter === 'Published' && n.status !== 'Published') return false;
      if (statusFilter === 'Draft' && n.status !== 'Draft') return false;
      if (statusFilter === 'Important' && !n.isImportant) return false;

      return true;
    });
  }, [notices, searchTerm, categoryFilter, statusFilter]);

  const stats = useMemo(() => {
    const total = notices.length;
    const published = notices.filter((n) => n.status === 'Published').length;
    const drafts = notices.filter((n) => n.status === 'Draft').length;
    const important = notices.filter((n) => n.isImportant).length;
    return { total, published, drafts, important };
  }, [notices]);

  const categoryColor: Record<string, string> = {
    Notice: 'bg-blue-100 text-blue-800 border-blue-200',
    Circular: 'bg-amber-100 text-amber-800 border-amber-200',
    Event: 'bg-purple-100 text-purple-800 border-purple-200',
    Notification: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    Meeting: 'bg-rose-100 text-rose-800 border-rose-200',
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-700"></span>
            <span className="text-[11px] font-extrabold text-amber-700 uppercase tracking-wider">
              Department Communications &amp; Circulars
            </span>
          </div>
          <h2 className="text-xl font-black text-[#0F2942] uppercase tracking-wide">
            MANAGE NOTICEBOARD &amp; CIRCULARS
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Publish, edit, and maintain official departmental notifications, meetings, events, and important circulars for all 50 ITIs.
          </p>
        </div>

        <button
          type="button"
          id="admin-create-notice-btn"
          onClick={handleOpenAdd}
          className="px-4 py-2.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all shadow-sm shrink-0 self-start md:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>PUBLISH NEW NOTICE</span>
        </button>
      </div>

      {/* Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div
          onClick={() => { setCategoryFilter('All'); setStatusFilter('All'); }}
          className={`bg-white p-3.5 rounded-xl border transition-all cursor-pointer ${
            statusFilter === 'All' && categoryFilter === 'All'
              ? 'border-blue-500 ring-2 ring-blue-200'
              : 'border-slate-200 hover:border-slate-300'
          }`}
        >
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
            Total Notices
          </span>
          <span className="text-xl font-black text-slate-900 mt-1 block">{stats.total}</span>
        </div>

        <div
          onClick={() => setStatusFilter(statusFilter === 'Published' ? 'All' : 'Published')}
          className={`bg-white p-3.5 rounded-xl border transition-all cursor-pointer ${
            statusFilter === 'Published'
              ? 'border-emerald-500 ring-2 ring-emerald-200'
              : 'border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block">
              Published Live
            </span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          </div>
          <span className="text-xl font-black text-emerald-900 mt-1 block">{stats.published}</span>
        </div>

        <div
          onClick={() => setStatusFilter(statusFilter === 'Draft' ? 'All' : 'Draft')}
          className={`bg-white p-3.5 rounded-xl border transition-all cursor-pointer ${
            statusFilter === 'Draft'
              ? 'border-amber-500 ring-2 ring-amber-200'
              : 'border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider block">
              Drafts / Pending
            </span>
            <Clock className="w-3.5 h-3.5 text-amber-600" />
          </div>
          <span className="text-xl font-black text-amber-900 mt-1 block">{stats.drafts}</span>
        </div>

        <div
          onClick={() => setStatusFilter(statusFilter === 'Important' ? 'All' : 'Important')}
          className={`bg-white p-3.5 rounded-xl border transition-all cursor-pointer ${
            statusFilter === 'Important'
              ? 'border-rose-500 ring-2 ring-rose-200'
              : 'border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-rose-700 uppercase tracking-wider block">
              Important Priority
            </span>
            <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
          </div>
          <span className="text-xl font-black text-rose-900 mt-1 block">{stats.important}</span>
        </div>
      </div>

      {/* Filter and Search Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by title, description, or author..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden text-slate-800"
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Categories & Filter Dropdowns */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
            {['All', 'Notice', 'Circular', 'Event', 'Notification', 'Meeting'].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategoryFilter(cat)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-all ${
                  categoryFilter === cat
                    ? 'bg-[#0F2942] text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="p-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-slate-700"
          >
            <option value="All">All Statuses</option>
            <option value="Published">Published Only</option>
            <option value="Draft">Drafts Only</option>
            <option value="Important">Important Only</option>
          </select>
        </div>
      </div>

      {/* Notices Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                <th className="py-3 px-3.5 text-center w-12">#</th>
                <th className="py-3 px-4 min-w-[260px]">Title &amp; Content Summary</th>
                <th className="py-3 px-3.5 text-center">Category</th>
                <th className="py-3 px-3.5 text-center">Publish Date</th>
                <th className="py-3 px-3.5 text-center">Event Date</th>
                <th className="py-3 px-3.5 text-center">Priority</th>
                <th className="py-3 px-3.5 text-center">Status</th>
                <th className="py-3 px-4 text-right min-w-[130px]">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredNotices.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    <div className="max-w-sm mx-auto space-y-2">
                      <Bell className="w-8 h-8 text-slate-300 mx-auto" />
                      <p className="font-bold text-slate-700">No notices found matching your search</p>
                      <p className="text-[11px] text-slate-400">
                        Adjust your filters or click "PUBLISH NEW NOTICE" to add a new circular.
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredNotices.map((n, idx) => (
                  <tr
                    key={n.id}
                    className={`hover:bg-blue-50/40 transition-colors ${
                      idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/40'
                    }`}
                  >
                    <td className="py-3 px-3.5 text-center font-bold text-slate-500">
                      {idx + 1}
                    </td>
                    <td className="py-3 px-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-slate-900 text-xs hover:text-blue-900 cursor-pointer" onClick={() => setPreviewNotice(n)}>
                            {n.title}
                          </span>
                          {n.attachmentUrl && (
                            <a
                              href={n.attachmentUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:text-blue-800 inline-flex items-center gap-0.5 text-[10px] font-semibold underline"
                              title="Attachment Link"
                            >
                              <ExternalLink className="w-3 h-3" />
                              <span>Link</span>
                            </a>
                          )}
                        </div>
                        <p className="text-slate-500 line-clamp-1 text-[11px] max-w-md">
                          {n.description}
                        </p>
                        <span className="text-[10px] text-slate-400 block">
                          By: {n.publishedBy || 'Directorate of Skill Development J&K'}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-3.5 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-extrabold border ${
                          categoryColor[n.category] || 'bg-slate-100 text-slate-700 border-slate-200'
                        }`}
                      >
                        {n.category}
                      </span>
                    </td>
                    <td className="py-3 px-3.5 text-center font-mono text-slate-700">
                      {formatDate(n.publishDate)}
                    </td>
                    <td className="py-3 px-3.5 text-center font-mono text-purple-700">
                      {n.eventDate ? formatDate(n.eventDate) : '—'}
                    </td>
                    <td className="py-3 px-3.5 text-center">
                      <button
                        type="button"
                        onClick={() => handleTogglePriority(n)}
                        title="Click to toggle importance"
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold transition-all cursor-pointer ${
                          n.isImportant
                            ? 'bg-rose-100 hover:bg-rose-200 text-rose-800 border border-rose-200'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-500 border border-slate-200'
                        }`}
                      >
                        <AlertCircle className={`w-3 h-3 ${n.isImportant ? 'text-rose-600' : 'text-slate-400'}`} />
                        <span>{n.isImportant ? 'Important' : 'Normal'}</span>
                      </button>
                    </td>
                    <td className="py-3 px-3.5 text-center">
                      <button
                        type="button"
                        onClick={() => handleToggleStatus(n)}
                        title="Click to toggle Published / Draft"
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold transition-all cursor-pointer ${
                          n.status === 'Published'
                            ? 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800 border border-emerald-200'
                            : 'bg-amber-100 hover:bg-amber-200 text-amber-800 border border-amber-200'
                        }`}
                      >
                        {n.status === 'Published' ? (
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        ) : (
                          <Clock className="w-3 h-3 text-amber-600" />
                        )}
                        <span>{n.status}</span>
                      </button>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => setPreviewNotice(n)}
                          className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                          title="Preview Notice"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          id={`edit-notice-${n.id}`}
                          onClick={() => handleOpenEdit(n)}
                          className="p-1.5 text-blue-700 hover:text-blue-900 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Edit Notice Details"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          id={`delete-notice-${n.id}`}
                          onClick={() => setDeleteTarget(n)}
                          className="p-1.5 text-rose-700 hover:text-rose-900 hover:bg-rose-50 rounded-lg transition-colors"
                          title="Delete Notice"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-xl w-full overflow-hidden animate-scaleUp">
            <div className="bg-[#0F2942] text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-black uppercase tracking-wide">
                  {editingNotice ? 'EDIT NOTICE / CIRCULAR' : 'PUBLISH NEW NOTICE / CIRCULAR'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsModalOpen(false);
                  setEditingNotice(null);
                }}
                className="p-1 text-slate-300 hover:text-white rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs max-h-[80vh] overflow-y-auto">
              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Notice Title *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. State Level Vocational Skills Meet & Exhibition 2025"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:ring-2 focus:ring-blue-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Notice Content / Directives *
                </label>
                <textarea
                  rows={4}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Full text of notification, official circular directives, venue details, or instructions..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:ring-2 focus:ring-blue-500 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Category *
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-medium"
                  >
                    <option value="Notice">Notice</option>
                    <option value="Circular">Circular</option>
                    <option value="Event">Event</option>
                    <option value="Notification">Notification</option>
                    <option value="Meeting">Meeting</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Publish Status *
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-medium"
                  >
                    <option value="Published">Published (Live to public)</option>
                    <option value="Draft">Draft (Admin only)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Publish Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={publishDate}
                    onChange={(e) => setPublishDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Event / Meeting Date (Optional)
                  </label>
                  <input
                    type="date"
                    value={eventDate}
                    onChange={(e) => setEventDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Attachment / Document URL (Optional)
                </label>
                <input
                  type="url"
                  value={attachmentUrl}
                  onChange={(e) => setAttachmentUrl(e.target.value)}
                  placeholder="https://... (PDF, official document, or order link)"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono text-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Issuing Authority / Published By
                </label>
                <input
                  type="text"
                  value={publishedBy}
                  onChange={(e) => setPublishedBy(e.target.value)}
                  placeholder="Directorate of Skill Development J&K"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2.5">
                <input
                  type="checkbox"
                  id="notice-important-check"
                  checked={isImportant}
                  onChange={(e) => setIsImportant(e.target.checked)}
                  className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 cursor-pointer"
                />
                <label
                  htmlFor="notice-important-check"
                  className="font-bold text-rose-900 cursor-pointer select-none text-xs"
                >
                  Mark as High Priority / Important Notice (Pinnable announcement)
                </label>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setEditingNotice(null);
                  }}
                  className="px-4 py-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white font-bold disabled:opacity-50 flex items-center gap-1.5 shadow-sm"
                >
                  {isSubmitting ? 'Saving to Database...' : editingNotice ? 'Update Notice' : 'Publish Notice'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Preview Notice Modal */}
      {previewNotice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden animate-scaleUp">
            <div className="bg-[#0F2942] text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase ${categoryColor[previewNotice.category] || 'bg-blue-100 text-blue-800'}`}>
                  {previewNotice.category}
                </span>
                {previewNotice.isImportant && (
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-rose-500 text-white uppercase">
                    Important
                  </span>
                )}
              </div>
              <button
                type="button"
                onClick={() => setPreviewNotice(null)}
                className="p-1 text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <h3 className="text-base font-black text-slate-900">
                {previewNotice.title}
              </h3>

              <div className="flex flex-wrap items-center gap-4 text-slate-500 text-[11px] pb-3 border-b border-slate-100">
                <div className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>Published: {formatDate(previewNotice.publishDate)}</span>
                </div>
                {previewNotice.eventDate && (
                  <div className="flex items-center gap-1 text-purple-700 font-semibold">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Event: {formatDate(previewNotice.eventDate)}</span>
                  </div>
                )}
              </div>

              <div className="text-slate-700 whitespace-pre-wrap leading-relaxed">
                {previewNotice.description}
              </div>

              {previewNotice.attachmentUrl && (
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-center justify-between">
                  <span className="font-semibold text-blue-900">Attached Circular Document</span>
                  <a
                    href={previewNotice.attachmentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded text-[11px] flex items-center gap-1"
                  >
                    <span>View Link</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span>Issued by: {previewNotice.publishedBy || 'Directorate of Skill Development J&K'}</span>
                <span className={`font-bold ${previewNotice.status === 'Published' ? 'text-emerald-600' : 'text-amber-600'}`}>
                  Status: {previewNotice.status}
                </span>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const target = previewNotice;
                    setPreviewNotice(null);
                    handleOpenEdit(target);
                  }}
                  className="px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-lg"
                >
                  Edit Notice
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewNotice(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={!!deleteTarget}
        title="Confirm Notice Deletion"
        message={`Are you sure you want to permanently delete "${deleteTarget?.title}"? This action cannot be undone.`}
        confirmText="Yes, Delete Notice"
        cancelText="Cancel"
        isDanger={true}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};
