import React, { useState, useEffect, useMemo } from 'react';
import { 
  Calendar, 
  Search, 
  FileText, 
  ShoppingCart, 
  ArrowDownLeft, 
  ArrowUpRight, 
  RotateCcw,
  BookOpen, 
  Printer, 
  Filter, 
  ArrowLeftRight,
  TrendingUp,
  CreditCard,
  Building2,
  CheckCircle2,
  Layers,
  ChevronLeft,
  ChevronRight,
  CircleDollarSign,
  Wallet,
  Package,
  Store,
  Landmark,
  Users,
  X
} from 'lucide-react';
import { dbService } from '../services/storage';
import { SalesExchangeDeskRecord, CompanyInfo } from '../types';

export const DayBookComponent: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [filterType, setFilterType] = useState<string>('SALE');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [entries, setEntries] = useState<any[]>([]);
  const [exchangeDeskEntries, setExchangeDeskEntries] = useState<SalesExchangeDeskRecord[]>([]);
  const [company, setCompany] = useState<CompanyInfo>(() => dbService.getCompany());

  useEffect(() => {
    const loadDayEntries = () => {
      const targetDate = selectedDate;
      const allSales = dbService.getSales();
      const allPurchases = dbService.getPurchases();
      const allSalesReturns = dbService.getSalesReturns();
      const allSalesExchanges = dbService.getSalesExchanges();
      const allSalesExchangeDesk = dbService.getSalesExchangeDeskRecords();
      const allPurchaseReturns = dbService.getPurchaseReturns();
      const allReceipts = dbService.getReceipts();
      const allPayments = dbService.getPayments();
      const allCustomers = dbService.getCustomers();
      const allSuppliers = dbService.getSuppliers();
      setCompany(dbService.getCompany());

      const customerMap = new Map(allCustomers.map(c => [c.id, c]));
      const supplierMap = new Map(allSuppliers.map(sup => [sup.id, sup]));

      const getEntryTimestamp = (createdAt?: string, timeStr?: string, dateStr?: string): number => {
        if (createdAt) {
          const t = new Date(createdAt).getTime();
          if (!isNaN(t) && t > 0) return t;
        }
        if (timeStr && dateStr && timeStr !== 'N/A') {
          const match = timeStr.match(/(\d+):(\d+)(?::(\d+))?\s*(am|pm)?/i);
          if (match) {
            let hours = parseInt(match[1], 10);
            const minutes = parseInt(match[2], 10);
            const seconds = match[3] ? parseInt(match[3], 10) : 0;
            const meridiem = match[4]?.toLowerCase();
            if (meridiem === 'pm' && hours < 12) hours += 12;
            if (meridiem === 'am' && hours === 12) hours = 0;
            const d = new Date(dateStr);
            d.setHours(hours, minutes, seconds, 0);
            const t = d.getTime();
            if (!isNaN(t)) return t;
          }
        }
        if (dateStr) {
          const d = new Date(dateStr).getTime();
          if (!isNaN(d)) return d;
        }
        return 0;
      };

      const getFormattedTime = (createdAt?: string, timeStr?: string): string => {
        if (createdAt) {
          const d = new Date(createdAt);
          if (!isNaN(d.getTime())) {
            return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
          }
        }
        if (timeStr && timeStr !== 'N/A') {
          return timeStr;
        }
        return 'N/A';
      };

      const dayList: any[] = [];

      // Filter exchange desk records for selected day (exclude same-day modifications)
      const dayDeskList = allSalesExchangeDesk.filter(ed => 
        (ed.billModifiedDate === targetDate || ed.invoiceDate === targetDate || (ed.createdAt && ed.createdAt.startsWith(targetDate))) &&
        !(ed.invoiceDate && ed.billModifiedDate && ed.invoiceDate === ed.billModifiedDate)
      );
      setExchangeDeskEntries(dayDeskList);

      // Filter each list by matching date string
      allSales.forEach(s => {
        if (s.invoiceDate === targetDate) {
          const cust = customerMap.get(s.customerId);
          dayList.push({
            id: s.id,
            timestamp: getEntryTimestamp(s.createdAt, undefined, s.invoiceDate),
            time: getFormattedTime(s.createdAt),
            voucherNo: s.invoiceNo,
            voucherType: 'Sale Bill',
            customerName: s.customerName || cust?.customerName || 'Cash Customer',
            customerMobile: s.customerMobile || cust?.mobile || '-',
            paymentMode: s.paymentMode,
            amount: s.grandTotal,
            rawType: 'SALE',
            color: 'text-emerald-700 bg-emerald-50 border-emerald-200'
          });
        }
      });

      // Sales Exchange Desk Records
      dayDeskList.forEach(ed => {
        const cust = customerMap.get(ed.customerId);
        dayList.push({
          id: ed.id,
          timestamp: getEntryTimestamp(ed.createdAt, undefined, ed.billModifiedDate || ed.invoiceDate || targetDate),
          time: getFormattedTime(ed.createdAt),
          voucherNo: ed.invoiceNo,
          voucherType: 'Exchange Desk',
          customerName: ed.customerName || cust?.customerName || 'Cash Customer',
          customerMobile: ed.customerMobile || cust?.mobile || '-',
          paymentMode: ed.netAmount >= 0 ? `Net Diff (+₹${ed.netAmount})` : `Net Diff (-₹${Math.abs(ed.netAmount)})`,
          amount: ed.netAmount,
          rawType: 'SALES_EXCHANGE_DESK',
          color: 'text-amber-700 bg-amber-50 border-amber-200'
        });
      });

      allPurchases.forEach(p => {
        if (p.purchaseDate === targetDate) {
          const sup = supplierMap.get(p.supplierId);
          dayList.push({
            id: p.id,
            timestamp: getEntryTimestamp(p.createdAt, undefined, p.purchaseDate),
            time: getFormattedTime(p.createdAt),
            voucherNo: p.supplierBillNo || p.purchaseNo,
            voucherType: 'Purchase Inward',
            customerName: p.supplierName || sup?.supplierName || 'Supplier',
            customerMobile: (p as any).supplierMobile || sup?.mobile || '-',
            paymentMode: p.paymentMode,
            amount: p.grandTotal,
            rawType: 'PURCHASE',
            color: 'text-blue-700 bg-blue-50 border-blue-200'
          });
        }
      });

      allSalesReturns.forEach(sr => {
        if (sr.returnDate === targetDate) {
          const cust = customerMap.get(sr.customerId);
          dayList.push({
            id: sr.id,
            timestamp: getEntryTimestamp(sr.createdAt, sr.returnTime, sr.returnDate),
            time: getFormattedTime(sr.createdAt, sr.returnTime),
            voucherNo: sr.returnNo,
            voucherType: 'Sales Return',
            customerName: sr.customerName || cust?.customerName || 'Cash Customer',
            customerMobile: sr.customerMobile || cust?.mobile || '-',
            paymentMode: sr.refundMode,
            amount: sr.grandTotal,
            rawType: 'SALES_RETURN',
            color: 'text-rose-700 bg-rose-50 border-rose-200'
          });
        }
      });

      allSalesExchanges.forEach(exc => {
        if (exc.exchangeDate === targetDate) {
          const cust = customerMap.get(exc.customerId);
          dayList.push({
            id: exc.id,
            timestamp: getEntryTimestamp(exc.createdAt, exc.exchangeTime, exc.exchangeDate),
            time: getFormattedTime(exc.createdAt, exc.exchangeTime),
            voucherNo: exc.exchangeNo,
            voucherType: 'Sales Exchange',
            customerName: exc.customerName || cust?.customerName || 'Cash Customer',
            customerMobile: exc.customerMobile || cust?.mobile || '-',
            paymentMode: exc.settlementType === 'CUSTOMER_PAID' ? `Paid (${exc.paymentMethod || 'Cash'})` : exc.settlementType === 'STORE_CREDIT_ISSUED' ? 'Credit Note' : exc.settlementType === 'REFUND_PAID' ? 'Refund' : 'Even',
            amount: exc.newTotalValue,
            rawType: 'SALES_EXCHANGE',
            color: 'text-orange-700 bg-orange-50 border-orange-200'
          });
        }
      });

      allPurchaseReturns.forEach(pr => {
        if (pr.returnDate === targetDate) {
          const sup = supplierMap.get(pr.supplierId);
          dayList.push({
            id: pr.id,
            timestamp: getEntryTimestamp(pr.createdAt, undefined, pr.returnDate),
            time: getFormattedTime(pr.createdAt),
            voucherNo: pr.returnNo,
            voucherType: 'Purchase Return',
            customerName: pr.supplierName || sup?.supplierName || 'Supplier',
            customerMobile: sup?.mobile || '-',
            paymentMode: pr.refundMode,
            amount: pr.grandTotal,
            rawType: 'PURCHASE_RETURN',
            color: 'text-violet-700 bg-violet-50 border-violet-200'
          });
        }
      });

      allReceipts.forEach(r => {
        if (r.receiptDate === targetDate) {
          const cust = customerMap.get(r.customerId);
          dayList.push({
            id: r.id,
            timestamp: getEntryTimestamp(r.createdAt, undefined, r.receiptDate),
            time: getFormattedTime(r.createdAt),
            voucherNo: r.receiptNo,
            voucherType: 'Receipt voucher',
            customerName: r.customerName || cust?.customerName || 'Customer',
            customerMobile: cust?.mobile || '-',
            paymentMode: r.paymentMode,
            amount: r.amountReceived,
            rawType: 'RECEIPT',
            color: 'text-teal-700 bg-teal-50 border-teal-200'
          });
        }
      });

      allPayments.forEach(py => {
        if (py.voucherDate === targetDate) {
          const sup = supplierMap.get(py.supplierId);
          dayList.push({
            id: py.id,
            timestamp: getEntryTimestamp(py.createdAt, undefined, py.voucherDate),
            time: getFormattedTime(py.createdAt),
            voucherNo: py.voucherNo,
            voucherType: 'Payment Voucher',
            customerName: py.supplierName || sup?.supplierName || 'Supplier',
            customerMobile: sup?.mobile || '-',
            paymentMode: py.paymentMode,
            amount: py.amountPaid,
            rawType: 'PAYMENT',
            color: 'text-rose-700 bg-rose-50 border-rose-200'
          });
        }
      });

      // Always sort by chronological time in ASCENDING order (earliest to latest)
      dayList.sort((a, b) => (a.timestamp - b.timestamp) || a.voucherNo.localeCompare(b.voucherNo));
      setEntries(dayList);
    };

    loadDayEntries();
    return dbService.subscribe(loadDayEntries);
  }, [selectedDate]);

  // Compute filtered items and ensure ascending order by time is maintained
  const filteredEntries = useMemo(() => {
    return entries
      .filter(e => {
        if (filterType !== 'ALL' && e.rawType !== filterType) return false;
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchesVoucher = (e.voucherNo || '').toLowerCase().includes(q);
          const matchesCustomer = (e.customerName || '').toLowerCase().includes(q);
          const matchesMobile = (e.customerMobile || '').toLowerCase().includes(q);
          const matchesMethod = (e.paymentMode || '').toLowerCase().includes(q);
          const matchesType = (e.voucherType || '').toLowerCase().includes(q);
          return matchesVoucher || matchesCustomer || matchesMobile || matchesMethod || matchesType;
        }
        return true;
      })
      .sort((a, b) => (a.timestamp - b.timestamp) || a.voucherNo.localeCompare(b.voucherNo));
  }, [entries, filterType, searchQuery]);

  // Calculate day totals (Original Business Calculations strictly preserved)
  const salesEntries = entries.filter(e => e.rawType === 'SALE');
  const totalSales = salesEntries.reduce((sum, e) => sum + e.amount, 0);
  const cashSales = salesEntries
    .filter(e => (e.paymentMode || '').toUpperCase().includes('CASH'))
    .reduce((sum, e) => sum + e.amount, 0);
  const creditSales = salesEntries
    .filter(e => {
      const pm = (e.paymentMode || '').toUpperCase();
      return pm.includes('CREDIT') || pm.includes('KHATA') || pm.includes('DUE');
    })
    .reduce((sum, e) => sum + e.amount, 0);

  // Total Sales Exchange Net Amount
  const totalSalesExchangeAmount = exchangeDeskEntries.reduce((sum, ed) => sum + (Number(ed.netAmount) || 0), 0);

  // Gross Day Sales = Today Day Sales - Credit/Khata
  const grossDaySales = totalSales - creditSales;

  // Net Day Collection = Today Day Sales + Total Sales Exchange Amount
  const netDayCollection = totalSales + totalSalesExchangeAmount;

  const totalPurchases = entries.filter(e => e.rawType === 'PURCHASE').reduce((sum, e) => sum + e.amount, 0);
  const totalReceipts = entries.filter(e => e.rawType === 'RECEIPT').reduce((sum, e) => sum + e.amount, 0);
  const totalPayments = entries.filter(e => e.rawType === 'PAYMENT').reduce((sum, e) => sum + e.amount, 0);

  // Total Credit amount for filtered list
  const filteredCreditTotal = filteredEntries
    .filter(e => (e.paymentMode || '').toUpperCase().includes('CREDIT'))
    .reduce((sum, e) => sum + e.amount, 0);

  // Filter types metadata with counts
  const filterOptions = [
    { key: 'ALL', label: 'ALL' },
    { key: 'SALE', label: 'SALE' },
    { key: 'SALES_EXCHANGE_DESK', label: 'EXCHANGE DESK' },
    { key: 'SALES_EXCHANGE', label: 'SALES EXCHANGE' },
    { key: 'SALES_RETURN', label: 'SALES RETURN' },
    { key: 'PURCHASE', label: 'PURCHASE' },
    { key: 'PURCHASE_RETURN', label: 'PURCHASE RETURN' },
    { key: 'RECEIPT', label: 'RECEIPT' },
    { key: 'PAYMENT', label: 'PAYMENT' },
  ];

  // Visual Breakdown Calculations based only on existing data
  const totalSalesVolume = totalSales + Math.max(0, totalSalesExchangeAmount);
  const cashPercent = totalSalesVolume > 0 ? (cashSales / totalSalesVolume) * 100 : 0;
  const creditPercent = totalSalesVolume > 0 ? (creditSales / totalSalesVolume) * 100 : 0;
  const exchangePercent = totalSalesVolume > 0 ? (Math.max(0, totalSalesExchangeAmount) / totalSalesVolume) * 100 : 0;

  // Timezone-safe date shifting
  const shiftDate = (days: number) => {
    const [year, month, day] = selectedDate.split('-').map(Number);
    const d = new Date(year, month - 1, day);
    d.setDate(d.getDate() + days);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    setSelectedDate(`${yyyy}-${mm}-${dd}`);
  };

  const handleSetToday = () => {
    setSelectedDate(new Date().toISOString().split('T')[0]);
  };

  const formatDisplayDate = (dateStr: string): string => {
    if (!dateStr) return '';
    const [year, month, day] = dateStr.split('-').map(Number);
    const d = new Date(year, month - 1, day);
    return d.toLocaleDateString('en-IN', {
      weekday: 'short',
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  const handlePrint = () => {
    window.print();
  };

  // Professional Voucher Badge Helper
  const renderVoucherBadge = (rawType: string, voucherType: string) => {
    switch (rawType) {
      case 'SALE':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/80 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            {voucherType}
          </span>
        );
      case 'SALES_EXCHANGE_DESK':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200/80 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
            {voucherType}
          </span>
        );
      case 'SALES_EXCHANGE':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-orange-50 text-orange-800 border border-orange-200/80 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
            {voucherType}
          </span>
        );
      case 'SALES_RETURN':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-rose-50 text-rose-700 border border-rose-200/80 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
            {voucherType}
          </span>
        );
      case 'PURCHASE':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200/80 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
            {voucherType}
          </span>
        );
      case 'PURCHASE_RETURN':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-violet-50 text-violet-700 border border-violet-200/80 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-violet-500"></span>
            {voucherType}
          </span>
        );
      case 'RECEIPT':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-teal-50 text-teal-700 border border-teal-200/80 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
            {voucherType}
          </span>
        );
      case 'PAYMENT':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-red-50 text-red-700 border border-red-200/80 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500"></span>
            {voucherType}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 text-slate-700 border border-slate-200 whitespace-nowrap">
            {voucherType}
          </span>
        );
    }
  };

  // Compact Payment Method Badge Helper
  const renderMethodBadge = (method?: string) => {
    const m = (method || 'N/A').toUpperCase();
    if (m.includes('CASH')) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200/60 whitespace-nowrap">
          {method}
        </span>
      );
    }
    if (m.includes('CREDIT')) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-50 text-purple-800 border border-purple-200/60 whitespace-nowrap">
          {method}
        </span>
      );
    }
    if (m.includes('UPI')) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-800 border border-indigo-200/60 whitespace-nowrap">
          {method}
        </span>
      );
    }
    if (m.includes('BANK') || m.includes('CARD') || m.includes('NEFT') || m.includes('RTGS')) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-sky-50 text-sky-800 border border-sky-200/60 whitespace-nowrap">
          {method}
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-700 border border-slate-200/80 whitespace-nowrap">
        {method || 'N/A'}
      </span>
    );
  };

  return (
    <div id="daybook-page-root" className="daybook-page space-y-5 print:space-y-3">
      {/* ==================================================== */}
      {/* 1. TOP PAGE HEADER                                   */}
      {/* ==================================================== */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-4 sm:p-5 shadow-xs flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 print:hidden">
        {/* Left: Branding & Subtitle */}
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-amber-50 border border-amber-200/70 text-amber-700 flex items-center justify-center shadow-xs shrink-0">
            <BookOpen className="w-5 h-5 text-amber-700" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">DAY BOOK</h1>
              <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-200/80 uppercase tracking-wide">
                Register
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5 font-normal">
              Daily financial activity & transaction register
            </p>
          </div>
        </div>

        {/* Right: Date Picker with Nav & Print Ledger */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Quick Date Navigator */}
          <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg p-0.5">
            <button
              type="button"
              onClick={() => shiftDate(-1)}
              title="Previous Day"
              className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-white rounded transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleSetToday}
              className="px-2 py-1 text-[11px] font-bold text-slate-700 hover:text-slate-900 hover:bg-white rounded transition-colors"
            >
              Today
            </button>
            <button
              type="button"
              onClick={() => shiftDate(1)}
              title="Next Day"
              className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-white rounded transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Business Date Selector */}
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg shadow-xs hover:border-slate-300 transition-colors">
            <Calendar className="w-4 h-4 text-amber-600 shrink-0" />
            <div className="flex flex-col">
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider leading-none">Business Date</span>
              <input
                id="daybook-date-input"
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="bg-transparent text-xs font-bold text-slate-800 focus:outline-none cursor-pointer p-0 mt-0.5"
              />
            </div>
          </div>

          {/* Print Ledger Action Button */}
          <button
            id="daybook-print-ledger-btn"
            onClick={handlePrint}
            type="button"
            className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 active:bg-black text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all cursor-pointer whitespace-nowrap"
          >
            <Printer className="w-4 h-4" />
            <span>PRINT LEDGER</span>
          </button>
        </div>
      </div>

      {/* ==================================================== */}
      {/* 2. FINANCIAL SUMMARY METRIC CARDS (6-Grid)            */}
      {/* ==================================================== */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 print:grid-cols-3 print:gap-2">
        {/* Card 1: TODAY DAY SALES */}
        <div 
          id="card-today-day-sales"
          className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Today Day Sales</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 border border-emerald-200/70 text-emerald-700 flex items-center justify-center">
              <Store className="w-4 h-4 text-emerald-600" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold text-emerald-700 font-mono tracking-tight">
              ₹{totalSales.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="grid grid-cols-2 gap-1.5 pt-2 mt-2 border-t border-slate-100 text-[10px]">
              <div>
                <span className="text-slate-400 block font-medium">Cash</span>
                <span className="font-bold font-mono text-emerald-700">
                  ₹{cashSales.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">Credit</span>
                <span className="font-bold font-mono text-purple-700">
                  ₹{creditSales.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Card 2: CREDIT/KHATA (Sales made to credit customers today) */}
        <div 
          id="card-daybook-credit-khata"
          className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Credit/Khata</span>
            <div className="w-7 h-7 rounded-lg bg-purple-50 border border-purple-200/70 text-purple-700 flex items-center justify-center">
              <Users className="w-4 h-4 text-purple-600" />
            </div>
          </div>
          <div className="mt-2.5">
            <div className="text-xl font-bold text-purple-700 font-mono tracking-tight">
              ₹{creditSales.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
              Credit customer sales
            </div>
          </div>
        </div>

        {/* Card 3: GROSS DAY SALES (Today Day Sales - Credit/Khata) */}
        <div 
          id="card-gross-day-sales"
          className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Gross Day Sales</span>
            <div className="w-7 h-7 rounded-lg bg-teal-50 border border-teal-200/70 text-teal-700 flex items-center justify-center">
              <Wallet className="w-4 h-4 text-teal-600" />
            </div>
          </div>
          <div className="mt-2.5">
            <div className="text-xl font-bold text-teal-700 font-mono tracking-tight">
              ₹{grossDaySales.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
              Sales minus Credit/Khata
            </div>
          </div>
        </div>

        {/* Card 4: TOTAL SALES EXCHANGE AMOUNT */}
        <div 
          id="card-total-sales-exchange-amount"
          className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Sales Exchange</span>
            <div className="w-7 h-7 rounded-lg bg-amber-50 border border-amber-200/70 text-amber-700 flex items-center justify-center">
              <ArrowLeftRight className="w-4 h-4 text-amber-600" />
            </div>
          </div>
          <div className="mt-2">
            <div className={`text-xl font-bold font-mono tracking-tight ${totalSalesExchangeAmount >= 0 ? 'text-amber-800' : 'text-rose-700'}`}>
              ₹{totalSalesExchangeAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="grid grid-cols-2 gap-1.5 pt-2 mt-2 border-t border-slate-100 text-[10px]">
              <div>
                <span className="text-slate-400 block font-medium">Exchanges</span>
                <span className="font-bold font-mono text-amber-800">
                  {exchangeDeskEntries.length} {exchangeDeskEntries.length === 1 ? 'Desk' : 'Desks'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">Net Diff</span>
                <span className={`font-bold font-mono ${totalSalesExchangeAmount >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {totalSalesExchangeAmount > 0 
                    ? `+₹${totalSalesExchangeAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}` 
                    : `₹${totalSalesExchangeAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Card 5: PARTY PAYMENTS */}
        <div 
          id="card-total-payments"
          className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Party Payments</span>
            <div className="w-7 h-7 rounded-lg bg-rose-50 border border-rose-200/70 text-rose-700 flex items-center justify-center">
              <ArrowUpRight className="w-4 h-4 text-rose-600" />
            </div>
          </div>
          <div className="mt-2.5">
            <div className="text-xl font-bold text-rose-700 font-mono tracking-tight">
              ₹{totalPayments.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
              Outward disbursements
            </div>
          </div>
        </div>

        {/* Card 6: NET DAY COLLECTION (Highlighted Primary Metric) */}
        <div 
          id="card-net-day-collection"
          className="bg-white border-2 border-amber-300/80 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between ring-1 ring-amber-200/50"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black uppercase tracking-wider text-amber-800">Net Day Collection</span>
            <div className="w-7 h-7 rounded-lg bg-amber-100/90 text-amber-800 flex items-center justify-center font-bold">
              <Landmark className="w-4 h-4 text-amber-800" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-extrabold text-amber-900 font-mono tracking-tight">
              ₹{netDayCollection.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="grid grid-cols-2 gap-1.5 pt-2 mt-2 border-t border-amber-100 text-[10px]">
              <div>
                <span className="text-slate-400 block font-medium">Sales + Exch</span>
                <span className="font-bold font-mono text-slate-800 truncate block" title={`₹${totalSales.toFixed(2)} + ₹${totalSalesExchangeAmount.toFixed(2)}`}>
                  ₹{netDayCollection.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">Status</span>
                <span className="inline-flex items-center gap-1 font-bold text-emerald-700">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  Active
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ==================================================== */}
      {/* 3. VISUAL SALES SUMMARY (Progress Breakdown)         */}
      {/* ==================================================== */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs print:hidden">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-slate-600" />
            <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Today's Sales Breakdown</h2>
          </div>
          <span className="text-xs text-slate-500 font-medium">
            Effective Turn: <strong className="text-slate-900 font-mono">₹{totalSalesVolume.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</strong>
          </span>
        </div>

        {/* Horizontal Stacked Progress Bar */}
        <div className="w-full bg-slate-100 rounded-full h-3 flex overflow-hidden p-0.5 border border-slate-200">
          {cashPercent > 0 && (
            <div
              style={{ width: `${Math.max(4, cashPercent)}%` }}
              className="bg-emerald-500 h-full rounded-full transition-all duration-300"
              title={`Cash Sales: ${cashPercent.toFixed(1)}%`}
            />
          )}
          {creditPercent > 0 && (
            <div
              style={{ width: `${Math.max(4, creditPercent)}%` }}
              className="bg-purple-500 h-full rounded-full transition-all duration-300 mx-0.5"
              title={`Credit Sales: ${creditPercent.toFixed(1)}%`}
            />
          )}
          {exchangePercent > 0 && (
            <div
              style={{ width: `${Math.max(4, exchangePercent)}%` }}
              className="bg-amber-500 h-full rounded-full transition-all duration-300"
              title={`Sales Exchange: ${exchangePercent.toFixed(1)}%`}
            />
          )}
        </div>

        {/* Breakdown Indicators */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3 pt-2 text-xs">
          <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/70">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
              <span className="font-semibold text-slate-700">Cash Sales</span>
            </div>
            <div className="text-right font-mono">
              <span className="font-bold text-slate-900">₹{cashSales.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
              <span className="text-[10px] text-slate-500 ml-1.5">({cashPercent.toFixed(1)}%)</span>
            </div>
          </div>

          <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/70">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
              <span className="font-semibold text-slate-700">Credit Sales</span>
            </div>
            <div className="text-right font-mono">
              <span className="font-bold text-slate-900">₹{creditSales.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
              <span className="text-[10px] text-slate-500 ml-1.5">({creditPercent.toFixed(1)}%)</span>
            </div>
          </div>

          <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/70">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              <span className="font-semibold text-slate-700">Sales Exchange</span>
            </div>
            <div className="text-right font-mono">
              <span className="font-bold text-slate-900">₹{totalSalesExchangeAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
              <span className="text-[10px] text-slate-500 ml-1.5">({exchangeDeskEntries.length} desk)</span>
            </div>
          </div>
        </div>
      </div>

      {/* ==================================================== */}
      {/* 4. FILTER TOOLBAR & INSTANT REGISTER SEARCH          */}
      {/* ==================================================== */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs space-y-3 print:hidden">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          {/* Label + Filter chips */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500 uppercase tracking-wider shrink-0 pr-1">
              <Filter className="w-3.5 h-3.5 text-slate-500" />
              <span>TRANSACTION TYPE:</span>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              {filterOptions.map((opt) => {
                const count = opt.key === 'ALL' 
                  ? entries.length 
                  : entries.filter(e => e.rawType === opt.key).length;
                const isActive = filterType === opt.key;

                return (
                  <button
                    key={opt.key}
                    id={`daybook-filter-${opt.key.toLowerCase()}`}
                    type="button"
                    onClick={() => setFilterType(opt.key)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                      isActive
                        ? 'bg-slate-900 text-white shadow-xs'
                        : 'bg-slate-100/90 text-slate-600 hover:bg-slate-200/80 border border-slate-200/60'
                    }`}
                  >
                    <span>{opt.label}</span>
                    <span 
                      className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-normal ${
                        isActive ? 'bg-slate-800 text-slate-200' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick Filter Search Box */}
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search voucher, party, mobile..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-7 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white transition-colors"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ==================================================== */}
      {/* 5. PRINT HEADER (Visible only during window.print()) */}
      {/* ==================================================== */}
      <div className="hidden print:block mb-4 border-b-2 border-black pb-2 text-black">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-xl font-bold uppercase tracking-tight">{company.companyName || 'ARCO FOOTWEAR'}</h1>
            <p className="text-xs">{company.addressLine1} {company.addressLine2}, {company.city} - {company.pincode}</p>
            <p className="text-xs">GSTIN: {company.gstin} | Mobile: {company.mobile}</p>
          </div>
          <div className="text-right">
            <h2 className="text-base font-bold uppercase">DAY BOOK REGISTER</h2>
            <p className="text-xs font-mono font-bold">DATE: {formatDisplayDate(selectedDate)}</p>
            <p className="text-[10px] text-gray-600">Printed on: {new Date().toLocaleString('en-IN')}</p>
          </div>
        </div>

        {/* Print Summary Metrics Row */}
        <div className="grid grid-cols-6 gap-2 mt-3 pt-2 border-t border-gray-300 text-center text-xs">
          <div className="border border-gray-300 p-1">
            <div className="text-[9px] uppercase font-bold text-gray-600">Today Sales</div>
            <div className="font-bold font-mono">₹{totalSales.toFixed(2)}</div>
          </div>
          <div className="border border-gray-300 p-1">
            <div className="text-[9px] uppercase font-bold text-gray-600">Credit/Khata</div>
            <div className="font-bold font-mono">₹{creditSales.toFixed(2)}</div>
          </div>
          <div className="border border-gray-300 p-1">
            <div className="text-[9px] uppercase font-bold text-gray-600">Gross Day Sales</div>
            <div className="font-bold font-mono">₹{grossDaySales.toFixed(2)}</div>
          </div>
          <div className="border border-gray-300 p-1">
            <div className="text-[9px] uppercase font-bold text-gray-600">Sales Exchange</div>
            <div className="font-bold font-mono">₹{totalSalesExchangeAmount.toFixed(2)}</div>
          </div>
          <div className="border border-gray-300 p-1">
            <div className="text-[9px] uppercase font-bold text-gray-600">Party Payments</div>
            <div className="font-bold font-mono">₹{totalPayments.toFixed(2)}</div>
          </div>
          <div className="border border-black p-1 bg-gray-100">
            <div className="text-[9px] uppercase font-bold">Net Day Collection</div>
            <div className="font-bold font-mono">₹{netDayCollection.toFixed(2)}</div>
          </div>
        </div>
      </div>

      {/* ==================================================== */}
      {/* 6. TRANSACTION REGISTER TABLE                        */}
      {/* ==================================================== */}
      <div className="bg-white border border-slate-200/90 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold uppercase tracking-wider text-slate-600">
                <th className="py-3 px-3.5 w-24">Time</th>
                <th className="py-3 px-3.5">Voucher Class</th>
                <th className="py-3 px-3.5">Voucher No</th>
                <th className="py-3 px-3.5">Customer / Party Name</th>
                <th className="py-3 px-3.5">Mobile No</th>
                <th className="py-3 px-3.5 w-28">Method</th>
                <th className="py-3 px-3.5 text-right w-36">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredEntries.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 px-4 text-slate-500">
                    <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mb-3">
                      <FileText className="w-6 h-6" />
                    </div>
                    <p className="font-semibold text-slate-700 text-sm">No transactions recorded</p>
                    <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                      No vouchers found on {formatDisplayDate(selectedDate)} for the selected filter.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredEntries.map((e, idx) => {
                  return (
                    <tr
                      key={e.id || `${e.voucherNo}-${idx}`}
                      className="transition-colors hover:bg-amber-50/30 group"
                    >
                      {/* Time */}
                      <td className="py-3 px-3.5 font-mono text-xs text-slate-500 whitespace-nowrap">
                        {e.time}
                      </td>

                      {/* Voucher Class */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        {renderVoucherBadge(e.rawType, e.voucherType)}
                      </td>

                      {/* Voucher No */}
                      <td className="py-3 px-3.5 font-mono font-bold text-xs text-slate-900 whitespace-nowrap">
                        {e.voucherNo}
                      </td>

                      {/* Customer / Party Name */}
                      <td className="py-3 px-3.5 font-semibold text-xs text-slate-800">
                        {e.customerName}
                      </td>

                      {/* Customer Mobile */}
                      <td className="py-3 px-3.5 font-mono text-xs text-slate-500 whitespace-nowrap">
                        {e.customerMobile && e.customerMobile !== '-' ? (
                          <span>{e.customerMobile}</span>
                        ) : (
                          <span className="text-slate-300">-</span>
                        )}
                      </td>

                      {/* Method */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        {renderMethodBadge(e.paymentMode)}
                      </td>

                      {/* Amount */}
                      <td className="py-3 px-3.5 text-right font-mono font-bold text-xs tabular-nums whitespace-nowrap">
                        <span className={e.amount < 0 ? 'text-rose-600' : 'text-slate-900'}>
                          {e.amount < 0 ? '-' : ''}₹{Math.abs(e.amount).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>

            {/* ==================================================== */}
            {/* 7. TABLE FOOTER / TOTALS                             */}
            {/* ==================================================== */}
            {filteredEntries.length > 0 && (
              <tfoot>
                <tr className="border-t-2 border-slate-300 bg-slate-50/90 font-bold text-slate-800">
                  <td colSpan={5} className="py-3.5 px-3.5 text-right text-xs uppercase tracking-wider text-slate-500">
                    Filtered Book Total ({filteredEntries.length} entries):
                  </td>
                  <td className="py-3.5 px-3.5">
                    <div className="text-[11px] bg-purple-50 border border-purple-200 text-purple-800 px-2 py-1 rounded-md flex flex-col font-mono">
                      <span className="text-[9px] uppercase tracking-wider text-purple-600 font-sans font-semibold">Total Credit:</span>
                      <span className="font-bold">₹{filteredCreditTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-3.5 text-right text-base text-slate-900 font-black font-mono tabular-nums">
                    ₹{filteredEntries.reduce((sum, e) => sum + e.amount, 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      {/* Print Footer Signatures (Print Only) */}
      <div className="hidden print:flex justify-between items-center pt-10 text-xs font-semibold text-black">
        <div className="text-center">
          <div className="w-40 border-t border-black pt-1">Prepared By</div>
        </div>
        <div className="text-center">
          <div className="w-40 border-t border-black pt-1">Cashier / Accountant</div>
        </div>
        <div className="text-center">
          <div className="w-40 border-t border-black pt-1">Authorized Signatory</div>
        </div>
      </div>
    </div>
  );
};

