import { AdminUser, ModuleTab, UserPermissions, UserRole } from '../types';
import { authService } from './authService';

export type { UserRole, UserPermissions };
export const ROLE_PERMISSIONS: Record<UserRole, UserPermissions> = {
  'Super Admin': {
    canViewPurchasePrice: true,
    canAccessCompanySettings: true,
    canBackdateBills: true,
    canDeleteInvoices: true,
    canManageInventory: true,
    canCreatePurchases: true,
    canManageLedgers: true,
    canViewReports: true,
    canManageUsers: true,
    canExportBackup: true,
    canAccessAuditTrail: true,
    canAccessBackups: true,
  },
  'Administrator': {
    canViewPurchasePrice: true,
    canAccessCompanySettings: true,
    canBackdateBills: true,
    canDeleteInvoices: true,
    canManageInventory: true,
    canCreatePurchases: true,
    canManageLedgers: true,
    canViewReports: true,
    canManageUsers: true,
    canExportBackup: true,
    canAccessAuditTrail: true,
    canAccessBackups: true,
  },
  'Branch Admin': {
    canViewPurchasePrice: true,
    canAccessCompanySettings: false,
    canBackdateBills: true,
    canDeleteInvoices: false,
    canManageInventory: true,
    canCreatePurchases: true,
    canManageLedgers: true,
    canViewReports: true,
    canManageUsers: false,
    canExportBackup: false,
    canAccessAuditTrail: false,
    canAccessBackups: false,
  },
  'Store Manager': {
    canViewPurchasePrice: true,
    canAccessCompanySettings: false,
    canBackdateBills: false,
    canDeleteInvoices: false,
    canManageInventory: true,
    canCreatePurchases: true,
    canManageLedgers: true,
    canViewReports: true,
    canManageUsers: false,
    canExportBackup: false,
    canAccessAuditTrail: false,
    canAccessBackups: false,
  },
  'Billing Admin': {
    canViewPurchasePrice: true,
    canAccessCompanySettings: false,
    canBackdateBills: true,
    canDeleteInvoices: true,
    canManageInventory: false,
    canCreatePurchases: false,
    canManageLedgers: true,
    canViewReports: true,
    canManageUsers: false,
    canExportBackup: false,
    canAccessAuditTrail: false,
    canAccessBackups: false,
  },
  'Billing Operator': {
    canViewPurchasePrice: false,
    canAccessCompanySettings: false,
    canBackdateBills: false,
    canDeleteInvoices: false,
    canManageInventory: false,
    canCreatePurchases: false,
    canManageLedgers: true,
    canViewReports: false,
    canManageUsers: false,
    canExportBackup: false,
    canAccessAuditTrail: false,
    canAccessBackups: false,
  },
  'Cashier': {
    canViewPurchasePrice: false,
    canAccessCompanySettings: false,
    canBackdateBills: false,
    canDeleteInvoices: false,
    canManageInventory: false,
    canCreatePurchases: false,
    canManageLedgers: false,
    canViewReports: false,
    canManageUsers: false,
    canExportBackup: false,
    canAccessAuditTrail: false,
    canAccessBackups: false,
  },
};

export const ROLE_DESCRIPTIONS: Record<UserRole, { badge: string; color: string; desc: string }> = {
  'Super Admin': {
    badge: 'Super Admin',
    color: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    desc: 'Unrestricted master control. All permissions, company settings, user management, and cloud backups enabled.',
  },
  'Administrator': {
    badge: 'Administrator',
    color: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
    desc: 'Full administrative access to all ERP billing, stock, and settings modules.',
  },
  'Branch Admin': {
    badge: 'Branch Admin',
    color: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40',
    desc: 'Branch operational supervision covering transactions, stock, and customer accounts.',
  },
  'Store Manager': {
    badge: 'Store Manager',
    color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    desc: 'Retail floor and inventory management with purchase and ledger oversight. Company settings locked.',
  },
  'Billing Admin': {
    badge: 'Billing Admin',
    color: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
    desc: 'Advanced billing authority with back-dating rights and invoice management.',
  },
  'Billing Operator': {
    badge: 'Billing Operator',
    color: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
    desc: 'Standard counter and retail sales billing. Purchase prices masked, settings locked, back-dating disabled.',
  },
  'Cashier': {
    badge: 'Cashier',
    color: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
    desc: 'Quick retail checkout & receipt collection. Cost prices, back-dating, purchases, and settings restricted.',
  },
};

class RbacService {
  /**
   * Normalize various role string representations into valid UserRole
   */
  normalizeRole(roleStr: string): UserRole {
    if (!roleStr) return 'Super Admin';
    const clean = roleStr.toUpperCase().replace(/\s+|_/g, '');
    if (clean.includes('SUPER')) return 'Super Admin';
    if (clean.includes('BRANCH')) return 'Branch Admin';
    if (clean.includes('STORE') || clean.includes('WAREHOUSE')) return 'Store Manager';
    if (clean.includes('OPERATOR')) return 'Billing Operator';
    if (clean.includes('CASHIER')) return 'Cashier';
    if (clean.includes('BILLING') && clean.includes('ADMIN')) return 'Billing Admin';
    if (clean.includes('ADMIN')) return 'Administrator';
    return 'Administrator';
  }

  /**
   * Get effective permissions for a user, combining role defaults with any custom overrides
   */
  getPermissions(user?: AdminUser | null): UserPermissions {
    if (!user) {
      user = authService.getActiveAdmin();
    }
    const roleKey = this.normalizeRole(user?.role || 'Super Admin');
    const defaults = ROLE_PERMISSIONS[roleKey] || ROLE_PERMISSIONS['Super Admin'];

    if (user?.permissions) {
      return {
        ...defaults,
        ...user.permissions,
      };
    }
    return defaults;
  }

  /**
   * Check if the currently active user has a specific permission
   */
  can(permission: keyof UserPermissions): boolean {
    const user = authService.getActiveAdmin();
    const perms = this.getPermissions(user);
    return Boolean(perms[permission]);
  }

  /**
   * Check if current user is Super Admin
   */
  isSuperAdmin(): boolean {
    const user = authService.getActiveAdmin();
    return user?.role === 'Super Admin' || Boolean(user?.isPrimary);
  }

  /**
   * Get active user's role metadata
   */
  getActiveRoleInfo(): { role: UserRole; badge: string; color: string; desc: string } {
    const user = authService.getActiveAdmin();
    const roleKey = this.normalizeRole(user?.role || 'Super Admin');
    const info = ROLE_DESCRIPTIONS[roleKey] || ROLE_DESCRIPTIONS['Super Admin'];
    return {
      role: roleKey,
      ...info,
    };
  }

  /**
   * Get the required permission for a specific module tab (if restricted)
   */
  getRequiredPermissionForTab(tabId: ModuleTab): { permission: keyof UserPermissions; label: string } | null {
    switch (tabId) {
      case 'company_settings':
        return { permission: 'canAccessCompanySettings', label: 'Company Settings & Staff Roles' };
      case 'audit_logs':
        return { permission: 'canAccessAuditTrail', label: 'Audit Trail & Security Logs' };
      case 'backup_center':
        return { permission: 'canAccessBackups', label: 'Cloud Backups & Restore Center' };
      case 'purchase_entry':
        return { permission: 'canCreatePurchases', label: 'Inward Purchases Entry' };
      case 'bills':
        return { permission: 'canCreatePurchases', label: 'Supplier Bills & Purchases' };
      case 'purchase_return':
        return { permission: 'canCreatePurchases', label: 'Purchase Returns Register' };
      case 'supplier_master':
        return { permission: 'canCreatePurchases', label: 'Supplier Directory' };
      case 'supplier_payment':
        return { permission: 'canCreatePurchases', label: 'Supplier Payment Entries' };
      case 'supplier_ledger':
        return { permission: 'canManageLedgers', label: 'Supplier Accounts Ledger' };
      case 'customer_ledger':
        return { permission: 'canManageLedgers', label: 'Customer Accounts Ledger' };
      case 'cash_ledger':
        return { permission: 'canManageLedgers', label: 'Cash & Bank Register' };
      case 'day_book':
        return { permission: 'canViewReports', label: 'Daily Business Book & Ledger' };
      case 'gst_reports':
        return { permission: 'canViewReports', label: 'GST Tax Reports & GSTR Filings' };
      case 'stock_adjustment':
        return { permission: 'canManageInventory', label: 'Physical Stock Sheet & Adjustments' };
      default:
        return null;
    }
  }

  /**
   * Determine if the active user (or given user) is permitted to access a tab
   */
  canAccessTab(tabId: ModuleTab, user?: AdminUser | null): boolean {
    const req = this.getRequiredPermissionForTab(tabId);
    if (!req) return true; // Standard tabs accessible to all users
    const perms = this.getPermissions(user);
    return Boolean(perms[req.permission]);
  }

  /**
   * Format masked price for restricted users
   */
  formatMaskedPrice(price: number | undefined | null, canView: boolean): string {
    if (canView) {
      return price !== undefined && price !== null ? `₹${price.toFixed(2)}` : '₹0.00';
    }
    return '🔒 Restricted';
  }
}

export const rbacService = new RbacService();

