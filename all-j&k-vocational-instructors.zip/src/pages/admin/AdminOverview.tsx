import React, { useState } from 'react';
import {
  TrainingCenter,
  Instructor,
  Scheme,
  Contribution,
  Notice,
  ItiAggregatedData,
} from '../../types';
import { formatCurrency, formatNumber, formatDate } from '../../utils/format';
import {
  Building2,
  Users,
  Layers,
  IndianRupee,
  Target,
  TrendingUp,
  PlusCircle,
  Receipt,
  Bell,
  ArrowRight,
  ShieldCheck,
  Clock,
  AlertTriangle,
  Filter,
} from 'lucide-react';

interface AdminOverviewProps {
  trainingCenters: TrainingCenter[];
  instructors: Instructor[];
  schemes: Scheme[];
  contributions: Contribution[];
  notices: Notice[];
  targetAmount: number;
  aggregatedItis: ItiAggregatedData[];
  onSelectTab: (tab: string) => void;
}

export const AdminOverview: React.FC<AdminOverviewProps> = ({
  trainingCenters,
  instructors,
  schemes,
  contributions,
  notices,
  targetAmount,
  aggregatedItis,
  onSelectTab,
}) => {
  const [selectedSchemeId, setSelectedSchemeId] = useState<string>('all');

  const selectedScheme = schemes.find((s) => s.id === selectedSchemeId);

  // Filter contributions reactively based on scheme dropdown selection
  const filteredContributions =
    selectedSchemeId === 'all'
      ? contributions
      : contributions.filter(
          (c) => c.schemeId === selectedSchemeId || (selectedScheme && c.schemeName === selectedScheme.name)
        );

  const totalCollection = filteredContributions.reduce((acc, c) => acc + (c.amount || 0), 0);

  // Derive target amount for all schemes vs selected individual scheme
  const schemesTargetSum = schemes.reduce((acc, s) => acc + (s.targetAmount || 0), 0);
  const effectiveTarget =
    selectedSchemeId === 'all'
      ? schemesTargetSum > 0
        ? schemesTargetSum
        : targetAmount
      : selectedScheme?.targetAmount || 0;

  const progressPercent =
    effectiveTarget > 0 ? ((totalCollection / effectiveTarget) * 100).toFixed(1) : '0.0';

  const collectionSubtitle =
    selectedSchemeId === 'all'
      ? 'From All ITIs'
      : selectedScheme
      ? selectedScheme.name
      : 'Selected Scheme';

  const targetSubtitle =
    selectedSchemeId === 'all'
      ? 'Directorate Target'
      : selectedScheme
      ? `Target: ${selectedScheme.name}`
      : 'Scheme Target';

  const pendingInstructors = instructors.filter(
    (i) => i.approvalStatus === 'Pending' || i.approvalStatus === 'Pending Review (Awaiting Approval)'
  );

  const topContributingItis = [...aggregatedItis]
    .sort((a, b) => b.totalContribution - a.totalContribution)
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Pending Approvals Action Banner if any pending self-registrations */}
      {pendingInstructors.length > 0 && (
        <div className="bg-amber-500/10 border-2 border-amber-500 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center font-black shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-slate-900 uppercase">
                {pendingInstructors.length} New Instructor Registration{pendingInstructors.length > 1 ? 's' : ''} Awaiting Review
              </h3>
              <p className="text-xs text-slate-600">
                Self-registered instructors submitted their details through the public portal and require CPANEL verification before being listed publicly.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onSelectTab('pending-instructors')}
            className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs uppercase tracking-wider transition-colors shadow-xs shrink-0 cursor-pointer flex items-center gap-1.5"
          >
            <span>Review Registrations ({pendingInstructors.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Welcome Banner */}
      <div className="bg-[#0F2942] text-white p-6 rounded-xl border border-blue-900 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-amber-400 font-bold uppercase tracking-wider mb-1">
            <ShieldCheck className="w-4 h-4" />
            <span>Administrative Control Center</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black">
            DIRECTORATE CPANEL OVERVIEW
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            Live database management for Skill Development Employees, 50 Government ITIs, Schemes &amp; Remittances.
          </p>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <button
            type="button"
            onClick={() => onSelectTab('add-training-center')}
            className="px-3.5 py-2 rounded-lg bg-[#0F2942] hover:bg-[#183d63] text-amber-400 font-bold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Building2 className="w-4 h-4" />
            <span>Add Training Center</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('contributions')}
            className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Record Contribution</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('instructors')}
            className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add Instructor</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('notices')}
            className="px-3.5 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Bell className="w-4 h-4" />
            <span>Publish Notice</span>
          </button>
        </div>
      </div>

      {/* Scheme Dropdown Selector & Metric Cards Grid */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Live Remittance &amp; Institutional Analytics
            </span>
          </div>

          <div className="flex items-center gap-2">
            <label htmlFor="overview-scheme-filter" className="text-xs font-bold text-slate-700 flex items-center gap-1.5 whitespace-nowrap">
              <Layers className="w-4 h-4 text-amber-600" />
              <span>Scheme:</span>
            </label>
            <select
              id="overview-scheme-filter"
              value={selectedSchemeId}
              onChange={(e) => setSelectedSchemeId(e.target.value)}
              className="text-xs font-bold bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-sky-500 cursor-pointer min-w-[220px]"
            >
              <option value="all">All Schemes (Consolidated)</option>
              {schemes.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} {s.targetAmount > 0 ? `(Target: ${formatCurrency(s.targetAmount)})` : ''}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] uppercase font-bold text-slate-500 block">Total ITIs</span>
            <div className="text-2xl font-black text-slate-900 mt-1">{trainingCenters.length}</div>
            <span className="text-[10px] text-blue-600 font-semibold mt-1 block">Registered ITIs</span>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] uppercase font-bold text-slate-500 block">Employees</span>
            <div className="text-2xl font-black text-indigo-900 mt-1">{instructors.length}</div>
            <span className="text-[10px] text-indigo-600 font-semibold mt-1 block">
              {instructors.filter((i) => i.status === 'Active').length} Active
            </span>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] uppercase font-bold text-slate-500 block">Schemes</span>
            <div className="text-2xl font-black text-amber-900 mt-1">{schemes.length}</div>
            <span className="text-[10px] text-amber-600 font-semibold mt-1 block truncate">
              {selectedSchemeId === 'all' ? 'All Configured' : (selectedScheme?.name || '1 Selected')}
            </span>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] uppercase font-bold text-slate-500 block">Total Collection</span>
            <div className="text-xl font-black text-emerald-700 mt-1 font-mono">
              {formatCurrency(totalCollection)}
            </div>
            <span className="text-[10px] text-emerald-600 font-semibold mt-1 block truncate" title={collectionSubtitle}>
              {collectionSubtitle}
            </span>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] uppercase font-bold text-slate-500 block">Target Amount</span>
            <div className="text-xl font-black text-sky-800 mt-1 font-mono">
              {formatCurrency(effectiveTarget)}
            </div>
            <span className="text-[10px] text-sky-600 font-semibold mt-1 block truncate" title={targetSubtitle}>
              {targetSubtitle}
            </span>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] uppercase font-bold text-slate-500 block">Collection Progress</span>
            <div className="text-2xl font-black text-purple-900 mt-1">{progressPercent}%</div>
            <span className="text-[10px] text-purple-600 font-semibold mt-1 block">Achieved</span>
          </div>
        </div>
      </div>

      {/* Grid: Top Contributing ITIs & Latest Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top ITIs */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-xs sm:text-sm font-black text-[#0F2942] uppercase tracking-wide">
              TOP CONTRIBUTING ITIs
            </h3>
            <button
              type="button"
              onClick={() => onSelectTab('reports')}
              className="text-xs font-bold text-blue-700 hover:underline flex items-center gap-1"
            >
              <span>View Report</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="divide-y divide-slate-100 mt-2">
            {topContributingItis.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-500">
                No training center records found in the database.
              </div>
            ) : (
              topContributingItis.map((iti, idx) => (
                <div key={iti.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-600 font-bold flex items-center justify-center text-[10px]">
                      {idx + 1}
                    </span>
                    <div>
                      <span className="font-bold text-slate-900 block">{iti.name}</span>
                      <span className="text-[10px] text-slate-600">{iti.division} &bull; {iti.calculatedInstructorCount} Instructors</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold text-emerald-700 block">
                      {formatCurrency(iti.totalContribution)}
                    </span>
                    <span className="text-[10px] text-slate-600">
                      {iti.lastContributionDate ? formatDate(iti.lastContributionDate) : 'No remittances'}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Contributions in Admin */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-xs sm:text-sm font-black text-[#0F2942] uppercase tracking-wide">
              LATEST REMITTANCE ENTRIES
            </h3>
            <button
              type="button"
              onClick={() => onSelectTab('contributions')}
              className="text-xs font-bold text-blue-700 hover:underline flex items-center gap-1"
            >
              <span>Manage All ({contributions.length})</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="divide-y divide-slate-100 mt-2">
            {contributions.slice(0, 5).length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-500">
                No contribution transactions recorded yet. Click "Record Contribution" above.
              </div>
            ) : (
              contributions.slice(0, 5).map((c) => (
                <div key={c.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-900 block">{c.itiName}</span>
                    <span className="text-[10px] text-slate-600">
                      {c.schemeName} &bull; Ref: {c.receiptNumber || 'N/A'}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold text-emerald-700 block">
                      {formatCurrency(c.amount)}
                    </span>
                    <span className="text-[10px] text-slate-600 font-mono">
                      {formatDate(c.contributionDate)}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
