/**
 * Reliable, high-precision print helper service for web and thermal POS printing.
 * Eliminates print layout inconsistencies and blank first-attempts by ensuring all 
 * stylesheets, web fonts, and images (e.g. store logos, UPI QR codes) are 100% loaded
 * inside the print context before invoking the browser print dialog.
 */

export interface PrintOptions {
  elementId?: string;
  element?: HTMLElement | null;
  format?: 'A4' | 'Thermal80' | 'Thermal70';
  customCss?: string;
  title?: string;
  onBeforePrint?: () => void;
  onAfterPrint?: () => void;
}

export async function printElement(options: PrintOptions): Promise<void> {
  const { elementId, element: providedElement, format = 'A4', customCss = '', title = 'Print Document' } = options;
  const targetEl = providedElement || (elementId ? document.getElementById(elementId) : null);

  if (!targetEl) {
    console.warn('[PrintService] Printable element not found, falling back to standard window.print()');
    window.print();
    return;
  }

  // Remove any stale print frame
  const iframeId = 'arco-app-print-frame';
  const existingFrame = document.getElementById(iframeId);
  if (existingFrame) {
    existingFrame.remove();
  }

  // Create clean hidden iframe
  const iframe = document.createElement('iframe');
  iframe.id = iframeId;
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0px';
  iframe.style.height = '0px';
  iframe.style.border = 'none';
  iframe.style.opacity = '0';
  iframe.style.pointerEvents = 'none';
  iframe.style.zIndex = '-9999';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document || iframe.contentDocument;
  if (!doc) {
    window.print();
    return;
  }

  // Extract all stylesheet links and inline style tags from parent document
  const headLinks = Array.from(document.querySelectorAll('link[rel="stylesheet"], style'))
    .map((el) => el.outerHTML)
    .join('\n');

  // Format specific layout CSS
  let formatPageCss = '';
  if (format === 'Thermal70') {
    formatPageCss = `
      @page { size: 70mm auto; margin: 2mm 0mm 0mm 0mm; }
      html, body {
        width: 70mm !important;
        max-width: 70mm !important;
        margin: 0 !important;
        margin-top: 2mm !important;
        margin-right: 0mm !important;
        padding: 2mm 0 0 0 !important;
        overflow-x: hidden !important;
        text-align: left !important;
        font-family: monospace, 'Courier New', Courier, monospace !important;
        font-weight: 700 !important;
        font-size: 11px !important;
        background: #ffffff !important;
        color: #000000 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      * {
        box-sizing: border-box !important;
      }
      .print-container,
      .thermal-70mm-slip,
      #thermal-70mm-print-slip,
      #thermal-70mm-register-slip,
      #thermal-70mm-ledger-slip {
        width: 70mm !important;
        max-width: 70mm !important;
        margin: 0 !important;
        margin-top: 2mm !important;
        margin-right: 0mm !important;
        padding-top: 2mm !important;
        padding-right: 0mm !important;
        padding-bottom: 0 !important;
        padding-left: 0 !important;
        overflow: hidden !important;
        box-sizing: border-box !important;
        border: none !important;
        box-shadow: none !important;
        background-color: #ffffff !important;
        color: #000000 !important;
      }
      .thermal-70mm-slip,
      .thermal-70mm-slip * {
        background-color: #ffffff !important;
        color: #000000 !important;
        font-weight: 700 !important;
      }
      div, table, tr, td, th, p, span {
        box-sizing: border-box !important;
        max-width: 100% !important;
      }
      table {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border-collapse: collapse !important;
        margin: 4px 0 !important;
      }
      td, th {
        box-sizing: border-box !important;
        overflow-wrap: break-word !important;
        word-break: break-word !important;
      }
    `;
  } else if (format === 'Thermal80') {
    formatPageCss = `
      @page { size: 80mm auto; margin: 2mm 0mm 0mm 0mm; }
      html, body {
        width: 80mm !important;
        max-width: 80mm !important;
        margin: 0 !important;
        margin-top: 2mm !important;
        margin-right: 0mm !important;
        padding: 2mm 0 0 0 !important;
        overflow-x: hidden !important;
        text-align: left !important;
        font-family: monospace, 'Courier New', Courier, monospace !important;
        font-weight: 700 !important;
        font-size: 12px !important;
        background: #ffffff !important;
        color: #000000 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      * {
        box-sizing: border-box !important;
      }
      .print-container,
      .thermal-80mm-slip,
      #thermal-80mm-print-slip,
      #thermal-80mm-register-slip,
      #thermal-80mm-ledger-slip {
        width: 80mm !important;
        max-width: 80mm !important;
        margin: 0 !important;
        margin-top: 2mm !important;
        margin-right: 0mm !important;
        padding-top: 2mm !important;
        padding-right: 0mm !important;
        padding-bottom: 0 !important;
        padding-left: 0 !important;
        overflow: hidden !important;
        box-sizing: border-box !important;
        border: none !important;
        box-shadow: none !important;
        background-color: #ffffff !important;
        color: #000000 !important;
      }
      .thermal-80mm-slip,
      .thermal-80mm-slip * {
        background-color: #ffffff !important;
        color: #000000 !important;
        font-weight: 700 !important;
      }
      div, table, tr, td, th, p, span {
        box-sizing: border-box !important;
        max-width: 100% !important;
      }
      table {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border-collapse: collapse !important;
        margin: 4px 0 !important;
      }
      td, th {
        box-sizing: border-box !important;
        overflow-wrap: break-word !important;
        word-break: break-word !important;
      }
    `;
  } else {
    formatPageCss = `
      @page { size: A4 portrait; margin: 6mm; }
      html, body {
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
        background: #ffffff !important;
        color: #000000 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      * {
        box-sizing: border-box !important;
      }
    `;
  }

  const htmlContent = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>${title}</title>
        ${headLinks}
        <style>
          ${formatPageCss}
          ${customCss}
          body {
            background: #ffffff !important;
            color: #000000 !important;
            visibility: visible !important;
          }
          .no-print, .print\\:hidden {
            display: none !important;
          }
        </style>
      </head>
      <body>
        ${targetEl.innerHTML}
      </body>
    </html>
  `;

  doc.open();
  doc.write(htmlContent);
  doc.close();

  // Promise-based readiness wait:
  // 1. Wait for document ready
  // 2. Wait for all <img> tags inside the iframe to load (or fail gracefully)
  // 3. Wait for web fonts
  const waitForImages = new Promise<void>((resolve) => {
    const images = Array.from(doc.images);
    const pendingImages = images.filter((img) => !img.complete);

    if (pendingImages.length === 0) {
      resolve();
      return;
    }

    let resolvedCount = 0;
    const checkComplete = () => {
      resolvedCount++;
      if (resolvedCount >= pendingImages.length) {
        resolve();
      }
    };

    pendingImages.forEach((img) => {
      img.onload = checkComplete;
      img.onerror = checkComplete;
    });
  });

  const waitForFonts = new Promise<void>((resolve) => {
    if ((doc as any).fonts && (doc as any).fonts.ready) {
      (doc as any).fonts.ready.then(() => resolve()).catch(() => resolve());
    } else {
      resolve();
    }
  });

  // Maximum safety timeout of 1000ms to guarantee non-blocking print
  const timeoutGuard = new Promise<void>((resolve) => {
    setTimeout(resolve, 1000);
  });

  await Promise.race([Promise.all([waitForImages, waitForFonts]), timeoutGuard]);

  // Small 120ms layout buffer to let browser finish repaint and reflow
  await new Promise((r) => setTimeout(r, 120));

  options.onBeforePrint?.();

  try {
    iframe.contentWindow?.focus();
    iframe.contentWindow?.print();
  } catch (err) {
    console.error('[PrintService] Iframe print failed, falling back to window.print():', err);
    window.print();
  }

  options.onAfterPrint?.();
}
