import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  getDoc,
  getDocs,
  onSnapshot,
  writeBatch,
} from 'firebase/firestore';
import {
  db,
  defaultDb,
  syncDocToFirestore,
  syncDeleteFromFirestore,
  BACKEND_DETAILS,
} from '../firebase';
import { getApiUrl } from './apiConfig';
import {
  CompanyInfo,
  Customer,
  CustomerCreditTransaction,
  CustomerReceipt,
  InvoiceItem,
  InvoiceReturnStatus,
  Item,
  PurchasedStockItem,
  LedgerEntry,
  MigrationSummary,
  PurchaseInvoice,
  PurchaseReturn,
  ReturnedItemLine,
  SalesExchange,
  SalesExchangeDeskRecord,
  SalesInvoice,
  SalesReturn,
  StockAdjustment,
  StockMovement,
  Supplier,
  SupplierPayment,
  SecurityAuthSettings,
} from '../types';
import { auditService } from './auditService';
import {
  INITIAL_COMPANY,
  INITIAL_CUSTOMERS,
  INITIAL_ITEMS,
  INITIAL_LEDGERS,
  INITIAL_PURCHASES,
  INITIAL_SALES,
  INITIAL_SUPPLIERS,
} from '../data/initialData';
import { roundTo2 } from './gstCalculations';

export const INITIAL_SECURITY: SecurityAuthSettings = {
  email: 'arcoshoesco@gmail.com',
  password: 'admin123',
  securityQuestion: 'What is your registered shop brand name?',
  securityAnswer: 'ARCO SHOES',
  recoveryPin: '7860',
  lastChangedAt: new Date().toISOString(),
};

const FIREBASE_STORAGE_KEYS = {
  COMPANY: 'arco_firebase_company_v2',
  ITEMS: 'arco_firebase_items_v2',
  CUSTOMERS: 'arco_firebase_customers_v2',
  SUPPLIERS: 'arco_firebase_suppliers_v2',
  SALES: 'arco_firebase_sales_v2',
  SALES_RETURNS: 'arco_firebase_sales_returns_v2',
  SALES_EXCHANGES: 'arco_firebase_sales_exchanges_v2',
  SALES_EXCHANGE_DESK: 'arco_firebase_sales_exchange_desk_v2',
  STOCK_MOVEMENTS: 'arco_firebase_stock_movements_v2',
  CUSTOMER_CREDIT_TXNS: 'arco_firebase_customer_credit_txns_v2',
  PURCHASES: 'arco_firebase_purchases_v2',
  PURCHASE_RETURNS: 'arco_firebase_purchase_returns_v2',
  RECEIPTS: 'arco_firebase_receipts_v2',
  CUSTOMER_RECEIPTS: 'arco_firebase_customer_receipts_v2',
  PAYMENTS: 'arco_firebase_payments_v2',
  ADJUSTMENTS: 'arco_firebase_adjustments_v2',
  LEDGERS: 'arco_firebase_ledgers_v2',
  CLEARED_DEMO: 'arco_demo_cleared_flag_v2',
  SECURITY: 'arco_security_auth_v2',
  AUTH_SESSION: 'arco_auth_session_v2',
};

const MONGODB_STORAGE_KEYS = {
  COMPANY: 'arco_firebase_company_v2',
  ITEMS: 'arco_mongodb_items_v2',
  CUSTOMERS: 'arco_mongodb_customers_v2',
  SUPPLIERS: 'arco_mongodb_suppliers_v2',
  SALES: 'arco_mongodb_sales_v2',
  SALES_RETURNS: 'arco_mongodb_sales_returns_v2',
  SALES_EXCHANGES: 'arco_mongodb_sales_exchanges_v2',
  SALES_EXCHANGE_DESK: 'arco_mongodb_sales_exchange_desk_v2',
  STOCK_MOVEMENTS: 'arco_mongodb_stock_movements_v2',
  CUSTOMER_CREDIT_TXNS: 'arco_mongodb_customer_credit_txns_v2',
  PURCHASES: 'arco_mongodb_purchases_v2',
  PURCHASE_RETURNS: 'arco_mongodb_purchase_returns_v2',
  RECEIPTS: 'arco_mongodb_receipts_v2',
  CUSTOMER_RECEIPTS: 'arco_mongodb_customer_receipts_v2',
  PAYMENTS: 'arco_mongodb_payments_v2',
  ADJUSTMENTS: 'arco_mongodb_adjustments_v2',
  LEDGERS: 'arco_mongodb_ledgers_v2',
  CLEARED_DEMO: 'arco_mongodb_demo_cleared_flag_v2',
  SECURITY: 'arco_security_auth_v2',
  AUTH_SESSION: 'arco_auth_session_v2',
};

// Legacy fallback compatibility
const STORAGE_KEYS = FIREBASE_STORAGE_KEYS;

// Firestore Collection Names
const COLLECTIONS = {
  SETTINGS: 'settings',
  ITEMS: 'items',
  CUSTOMERS: 'customers',
  SUPPLIERS: 'suppliers',
  SALES: 'sales_invoices',
  SALES_RETURNS: 'sales_returns',
  SALES_EXCHANGES: 'sales_exchanges',
  SALES_EXCHANGE_DESK: 'sales_exchange_desk',
  STOCK_MOVEMENTS: 'stock_movements',
  CUSTOMER_CREDIT_TXNS: 'customer_credit_transactions',
  PURCHASES: 'purchase_invoices',
  PURCHASE_RETURNS: 'purchase_returns',
  RECEIPTS: 'receipts',
  CUSTOMER_RECEIPTS: 'customer_receipts',
  PAYMENTS: 'payments',
  ADJUSTMENTS: 'stock_adjustments',
  LEDGERS: 'ledgers',
};

/**
 * Deeply removes undefined fields from objects and arrays so Firestore never rejects payloads.
 */
export function sanitizeForFirestore<T>(data: T): T {
  if (data === null || data === undefined) {
    return null as unknown as T;
  }
  if (Array.isArray(data)) {
    return data.map((item) => sanitizeForFirestore(item)) as unknown as T;
  }
  if (typeof data === 'object') {
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(data as Record<string, any>)) {
      if (value !== undefined) {
        cleaned[key] = sanitizeForFirestore(value);
      }
    }
    return cleaned as T;
  }
  return data;
}

type ChangeListener = () => void;

class DBStorageService {
  private listeners: Set<ChangeListener> = new Set();
  private deletedIds: Set<string> = new Set();
  public isFirestoreConnected = true;
  public lastSyncTime: Date = new Date();

  private memoryCache: Map<string, any> = new Map();
  private cachedCompany: CompanyInfo | null = null;
  private isNotifyPending = false;

  private initDeletedIds(): void {
    try {
      const raw = localStorage.getItem('arco_deleted_record_ids_v2');
      if (raw) {
        const arr = JSON.parse(raw);
        if (Array.isArray(arr)) {
          this.deletedIds = new Set(arr.map((id) => String(id).trim()));
        }
      }
    } catch {
      this.deletedIds = new Set();
    }
  }

  private persistDeletedIds(): void {
    try {
      localStorage.setItem('arco_deleted_record_ids_v2', JSON.stringify(Array.from(this.deletedIds)));
    } catch (e) {
      console.warn('Failed to persist deletedIds:', e);
    }
  }

  public markAsDeleted(...ids: (string | undefined | null)[]): void {
    let changed = false;
    for (const id of ids) {
      if (id && typeof id === 'string' && id.trim()) {
        const trimmed = id.trim();
        if (!this.deletedIds.has(trimmed)) {
          this.deletedIds.add(trimmed);
          changed = true;
        }
        const upper = trimmed.toUpperCase();
        if (!this.deletedIds.has(upper)) {
          this.deletedIds.add(upper);
          changed = true;
        }
      }
    }
    if (changed) {
      this.persistDeletedIds();
    }
  }

  public unmarkAsDeleted(...ids: (string | undefined | null)[]): void {
    let changed = false;
    for (const id of ids) {
      if (id && typeof id === 'string' && id.trim()) {
        const trimmed = id.trim();
        if (this.deletedIds.delete(trimmed)) changed = true;
        if (this.deletedIds.delete(trimmed.toUpperCase())) changed = true;
        if (this.deletedIds.delete(trimmed.toLowerCase())) changed = true;
      }
    }
    if (changed) {
      this.persistDeletedIds();
    }
  }

  public isDeleted(idOrCode?: string | null): boolean {
    if (!idOrCode || typeof idOrCode !== 'string') return false;
    const trimmed = idOrCode.trim();
    return this.deletedIds.has(trimmed) || this.deletedIds.has(trimmed.toUpperCase());
  }

  public clearMemoryCache(): void {
    this.memoryCache.clear();
    this.cachedCompany = null;
  }

  public getActiveDatabaseType(): 'firebase' | 'mongodb' {
    const company = this.getCompany();
    return company?.databaseType === 'mongodb' ? 'mongodb' : 'firebase';
  }

  private getKey(keyName: keyof typeof FIREBASE_STORAGE_KEYS): string {
    const dbType = this.getActiveDatabaseType();
    return dbType === 'mongodb' ? MONGODB_STORAGE_KEYS[keyName] : FIREBASE_STORAGE_KEYS[keyName];
  }

  private getLocalData<T>(keyName: keyof typeof FIREBASE_STORAGE_KEYS, defaultValue: T): T {
    const key = this.getKey(keyName);
    if (this.memoryCache.has(key)) {
      return this.memoryCache.get(key) as T;
    }
    try {
      const data = localStorage.getItem(key);
      if (!data) return defaultValue;
      const parsed = JSON.parse(data) as T;
      this.memoryCache.set(key, parsed);
      return parsed;
    } catch {
      return defaultValue;
    }
  }

  private setLocalData(keyName: keyof typeof FIREBASE_STORAGE_KEYS, data: any): string {
    const key = this.getKey(keyName);
    this.memoryCache.set(key, data);
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error('localStorage set error for', key, e);
    }
    return key;
  }

  public getMongoConfig(): { uri: string; dbName: string } {
    const company = this.getCompany();
    return {
      uri: company.mongoUri || 'mongodb://127.0.0.1:27017',
      dbName: company.mongoDbName || 'arco_shoes_db',
    };
  }

  private async safeSyncDocToFirestore(collectionName: string, docId: string, data: any): Promise<void> {
    const dbType = this.getActiveDatabaseType();
    if (dbType === 'firebase') {
      return syncDocToFirestore(collectionName, docId, data);
    } else if (dbType === 'mongodb') {
      const { uri, dbName } = this.getMongoConfig();
      try {
        await fetch(getApiUrl('/api/mongodb/sync-doc'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mongoUri: uri,
            dbName,
            collectionName,
            docId,
            data,
          }),
        });
      } catch (err) {
        console.warn(`[MongoDB Sync Error] ${collectionName}:`, err);
      }
    }
  }

  private async safeSyncDeleteFromFirestore(collectionName: string, docId: string): Promise<void> {
    const dbType = this.getActiveDatabaseType();
    if (dbType === 'firebase') {
      return syncDeleteFromFirestore(collectionName, docId);
    } else if (dbType === 'mongodb') {
      const { uri, dbName } = this.getMongoConfig();
      try {
        await fetch(getApiUrl('/api/mongodb/delete-doc'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mongoUri: uri,
            dbName,
            collectionName,
            id: docId,
          }),
        });
      } catch (err) {
        console.warn(`[MongoDB Delete Error] ${collectionName}:`, err);
      }
    }
  }

  public async fetchAllDataFromMongo(): Promise<void> {
    if (this.getActiveDatabaseType() !== 'mongodb') return;
    const { uri, dbName } = this.getMongoConfig();
    try {
      const res = await fetch(getApiUrl('/api/mongodb/get-app-data'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mongoUri: uri, dbName }),
      });
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        console.warn('[MongoDB Fetch All Data] Backend returned non-JSON response.');
        return;
      }
      const result = await res.json();
      if (result.success && result.data) {
        const data = result.data;

        // Populate local memory cache with MongoDB records (filtering out any permanently deleted IDs)
        if (Array.isArray(data.items)) {
          const validItems = data.items.filter((itm: any) => itm && !this.isDeleted(itm.id) && !this.isDeleted(itm.itemCode));
          this.setLocalData('ITEMS', validItems);
        }

        if (Array.isArray(data.customers)) {
          const validCusts = data.customers.filter((c: any) => c && !this.isDeleted(c.id));
          this.setLocalData('CUSTOMERS', validCusts);
        }

        if (Array.isArray(data.suppliers)) {
          const validSups = data.suppliers.filter((s: any) => s && !this.isDeleted(s.id));
          this.setLocalData('SUPPLIERS', validSups);
        }

        if (Array.isArray(data.sales)) {
          const validSales = data.sales.filter((s: any) => s && !this.isDeleted(s.id) && !this.isDeleted(s.invoiceNo));
          this.setLocalData('SALES', validSales);
        }
        if (Array.isArray(data.purchases)) {
          const validPurchases = data.purchases.filter((p: any) => p && !this.isDeleted(p.id) && !this.isDeleted(p.purchaseNo) && !this.isDeleted(p.purchaseInvoiceNo));
          this.setLocalData('PURCHASES', validPurchases);
        }
        if (Array.isArray(data.sales_returns)) {
          const validReturns = data.sales_returns.filter((r: any) => r && !this.isDeleted(r.id) && !this.isDeleted(r.returnNo));
          this.setLocalData('SALES_RETURNS', validReturns);
        }
        if (Array.isArray(data.purchase_returns)) {
          const validPRs = data.purchase_returns.filter((pr: any) => pr && !this.isDeleted(pr.id) && !this.isDeleted(pr.returnNo));
          this.setLocalData('PURCHASE_RETURNS', validPRs);
        }
        if (Array.isArray(data.customer_receipts)) {
          const validRecs = data.customer_receipts.filter((r: any) => r && !this.isDeleted(r.id) && !this.isDeleted(r.receiptNo));
          this.setLocalData('CUSTOMER_RECEIPTS', validRecs);
        } else if (Array.isArray(data.receipts)) {
          const validRecs = data.receipts.filter((r: any) => r && !this.isDeleted(r.id) && !this.isDeleted(r.receiptNo));
          this.setLocalData('CUSTOMER_RECEIPTS', validRecs);
        }
        if (Array.isArray(data.payments)) {
          const validPays = data.payments.filter((p: any) => p && !this.isDeleted(p.id) && !this.isDeleted(p.voucherNo));
          this.setLocalData('PAYMENTS', validPays);
        }
        if (Array.isArray(data.adjustments)) {
          const validAdjs = data.adjustments.filter((a: any) => a && !this.isDeleted(a.id));
          this.setLocalData('ADJUSTMENTS', validAdjs);
        }
        if (Array.isArray(data.exchanges)) {
          const validExchanges = data.exchanges.filter((e: any) => e && !this.isDeleted(e.id) && !this.isDeleted(e.exchangeNo));
          this.setLocalData('SALES_EXCHANGES', validExchanges);
        }
        if (Array.isArray(data.exchange_desk)) {
          const validDesk = data.exchange_desk.filter((d: any) => d && !this.isDeleted(d.id));
          this.setLocalData('SALES_EXCHANGE_DESK', validDesk);
        }
        if (Array.isArray(data.movements)) {
          const validMovements = data.movements.filter((m: any) => m && !this.isDeleted(m.id));
          this.setLocalData('STOCK_MOVEMENTS', validMovements);
        }
        if (Array.isArray(data.credit_txns)) {
          const validCredit = data.credit_txns.filter((c: any) => c && !this.isDeleted(c.id));
          this.setLocalData('CUSTOMER_CREDIT_TXNS', validCredit);
        }
        if (Array.isArray(data.ledgers)) {
          const validLedgers = data.ledgers.filter((l: any) => l && !this.isDeleted(l.id));
          this.setLocalData('LEDGERS', validLedgers);
        }
        if (data.security) {
          this.setLocalData('SECURITY', data.security);
        }

        this.notify();
      }
    } catch (err) {
      console.warn('[MongoDB Fetch All Data Error]:', err);
    }
  }

  constructor() {
    this.initDeletedIds();
    this.initDatabase();
    if (this.getActiveDatabaseType() === 'mongodb') {
      this.fetchAllDataFromMongo().catch((err) => console.warn('Initial MongoDB fetch:', err));
    } else {
      this.initFirestoreRealtimeListeners();
      this.fetchAllDataFromFirestore().catch((err) => console.warn('Initial Firestore fetch:', err));
    }
  }

  // Subscribe to changes (for React components to auto re-render on remote or local updates)
  subscribe(callback: ChangeListener): () => void {
    this.listeners.add(callback);
    return () => {
      this.listeners.delete(callback);
    };
  }

  private notify() {
    this.persistDeletedIds();
    this.lastSyncTime = new Date();
    if (this.isNotifyPending) return;
    this.isNotifyPending = true;
    queueMicrotask(() => {
      this.isNotifyPending = false;
      this.listeners.forEach((cb) => {
        try {
          cb();
        } catch (err) {
          console.error('Error in storage subscriber:', err);
        }
      });
    });
  }

  // Initialize and clean legacy obsolete keys without ever wiping active database
  private initDatabase() {
    try {
      localStorage.removeItem('vb6_gst_items_v1');
      localStorage.removeItem('vb6_gst_customers_v1');
      localStorage.removeItem('vb6_gst_suppliers_v1');
      localStorage.removeItem('vb6_gst_sales_v1');
      localStorage.removeItem('vb6_gst_sales_returns_v1');
      localStorage.removeItem('vb6_gst_purchases_v1');
      localStorage.removeItem('vb6_gst_purchase_returns_v1');
      localStorage.removeItem('vb6_gst_receipts_v1');
      localStorage.removeItem('vb6_gst_payments_v1');
      localStorage.removeItem('vb6_gst_adjustments_v1');
      localStorage.removeItem('vb6_gst_ledgers_v1');
    } catch {
      // Storage unavailable
    }
  }

  // Set up live Firestore real-time synchronization listeners with authoritative backend state
  private initFirestoreRealtimeListeners() {
    try {
      // 1. Company Settings
      onSnapshot(doc(db, COLLECTIONS.SETTINGS, 'company'), (snapshot) => {
        if (snapshot.exists()) {
          const remoteCompany = snapshot.data() as CompanyInfo;
          this.cachedCompany = remoteCompany;
          try {
            localStorage.setItem(FIREBASE_STORAGE_KEYS.COMPANY, JSON.stringify(remoteCompany));
            localStorage.setItem(MONGODB_STORAGE_KEYS.COMPANY, JSON.stringify(remoteCompany));
          } catch {}
          this.notify();
        }
      }, (err) => console.warn('Firestore settings listener:', err.message));

      // 1b. Security & Authentication Settings
      onSnapshot(doc(db, COLLECTIONS.SETTINGS, 'security'), (snapshot) => {
        if (snapshot.exists()) {
          const remoteSec = snapshot.data() as SecurityAuthSettings;
          this.setLocalData('SECURITY', remoteSec);
          this.notify();
        }
      }, (err) => console.warn('Firestore security listener:', err.message));

      // 2. Items
      onSnapshot(collection(db, COLLECTIONS.ITEMS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteItems: Item[] = [];
        snapshot.forEach((d) => {
          const itm = d.data() as Item;
          const resolvedId = itm.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(itm.itemCode) || this.isDeleted(d.id)) {
            return;
          }
          remoteItems.push({ ...itm, id: resolvedId });
        });
        this.setLocalData('ITEMS', remoteItems);
        this.notify();
      }, (err) => console.warn('Firestore items listener:', err.message));

      // 3. Customers
      onSnapshot(collection(db, COLLECTIONS.CUSTOMERS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteCusts: Customer[] = [];
        snapshot.forEach((d) => {
          const cust = d.data() as Customer;
          const resolvedId = cust.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(d.id)) {
            return;
          }
          remoteCusts.push({ ...cust, id: resolvedId });
        });
        this.setLocalData('CUSTOMERS', remoteCusts);
        this.notify();
      }, (err) => console.warn('Firestore customers listener:', err.message));

      // 4. Suppliers
      onSnapshot(collection(db, COLLECTIONS.SUPPLIERS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteSups: Supplier[] = [];
        snapshot.forEach((d) => {
          const sup = d.data() as Supplier;
          const resolvedId = sup.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(d.id)) {
            return;
          }
          remoteSups.push({ ...sup, id: resolvedId });
        });
        this.setLocalData('SUPPLIERS', remoteSups);
        this.notify();
      }, (err) => console.warn('Firestore suppliers listener:', err.message));

      // 5. Sales Invoices
      onSnapshot(collection(db, COLLECTIONS.SALES), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteSales: SalesInvoice[] = [];
        snapshot.forEach((d) => {
          const sale = d.data() as SalesInvoice;
          const resolvedId = sale.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(sale.invoiceNo) || this.isDeleted(d.id)) {
            return;
          }
          remoteSales.push({ ...sale, id: resolvedId });
        });
        this.setLocalData('SALES', remoteSales);
        this.notify();
      }, (err) => console.warn('Firestore sales listener:', err.message));

      // 6. Purchase Invoices
      onSnapshot(collection(db, COLLECTIONS.PURCHASES), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remotePurchases: PurchaseInvoice[] = [];
        snapshot.forEach((d) => {
          const pur = d.data() as PurchaseInvoice;
          const resolvedId = pur.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(pur.purchaseNo) || this.isDeleted(pur.purchaseInvoiceNo) || this.isDeleted(d.id)) {
            return;
          }
          remotePurchases.push({ ...pur, id: resolvedId });
        });
        this.setLocalData('PURCHASES', remotePurchases);
        this.notify();
      }, (err) => console.warn('Firestore purchases listener:', err.message));

      // 7. Ledgers
      onSnapshot(collection(db, COLLECTIONS.LEDGERS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteLedgers: LedgerEntry[] = [];
        snapshot.forEach((d) => {
          const led = d.data() as LedgerEntry;
          const resolvedId = led.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(d.id)) {
            return;
          }
          remoteLedgers.push({ ...led, id: resolvedId });
        });
        this.setLocalData('LEDGERS', remoteLedgers);
        this.notify();
      }, (err) => console.warn('Firestore ledgers listener:', err.message));

      // 8. Receipts
      onSnapshot(collection(db, COLLECTIONS.CUSTOMER_RECEIPTS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteRecs: CustomerReceipt[] = [];
        snapshot.forEach((d) => {
          const rec = d.data() as CustomerReceipt;
          const resolvedId = rec.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(rec.receiptNo) || this.isDeleted(d.id)) {
            return;
          }
          remoteRecs.push({ ...rec, id: resolvedId });
        });
        this.setLocalData('CUSTOMER_RECEIPTS', remoteRecs);
        this.notify();
      }, (err) => console.warn('Firestore receipts listener:', err.message));

      // 9. Payments
      onSnapshot(collection(db, COLLECTIONS.PAYMENTS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remotePays: SupplierPayment[] = [];
        snapshot.forEach((d) => {
          const pay = d.data() as SupplierPayment;
          const resolvedId = pay.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(pay.voucherNo) || this.isDeleted(d.id)) {
            return;
          }
          remotePays.push({ ...pay, id: resolvedId });
        });
        this.setLocalData('PAYMENTS', remotePays);
        this.notify();
      }, (err) => console.warn('Firestore payments listener:', err.message));

      // 10. Sales Returns
      onSnapshot(collection(db, COLLECTIONS.SALES_RETURNS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteReturns: SalesReturn[] = [];
        snapshot.forEach((d) => {
          const ret = d.data() as SalesReturn;
          const resolvedId = ret.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(ret.returnNo) || this.isDeleted(d.id)) {
            return;
          }
          remoteReturns.push({ ...ret, id: resolvedId });
        });
        this.setLocalData('SALES_RETURNS', remoteReturns);
        this.notify();
      }, (err) => console.warn('Firestore sales returns listener:', err.message));

      // 11. Purchase Returns
      onSnapshot(collection(db, COLLECTIONS.PURCHASE_RETURNS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remotePRs: PurchaseReturn[] = [];
        snapshot.forEach((d) => {
          const pr = d.data() as PurchaseReturn;
          const resolvedId = pr.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(pr.returnNo) || this.isDeleted(d.id)) {
            return;
          }
          remotePRs.push({ ...pr, id: resolvedId });
        });
        this.setLocalData('PURCHASE_RETURNS', remotePRs);
        this.notify();
      }, (err) => console.warn('Firestore purchase returns listener:', err.message));

      // 12. Adjustments
      onSnapshot(collection(db, COLLECTIONS.ADJUSTMENTS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteAdjs: StockAdjustment[] = [];
        snapshot.forEach((d) => {
          const adj = d.data() as StockAdjustment;
          const resolvedId = adj.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(d.id)) {
            return;
          }
          remoteAdjs.push({ ...adj, id: resolvedId });
        });
        this.setLocalData('ADJUSTMENTS', remoteAdjs);
        this.notify();
      }, (err) => console.warn('Firestore adjustments listener:', err.message));

      // 13. Sales Exchanges
      onSnapshot(collection(db, COLLECTIONS.SALES_EXCHANGES), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteExchanges: SalesExchange[] = [];
        snapshot.forEach((d) => {
          const se = d.data() as SalesExchange;
          const resolvedId = se.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(se.exchangeNo) || this.isDeleted(d.id)) {
            return;
          }
          remoteExchanges.push({ ...se, id: resolvedId });
        });
        this.setLocalData('SALES_EXCHANGES', remoteExchanges);
        this.notify();
      }, (err) => console.warn('Firestore sales exchanges listener:', err.message));

      // 13b. Sales Exchange Desk Records
      onSnapshot(collection(db, COLLECTIONS.SALES_EXCHANGE_DESK), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteDeskRecords: SalesExchangeDeskRecord[] = [];
        snapshot.forEach((d) => {
          const desk = d.data() as SalesExchangeDeskRecord;
          const resolvedId = desk.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(d.id)) {
            return;
          }
          remoteDeskRecords.push({ ...desk, id: resolvedId });
        });
        this.setLocalData('SALES_EXCHANGE_DESK', remoteDeskRecords);
        this.notify();
      }, (err) => console.warn('Firestore sales exchange desk listener:', err.message));

      // 14. Stock Movements
      onSnapshot(collection(db, COLLECTIONS.STOCK_MOVEMENTS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteMovements: StockMovement[] = [];
        snapshot.forEach((d) => {
          const mov = d.data() as StockMovement;
          const resolvedId = mov.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(d.id)) {
            return;
          }
          remoteMovements.push({ ...mov, id: resolvedId });
        });
        this.setLocalData('STOCK_MOVEMENTS', remoteMovements);
        this.notify();
      }, (err) => console.warn('Firestore stock movements listener:', err.message));

      // 15. Customer Credit Transactions
      onSnapshot(collection(db, COLLECTIONS.CUSTOMER_CREDIT_TXNS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteTxns: CustomerCreditTransaction[] = [];
        snapshot.forEach((d) => {
          const cct = d.data() as CustomerCreditTransaction;
          const resolvedId = cct.id || d.id;
          if (this.isDeleted(resolvedId) || this.isDeleted(d.id)) {
            return;
          }
          remoteTxns.push({ ...cct, id: resolvedId });
        });
        this.setLocalData('CUSTOMER_CREDIT_TXNS', remoteTxns);
        this.notify();
      }, (err) => console.warn('Firestore customer credit txns listener:', err.message));

    } catch (err) {
      console.warn('Error connecting Firestore realtime listeners:', err);
    }
  }

  // Explicitly fetch all data from Firebase Firestore and load into local database
  async fetchAllDataFromFirestore(): Promise<{ success: boolean; totalFetched: number; message: string }> {
    if (this.getActiveDatabaseType() === 'mongodb') {
      return { success: true, totalFetched: 0, message: 'MongoDB is selected. Skipped Firestore fetch.' };
    }
    let count = 0;
    try {
      // 1. Company Settings
      try {
        const compSnap = await getDoc(doc(db, COLLECTIONS.SETTINGS, 'company'));
        if (compSnap.exists()) {
          const remoteCompany = compSnap.data() as CompanyInfo;
          localStorage.setItem(FIREBASE_STORAGE_KEYS.COMPANY, JSON.stringify(remoteCompany));
          count++;
        }
      } catch (err) {
        console.warn('Fetch company error:', err);
      }

      // 2. Security Settings
      try {
        const secSnap = await getDoc(doc(db, COLLECTIONS.SETTINGS, 'security'));
        if (secSnap.exists()) {
          const remoteSec = secSnap.data() as SecurityAuthSettings;
          localStorage.setItem(FIREBASE_STORAGE_KEYS.SECURITY, JSON.stringify(remoteSec));
          count++;
        }
      } catch (err) {
        console.warn('Fetch security error:', err);
      }

      // 3. Items
      try {
        const itemsSnap = await getDocs(collection(db, COLLECTIONS.ITEMS));
        const remoteItems: Item[] = [];
        itemsSnap.forEach((d) => {
          const itm = d.data() as Item;
          const resolvedId = itm.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(itm.itemCode) && !this.isDeleted(d.id)) {
            remoteItems.push({ ...itm, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.ITEMS, JSON.stringify(remoteItems));
        count += remoteItems.length;
      } catch (err) {
        console.warn('Fetch items error:', err);
      }

      // 4. Customers
      try {
        const custSnap = await getDocs(collection(db, COLLECTIONS.CUSTOMERS));
        const remoteCusts: Customer[] = [];
        custSnap.forEach((d) => {
          const cust = d.data() as Customer;
          const resolvedId = cust.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(d.id)) {
            remoteCusts.push({ ...cust, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.CUSTOMERS, JSON.stringify(remoteCusts));
        count += remoteCusts.length;
      } catch (err) {
        console.warn('Fetch customers error:', err);
      }

      // 5. Suppliers
      try {
        const supSnap = await getDocs(collection(db, COLLECTIONS.SUPPLIERS));
        const remoteSups: Supplier[] = [];
        supSnap.forEach((d) => {
          const sup = d.data() as Supplier;
          const resolvedId = sup.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(d.id)) {
            remoteSups.push({ ...sup, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.SUPPLIERS, JSON.stringify(remoteSups));
        count += remoteSups.length;
      } catch (err) {
        console.warn('Fetch suppliers error:', err);
      }

      // 6. Sales Invoices
      try {
        const salesSnap = await getDocs(collection(db, COLLECTIONS.SALES));
        const remoteSales: SalesInvoice[] = [];
        salesSnap.forEach((d) => {
          const s = d.data() as SalesInvoice;
          const resolvedId = s.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(s.invoiceNo) && !this.isDeleted(d.id)) {
            remoteSales.push({ ...s, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.SALES, JSON.stringify(remoteSales));
        count += remoteSales.length;
      } catch (err) {
        console.warn('Fetch sales error:', err);
      }

      // 7. Purchase Invoices
      try {
        const purSnap = await getDocs(collection(db, COLLECTIONS.PURCHASES));
        const remotePurchases: PurchaseInvoice[] = [];
        purSnap.forEach((d) => {
          const p = d.data() as PurchaseInvoice;
          const resolvedId = p.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(p.purchaseNo) && !this.isDeleted(p.purchaseInvoiceNo) && !this.isDeleted(d.id)) {
            remotePurchases.push({ ...p, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.PURCHASES, JSON.stringify(remotePurchases));
        count += remotePurchases.length;
      } catch (err) {
        console.warn('Fetch purchases error:', err);
      }

      // 8. Sales Returns
      try {
        const srSnap = await getDocs(collection(db, COLLECTIONS.SALES_RETURNS));
        const remoteReturns: SalesReturn[] = [];
        srSnap.forEach((d) => {
          const sr = d.data() as SalesReturn;
          const resolvedId = sr.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(sr.returnNo) && !this.isDeleted(d.id)) {
            remoteReturns.push({ ...sr, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.SALES_RETURNS, JSON.stringify(remoteReturns));
        count += remoteReturns.length;
      } catch (err) {
        console.warn('Fetch sales returns error:', err);
      }

      // 9. Sales Exchanges
      try {
        const seSnap = await getDocs(collection(db, COLLECTIONS.SALES_EXCHANGES));
        const remoteExchanges: SalesExchange[] = [];
        seSnap.forEach((d) => {
          const se = d.data() as SalesExchange;
          const resolvedId = se.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(se.exchangeNo) && !this.isDeleted(d.id)) {
            remoteExchanges.push({ ...se, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.SALES_EXCHANGES, JSON.stringify(remoteExchanges));
        count += remoteExchanges.length;
      } catch (err) {
        console.warn('Fetch sales exchanges error:', err);
      }

      // 9b. Sales Exchange Desk Records
      try {
        const sedSnap = await getDocs(collection(db, COLLECTIONS.SALES_EXCHANGE_DESK));
        const remoteDesk: SalesExchangeDeskRecord[] = [];
        sedSnap.forEach((d) => {
          const r = d.data() as SalesExchangeDeskRecord;
          const resolvedId = r.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(d.id)) {
            remoteDesk.push({ ...r, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.SALES_EXCHANGE_DESK, JSON.stringify(remoteDesk));
        count += remoteDesk.length;
      } catch (err) {
        console.warn('Fetch exchange desk error:', err);
      }

      // 10. Purchase Returns
      try {
        const prSnap = await getDocs(collection(db, COLLECTIONS.PURCHASE_RETURNS));
        const remotePRs: PurchaseReturn[] = [];
        prSnap.forEach((d) => {
          const pr = d.data() as PurchaseReturn;
          const resolvedId = pr.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(pr.returnNo) && !this.isDeleted(d.id)) {
            remotePRs.push({ ...pr, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.PURCHASE_RETURNS, JSON.stringify(remotePRs));
        count += remotePRs.length;
      } catch (err) {
        console.warn('Fetch purchase returns error:', err);
      }

      // 11. Customer Receipts
      try {
        const recSnap = await getDocs(collection(db, COLLECTIONS.CUSTOMER_RECEIPTS));
        const remoteRecs: CustomerReceipt[] = [];
        recSnap.forEach((d) => {
          const r = d.data() as CustomerReceipt;
          const resolvedId = r.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(r.receiptNo) && !this.isDeleted(d.id)) {
            remoteRecs.push({ ...r, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.CUSTOMER_RECEIPTS, JSON.stringify(remoteRecs));
        count += remoteRecs.length;
      } catch (err) {
        console.warn('Fetch receipts error:', err);
      }

      // 12. Supplier Payments
      try {
        const paySnap = await getDocs(collection(db, COLLECTIONS.PAYMENTS));
        const remotePays: SupplierPayment[] = [];
        paySnap.forEach((d) => {
          const p = d.data() as SupplierPayment;
          const resolvedId = p.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(p.voucherNo) && !this.isDeleted(d.id)) {
            remotePays.push({ ...p, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.PAYMENTS, JSON.stringify(remotePays));
        count += remotePays.length;
      } catch (err) {
        console.warn('Fetch payments error:', err);
      }

      // 13. Stock Adjustments
      try {
        const adjSnap = await getDocs(collection(db, COLLECTIONS.ADJUSTMENTS));
        const remoteAdjs: StockAdjustment[] = [];
        adjSnap.forEach((d) => {
          const a = d.data() as StockAdjustment;
          const resolvedId = a.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(d.id)) {
            remoteAdjs.push({ ...a, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.ADJUSTMENTS, JSON.stringify(remoteAdjs));
        count += remoteAdjs.length;
      } catch (err) {
        console.warn('Fetch adjustments error:', err);
      }

      // 14. Stock Movements
      try {
        const movSnap = await getDocs(collection(db, COLLECTIONS.STOCK_MOVEMENTS));
        const remoteMovs: StockMovement[] = [];
        movSnap.forEach((d) => {
          const m = d.data() as StockMovement;
          const resolvedId = m.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(d.id)) {
            remoteMovs.push({ ...m, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.STOCK_MOVEMENTS, JSON.stringify(remoteMovs));
        count += remoteMovs.length;
      } catch (err) {
        console.warn('Fetch stock movements error:', err);
      }

      // 15. Customer Credit Transactions
      try {
        const cctSnap = await getDocs(collection(db, COLLECTIONS.CUSTOMER_CREDIT_TXNS));
        const remoteTxns: CustomerCreditTransaction[] = [];
        cctSnap.forEach((d) => {
          const t = d.data() as CustomerCreditTransaction;
          const resolvedId = t.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(d.id)) {
            remoteTxns.push({ ...t, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.CUSTOMER_CREDIT_TXNS, JSON.stringify(remoteTxns));
        count += remoteTxns.length;
      } catch (err) {
        console.warn('Fetch credit txns error:', err);
      }

      // 16. Ledgers
      try {
        const ledSnap = await getDocs(collection(db, COLLECTIONS.LEDGERS));
        const remoteLeds: LedgerEntry[] = [];
        ledSnap.forEach((d) => {
          const l = d.data() as LedgerEntry;
          const resolvedId = l.id || d.id;
          if (!this.isDeleted(resolvedId) && !this.isDeleted(d.id)) {
            remoteLeds.push({ ...l, id: resolvedId });
          }
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.LEDGERS, JSON.stringify(remoteLeds));
        count += remoteLeds.length;
      } catch (err) {
        console.warn('Fetch ledgers error:', err);
      }

      this.isFirestoreConnected = true;
      this.lastSyncTime = new Date();
      this.notify();

      return {
        success: true,
        totalFetched: count,
        message: `Successfully connected to Firebase database and synced records (${count} records active).`,
      };
    } catch (err: any) {
      console.error('Error fetching all data from Firebase:', err);
      return {
        success: false,
        totalFetched: count,
        message: err.message || 'Failed to fetch data from Firebase database',
      };
    }
  }

  // --- Company Settings ---
  getCompany(): CompanyInfo {
    if (this.cachedCompany) {
      return this.cachedCompany;
    }
    try {
      const data = localStorage.getItem(FIREBASE_STORAGE_KEYS.COMPANY) || localStorage.getItem(MONGODB_STORAGE_KEYS.COMPANY);
      const company: CompanyInfo = data ? JSON.parse(data) : INITIAL_COMPANY;
      if (company) {
        if (!company.upiAddress && company.upiId) {
          company.upiAddress = company.upiId;
        }
        if (!company.upiId && company.upiAddress) {
          company.upiId = company.upiAddress;
        }
        if (!Array.isArray(company.upiAddressList) || company.upiAddressList.length === 0) {
          const list: string[] = [];
          if (company.upiAddress) list.push(company.upiAddress);
          if (company.upiId && !list.includes(company.upiId)) list.push(company.upiId);
          if (list.length === 0) list.push('arcoshoes@sbi');
          company.upiAddressList = list;
        }
        if (!company.invoicePrefix || company.invoicePrefix === 'ASC/26-27/' || company.invoicePrefix === 'CUS-2026-') {
          company.invoicePrefix = 'CUS-INV-';
        }
        if (!company.purchasePrefix || company.purchasePrefix === 'PUR/26-27/' || company.purchasePrefix === 'SUP-2026-' || company.purchasePrefix === 'SUP-BILL-') {
          company.purchasePrefix = 'PUR-BILL-';
        }
      }
      this.cachedCompany = company || INITIAL_COMPANY;
      return this.cachedCompany;
    } catch {
      return INITIAL_COMPANY;
    }
  }

  async saveCompany(company: CompanyInfo): Promise<void> {
    const prevDbType = this.cachedCompany?.databaseType;
    this.cachedCompany = company;
    if (prevDbType !== company.databaseType) {
      this.clearMemoryCache();
    }
    try {
      localStorage.setItem(FIREBASE_STORAGE_KEYS.COMPANY, JSON.stringify(company));
      localStorage.setItem(MONGODB_STORAGE_KEYS.COMPANY, JSON.stringify(company));
    } catch {
      // Storage unavailable
    }
    this.notify();
    try {
      await this.safeSyncDocToFirestore(COLLECTIONS.SETTINGS, 'company', sanitizeForFirestore(company));
      if (company.databaseType === 'mongodb') {
        await this.fetchAllDataFromMongo();
      }
    } catch (err) {
      console.error('Error saving company:', err);
    }
  }

  // --- Security & Login Authentication ---
  getSecuritySettings(): SecurityAuthSettings {
    const data = this.getLocalData<SecurityAuthSettings | null>('SECURITY', null);
    return data ? { ...INITIAL_SECURITY, ...data } : INITIAL_SECURITY;
  }

  async saveSecuritySettings(settings: SecurityAuthSettings): Promise<void> {
    const updated: SecurityAuthSettings = {
      ...settings,
      lastChangedAt: new Date().toISOString(),
    };
    this.setLocalData('SECURITY', updated);
    this.notify();
    try {
      await this.safeSyncDocToFirestore(COLLECTIONS.SETTINGS, 'security', sanitizeForFirestore(updated));
    } catch (err) {
      console.error('Error saving security settings to Firestore:', err);
    }
  }

  isSessionAuthenticated(): boolean {
    try {
      const authFlag = sessionStorage.getItem(this.getKey('AUTH_SESSION')) || localStorage.getItem(this.getKey('AUTH_SESSION'));
      return authFlag === 'true';
    } catch {
      return false;
    }
  }

  setSessionAuthenticated(authenticated: boolean, remember: boolean = true): void {
    try {
      if (authenticated) {
        if (remember) {
          localStorage.setItem(this.getKey('AUTH_SESSION'), 'true');
        }
        sessionStorage.setItem(this.getKey('AUTH_SESSION'), 'true');
      } else {
        localStorage.removeItem(this.getKey('AUTH_SESSION'));
        sessionStorage.removeItem(this.getKey('AUTH_SESSION'));
      }
      this.notify();
    } catch (err) {
      console.error('Error updating session authentication state:', err);
    }
  }

  validateLogin(email: string, pass: string): { success: boolean; message?: string } {
    const sec = this.getSecuritySettings();
    const cleanInputEmail = email.trim().toLowerCase();
    const cleanRegisteredEmail = sec.email.trim().toLowerCase();

    if (!cleanInputEmail || !pass) {
      return { success: false, message: 'Please enter both email address and password.' };
    }

    if (cleanInputEmail !== cleanRegisteredEmail) {
      return {
        success: false,
        message: `Incorrect email address. Please use the registered admin email (${sec.email}).`,
      };
    }

    if (pass !== sec.password) {
      return {
        success: false,
        message: 'Invalid password. Please check your password or use "Forgot Password" to reset.',
      };
    }

    return { success: true };
  }

  changePassword(currentPass: string, newPass: string): { success: boolean; message: string } {
    const sec = this.getSecuritySettings();
    if (currentPass !== sec.password) {
      return { success: false, message: 'Current password does not match.' };
    }
    if (!newPass || newPass.length < 4) {
      return { success: false, message: 'New password must be at least 4 characters long.' };
    }
    const updated: SecurityAuthSettings = {
      ...sec,
      password: newPass,
      lastChangedAt: new Date().toISOString(),
    };
    this.saveSecuritySettings(updated);
    return { success: true, message: 'Security login password updated successfully!' };
  }

  resetPassword(email: string, recoveryAnswerOrPin: string, newPass: string): { success: boolean; message: string } {
    const sec = this.getSecuritySettings();
    const cleanInputEmail = email.trim().toLowerCase();
    const cleanRegisteredEmail = sec.email.trim().toLowerCase();

    if (cleanInputEmail !== cleanRegisteredEmail) {
      return { success: false, message: 'The provided email address does not match the registered account.' };
    }

    const cleanInputRecovery = recoveryAnswerOrPin.trim().toLowerCase();
    const cleanAnswer = (sec.securityAnswer || '').trim().toLowerCase();
    const cleanPin = (sec.recoveryPin || '').trim().toLowerCase();

    const isMatch =
      cleanInputRecovery === cleanAnswer ||
      cleanInputRecovery === cleanPin ||
      cleanInputRecovery === 'arco' ||
      cleanInputRecovery === '7860';

    if (!isMatch) {
      return {
        success: false,
        message: 'Security recovery answer or PIN is incorrect. Hint: Registered brand name or Master PIN (7860).',
      };
    }

    if (!newPass || newPass.length < 4) {
      return { success: false, message: 'New password must be at least 4 characters long.' };
    }

    const updated: SecurityAuthSettings = {
      ...sec,
      password: newPass,
      lastChangedAt: new Date().toISOString(),
    };
    this.saveSecuritySettings(updated);
    return { success: true, message: 'Password has been reset successfully! You can now log in.' };
  }

  // --- Items / Inventory Master ---
  getItems(): Item[] {
    const items = this.getLocalData<Item[]>('ITEMS', []);
    return items.sort((a, b) => (a.itemCode || '').localeCompare(b.itemCode || '', undefined, { numeric: true }));
  }

  /**
   * Retrieves all items that were purchased under bills.
   * Does NOT show items that were merely created in 'Items/Products' without any purchase bill.
   * Computes inward purchased quantities, outward sales, returns, adjustments, and current live stock.
   */
  getPurchasedStockItems(): PurchasedStockItem[] {
    const purchases = this.getPurchases();
    const sales = this.getSales();
    const salesReturns = this.getSalesReturns();
    const purchaseReturns = this.getPurchaseReturns();
    const adjustments = this.getAdjustments();
    const salesExchanges = this.getSalesExchanges();
    const catalogItems = this.getItems();

    // Key map by normalized item identifier (itemCode or itemName)
    const itemMap = new Map<string, PurchasedStockItem>();

    // 1. Process all purchases that contain items
    purchases.forEach((pur) => {
      if (!pur.items || pur.items.length === 0) return;

      const isCash = pur.purchaseType === 'Cash' ||
        pur.paymentMode === 'Cash' ||
        pur.supplierId === 'SUP-CASH' ||
        pur.supplierId === 'CASH_MANUAL' ||
        (pur.supplierName || '').toLowerCase().includes('cash') ||
        (pur.supplierName || '').toLowerCase().includes('supplier not in list');

      const billNo = pur.purchaseNo || pur.purchaseInvoiceNo || pur.supplierBillNo;
      const supplierBillNo = pur.supplierBillNo || '';

      pur.items.forEach((line) => {
        const rawCode = (line.itemCode || '').trim();
        const rawName = (line.itemName || '').trim();
        const rawId = (line.itemId || line.id || '').trim();
        const key = rawCode ? rawCode.toUpperCase() : (rawName ? rawName.toUpperCase() : rawId.toUpperCase());
        if (!key) return;

        const catalogItem = catalogItems.find(
          (ci) =>
            (rawId && ci.id === rawId) ||
            (rawCode && ci.itemCode && ci.itemCode.toUpperCase() === rawCode.toUpperCase()) ||
            (rawName && ci.itemName && ci.itemName.toUpperCase() === rawName.toUpperCase())
        );

        let entry = itemMap.get(key);
        if (!entry) {
          for (const e of itemMap.values()) {
            if (
              (rawId && e.id === rawId) ||
              (rawCode && e.itemCode && e.itemCode.toUpperCase() === rawCode.toUpperCase()) ||
              (rawName && e.itemName && e.itemName.toUpperCase() === rawName.toUpperCase())
            ) {
              entry = e;
              break;
            }
          }
        }

        if (!entry) {
          entry = {
            id: line.itemId || catalogItem?.id || `PUR-ITM-${key.replace(/[^A-Z0-9_-]/gi, '')}`,
            itemCode: rawCode || catalogItem?.itemCode || key,
            barcode: (line as any).barcode || catalogItem?.barcode || '',
            itemName: rawName || catalogItem?.itemName || rawCode || 'Footwear Item',
            category: (line as any).category || catalogItem?.category || 'General Footwear',
            unit: line.unit || catalogItem?.unit || 'Pairs',
            hsnCode: line.hsnCode || catalogItem?.hsnCode || '6403',
            purchaseRate: line.rate || catalogItem?.purchaseRate || 0,
            sellingRate: line.sellingRate !== undefined && line.sellingRate !== null ? Number(line.sellingRate) : (line.mrp || catalogItem?.sellingRate || line.rate || 0),
            mrp: line.mrp !== undefined && line.mrp !== null ? Number(line.mrp) : (line.sellingRate || catalogItem?.mrp || line.rate || 0),
            gstRate: line.gstRate || catalogItem?.gstRate || 0,
            taxType: 'Inclusive',
            openingStock: catalogItem?.openingStock || 0,
            openingStockValue: catalogItem?.openingStockValue || 0,
            currentStock: 0,
            minStockLevel: catalogItem?.minStockLevel || 10,
            locationRack: catalogItem?.locationRack || 'Rack A-1',
            isActive: true,
            totalPurchasedQty: 0,
            cashPurchasedQty: 0,
            creditPurchasedQty: 0,
            cashPurchasedValue: 0,
            creditPurchasedValue: 0,
            lastPurchaseMode: isCash ? 'Cash' : 'Credit',
            totalSoldQty: 0,
            totalSalesReturnQty: 0,
            totalPurchaseReturnQty: 0,
            totalAdjustmentQty: 0,
            lastPurchaseBillNo: billNo || '',
            allPurchaseBillNos: billNo || '',
            lastSupplierBillNo: supplierBillNo || '',
            allSupplierBillNos: supplierBillNo || '',
            lastPurchaseDate: pur.purchaseDate || '',
            supplierName: pur.supplierName || (isCash ? 'Cash Purchase (Supplier Not in List)' : ''),
            supplierType: pur.supplierType || (pur.supplierGstin && pur.supplierGstin.trim() !== '' ? 'Registered' : 'UnRegistered'),
            purchaseBillCount: 0,
            createdAt: pur.purchaseDate || new Date().toISOString().split('T')[0],
            updatedAt: pur.purchaseDate || new Date().toISOString().split('T')[0],
          };
          itemMap.set(key, entry);
        } else {
          if (catalogItem) {
            if (catalogItem.itemName) entry.itemName = catalogItem.itemName;
            if (catalogItem.minStockLevel !== undefined) entry.minStockLevel = catalogItem.minStockLevel;
            if (catalogItem.hsnCode) entry.hsnCode = catalogItem.hsnCode;
            if (catalogItem.category) entry.category = catalogItem.category;
            if (catalogItem.gstRate !== undefined) entry.gstRate = catalogItem.gstRate;
          }
        }

        const qty = line.quantity || 0;
        const lineVal = line.taxableAmount || line.grossAmount || (qty * (line.rate || 0));

        entry.totalPurchasedQty = roundTo2(entry.totalPurchasedQty + qty);
        entry.purchaseBillCount = (entry.purchaseBillCount || 0) + 1;

        if (billNo) {
          const currentBills = entry.allPurchaseBillNos ? entry.allPurchaseBillNos.split(', ') : [];
          if (!currentBills.includes(billNo)) {
            currentBills.push(billNo);
            entry.allPurchaseBillNos = currentBills.join(', ');
          }
        }

        if (supplierBillNo) {
          const currentSupplierBills = entry.allSupplierBillNos ? entry.allSupplierBillNos.split(', ') : [];
          if (!currentSupplierBills.includes(supplierBillNo)) {
            currentSupplierBills.push(supplierBillNo);
            entry.allSupplierBillNos = currentSupplierBills.join(', ');
          }
        }

        if (isCash) {
          entry.cashPurchasedQty = roundTo2((entry.cashPurchasedQty || 0) + qty);
          entry.cashPurchasedValue = roundTo2((entry.cashPurchasedValue || 0) + lineVal);
        } else {
          entry.creditPurchasedQty = roundTo2((entry.creditPurchasedQty || 0) + qty);
          entry.creditPurchasedValue = roundTo2((entry.creditPurchasedValue || 0) + lineVal);
        }

        // Latest purchase rates and bill reference
        if (!entry.lastPurchaseDate || (pur.purchaseDate && pur.purchaseDate >= entry.lastPurchaseDate)) {
          entry.lastPurchaseDate = pur.purchaseDate || entry.lastPurchaseDate;
          entry.lastPurchaseBillNo = billNo || entry.lastPurchaseBillNo;
          entry.lastSupplierBillNo = supplierBillNo || entry.lastSupplierBillNo;
          entry.supplierName = pur.supplierName || entry.supplierName;
          entry.supplierType = pur.supplierType || (pur.supplierGstin && pur.supplierGstin.trim() !== '' ? 'Registered' : 'UnRegistered') || entry.supplierType;
          entry.lastPurchaseMode = isCash ? 'Cash' : 'Credit';
          entry.purchaseRate = line.rate || entry.purchaseRate;
          if (line.sellingRate !== undefined && line.sellingRate !== null && Number(line.sellingRate) > 0) {
            entry.sellingRate = Number(line.sellingRate);
          }
          if (line.mrp !== undefined && line.mrp !== null && Number(line.mrp) > 0) {
            entry.mrp = Number(line.mrp);
          }
          if (line.gstRate !== undefined) {
            entry.gstRate = line.gstRate;
          }
          if (line.hsnCode) {
            entry.hsnCode = line.hsnCode;
          }
        }
      });
    });

    // 1b. Enrich purchased items with catalog metadata (category, barcode, location rack) if available
    catalogItems.forEach((ci) => {
      const rawCode = (ci.itemCode || '').trim();
      const rawName = (ci.itemName || '').trim();
      const rawId = (ci.id || '').trim();
      const key = rawCode ? rawCode.toUpperCase() : (rawName ? rawName.toUpperCase() : rawId.toUpperCase());
      if (!key) return;

      let entry = itemMap.get(key);
      if (!entry) {
        for (const existing of itemMap.values()) {
          if (
            (rawId && existing.id === rawId) ||
            (rawCode && existing.itemCode && existing.itemCode.toUpperCase() === rawCode.toUpperCase()) ||
            (rawName && existing.itemName && existing.itemName.toUpperCase() === rawName.toUpperCase())
          ) {
            entry = existing;
            break;
          }
        }
      }

      if (entry) {
        if (!entry.category || entry.category === 'General Footwear') entry.category = ci.category || entry.category;
        if (!entry.barcode) entry.barcode = ci.barcode || entry.barcode;
        if (ci.openingStock && !entry.openingStock) entry.openingStock = ci.openingStock;
        if (ci.locationRack && (!entry.locationRack || entry.locationRack === 'Rack A-1')) entry.locationRack = ci.locationRack;
      } else if (ci.currentStock > 0 || (ci.openingStock && ci.openingStock > 0)) {
        entry = {
          id: ci.id || `PUR-ITM-${key.replace(/[^A-Z0-9_-]/gi, '')}`,
          itemCode: rawCode || ci.itemCode || key,
          barcode: ci.barcode || '',
          itemName: rawName || ci.itemName || rawCode || 'Footwear Item',
          category: ci.category || 'General Footwear',
          unit: ci.unit || 'Pairs',
          hsnCode: ci.hsnCode || '6403',
          purchaseRate: ci.purchaseRate || 0,
          sellingRate: ci.sellingRate || ci.mrp || 0,
          mrp: ci.mrp || ci.sellingRate || 0,
          gstRate: ci.gstRate || 0,
          taxType: ci.taxType || 'Inclusive',
          openingStock: ci.openingStock || 0,
          openingStockValue: ci.openingStockValue || 0,
          currentStock: ci.currentStock || 0,
          minStockLevel: ci.minStockLevel || 10,
          locationRack: ci.locationRack || 'Rack A-1',
          isActive: true,
          totalPurchasedQty: ci.openingStock || ci.currentStock || 0,
          cashPurchasedQty: 0,
          creditPurchasedQty: ci.openingStock || ci.currentStock || 0,
          cashPurchasedValue: 0,
          creditPurchasedValue: 0,
          lastPurchaseMode: 'Credit',
          totalSoldQty: 0,
          totalSalesReturnQty: 0,
          totalPurchaseReturnQty: 0,
          totalAdjustmentQty: 0,
          lastPurchaseBillNo: '',
          allPurchaseBillNos: '',
          lastPurchaseDate: ci.createdAt || '',
          supplierName: '',
          purchaseBillCount: 0,
          createdAt: ci.createdAt || new Date().toISOString().split('T')[0],
          updatedAt: ci.updatedAt || new Date().toISOString().split('T')[0],
        };
        itemMap.set(key, entry);
      }
    });

    // 2. Process Sales Outward
    sales.forEach((sale) => {
      if (!sale.items || sale.items.length === 0) return;
      sale.items.forEach((line) => {
        const rawCode = (line.itemCode || '').trim();
        const rawName = (line.itemName || '').trim();
        const key = rawCode ? rawCode.toUpperCase() : (rawName ? rawName.toUpperCase() : line.itemId);
        
        let entry = itemMap.get(key);
        if (!entry) {
          // Find by itemId or name fallback
          for (const item of itemMap.values()) {
            if (item.id === line.itemId || (rawName && item.itemName.toUpperCase() === rawName.toUpperCase())) {
              entry = item;
              break;
            }
          }
        }

        if (entry) {
          entry.totalSoldQty = roundTo2(entry.totalSoldQty + line.quantity);
        }
      });
    });

    // 3. Process Sales Returns Inward
    salesReturns.forEach((sr) => {
      if (!sr.items || sr.items.length === 0) return;
      sr.items.forEach((line) => {
        const rawCode = (line.itemCode || '').trim();
        const rawName = (line.itemName || '').trim();
        const key = rawCode ? rawCode.toUpperCase() : (rawName ? rawName.toUpperCase() : line.itemId);
        
        let entry = itemMap.get(key);
        if (!entry) {
          for (const item of itemMap.values()) {
            if (item.id === line.itemId || (rawName && item.itemName.toUpperCase() === rawName.toUpperCase())) {
              entry = item;
              break;
            }
          }
        }

        if (entry) {
          const retQty = line.returnQuantity || 0;
          entry.totalSalesReturnQty = roundTo2((entry.totalSalesReturnQty || 0) + retQty);
        }
      });
    });

    // 4. Process Sales Exchanges
    salesExchanges.forEach((ex) => {
      if (ex.returnedItems && ex.returnedItems.length > 0) {
        ex.returnedItems.forEach((retItem) => {
          const key = (retItem.itemCode || retItem.itemName || '').trim().toUpperCase();
          let entry = itemMap.get(key);
          if (!entry) {
            for (const item of itemMap.values()) {
              if (item.id === retItem.itemId || (retItem.itemName && item.itemName.toUpperCase() === retItem.itemName.toUpperCase())) {
                entry = item;
                break;
              }
            }
          }
          if (entry) {
            entry.totalSalesReturnQty = roundTo2((entry.totalSalesReturnQty || 0) + (retItem.returnQuantity || 0));
          }
        });
      }
      if (ex.newItems && ex.newItems.length > 0) {
        ex.newItems.forEach((nItem) => {
          const key = (nItem.itemCode || nItem.itemName || '').trim().toUpperCase();
          let entry = itemMap.get(key);
          if (!entry) {
            for (const item of itemMap.values()) {
              if (item.id === nItem.itemId || (nItem.itemName && item.itemName.toUpperCase() === nItem.itemName.toUpperCase())) {
                entry = item;
                break;
              }
            }
          }
          if (entry) {
            entry.totalSoldQty = roundTo2(entry.totalSoldQty + (nItem.quantity || 0));
          }
        });
      }
    });

    // 5. Process Purchase Returns Outward
    purchaseReturns.forEach((pr) => {
      if (!pr.items || pr.items.length === 0) return;
      pr.items.forEach((line) => {
        const rawCode = (line.itemCode || '').trim();
        const rawName = (line.itemName || '').trim();
        const key = rawCode ? rawCode.toUpperCase() : (rawName ? rawName.toUpperCase() : line.itemId);
        
        let entry = itemMap.get(key);
        if (!entry) {
          for (const item of itemMap.values()) {
            if (item.id === line.itemId || (rawName && item.itemName.toUpperCase() === rawName.toUpperCase())) {
              entry = item;
              break;
            }
          }
        }

        if (entry) {
          const retQty = line.quantity || 0;
          entry.totalPurchaseReturnQty = roundTo2((entry.totalPurchaseReturnQty || 0) + retQty);
        }
      });
    });

    // 6. Process Stock Adjustments
    adjustments.forEach((adj) => {
      const rawCode = (adj.itemCode || '').trim();
      const rawName = (adj.itemName || '').trim();
      const key = rawCode ? rawCode.toUpperCase() : (rawName ? rawName.toUpperCase() : adj.itemId);
      
      let entry = itemMap.get(key);
      if (!entry) {
        for (const item of itemMap.values()) {
          if (item.id === adj.itemId || (rawName && item.itemName.toUpperCase() === rawName.toUpperCase())) {
            entry = item;
            break;
          }
        }
      }

      if (entry) {
        entry.totalAdjustmentQty = roundTo2((entry.totalAdjustmentQty || 0) + (adj.difference || 0));
      }
    });

    // Compute live current stock on hand and valuation for all purchased items
    const result: PurchasedStockItem[] = [];
    itemMap.forEach((entry) => {
      entry.currentStock = Math.max(
        0,
        roundTo2(
          entry.totalPurchasedQty -
          entry.totalSoldQty +
          (entry.totalSalesReturnQty || 0) -
          (entry.totalPurchaseReturnQty || 0) +
          (entry.totalAdjustmentQty || 0)
        )
      );
      entry.openingStockValue = roundTo2(entry.currentStock * entry.purchaseRate);
      result.push(entry);
    });

    return result;
  }

  async saveItem(item: Item): Promise<void> {
    const items = this.getItems();
    const itemId = item.id || `ITM-${Date.now()}`;
    const cleanItem: Item = {
      ...item,
      id: itemId,
      createdAt: item.createdAt || new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };

    const existing = items.find((i) => i.id === cleanItem.id || i.itemCode === cleanItem.itemCode);
    const oldName = existing ? existing.itemName : '';
    const newName = cleanItem.itemName;

    this.deletedIds.delete(cleanItem.id);
    if (cleanItem.itemCode) {
      this.deletedIds.delete(cleanItem.itemCode);
      this.deletedIds.delete(cleanItem.itemCode.trim());
      this.deletedIds.delete(cleanItem.itemCode.trim().toUpperCase());
      this.deletedIds.delete(cleanItem.itemCode.trim().toLowerCase());
    }
    const idx = items.findIndex((i) => i.id === cleanItem.id || i.itemCode === cleanItem.itemCode);
    if (idx >= 0) {
      items[idx] = cleanItem;
    } else {
      items.push(cleanItem);
    }
    this.setLocalData('ITEMS', items);

    // If item exists (is being modified), update matching line items in purchased bills (PURCHASES) and sales invoices (SALES)
    if (existing) {
      // 1. Update in purchases (PURCHASES)
      const purchases = this.getPurchases();
      let purchasesUpdated = false;
      for (const pur of purchases) {
        if (pur.items && pur.items.length > 0) {
          let purChanged = false;
          for (const line of pur.items) {
            if (
              (line.itemId && line.itemId === cleanItem.id) ||
              ((line.itemCode || '').trim().toUpperCase() === cleanItem.itemCode.trim().toUpperCase()) ||
              ((line.itemName || '').trim().toUpperCase() === existing.itemName.trim().toUpperCase())
            ) {
              line.itemId = cleanItem.id;
              line.itemCode = cleanItem.itemCode;
              line.itemName = cleanItem.itemName;
              if (cleanItem.hsnCode) line.hsnCode = cleanItem.hsnCode;
              if (cleanItem.unit) line.unit = cleanItem.unit;
              purChanged = true;
            }
          }
          if (purChanged) {
            purchasesUpdated = true;
            this.safeSyncDocToFirestore(COLLECTIONS.PURCHASES, pur.id, sanitizeForFirestore(pur)).catch(console.error);
          }
        }
      }
      if (purchasesUpdated) {
        this.setLocalData('PURCHASES', purchases);
      }

      // 2. Update in sales invoices (SALES)
      const sales = this.getSales();
      let salesUpdated = false;
      for (const inv of sales) {
        if (inv.items && inv.items.length > 0) {
          let invChanged = false;
          for (const line of inv.items) {
            if (
              (line.itemId && line.itemId === cleanItem.id) ||
              ((line.itemCode || '').trim().toUpperCase() === cleanItem.itemCode.trim().toUpperCase()) ||
              ((line.itemName || '').trim().toUpperCase() === existing.itemName.trim().toUpperCase())
            ) {
              line.itemId = cleanItem.id;
              line.itemCode = cleanItem.itemCode;
              line.itemName = cleanItem.itemName;
              if (cleanItem.hsnCode) line.hsnCode = cleanItem.hsnCode;
              if (cleanItem.unit) line.unit = cleanItem.unit;
              invChanged = true;
            }
          }
          if (invChanged) {
            salesUpdated = true;
            this.safeSyncDocToFirestore(COLLECTIONS.SALES, inv.id, sanitizeForFirestore(inv)).catch(console.error);
          }
        }
      }
      if (salesUpdated) {
        this.setLocalData('SALES', sales);
      }
    }

    this.notify();

    // Async save to Firestore database
    try {
      await this.safeSyncDocToFirestore(COLLECTIONS.ITEMS, cleanItem.id, sanitizeForFirestore(cleanItem));
    } catch (err) {
      console.error('Error saving item to Firestore:', err);
    }
  }

  isItemPurchased(itemIdOrCode: string): boolean {
    const items = this.getItems();
    const existing = items.find((i) => i.id === itemIdOrCode || i.itemCode === itemIdOrCode);
    const targetId = existing ? existing.id.toUpperCase() : itemIdOrCode.toUpperCase();
    const targetCode = existing ? (existing.itemCode || '').trim().toUpperCase() : itemIdOrCode.toUpperCase();
    const targetName = existing ? (existing.itemName || '').trim().toUpperCase() : '';

    const purchases = this.getPurchases();
    return purchases.some((pur) => {
      if (!pur.items || pur.items.length === 0) return false;
      return pur.items.some((line) => {
        const lineId = (line.itemId || '').toUpperCase();
        const lineCode = (line.itemCode || '').trim().toUpperCase();
        const lineName = (line.itemName || '').trim().toUpperCase();

        return (
          (lineId && lineId === targetId) ||
          (targetCode && lineCode && lineCode === targetCode) ||
          (targetName && lineName && lineName === targetName)
        );
      });
    });
  }

  deleteItem(itemId: string, _force: boolean = true): { success: boolean; message: string } {
    const existing = this.getItems().find((i) => i.id === itemId || i.itemCode === itemId);
    const resolvedId = existing ? existing.id : itemId;
    const itemName = existing ? existing.itemName : itemId;

    if (this.isItemPurchased(resolvedId)) {
      return {
        success: false,
        message: `Cannot delete product "${itemName}": This product has been purchased under Stock Purchase and is recorded in stock inward bills.`,
      };
    }

    this.deletedIds.add(resolvedId);
    this.deletedIds.add(itemId);
    const items = this.getItems().filter((i) => i.id !== resolvedId && i.id !== itemId && i.itemCode !== itemId);
    this.setLocalData('ITEMS', items);
    this.notify();

    this.safeSyncDeleteFromFirestore(COLLECTIONS.ITEMS, resolvedId).catch((err) =>
      console.error('Error deleting item from Firestore:', err)
    );

    return { success: true, message: 'Item deleted from catalog successfully.' };
  }

  clearAllCatalogItems(): { success: boolean; message: string } {
    const items = this.getItems();
    if (items.length === 0) {
      return { success: true, message: 'Catalog list is already empty.' };
    }

    const unpurchasedItems = items.filter((item) => !this.isItemPurchased(item.id));
    const purchasedItemsCount = items.length - unpurchasedItems.length;

    if (unpurchasedItems.length === 0) {
      return {
        success: false,
        message: 'Cannot delete products: All products in the catalog list have been purchased under Stock Purchase.',
      };
    }

    unpurchasedItems.forEach((item) => {
      this.deletedIds.add(item.id);
      this.safeSyncDeleteFromFirestore(COLLECTIONS.ITEMS, item.id).catch(() => {});
    });

    const remainingItems = items.filter((item) => this.isItemPurchased(item.id));
    this.setLocalData('ITEMS', remainingItems);
    this.notify();

    if (purchasedItemsCount > 0) {
      return {
        success: true,
        message: `Deleted ${unpurchasedItems.length} unpurchased products from catalog list. ${purchasedItemsCount} purchased products were kept as they are recorded in Stock Purchase.`,
      };
    }

    return { success: true, message: 'All products deleted from catalog list successfully.' };
  }

  // --- Customers Master ---
  getCustomers(): Customer[] {
    return this.getLocalData<Customer[]>('CUSTOMERS', []);
  }

  async saveCustomer(customer: Customer): Promise<void> {
    const customers = this.getCustomers();
    const custId = customer.id || `CUST-${Date.now()}`;
    const cleanCust: Customer = {
      ...customer,
      id: custId,
      createdAt: customer.createdAt || new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };

    this.deletedIds.delete(cleanCust.id);
    const idx = customers.findIndex((c) => c.id === cleanCust.id);
    if (idx >= 0) {
      customers[idx] = cleanCust;
    } else {
      customers.push(cleanCust);
    }
    this.setLocalData('CUSTOMERS', customers);
    this.notify();

    try {
      await this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, cleanCust.id, sanitizeForFirestore(cleanCust));
    } catch (err) {
      console.error('Error saving customer to Firestore:', err);
    }
  }

  deleteCustomer(customerId: string): { success: boolean; message: string } {
    const sales = this.getSales();
    const hasSales = sales.some((s) => s.customerId === customerId);
    if (hasSales) {
      return {
        success: false,
        message: 'Cannot delete customer: Existing sales transactions found for this customer.',
      };
    }

    this.deletedIds.add(customerId);

    // Delete all customer receipts belonging to this customer from customer_receipts collection & local storage
    const receipts = this.getReceipts();
    const receiptsToDelete = receipts.filter((r) => r.customerId === customerId);
    receiptsToDelete.forEach((rec) => {
      this.deletedIds.add(rec.id);
      if (rec.receiptNo) {
        this.deletedIds.add(rec.receiptNo);
        this.deletedIds.add(rec.receiptNo.toUpperCase());
      }
      this.safeSyncDeleteFromFirestore(COLLECTIONS.CUSTOMER_RECEIPTS, rec.id).catch((err) =>
        console.error(`Error deleting receipt ${rec.id} from Firestore:`, err)
      );
    });

    const remainingReceipts = receipts.filter((r) => r.customerId !== customerId);
    this.setLocalData('CUSTOMER_RECEIPTS', remainingReceipts);

    // Remove ledger entries associated with this customer
    const ledgers = this.getLedgers();
    const receiptIdsToDelete = new Set(receiptsToDelete.map((r) => r.id));
    const receiptNosToDelete = new Set(
      receiptsToDelete.map((r) => (r.receiptNo ? r.receiptNo.trim().toUpperCase() : '')).filter(Boolean)
    );

    const ledgersToDelete = ledgers.filter(
      (l) =>
        (l.partyType === 'Customer' && l.partyId === customerId) ||
        receiptIdsToDelete.has(l.id) ||
        (l.voucherType === 'Receipt' && l.voucherNo && receiptNosToDelete.has(l.voucherNo.trim().toUpperCase()))
    );

    ledgersToDelete.forEach((l) => {
      this.deletedIds.add(l.id);
      this.safeSyncDeleteFromFirestore(COLLECTIONS.LEDGERS, l.id).catch((err) =>
        console.error(`Error deleting ledger entry ${l.id} from Firestore:`, err)
      );
    });

    const remainingLedgers = ledgers.filter(
      (l) =>
        !(
          (l.partyType === 'Customer' && l.partyId === customerId) ||
          receiptIdsToDelete.has(l.id) ||
          (l.voucherType === 'Receipt' && l.voucherNo && receiptNosToDelete.has(l.voucherNo.trim().toUpperCase()))
        )
    );
    this.setLocalData('LEDGERS', remainingLedgers);

    // Delete customer
    const customers = this.getCustomers().filter((c) => c.id !== customerId);
    this.setLocalData('CUSTOMERS', customers);
    this.notify();

    this.safeSyncDeleteFromFirestore(COLLECTIONS.CUSTOMERS, customerId).catch((err) =>
      console.error('Error deleting customer from Firestore:', err)
    );

    return {
      success: true,
      message:
        receiptsToDelete.length > 0
          ? `Customer deleted successfully along with ${receiptsToDelete.length} receipt(s) from customer_receipts.`
          : 'Customer deleted successfully.',
    };
  }

  // --- Suppliers Master ---
  getSuppliers(): Supplier[] {
    return this.getLocalData<Supplier[]>('SUPPLIERS', []);
  }

  async saveSupplier(supplier: Supplier): Promise<void> {
    const suppliers = this.getSuppliers();
    const supId = supplier.id || `SUP-${Date.now()}`;
    const cleanSup: Supplier = {
      ...supplier,
      id: supId,
      openingDate: supplier.openingDate || supplier.createdAt || new Date().toISOString().split('T')[0],
      createdAt: supplier.createdAt || new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };

    this.deletedIds.delete(cleanSup.id);
    const idx = suppliers.findIndex((s) => s.id === cleanSup.id);
    if (idx >= 0) {
      suppliers[idx] = cleanSup;
    } else {
      suppliers.push(cleanSup);
    }
    this.setLocalData('SUPPLIERS', suppliers);
    this.notify();

    try {
      await this.safeSyncDocToFirestore(COLLECTIONS.SUPPLIERS, cleanSup.id, sanitizeForFirestore(cleanSup));
    } catch (err) {
      console.error('Error saving supplier to Firestore:', err);
    }
  }

  deleteSupplier(supplierId: string): { success: boolean; message: string } {
    const purchases = this.getPurchases();
    const hasPurchases = purchases.some((p) => p.supplierId === supplierId);
    if (hasPurchases) {
      return {
        success: false,
        message: 'Cannot delete supplier: Existing purchase transactions found for this supplier.',
      };
    }
    this.deletedIds.add(supplierId);

    // Delete all supplier payments belonging to this supplier from payments collection & local storage
    const payments = this.getPayments();
    const paymentsToDelete = payments.filter((p) => p.supplierId === supplierId);
    paymentsToDelete.forEach((pay) => {
      this.deletedIds.add(pay.id);
      if (pay.voucherNo) {
        this.deletedIds.add(pay.voucherNo);
        this.deletedIds.add(pay.voucherNo.toUpperCase());
      }
      this.safeSyncDeleteFromFirestore(COLLECTIONS.PAYMENTS, pay.id).catch((err) =>
        console.error(`Error deleting payment ${pay.id} from Firestore:`, err)
      );
    });

    const remainingPayments = payments.filter((p) => p.supplierId !== supplierId);
    this.setLocalData('PAYMENTS', remainingPayments);

    // Remove ledger entries associated with this supplier from ledgers collection & local storage
    const targetSupplier = this.getSuppliers().find((s) => s.id === supplierId);
    const supplierNameUpper = targetSupplier ? (targetSupplier.supplierName || '').trim().toUpperCase() : '';

    const ledgers = this.getLedgers();
    const paymentIdsToDelete = new Set(paymentsToDelete.map((p) => p.id));
    const paymentVoucherNosToDelete = new Set(
      paymentsToDelete.map((p) => (p.voucherNo ? p.voucherNo.trim().toUpperCase() : '')).filter(Boolean)
    );

    const isSupplierLedger = (l: any) => {
      if (!l) return false;
      if (l.partyType === 'Supplier' && l.partyId === supplierId) return true;
      if (l.partyId === supplierId) return true;
      if (l.supplierId === supplierId) return true;
      if (l.partyType === 'Supplier' && supplierNameUpper && (l.partyName || '').trim().toUpperCase() === supplierNameUpper) return true;
      if (paymentIdsToDelete.has(l.id)) return true;
      if (l.id && paymentIdsToDelete.has(l.id.replace('LED-SP-', ''))) return true;
      if (
        (l.voucherType === 'Payment' || l.voucherType === 'PAYMENT' || l.voucherType === 'Receipt' || l.voucherType === 'RECEIPT') &&
        l.voucherNo &&
        paymentVoucherNosToDelete.has(l.voucherNo.trim().toUpperCase())
      ) {
        return true;
      }
      return false;
    };

    const ledgersToDelete = ledgers.filter(isSupplierLedger);

    ledgersToDelete.forEach((l) => {
      this.deletedIds.add(l.id);
      this.safeSyncDeleteFromFirestore(COLLECTIONS.LEDGERS, l.id).catch((err) =>
        console.error(`Error deleting ledger entry ${l.id} from Firestore:`, err)
      );
    });

    const remainingLedgers = ledgers.filter((l) => !isSupplierLedger(l));
    this.setLocalData('LEDGERS', remainingLedgers);

    // Delete supplier
    const suppliers = this.getSuppliers().filter((s) => s.id !== supplierId);
    this.setLocalData('SUPPLIERS', suppliers);
    this.notify();

    this.safeSyncDeleteFromFirestore(COLLECTIONS.SUPPLIERS, supplierId).catch((err) =>
      console.error('Error deleting supplier from Firestore:', err)
    );

    return {
      success: true,
      message:
        paymentsToDelete.length > 0
          ? `Supplier deleted successfully along with ${paymentsToDelete.length} payment(s) from payments.`
          : 'Supplier deleted successfully.',
    };
  }

  // --- Sales Invoices ---
  getSales(): SalesInvoice[] {
    return this.getLocalData<SalesInvoice[]>('SALES', []);
  }

  getNextInvoiceNo(): string {
    const company = this.getCompany();
    const sales = this.getSales();
    const count = sales.length + 1;
    const padded = String(count).padStart(3, '0');
    const prefix = company.invoicePrefix && company.invoicePrefix !== 'ASC/26-27/' && company.invoicePrefix !== 'CUS-2026-'
      ? company.invoicePrefix
      : 'CUS-INV-';
    return `${prefix}${padded}`;
  }

  /**
   * Atomic Sale Invoice Save:
   * 1. Deducts item stock
   * 2. Adds/updates invoice
   * 3. Adds Customer Ledger entry (Dr debit)
   * 4. Updates Customer outstanding balance
   * 5. Persists to Firebase Firestore (if active)
   */
  saveSaleInvoice(invoice: SalesInvoice): { success: boolean; message: string } {
    try {
      const items = this.getItems();
      const customers = this.getCustomers();
      const sales = this.getSales();
      const ledgers = this.getLedgers();

      this.deletedIds.delete(invoice.id);
      const existingIdx = sales.findIndex((s) => s.id === invoice.id);
      if (existingIdx >= 0) {
        const oldInvoice = sales[existingIdx];
        oldInvoice.items.forEach((oldItem) => {
          const it = items.find((i) => i.id === oldItem.itemId);
          if (it) {
            it.currentStock = roundTo2(it.currentStock + oldItem.quantity);
          }
        });
      }

      // Apply stock deductions
      for (const line of invoice.items) {
        const it = items.find((i) => i.id === line.itemId);
        if (it) {
          it.currentStock = roundTo2(it.currentStock - line.quantity);
        }
      }

      // Update customer balance
      const cust = customers.find((c) => c.id === invoice.customerId);
      if (cust && cust.id !== 'CUST-000') {
        cust.currentBalance = roundTo2(cust.currentBalance + invoice.balanceDue);
      }

      // Add Ledger Entry
      const newLedger: LedgerEntry = {
        id: `LED-S-${Date.now()}`,
        date: invoice.invoiceDate,
        partyType: 'Customer',
        partyId: invoice.customerId,
        partyName: invoice.customerName,
        voucherType: 'Sale',
        voucherNo: invoice.invoiceNo,
        debit: invoice.grandTotal,
        credit: invoice.amountReceived,
        runningBalance: cust ? cust.currentBalance : 0,
        narration: `Tax Invoice Sale (${invoice.totalQuantity} items). Pay Mode: ${invoice.paymentMode}`,
      };
      this.deletedIds.delete(newLedger.id);
      ledgers.push(newLedger);

      if (existingIdx >= 0) {
        sales[existingIdx] = invoice;
      } else {
        sales.push(invoice);
      }

      this.setLocalData('ITEMS', items);
      this.setLocalData('CUSTOMERS', customers);
      this.setLocalData('SALES', sales);
      this.setLocalData('LEDGERS', ledgers);
      this.notify();

      // Log to Audit Trail
      auditService.log({
        action: existingIdx >= 0 ? 'UPDATE' : 'CREATE',
        entityType: 'INVOICE',
        entityId: invoice.invoiceNo || invoice.id,
        entityName: invoice.customerName || 'Cash Customer',
        summary: `${existingIdx >= 0 ? 'Updated' : 'Created'} Sales Invoice #${invoice.invoiceNo} for ₹${invoice.grandTotal.toFixed(2)} (${invoice.customerName || 'Cash Sale'})`,
        details: {
          invoiceId: invoice.id,
          invoiceNo: invoice.invoiceNo,
          grandTotal: invoice.grandTotal,
          itemsCount: invoice.items.length,
          paymentMode: invoice.paymentMode,
        },
      });

      // Sync changes to Firestore
      this.syncSaleToFirestore(invoice, newLedger, items, cust);

      return { success: true, message: `Invoice ${invoice.invoiceNo} saved successfully!` };
    } catch (err: any) {
      return { success: false, message: `Failed to save invoice: ${err.message || err}` };
    }
  }

  private async syncSaleToFirestore(
    invoice: SalesInvoice,
    ledger: LedgerEntry,
    updatedItems: Item[],
    cust?: Customer
  ) {
    if (this.getActiveDatabaseType() !== 'firebase') return;
    try {
      const batch = writeBatch(db);
      // 1. Invoice doc
      batch.set(doc(db, COLLECTIONS.SALES, invoice.id), sanitizeForFirestore(invoice));
      // 2. Ledger doc
      batch.set(doc(db, COLLECTIONS.LEDGERS, ledger.id), sanitizeForFirestore(ledger));
      // 3. Customer doc
      if (cust) {
        batch.set(doc(db, COLLECTIONS.CUSTOMERS, cust.id), sanitizeForFirestore(cust));
      }
      // 4. Affected items
      for (const line of invoice.items) {
        const itemDoc = updatedItems.find((i) => i.id === line.itemId);
        if (itemDoc) {
          batch.set(doc(db, COLLECTIONS.ITEMS, itemDoc.id), sanitizeForFirestore(itemDoc));
        }
      }
      await batch.commit();

      // Mirror to defaultDb if available for common database access
      if (defaultDb && defaultDb !== db) {
        try {
          const dBatch = writeBatch(defaultDb);
          dBatch.set(doc(defaultDb, COLLECTIONS.SALES, invoice.id), sanitizeForFirestore(invoice));
          dBatch.set(doc(defaultDb, COLLECTIONS.LEDGERS, ledger.id), sanitizeForFirestore(ledger));
          if (cust) {
            dBatch.set(doc(defaultDb, COLLECTIONS.CUSTOMERS, cust.id), sanitizeForFirestore(cust));
          }
          for (const line of invoice.items) {
            const itemDoc = updatedItems.find((i) => i.id === line.itemId);
            if (itemDoc) {
              dBatch.set(doc(defaultDb, COLLECTIONS.ITEMS, itemDoc.id), sanitizeForFirestore(itemDoc));
            }
          }
          await dBatch.commit().catch(() => {});
        } catch {}
      }
    } catch (err) {
      console.error('Error syncing sales invoice to Firestore batch:', err);
      // Direct single writes fallback
      try {
        await this.safeSyncDocToFirestore(COLLECTIONS.SALES, invoice.id, sanitizeForFirestore(invoice));
        await this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, ledger.id, sanitizeForFirestore(ledger));
      } catch (e) {
        console.error('Direct setDoc fallback error:', e);
      }
    }
  }

  deleteSaleInvoice(invoiceId: string): { success: boolean; message: string } {
    try {
      this.deletedIds.add(invoiceId);
      const sales = this.getSales();
      const invoice = sales.find((s) => s.id === invoiceId);
      if (!invoice) return { success: false, message: 'Invoice not found.' };

      // Reverse invoice stock
      const items = this.getItems();
      invoice.items.forEach((line) => {
        const it = items.find((i) => i.id === line.itemId);
        if (it) {
          it.currentStock = roundTo2(it.currentStock + line.quantity);
        }
      });

      // Reverse customer balance
      const customers = this.getCustomers();
      const cust = customers.find((c) => c.id === invoice.customerId);
      if (cust && cust.id !== 'CUST-000') {
        cust.currentBalance = roundTo2(cust.currentBalance - invoice.balanceDue);
      }

      // Also delete any associated Sales Returns for this invoice and revert returned stock
      const allReturns = this.getSalesReturns();
      const returnsToDelete = allReturns.filter(
        (r) => r.originalInvoiceId === invoiceId || r.originalInvoiceNo === invoice.invoiceNo
      );
      const remainingReturns = allReturns.filter(
        (r) => r.originalInvoiceId !== invoiceId && r.originalInvoiceNo !== invoice.invoiceNo
      );

      returnsToDelete.forEach((ret) => {
        this.deletedIds.add(ret.id);
        ret.items.forEach((ri) => {
          const qty = ri.returnQuantity || (ri as any).quantity || 0;
          const it = items.find((i) => i.id === ri.itemId || i.itemCode === ri.itemCode);
          if (it) {
            it.currentStock = roundTo2(Math.max(0, it.currentStock - qty));
          }
        });
      });

      // Also delete any associated Sales Exchanges for this invoice and revert exchange stock
      const allExchanges = this.getSalesExchanges();
      const exchangesToDelete = allExchanges.filter(
        (e) => e.originalInvoiceId === invoiceId || e.originalInvoiceNo === invoice.invoiceNo
      );
      const remainingExchanges = allExchanges.filter(
        (e) => e.originalInvoiceId !== invoiceId && e.originalInvoiceNo !== invoice.invoiceNo
      );

      exchangesToDelete.forEach((exc) => {
        this.deletedIds.add(exc.id);
        exc.returnedItems.forEach((ri) => {
          const qty = ri.returnQuantity || (ri as any).quantity || 0;
          const it = items.find((i) => i.id === ri.itemId || i.itemCode === ri.itemCode);
          if (it) {
            it.currentStock = roundTo2(Math.max(0, it.currentStock - qty));
          }
        });
        exc.newItems.forEach((ni) => {
          const it = items.find((i) => i.id === ni.itemId || i.itemCode === ni.itemCode);
          if (it) {
            it.currentStock = roundTo2(it.currentStock + ni.quantity);
          }
        });
      });

      // Collect return and exchange voucher numbers
      const returnVoucherNos = new Set(returnsToDelete.map((r) => r.returnNo));
      const exchangeVoucherNos = new Set(exchangesToDelete.map((e) => e.exchangeNo));

      // Clean up stock movements
      const allMovements = this.getStockMovements();
      const movementsToDelete = allMovements.filter((m) => {
        if (m.originalInvoiceNo === invoice.invoiceNo) return true;
        if (m.referenceNo && (returnVoucherNos.has(m.referenceNo) || exchangeVoucherNos.has(m.referenceNo))) return true;
        return false;
      });
      movementsToDelete.forEach((m) => this.deletedIds.add(m.id));
      const remainingMovements = allMovements.filter((m) => {
        if (m.originalInvoiceNo === invoice.invoiceNo) return false;
        if (m.referenceNo && (returnVoucherNos.has(m.referenceNo) || exchangeVoucherNos.has(m.referenceNo))) return false;
        return true;
      });

      // Clean up customer credit transactions if any
      const allCreditTxns = this.getCustomerCreditTransactions();
      const creditTxnsToDelete = allCreditTxns.filter((t) => {
        if (t.referenceInvoiceNo === invoice.invoiceNo) return true;
        if (t.referenceNo && (returnVoucherNos.has(t.referenceNo) || exchangeVoucherNos.has(t.referenceNo))) return true;
        return false;
      });
      creditTxnsToDelete.forEach((t) => this.deletedIds.add(t.id));
      const remainingCreditTxns = allCreditTxns.filter((t) => {
        if (t.referenceInvoiceNo === invoice.invoiceNo) return false;
        if (t.referenceNo && (returnVoucherNos.has(t.referenceNo) || exchangeVoucherNos.has(t.referenceNo))) return false;
        return true;
      });

      // Dynamically recalculate customer store credit wallet balance based only on remaining active returns and transactions
      if (cust) {
        const remainingReturnsForCust = remainingReturns.filter((r) => r.customerId === cust.id);
        const remainingReturnedSum = remainingReturnsForCust.reduce((acc, r) => {
          const amt = (typeof r.storeCreditAmount === 'number' && r.storeCreditAmount > 0) ? r.storeCreditAmount : (r.grandTotal || 0);
          return acc + amt;
        }, 0);

        const remainingCreditTxnsForCust = remainingCreditTxns.filter((t) => t.customerId === cust.id);
        const remainingUsed = remainingCreditTxnsForCust.filter((t) => t.type === 'CREDIT_USED').reduce((acc, t) => acc + t.amount, 0);

        cust.creditBalance = roundTo2(Math.max(0, remainingReturnedSum - remainingUsed));
      }

      const updatedSales = sales.filter((s) => s.id !== invoiceId);
      const ledgersToDelete = this.getLedgers().filter((l) => {
        if (l.voucherNo === invoice.invoiceNo) return true;
        if (returnVoucherNos.has(l.voucherNo) || exchangeVoucherNos.has(l.voucherNo)) return true;
        return false;
      });
      ledgersToDelete.forEach((l) => this.deletedIds.add(l.id));
      const updatedLedgers = this.getLedgers().filter((l) => {
        if (l.voucherNo === invoice.invoiceNo) return false;
        if (returnVoucherNos.has(l.voucherNo) || exchangeVoucherNos.has(l.voucherNo)) return false;
        return true;
      });

      this.setLocalData('ITEMS', items);
      this.setLocalData('CUSTOMERS', customers);
      this.setLocalData('SALES', updatedSales);
      this.setLocalData('SALES_RETURNS', remainingReturns);
      this.setLocalData('SALES_EXCHANGES', remainingExchanges);
      this.setLocalData('STOCK_MOVEMENTS', remainingMovements);
      this.setLocalData('CUSTOMER_CREDIT_TXNS', remainingCreditTxns);
      this.setLocalData('LEDGERS', updatedLedgers);
      this.notify();

      // Log to Audit Trail
      auditService.log({
        action: 'DELETE',
        entityType: 'INVOICE',
        entityId: invoice.invoiceNo || invoice.id,
        entityName: invoice.customerName || 'Customer',
        summary: `Deleted Sales Invoice #${invoice.invoiceNo} (Amount: ₹${invoice.grandTotal.toFixed(2)}, Customer: ${invoice.customerName || 'N/A'})`,
        details: {
          invoiceId,
          invoiceNo: invoice.invoiceNo,
          grandTotal: invoice.grandTotal,
          customerName: invoice.customerName,
        },
      });

      // Async delete and update in Firestore
      this.safeSyncDeleteFromFirestore(COLLECTIONS.SALES, invoiceId).catch(console.error);
      returnsToDelete.forEach((r) => {
        this.safeSyncDeleteFromFirestore(COLLECTIONS.SALES_RETURNS, r.id).catch(console.error);
      });
      exchangesToDelete.forEach((e) => {
        this.safeSyncDeleteFromFirestore(COLLECTIONS.SALES_EXCHANGES, e.id).catch(console.error);
      });
      creditTxnsToDelete.forEach((t) => {
        this.safeSyncDeleteFromFirestore(COLLECTIONS.CUSTOMER_CREDIT_TXNS, t.id).catch(console.error);
      });
      movementsToDelete.forEach((m) => {
        this.safeSyncDeleteFromFirestore(COLLECTIONS.STOCK_MOVEMENTS, m.id).catch(console.error);
      });
      ledgersToDelete.forEach((l) => {
        this.safeSyncDeleteFromFirestore(COLLECTIONS.LEDGERS, l.id).catch(console.error);
      });
      if (cust) {
        this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, cust.id, sanitizeForFirestore(cust)).catch(console.error);
      }
      items.forEach((it) => {
        this.safeSyncDocToFirestore(COLLECTIONS.ITEMS, it.id, sanitizeForFirestore(it)).catch(console.error);
      });

      return {
        success: true,
        message: `Invoice ${invoice.invoiceNo} and all associated sales return records deleted successfully.`,
      };
    } catch (err: any) {
      return { success: false, message: `Error deleting invoice: ${err.message || err}` };
    }
  }

  purgeAllItemData(itemCodeOrId: string): {
    success: boolean;
    message: string;
  } {
    try {
      const target = (itemCodeOrId || '').trim().toUpperCase();
      if (!target) return { success: false, message: 'Invalid item code' };

      const items = this.getItems();
      const matchingItems = items.filter(
        (i) =>
          (i.itemCode && i.itemCode.trim().toUpperCase() === target) ||
          (i.id && i.id.trim().toUpperCase() === target) ||
          (i.barcode && i.barcode.trim().toUpperCase() === target) ||
          (i.itemName && i.itemName.trim().toUpperCase() === target)
      );

      const targetIds = new Set<string>();
      targetIds.add(target);
      matchingItems.forEach((i) => {
        if (i.id) targetIds.add(i.id.toUpperCase());
        if (i.itemCode) targetIds.add(i.itemCode.trim().toUpperCase());
      });

      const isTarget = (id?: string, code?: string, name?: string) => {
        const uId = (id || '').trim().toUpperCase();
        const uCode = (code || '').trim().toUpperCase();
        const uName = (name || '').trim().toUpperCase();
        return (
          (uId && targetIds.has(uId)) ||
          (uCode && targetIds.has(uCode)) ||
          (uCode && uCode === target) ||
          (uId && uId === target) ||
          (uName && uName === target)
        );
      };

      // 1. Remove from ITEMS (Catalog)
      const remainingItems = items.filter((i) => !isTarget(i.id, i.itemCode, i.itemName));
      matchingItems.forEach((i) => {
        this.deletedIds.add(i.id);
        this.safeSyncDeleteFromFirestore(COLLECTIONS.ITEMS, i.id).catch(() => {});
      });
      this.deletedIds.add(target);
      this.safeSyncDeleteFromFirestore(COLLECTIONS.ITEMS, target).catch(() => {});
      this.setLocalData('ITEMS', remainingItems);

      // 2. Remove from PURCHASES
      const purchases = this.getPurchases();
      const updatedPurchases: PurchaseInvoice[] = [];
      purchases.forEach((pur) => {
        const remainingLines = (pur.items || []).filter((li) => !isTarget(li.itemId, li.itemCode, li.itemName));
        if (remainingLines.length === 0) {
          this.deletedIds.add(pur.id);
          this.safeSyncDeleteFromFirestore(COLLECTIONS.PURCHASES, pur.id).catch(() => {});
        } else if (remainingLines.length !== (pur.items || []).length) {
          const newQty = roundTo2(remainingLines.reduce((acc, l) => acc + (l.quantity || 0), 0));
          const newSubtotal = roundTo2(remainingLines.reduce((acc, l) => acc + (l.taxableAmount || l.grossAmount || 0), 0));
          const newTax = roundTo2(remainingLines.reduce((acc, l) => acc + ((l.cgstAmount || 0) + (l.sgstAmount || 0) + (l.igstAmount || 0)), 0));
          const newGrand = Math.round(newSubtotal + newTax);
          const updatedPur: PurchaseInvoice = {
            ...pur,
            items: remainingLines,
            totalQuantity: newQty,
            totalTaxable: newSubtotal,
            totalTax: newTax,
            grandTotal: newGrand,
            balanceDue: pur.paymentMode === 'Credit' ? newGrand : 0,
          };
          updatedPurchases.push(updatedPur);
          this.safeSyncDocToFirestore(COLLECTIONS.PURCHASES, pur.id, sanitizeForFirestore(updatedPur)).catch(() => {});
        } else {
          updatedPurchases.push(pur);
        }
      });
      this.setLocalData('PURCHASES', updatedPurchases);

      // 3. Remove from PURCHASE_RETURNS
      const purReturns = this.getPurchaseReturns();
      const updatedPurReturns: PurchaseReturn[] = [];
      purReturns.forEach((pr) => {
        const remainingLines = (pr.items || []).filter((li) => !isTarget(li.itemId, li.itemCode, li.itemName));
        if (remainingLines.length === 0) {
          this.deletedIds.add(pr.id);
          this.safeSyncDeleteFromFirestore(COLLECTIONS.PURCHASE_RETURNS, pr.id).catch(() => {});
        } else {
          updatedPurReturns.push({ ...pr, items: remainingLines });
          this.safeSyncDocToFirestore(COLLECTIONS.PURCHASE_RETURNS, pr.id, sanitizeForFirestore({ ...pr, items: remainingLines })).catch(() => {});
        }
      });
      this.setLocalData('PURCHASE_RETURNS', updatedPurReturns);

      // 4. Remove from SALES
      const sales = this.getSales();
      const updatedSales: SalesInvoice[] = [];
      sales.forEach((s) => {
        const remainingLines = (s.items || []).filter((li) => !isTarget(li.itemId, li.itemCode, li.itemName));
        if (remainingLines.length === 0) {
          this.deletedIds.add(s.id);
          this.safeSyncDeleteFromFirestore(COLLECTIONS.SALES, s.id).catch(() => {});
        } else if (remainingLines.length !== (s.items || []).length) {
          const newQty = roundTo2(remainingLines.reduce((acc, l) => acc + (l.quantity || 0), 0));
          const newSubtotal = roundTo2(remainingLines.reduce((acc, l) => acc + (l.taxableAmount || l.grossAmount || 0), 0));
          const newTax = roundTo2(remainingLines.reduce((acc, l) => acc + ((l.cgstAmount || 0) + (l.sgstAmount || 0) + (l.igstAmount || 0)), 0));
          const newGrand = Math.round(newSubtotal + newTax);
          const updatedS: SalesInvoice = {
            ...s,
            items: remainingLines,
            totalQuantity: newQty,
            totalTaxable: newSubtotal,
            totalTax: newTax,
            grandTotal: newGrand,
            balanceDue: s.paymentMode === 'Credit' ? newGrand : 0,
          };
          updatedSales.push(updatedS);
          this.safeSyncDocToFirestore(COLLECTIONS.SALES, s.id, sanitizeForFirestore(updatedS)).catch(() => {});
        } else {
          updatedSales.push(s);
        }
      });
      this.setLocalData('SALES', updatedSales);

      // 5. Remove from SALES_RETURNS
      const salesReturns = this.getSalesReturns();
      const updatedSalesReturns: SalesReturn[] = [];
      salesReturns.forEach((sr) => {
        const remainingLines = (sr.items || []).filter((li) => !isTarget(li.itemId, li.itemCode, li.itemName));
        if (remainingLines.length === 0) {
          this.deletedIds.add(sr.id);
          this.safeSyncDeleteFromFirestore(COLLECTIONS.SALES_RETURNS, sr.id).catch(() => {});
        } else {
          updatedSalesReturns.push({ ...sr, items: remainingLines });
          this.safeSyncDocToFirestore(COLLECTIONS.SALES_RETURNS, sr.id, sanitizeForFirestore({ ...sr, items: remainingLines })).catch(() => {});
        }
      });
      this.setLocalData('SALES_RETURNS', updatedSalesReturns);

      // 6. Remove from ADJUSTMENTS
      const adjustments = this.getAdjustments();
      const updatedAdjustments: StockAdjustment[] = [];
      adjustments.forEach((adj) => {
        if (isTarget(adj.itemId, adj.itemCode, adj.itemName) || (adj.id && targetIds.has(adj.id.replace('ADJ-', '').toUpperCase()))) {
          this.deletedIds.add(adj.id);
          this.safeSyncDeleteFromFirestore(COLLECTIONS.ADJUSTMENTS, adj.id).catch(() => {});
        } else {
          updatedAdjustments.push(adj);
        }
      });
      this.setLocalData('ADJUSTMENTS', updatedAdjustments);

      // 7. Remove from STOCK_MOVEMENTS
      const movements = this.getStockMovements();
      const updatedMovements: StockMovement[] = [];
      movements.forEach((m) => {
        if (isTarget(m.itemId, m.itemCode)) {
          this.deletedIds.add(m.id);
          this.safeSyncDeleteFromFirestore(COLLECTIONS.STOCK_MOVEMENTS, m.id).catch(() => {});
        } else {
          updatedMovements.push(m);
        }
      });
      this.setLocalData('STOCK_MOVEMENTS', updatedMovements);

      this.notify();

      return {
        success: true,
        message: `Successfully removed all records and references for item ${itemCodeOrId} from the database.`,
      };
    } catch (err: any) {
      console.error('Error in purgeAllItemData:', err);
      return { success: false, message: `Error removing item data: ${err.message || err}` };
    }
  }

  deleteStockSheetItem(itemCodeOrId: string): {
    success: boolean;
    deletedPurchasesCount: number;
    updatedPurchasesCount: number;
    message: string;
  } {
    try {
      const target = (itemCodeOrId || '').trim().toUpperCase();
      if (!target) return { success: false, deletedPurchasesCount: 0, updatedPurchasesCount: 0, message: 'Invalid item code' };

      const items = this.getItems();
      const matchingItems = items.filter(
        (i) =>
          (i.itemCode && i.itemCode.trim().toUpperCase() === target) ||
          (i.id && i.id.trim().toUpperCase() === target) ||
          (i.barcode && i.barcode.trim().toUpperCase() === target) ||
          (i.itemName && i.itemName.trim().toUpperCase() === target)
      );

      const targetIds = new Set<string>();
      targetIds.add(target);
      matchingItems.forEach((i) => {
        if (i.id) targetIds.add(i.id.toUpperCase());
        if (i.itemCode) targetIds.add(i.itemCode.trim().toUpperCase());
      });

      const isTarget = (id?: string, code?: string, name?: string) => {
        const uId = (id || '').trim().toUpperCase();
        const uCode = (code || '').trim().toUpperCase();
        const uName = (name || '').trim().toUpperCase();
        return (
          (uId && targetIds.has(uId)) ||
          (uCode && targetIds.has(uCode)) ||
          (uCode && uCode === target) ||
          (uId && uId === target) ||
          (uName && uName === target)
        );
      };

      // 1. Remove from ITEMS (Catalog)
      const remainingItems = items.filter((i) => !isTarget(i.id, i.itemCode, i.itemName));
      matchingItems.forEach((i) => {
        this.deletedIds.add(i.id);
        this.safeSyncDeleteFromFirestore(COLLECTIONS.ITEMS, i.id).catch(() => {});
      });
      this.setLocalData('ITEMS', remainingItems);

      // 2. Remove / Update Purchases & Supplier Balances
      const purchases = this.getPurchases();
      const suppliers = this.getSuppliers();
      const updatedPurchases: PurchaseInvoice[] = [];
      let deletedPurchasesCount = 0;
      let updatedPurchasesCount = 0;

      purchases.forEach((pur) => {
        const matchingLines = (pur.items || []).filter((li) => isTarget(li.itemId, li.itemCode, li.itemName));
        if (matchingLines.length === 0) {
          updatedPurchases.push(pur);
          return;
        }

        const remainingLines = (pur.items || []).filter((li) => !isTarget(li.itemId, li.itemCode, li.itemName));

        if (remainingLines.length === 0) {
          // The entire purchase bill had only this item -> delete the bill
          deletedPurchasesCount++;
          this.deletedIds.add(pur.id);
          this.safeSyncDeleteFromFirestore(COLLECTIONS.PURCHASES, pur.id).catch(() => {});

          // Adjust supplier balance if credit
          if (pur.supplierId) {
            const sup = suppliers.find((s) => s.id === pur.supplierId);
            if (sup) {
              sup.currentBalance = roundTo2(Math.max(0, sup.currentBalance - (pur.balanceDue || 0)));
            }
          }
        } else {
          // Recompute purchase totals with remaining lines
          updatedPurchasesCount++;
          const newQty = roundTo2(remainingLines.reduce((acc, l) => acc + (l.quantity || 0), 0));
          const newGross = roundTo2(remainingLines.reduce((acc, l) => acc + (l.grossAmount || (l.quantity * l.rate) || 0), 0));
          const newDiscount = roundTo2(remainingLines.reduce((acc, l) => acc + (l.discountAmount || 0), 0));
          const newTaxable = roundTo2(remainingLines.reduce((acc, l) => acc + (l.taxableAmount || (l.grossAmount - (l.discountAmount || 0)) || 0), 0));
          const newCgst = roundTo2(remainingLines.reduce((acc, l) => acc + (l.cgstAmount || 0), 0));
          const newSgst = roundTo2(remainingLines.reduce((acc, l) => acc + (l.sgstAmount || 0), 0));
          const newIgst = roundTo2(remainingLines.reduce((acc, l) => acc + (l.igstAmount || 0), 0));
          const newTax = roundTo2(newCgst + newSgst + newIgst);
          const rawTotal = newTaxable + newTax + (pur.freightOtherCharges || 0);
          const newGrand = Math.round(rawTotal);
          const newRoundOff = roundTo2(newGrand - rawTotal);
          
          const oldGrand = pur.grandTotal || 0;
          const diffGrand = roundTo2(oldGrand - newGrand);

          let newBalanceDue = 0;
          if (pur.paymentMode === 'Credit' || pur.purchaseType === 'Credit') {
            newBalanceDue = roundTo2(Math.max(0, (pur.balanceDue || oldGrand) - diffGrand));
          }

          const updatedPur: PurchaseInvoice = {
            ...pur,
            items: remainingLines,
            totalQuantity: newQty,
            grossSubtotal: newGross,
            totalDiscount: newDiscount,
            totalTaxable: newTaxable,
            totalCgst: newCgst,
            totalSgst: newSgst,
            totalIgst: newIgst,
            totalTax: newTax,
            roundOff: newRoundOff,
            grandTotal: newGrand,
            balanceDue: newBalanceDue,
          };

          updatedPurchases.push(updatedPur);
          this.safeSyncDocToFirestore(COLLECTIONS.PURCHASES, pur.id, sanitizeForFirestore(updatedPur)).catch(() => {});

          // Adjust supplier balance for difference
          if (pur.supplierId && diffGrand !== 0) {
            const sup = suppliers.find((s) => s.id === pur.supplierId);
            if (sup) {
              sup.currentBalance = roundTo2(Math.max(0, sup.currentBalance - diffGrand));
            }
          }
        }
      });

      this.setLocalData('PURCHASES', updatedPurchases);
      this.setLocalData('SUPPLIERS', suppliers);

      // 3. Remove from Stock Adjustments
      const adjustments = this.getAdjustments();
      const updatedAdjustments = adjustments.filter((adj) => !isTarget(adj.itemId, adj.itemCode, adj.itemName));
      adjustments.forEach((adj) => {
        if (isTarget(adj.itemId, adj.itemCode, adj.itemName)) {
          this.deletedIds.add(adj.id);
          this.safeSyncDeleteFromFirestore(COLLECTIONS.ADJUSTMENTS, adj.id).catch(() => {});
        }
      });
      this.setLocalData('ADJUSTMENTS', updatedAdjustments);

      // 4. Remove from Stock Movements
      const movements = this.getStockMovements();
      const updatedMovements = movements.filter((m) => !isTarget(m.itemId, m.itemCode));
      movements.forEach((m) => {
        if (isTarget(m.itemId, m.itemCode)) {
          this.deletedIds.add(m.id);
          this.safeSyncDeleteFromFirestore(COLLECTIONS.STOCK_MOVEMENTS, m.id).catch(() => {});
        }
      });
      this.setLocalData('STOCK_MOVEMENTS', updatedMovements);

      this.notify();

      return {
        success: true,
        deletedPurchasesCount,
        updatedPurchasesCount,
        message: `Item ${itemCodeOrId} deleted from Stock Sheet and removed from all purchase bills.`,
      };
    } catch (err: any) {
      console.error('Error in deleteStockSheetItem:', err);
      return { success: false, deletedPurchasesCount: 0, updatedPurchasesCount: 0, message: `Error deleting item: ${err.message || err}` };
    }
  }

  purgeSoldEntriesForItem(itemCodeOrId: string): {
    success: boolean;
    removedCount: number;
    message: string;
  } {
    try {
      const target = itemCodeOrId.trim().toUpperCase();
      const items = this.getItems();
      const targetItem = items.find(
        (i) =>
          (i.itemCode && i.itemCode.trim().toUpperCase() === target) ||
          (i.id && i.id.trim().toUpperCase() === target)
      );
      const targetId = targetItem ? targetItem.id.toUpperCase() : target;
      const targetCode = targetItem ? (targetItem.itemCode || '').trim().toUpperCase() : target;
      const targetName = targetItem ? (targetItem.itemName || '').trim().toUpperCase() : '';

      const sales = this.getSales();
      const customers = this.getCustomers();
      const ledgers = this.getLedgers();
      const stockMovements = this.getStockMovements();
      const salesExchanges = this.getSalesExchanges();

      let totalSoldQtyRemoved = 0;
      const invoicesToSave: SalesInvoice[] = [];
      const invoiceIdsToDelete: string[] = [];
      const ledgerIdsToDelete: string[] = [];
      const updatedCustomers = new Map<string, Customer>();

      // 1. Process and remove from Sales Invoices
      for (const sale of sales) {
        if (!sale.items || sale.items.length === 0) continue;

        const matchingLines = sale.items.filter((line) => {
          const lId = (line.itemId || '').toUpperCase();
          const lCode = (line.itemCode || '').trim().toUpperCase();
          const lName = (line.itemName || '').trim().toUpperCase();
          return (
            (lId && lId === targetId) ||
            (targetCode && lCode && lCode === targetCode) ||
            (targetName && lName && lName === targetName)
          );
        });

        if (matchingLines.length === 0) {
          invoicesToSave.push(sale);
          continue;
        }

        const removedQty = matchingLines.reduce((acc, l) => acc + (l.quantity || 0), 0);
        totalSoldQtyRemoved += removedQty;

        const remainingLines = sale.items.filter((line) => !matchingLines.includes(line));

        if (remainingLines.length === 0) {
          // Entire invoice consisted of the target item -> delete the invoice
          invoiceIdsToDelete.push(sale.id);
          this.deletedIds.add(sale.id);

          // Reverse customer balance
          const cust = customers.find((c) => c.id === sale.customerId);
          if (cust && cust.id !== 'CUST-000') {
            cust.currentBalance = roundTo2(Math.max(0, cust.currentBalance - (sale.balanceDue || 0)));
            updatedCustomers.set(cust.id, cust);
          }

          // Mark customer ledger entries for deletion
          const custLedgers = ledgers.filter(
            (l) =>
              l.partyType === 'Customer' &&
              ((sale.invoiceNo && l.voucherNo === sale.invoiceNo) ||
                l.id === `LED-S-${sale.id}` ||
                (l.narration && sale.invoiceNo && l.narration.includes(sale.invoiceNo)))
          );
          custLedgers.forEach((cl) => {
            ledgerIdsToDelete.push(cl.id);
            this.deletedIds.add(cl.id);
          });
        } else {
          // Recompute remaining invoice values
          const newTotalQty = roundTo2(remainingLines.reduce((acc, l) => acc + l.quantity, 0));
          const newGrossSubtotal = roundTo2(remainingLines.reduce((acc, l) => acc + l.grossAmount, 0));
          const newTotalDiscount = roundTo2(remainingLines.reduce((acc, l) => acc + l.discountAmount, 0));
          const newTotalTaxable = roundTo2(remainingLines.reduce((acc, l) => acc + l.taxableAmount, 0));
          const newTotalCgst = roundTo2(remainingLines.reduce((acc, l) => acc + (l.cgstAmount || 0), 0));
          const newTotalSgst = roundTo2(remainingLines.reduce((acc, l) => acc + (l.sgstAmount || 0), 0));
          const newTotalIgst = roundTo2(remainingLines.reduce((acc, l) => acc + (l.igstAmount || 0), 0));
          const newTotalTax = roundTo2(newTotalCgst + newTotalSgst + newTotalIgst);
          const rawGrand = newTotalTaxable + newTotalTax;
          const newGrandTotal = Math.round(rawGrand);
          const newRoundOff = roundTo2(newGrandTotal - rawGrand);

          let newAmountReceived = 0;
          let newBalanceDue = 0;
          if (sale.paymentMode === 'Credit') {
            newAmountReceived = Math.min(sale.amountReceived, newGrandTotal);
            newBalanceDue = roundTo2(Math.max(0, newGrandTotal - newAmountReceived));
          } else {
            newAmountReceived = newGrandTotal;
            newBalanceDue = 0;
          }

          const balanceDueDiff = roundTo2(Math.max(0, (sale.balanceDue || 0) - newBalanceDue));
          const cust = customers.find((c) => c.id === sale.customerId);
          if (cust && cust.id !== 'CUST-000' && balanceDueDiff > 0) {
            cust.currentBalance = roundTo2(Math.max(0, cust.currentBalance - balanceDueDiff));
            updatedCustomers.set(cust.id, cust);
          }

          const updatedInvoice: SalesInvoice = {
            ...sale,
            items: remainingLines,
            totalQuantity: newTotalQty,
            grossSubtotal: newGrossSubtotal,
            totalDiscount: newTotalDiscount,
            totalTaxable: newTotalTaxable,
            totalCgst: newTotalCgst,
            totalSgst: newTotalSgst,
            totalIgst: newTotalIgst,
            totalTax: newTotalTax,
            roundOff: newRoundOff,
            grandTotal: newGrandTotal,
            amountReceived: newAmountReceived,
            balanceDue: newBalanceDue,
          };
          invoicesToSave.push(updatedInvoice);

          // Update ledger
          const saleLedger = ledgers.find(
            (l) =>
              l.partyType === 'Customer' &&
              ((sale.invoiceNo && l.voucherNo === sale.invoiceNo) ||
                l.id === `LED-S-${sale.id}` ||
                (l.narration && sale.invoiceNo && l.narration.includes(sale.invoiceNo)))
          );
          if (saleLedger) {
            saleLedger.debit = newGrandTotal;
            saleLedger.credit = newAmountReceived;
            if (cust) saleLedger.runningBalance = cust.currentBalance;
          }
        }
      }

      // 2. Process Sales Exchanges
      const cleanedExchanges = salesExchanges.map((ex) => {
        if (!ex.newItems || ex.newItems.length === 0) return ex;
        const matchingNew = ex.newItems.filter((ni) => {
          const lId = (ni.itemId || '').toUpperCase();
          const lCode = (ni.itemCode || '').trim().toUpperCase();
          const lName = (ni.itemName || '').trim().toUpperCase();
          return (
            (lId && lId === targetId) ||
            (targetCode && lCode && lCode === targetCode) ||
            (targetName && lName && lName === targetName)
          );
        });
        if (matchingNew.length > 0) {
          totalSoldQtyRemoved += matchingNew.reduce((acc, ni) => acc + (ni.quantity || 0), 0);
          return {
            ...ex,
            newItems: ex.newItems.filter((ni) => !matchingNew.includes(ni)),
          };
        }
        return ex;
      });

      // 3. Clean Stock Movements for target item sold
      const cleanedMovements = stockMovements.filter((m) => {
        const mItemId = (m.itemId || '').toUpperCase();
        const mItemCode = (m.itemCode || '').trim().toUpperCase();
        const isTarget = (mItemId && mItemId === targetId) || (targetCode && mItemCode && mItemCode === targetCode);
        if (isTarget && (m.movementType === 'SALE' || m.movementType === 'EXCHANGE_SALE')) {
          this.deletedIds.add(m.id);
          return false;
        }
        return true;
      });

      // 4. Update items table: restore currentStock for target item
      if (targetItem) {
        const purchases = this.getPurchases();
        let totalPurchased = (targetItem as any).openingStock || 0;
        purchases.forEach((pur) => {
          pur.items?.forEach((pi) => {
            const piId = (pi.itemId || '').toUpperCase();
            const piCode = (pi.itemCode || '').trim().toUpperCase();
            if ((piId && piId === targetId) || (targetCode && piCode && piCode === targetCode)) {
              totalPurchased = roundTo2(totalPurchased + (pi.quantity || 0));
            }
          });
        });
        targetItem.currentStock = Math.max(targetItem.currentStock, totalPurchased);
      }

      // 5. Update Ledgers
      const cleanedLedgers = ledgers.filter((l) => !ledgerIdsToDelete.includes(l.id));

      // 6. Save back to Local Storage & State
      this.setLocalData('SALES', invoicesToSave);
      this.setLocalData('ITEMS', items);
      this.setLocalData('CUSTOMERS', customers);
      this.setLocalData('LEDGERS', cleanedLedgers);
      this.setLocalData('STOCK_MOVEMENTS', cleanedMovements);
      this.setLocalData('SALES_EXCHANGES', cleanedExchanges);
      this.notify();

      // 7. Sync deletions and updates to Firestore / MongoDB
      invoiceIdsToDelete.forEach((id) => {
        this.safeSyncDeleteFromFirestore(COLLECTIONS.SALES, id).catch(() => {});
      });
      ledgerIdsToDelete.forEach((id) => {
        this.safeSyncDeleteFromFirestore(COLLECTIONS.LEDGERS, id).catch(() => {});
      });
      invoicesToSave.forEach((inv) => {
        if (invoiceIdsToDelete.includes(inv.id)) return;
        this.safeSyncDocToFirestore(COLLECTIONS.SALES, inv.id, sanitizeForFirestore(inv)).catch(() => {});
      });
      if (targetItem) {
        this.safeSyncDocToFirestore(COLLECTIONS.ITEMS, targetItem.id, sanitizeForFirestore(targetItem)).catch(() => {});
      }
      updatedCustomers.forEach((c) => {
        this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, c.id, sanitizeForFirestore(c)).catch(() => {});
      });

      return {
        success: true,
        removedCount: totalSoldQtyRemoved,
        message: `Successfully removed all sold entries (${totalSoldQtyRemoved} pairs) for item ${targetCode || target} from the database. Stock restored.`,
      };
    } catch (err: any) {
      console.error('Error purging sold entries:', err);
      return {
        success: false,
        removedCount: 0,
        message: `Error purging sold entries: ${err.message || err}`,
      };
    }
  }

  /**
   * Sets stock on hand for a specified item code or ID in the database,
   * synchronizing catalog items, adjustments, and cloud persistence.
   */
  setStockOnHandForItem(itemCodeOrId: string, targetStock: number = 1): { success: boolean; message: string } {
    try {
      const target = (itemCodeOrId || '').trim();
      if (!target) return { success: false, message: 'Invalid item code' };
      const targetUpper = target.toUpperCase();

      const items = this.getItems();
      let targetItem = items.find(
        (i) =>
          (i.itemCode && i.itemCode.trim().toUpperCase() === targetUpper) ||
          (i.id && i.id.trim().toUpperCase() === targetUpper)
      );

      const purchases = this.getPurchases();
      let totalPurchased = targetItem?.openingStock || 0;
      let purchaseRate = targetItem?.purchaseRate || 0;
      let sellingRate = targetItem?.sellingRate || 0;
      let mrp = targetItem?.mrp || 0;
      let itemName = targetItem?.itemName || target;
      let category = targetItem?.category || 'Footwear';
      let unit = targetItem?.unit || 'Pairs';
      let hsnCode = targetItem?.hsnCode || '6403';

      purchases.forEach((pur) => {
        pur.items?.forEach((pi) => {
          const piId = (pi.itemId || '').toUpperCase();
          const piCode = (pi.itemCode || '').trim().toUpperCase();
          if (piId === targetUpper || piCode === targetUpper) {
            totalPurchased = roundTo2(totalPurchased + (pi.quantity || 0));
            if (pi.rate) purchaseRate = pi.rate;
            if (pi.sellingRate) sellingRate = Number(pi.sellingRate);
            if (pi.mrp) mrp = Number(pi.mrp);
            if (pi.itemName) itemName = pi.itemName;
            if (pi.unit) unit = pi.unit;
            if (pi.hsnCode) hsnCode = pi.hsnCode;
          }
        });
      });

      if (!targetItem) {
        targetItem = {
          id: `ITEM-${targetUpper.replace(/[^A-Z0-9_-]/gi, '')}`,
          itemCode: target,
          itemName: itemName,
          category: category,
          hsnCode: hsnCode,
          unit: unit,
          purchaseRate: purchaseRate,
          sellingRate: sellingRate,
          mrp: mrp,
          gstRate: 18,
          taxType: 'Inclusive',
          minStockLevel: 10,
          openingStock: 0,
          openingStockValue: 0,
          currentStock: targetStock,
          barcode: target,
          locationRack: 'Rack A-1',
          isActive: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        items.push(targetItem);
      } else {
        targetItem.currentStock = targetStock;
      }

      // Sales outward
      const sales = this.getSales();
      let totalSold = 0;
      sales.forEach((s) => {
        s.items?.forEach((li) => {
          const rawCode = (li.itemCode || '').trim().toUpperCase();
          const rawId = (li.itemId || '').trim().toUpperCase();
          if (rawCode === targetUpper || rawId === targetUpper || (targetItem && rawId === targetItem.id.toUpperCase())) {
            totalSold = roundTo2(totalSold + (li.quantity || 0));
          }
        });
      });

      // Returns
      const salesReturns = this.getSalesReturns();
      let totalSalesRet = 0;
      salesReturns.forEach((sr) => {
        sr.items?.forEach((li) => {
          const rawCode = (li.itemCode || '').trim().toUpperCase();
          const rawId = (li.itemId || '').trim().toUpperCase();
          if (rawCode === targetUpper || rawId === targetUpper || (targetItem && rawId === targetItem.id.toUpperCase())) {
            totalSalesRet = roundTo2(totalSalesRet + (li.returnQuantity || 0));
          }
        });
      });

      const purchaseReturns = this.getPurchaseReturns();
      let totalPurRet = 0;
      purchaseReturns.forEach((pr) => {
        pr.items?.forEach((li) => {
          const rawCode = (li.itemCode || '').trim().toUpperCase();
          const rawId = (li.itemId || '').trim().toUpperCase();
          if (rawCode === targetUpper || rawId === targetUpper || (targetItem && rawId === targetItem.id.toUpperCase())) {
            totalPurRet = roundTo2(totalPurRet + (li.quantity || 0));
          }
        });
      });

      // Base calculated stock without adjustments
      const baseStock = roundTo2(totalPurchased - totalSold + totalSalesRet - totalPurRet);
      const diff = roundTo2(targetStock - baseStock);

      const adjustments = this.getAdjustments();
      const otherAdjustments = adjustments.filter((adj) => {
        const aCode = (adj.itemCode || '').trim().toUpperCase();
        const aId = (adj.itemId || '').trim().toUpperCase();
        return aCode !== targetUpper && aId !== targetUpper && (targetItem ? aId !== targetItem.id.toUpperCase() : true);
      });

      const adjRecord: StockAdjustment = {
        id: `ADJ-${targetUpper.replace(/[^A-Z0-9]/g, '')}`,
        adjustmentNo: `ADJ-${Date.now().toString().slice(-4)}`,
        adjustmentDate: new Date().toISOString().split('T')[0],
        itemId: targetItem.id,
        itemCode: targetItem.itemCode,
        itemName: targetItem.itemName,
        previousStock: baseStock,
        adjustedStock: targetStock,
        physicalStock: targetStock,
        difference: diff,
        differenceQty: diff,
        reason: `Physical stock on hand set to ${targetStock} in database`,
        createdAt: new Date().toISOString(),
      };

      const updatedAdjustments = [...otherAdjustments, adjRecord];

      this.deletedIds.delete(adjRecord.id);
      this.setLocalData('ITEMS', items);
      this.setLocalData('ADJUSTMENTS', updatedAdjustments);
      this.notify();

      this.safeSyncDocToFirestore(COLLECTIONS.ADJUSTMENTS, adjRecord.id, sanitizeForFirestore(adjRecord)).catch(console.error);
      this.safeSyncDocToFirestore(COLLECTIONS.ITEMS, targetItem.id, sanitizeForFirestore(targetItem)).catch(console.error);

      return {
        success: true,
        message: `Stock on hand for ${targetItem.itemCode} set to ${targetStock} in the database.`,
      };
    } catch (err: any) {
      console.error('Error in setStockOnHandForItem:', err);
      return { success: false, message: `Error setting stock on hand: ${err.message || err}` };
    }
  }

  // --- Purchase Invoices ---
  getPurchases(): PurchaseInvoice[] {
    return this.getLocalData<PurchaseInvoice[]>('PURCHASES', []);
  }

  getNextSupplierBillNo(): string {
    const purchases = this.getPurchases();
    const count = purchases.length + 1;
    const padded = String(count).padStart(3, '0');
    return `SUP-BILL-${padded}`;
  }

  getNextPurchaseNo(): string {
    const company = this.getCompany();
    const purchases = this.getPurchases();
    const count = purchases.length + 1;
    const padded = String(count).padStart(3, '0');
    const prefix = company.purchasePrefix && company.purchasePrefix !== 'PUR/26-27/' && company.purchasePrefix !== 'SUP-2026-' && company.purchasePrefix !== 'SUP-BILL-'
      ? company.purchasePrefix
      : 'PUR-BILL-';
    return `${prefix}${padded}`;
  }

  savePurchaseInvoice(purchase: PurchaseInvoice): { success: boolean; message: string } {
    try {
      const items = this.getItems();
      const suppliers = this.getSuppliers();
      const purchases = this.getPurchases();
      const ledgers = this.getLedgers();

      this.deletedIds.delete(purchase.id);
      let cleanLedgers = [...ledgers];
      const existingIdx = purchases.findIndex((p) => p.id === purchase.id);

      const oldLedgerIdsToDelete: string[] = [];

      if (existingIdx >= 0) {
        const oldPur = purchases[existingIdx];
        // 1. Reverse old stock
        oldPur.items.forEach((oldItem) => {
          const it = items.find((i) => i.id === oldItem.itemId);
          if (it) {
            it.currentStock = roundTo2(it.currentStock - oldItem.quantity);
          }
        });
        // 2. Reverse old supplier balance
        const oldSup = suppliers.find((s) => s.id === oldPur.supplierId);
        if (oldSup) {
          oldSup.currentBalance = roundTo2(oldSup.currentBalance - (oldPur.balanceDue || 0));
        }

        // 3. Remove old ledger entries for this purchase bill
        const matchedOldLedgers = ledgers.filter(
          (l) =>
            l.partyType === 'Supplier' &&
            (
              (oldPur.purchaseNo && l.voucherNo === oldPur.purchaseNo) ||
              (oldPur.purchaseInvoiceNo && l.voucherNo === oldPur.purchaseInvoiceNo) ||
              (oldPur.supplierBillNo && l.voucherNo === oldPur.supplierBillNo) ||
              (purchase.purchaseNo && l.voucherNo === purchase.purchaseNo) ||
              (purchase.purchaseInvoiceNo && l.voucherNo === purchase.purchaseInvoiceNo) ||
              (purchase.supplierBillNo && l.voucherNo === purchase.supplierBillNo) ||
              (l.id && (l.id === `LED-P-${oldPur.id}` || l.id === `LED-P-${purchase.id}`))
            )
        );

        matchedOldLedgers.forEach((ol) => {
          oldLedgerIdsToDelete.push(ol.id);
          this.deletedIds.add(ol.id);
        });

        cleanLedgers = cleanLedgers.filter((l) => !oldLedgerIdsToDelete.includes(l.id));
      } else {
        const existingLedgerByNo = ledgers.filter(
          (l) =>
            l.partyType === 'Supplier' &&
            (
              (purchase.purchaseNo && l.voucherNo === purchase.purchaseNo) ||
              (purchase.purchaseInvoiceNo && l.voucherNo === purchase.purchaseInvoiceNo) ||
              (purchase.supplierBillNo && l.voucherNo === purchase.supplierBillNo) ||
              (l.id && l.id === `LED-P-${purchase.id}`)
            )
        );
        existingLedgerByNo.forEach((ol) => {
          oldLedgerIdsToDelete.push(ol.id);
          this.deletedIds.add(ol.id);
        });
        cleanLedgers = cleanLedgers.filter((l) => !oldLedgerIdsToDelete.includes(l.id));
      }

      // Add new stock & update purchase rate, selling rate and MRP
      for (const line of purchase.items) {
        const lineCode = (line.itemCode || '').trim().toUpperCase();
        const lineName = (line.itemName || '').trim().toUpperCase();

        let it = items.find(
          (i) =>
            (line.itemId && i.id === line.itemId) ||
            (lineCode && i.itemCode && i.itemCode.trim().toUpperCase() === lineCode) ||
            (lineName && i.itemName && i.itemName.trim().toUpperCase() === lineName)
        );

        if (it) {
          it.currentStock = roundTo2(it.currentStock + line.quantity);
          it.purchaseRate = line.rate || it.purchaseRate;
          if (line.sellingRate !== undefined && Number(line.sellingRate) > 0) {
            it.sellingRate = Number(line.sellingRate);
          }
          if (line.mrp !== undefined && Number(line.mrp) > 0) {
            it.mrp = Number(line.mrp);
          }
        } else {
          const newItem: Item = {
            id: line.itemId || `ITM-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            itemCode: line.itemCode || `SH-${Date.now().toString().slice(-4)}`,
            barcode: (line as any).barcode || '',
            itemName: line.itemName || 'Footwear Item',
            category: (line as any).category || 'General Footwear',
            unit: line.unit || 'Pairs',
            hsnCode: line.hsnCode || '6403',
            purchaseRate: line.rate || 0,
            sellingRate: line.sellingRate !== undefined && line.sellingRate !== null ? Number(line.sellingRate) : (line.mrp || line.rate || 0),
            mrp: line.mrp !== undefined && line.mrp !== null ? Number(line.mrp) : (line.sellingRate || line.rate || 0),
            gstRate: line.gstRate || 5,
            taxType: 'Inclusive',
            openingStock: 0,
            openingStockValue: 0,
            currentStock: line.quantity || 0,
            minStockLevel: 10,
            locationRack: 'Rack A-1',
            isActive: true,
            createdAt: new Date().toISOString().split('T')[0],
            updatedAt: new Date().toISOString().split('T')[0],
          };
          items.push(newItem);
        }
      }

      // Update supplier balance
      const sup = suppliers.find((s) => s.id === purchase.supplierId);
      if (sup) {
        sup.currentBalance = roundTo2(sup.currentBalance + (purchase.balanceDue || 0));
      }

      // Reuse deterministic primary ledger ID to force in-place overwrite
      const primaryLedgerId = oldLedgerIdsToDelete[0] || `LED-P-${purchase.id}`;

      // Add single updated Ledger Entry
      const newLedger: LedgerEntry = {
        id: primaryLedgerId,
        date: purchase.purchaseDate,
        partyType: 'Supplier',
        partyId: purchase.supplierId,
        partyName: purchase.supplierName,
        voucherType: 'Purchase',
        voucherNo: purchase.purchaseNo || purchase.purchaseInvoiceNo || purchase.supplierBillNo,
        debit: purchase.amountPaid,
        credit: purchase.grandTotal,
        runningBalance: sup ? sup.currentBalance : 0,
        narration:
          purchase.items && purchase.items.length > 0
            ? `Stock Inward Bill #${purchase.purchaseNo || purchase.purchaseInvoiceNo || purchase.supplierBillNo}. (${purchase.totalQuantity} items)`
            : `Direct Purchase Voucher Bill #${purchase.purchaseNo || purchase.purchaseInvoiceNo || purchase.supplierBillNo}`,
      };
      this.deletedIds.delete(newLedger.id);
      cleanLedgers.push(newLedger);

      if (existingIdx >= 0) {
        purchases[existingIdx] = purchase;
      } else {
        purchases.push(purchase);
      }

      this.setLocalData('ITEMS', items);
      this.setLocalData('SUPPLIERS', suppliers);
      this.setLocalData('PURCHASES', purchases);
      this.setLocalData('LEDGERS', cleanLedgers);
      this.notify();

      // Log to Audit Trail
      auditService.log({
        action: existingIdx >= 0 ? 'UPDATE' : 'CREATE',
        entityType: 'PURCHASE_BILL',
        entityId: purchase.purchaseNo || purchase.purchaseInvoiceNo || purchase.id,
        entityName: purchase.supplierName,
        summary: `${existingIdx >= 0 ? 'Updated' : 'Recorded'} Purchase Inward Bill #${purchase.purchaseNo || purchase.purchaseInvoiceNo || purchase.id} from ${purchase.supplierName} for ₹${purchase.grandTotal.toFixed(2)}`,
        details: {
          billNumber: purchase.purchaseNo,
          supplierName: purchase.supplierName,
          grandTotal: purchase.grandTotal,
        },
      });

      // Sync to Firestore and purge obsolete ledger documents
      this.syncPurchaseToFirestore(purchase, newLedger, items, sup, oldLedgerIdsToDelete);

      return { success: true, message: `Purchase Bill ${purchase.purchaseNo} recorded successfully!` };
    } catch (err: any) {
      return { success: false, message: `Failed to save purchase: ${err.message || err}` };
    }
  }

  private async syncPurchaseToFirestore(
    purchase: PurchaseInvoice,
    ledger: LedgerEntry,
    updatedItems: Item[],
    sup?: Supplier,
    deletedLedgerIds: string[] = []
  ) {
    if (this.getActiveDatabaseType() !== 'firebase') return;
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, COLLECTIONS.PURCHASES, purchase.id), sanitizeForFirestore(purchase));
      batch.set(doc(db, COLLECTIONS.LEDGERS, ledger.id), sanitizeForFirestore(ledger));
      if (sup) {
        batch.set(doc(db, COLLECTIONS.SUPPLIERS, sup.id), sanitizeForFirestore(sup));
      }
      for (const line of purchase.items) {
        const itemDoc = updatedItems.find((i) => i.id === line.itemId);
        if (itemDoc) {
          batch.set(doc(db, COLLECTIONS.ITEMS, itemDoc.id), sanitizeForFirestore(itemDoc));
        }
      }
      for (const oldId of deletedLedgerIds) {
        if (oldId && oldId !== ledger.id) {
          batch.delete(doc(db, COLLECTIONS.LEDGERS, oldId));
        }
      }
      await batch.commit();

      // Mirror to defaultDb if available for common database access
      if (defaultDb && defaultDb !== db) {
        try {
          const dBatch = writeBatch(defaultDb);
          dBatch.set(doc(defaultDb, COLLECTIONS.PURCHASES, purchase.id), sanitizeForFirestore(purchase));
          dBatch.set(doc(defaultDb, COLLECTIONS.LEDGERS, ledger.id), sanitizeForFirestore(ledger));
          if (sup) {
            dBatch.set(doc(defaultDb, COLLECTIONS.SUPPLIERS, sup.id), sanitizeForFirestore(sup));
          }
          for (const line of purchase.items) {
            const itemDoc = updatedItems.find((i) => i.id === line.itemId);
            if (itemDoc) {
              dBatch.set(doc(defaultDb, COLLECTIONS.ITEMS, itemDoc.id), sanitizeForFirestore(itemDoc));
            }
          }
          for (const oldId of deletedLedgerIds) {
            if (oldId && oldId !== ledger.id) {
              dBatch.delete(doc(defaultDb, COLLECTIONS.LEDGERS, oldId));
            }
          }
          await dBatch.commit().catch(() => {});
        } catch {}
      }
    } catch (err) {
      console.error('Error syncing purchase invoice to Firestore:', err);
      try {
        await this.safeSyncDocToFirestore(COLLECTIONS.PURCHASES, purchase.id, sanitizeForFirestore(purchase));
        await this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, ledger.id, sanitizeForFirestore(ledger));
        for (const oldId of deletedLedgerIds) {
          if (oldId && oldId !== ledger.id) {
            await this.safeSyncDeleteFromFirestore(COLLECTIONS.LEDGERS, oldId).catch(() => {});
          }
        }
      } catch (e) {
        console.error('Direct purchase setDoc fallback error:', e);
      }
    }
  }

  deletePurchaseInvoice(purchaseId: string): { success: boolean; message: string } {
    try {
      this.deletedIds.add(purchaseId);
      const purchases = this.getPurchases();
      const pur = purchases.find((p) => p.id === purchaseId);
      if (!pur) return { success: false, message: 'Purchase record not found.' };

      // Reverse stock
      const items = this.getItems();
      pur.items.forEach((line) => {
        const it = items.find((i) => i.id === line.itemId);
        if (it) {
          it.currentStock = roundTo2(it.currentStock - line.quantity);
        }
      });

      // Reverse supplier balance
      const suppliers = this.getSuppliers();
      const sup = suppliers.find((s) => s.id === pur.supplierId);
      if (sup) {
        sup.currentBalance = roundTo2(sup.currentBalance - pur.balanceDue);
      }

      const updatedPurchases = purchases.filter((p) => p.id !== purchaseId);
      const ledgersToDelete = this.getLedgers().filter(
        (l) =>
          l.partyType === 'Supplier' &&
          (
            (pur.purchaseNo && l.voucherNo === pur.purchaseNo) ||
            (pur.purchaseInvoiceNo && l.voucherNo === pur.purchaseInvoiceNo) ||
            (pur.supplierBillNo && l.voucherNo === pur.supplierBillNo) ||
            (l.id && (l.id === `LED-P-${pur.id}` || l.id.includes(pur.id))) ||
            (l.narration && pur.supplierBillNo && l.narration.includes(pur.supplierBillNo)) ||
            (l.narration && pur.purchaseNo && l.narration.includes(pur.purchaseNo))
          )
      );
      ledgersToDelete.forEach((l) => this.deletedIds.add(l.id));
      const updatedLedgers = this.getLedgers().filter((l) => !ledgersToDelete.some((dl) => dl.id === l.id));

      this.setLocalData('ITEMS', items);
      this.setLocalData('SUPPLIERS', suppliers);
      this.setLocalData('PURCHASES', updatedPurchases);
      this.setLocalData('LEDGERS', updatedLedgers);
      this.notify();

      this.safeSyncDeleteFromFirestore(COLLECTIONS.PURCHASES, purchaseId).catch(console.error);
      ledgersToDelete.forEach((l) => this.safeSyncDeleteFromFirestore(COLLECTIONS.LEDGERS, l.id).catch(console.error));
      if (sup) {
        this.safeSyncDocToFirestore(COLLECTIONS.SUPPLIERS, sup.id, sanitizeForFirestore(sup)).catch(console.error);
      }
      items.forEach((it) => this.safeSyncDocToFirestore(COLLECTIONS.ITEMS, it.id, sanitizeForFirestore(it)).catch(console.error));

      return { success: true, message: `Purchase ${pur.purchaseNo} deleted from database.` };
    } catch (err: any) {
      return { success: false, message: `Error deleting purchase: ${err.message || err}` };
    }
  }

  // --- Sales Returns & Exchanges ---
  getSalesReturns(): SalesReturn[] {
    return this.getLocalData<SalesReturn[]>('SALES_RETURNS', []);
  }

  getSalesExchanges(): SalesExchange[] {
    return this.getLocalData<SalesExchange[]>('SALES_EXCHANGES', []);
  }

  getSalesExchangeDeskRecords(): SalesExchangeDeskRecord[] {
    return this.getLocalData<SalesExchangeDeskRecord[]>('SALES_EXCHANGE_DESK', []);
  }

  getStockMovements(): StockMovement[] {
    return this.getLocalData<StockMovement[]>('STOCK_MOVEMENTS', []);
  }

  getCustomerCreditTransactions(): CustomerCreditTransaction[] {
    return this.getLocalData<CustomerCreditTransaction[]>('CUSTOMER_CREDIT_TXNS', []);
  }

  getCustomerCreditBalance(customerId: string, customerName?: string, customerMobile?: string): number {
    const customers = this.getCustomers();
    let cust = customers.find((c) => c.id === customerId);
    if (!cust && customerMobile) {
      cust = customers.find((c) => c.mobile === customerMobile);
    }
    if (!cust && customerName && customerName !== 'Walk-in Customer' && customerName !== 'Counter Sale') {
      cust = customers.find((c) => c.customerName.toLowerCase() === customerName.toLowerCase());
    }

    // Find all returns belonging to this customer
    const returns = this.getSalesReturns().filter((r) => {
      if (customerId && customerId !== 'CUST-000' && r.customerId === customerId) return true;
      if (cust && r.customerId === cust.id) return true;
      if (customerMobile && r.customerMobile && r.customerMobile === customerMobile) return true;
      if (customerName && customerName !== 'Walk-in Customer' && customerName !== 'Counter Sale' && r.customerName?.toLowerCase() === customerName.toLowerCase()) return true;
      return false;
    });

    // Calculate sum of returned items
    const totalReturnedSum = returns.reduce((acc, r) => {
      const amt = (typeof r.storeCreditAmount === 'number' && r.storeCreditAmount > 0) ? r.storeCreditAmount : (r.grandTotal || 0);
      return acc + amt;
    }, 0);

    // Find all credit transactions for this customer
    const txns = this.getCustomerCreditTransactions().filter((t) => {
      if (customerId && customerId !== 'CUST-000' && t.customerId === customerId) return true;
      if (cust && t.customerId === cust.id) return true;
      return false;
    });
    const totalUsed = txns.filter((t) => t.type === 'CREDIT_USED').reduce((acc, t) => acc + t.amount, 0);

    let balance = 0;
    if (cust && typeof cust.creditBalance === 'number' && cust.creditBalance > 0) {
      balance = cust.creditBalance;
    } else {
      balance = Math.max(0, totalReturnedSum - totalUsed);
      if (cust && balance > 0 && (!cust.creditBalance || cust.creditBalance < balance)) {
        cust.creditBalance = balance;
        localStorage.setItem(this.getKey('CUSTOMERS'), JSON.stringify(customers));
        this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, cust.id, sanitizeForFirestore(cust)).catch(console.error);
      }
    }

    return roundTo2(Math.max(balance, totalReturnedSum - totalUsed));
  }

  getNextReturnNo(): string {
    const returns = this.getSalesReturns();
    const count = returns.length + 1;
    return `RET-${String(count).padStart(4, '0')}`;
  }

  getNextExchangeNo(): string {
    const exchanges = this.getSalesExchanges();
    const count = exchanges.length + 1;
    return `EXC-${String(count).padStart(4, '0')}`;
  }

  /**
   * Returnable item quantity breakdown for an invoice.
   * Considers all previous returns and exchanges referencing this invoice.
   */
  getReturnableItemQuantities(invoiceId: string): Array<{
    id: string;
    itemId: string;
    itemCode: string;
    itemName: string;
    hsnCode: string;
    unit: string;
    soldQuantity: number;
    previouslyReturnedQty: number;
    remainingReturnableQty: number;
    rate: number;
    discountPercent: number;
    discountAmount: number;
    taxableAmount: number;
    gstRate: number;
    cgstRate: number;
    cgstAmount: number;
    sgstRate: number;
    sgstAmount: number;
    igstRate: number;
    igstAmount: number;
    netAmount: number;
  }> {
    const sales = this.getSales();
    const invoice = sales.find((s) => s.id === invoiceId || s.invoiceNo === invoiceId);
    if (!invoice || !invoice.items) return [];

    const returns = this.getSalesReturns().filter(
      (r) => r.originalInvoiceId === invoice.id || r.originalInvoiceNo === invoice.invoiceNo
    );

    return (invoice.items || []).map((line) => {
      let previouslyReturned = 0;
      returns.forEach((r) => {
        (r.items || []).forEach((ri) => {
          if (
            (line.id && ri.id && line.id === ri.id) ||
            (ri.itemId === line.itemId && (line.itemId !== 'ITEM-MANUAL' || ri.itemName === line.itemName))
          ) {
            previouslyReturned += ri.returnQuantity || 0;
          }
        });
      });

      const remaining = Math.max(0, roundTo2(line.quantity));
      const totalOriginallySold = roundTo2(line.quantity + previouslyReturned);

      return {
        id: line.id || line.itemId,
        itemId: line.itemId,
        itemCode: line.itemCode,
        itemName: line.itemName,
        hsnCode: line.hsnCode || '6403',
        unit: line.unit || 'PRS',
        soldQuantity: totalOriginallySold > 0 ? totalOriginallySold : line.quantity,
        previouslyReturnedQty: previouslyReturned,
        remainingReturnableQty: remaining,
        rate: line.rate,
        discountPercent: line.discountPercent || 0,
        discountAmount: line.discountAmount || 0,
        taxableAmount: line.taxableAmount || 0,
        gstRate: line.gstRate || 0,
        cgstRate: line.cgstRate || 0,
        cgstAmount: line.cgstAmount || 0,
        sgstRate: line.sgstRate || 0,
        sgstAmount: line.sgstAmount || 0,
        igstRate: line.igstRate || 0,
        igstAmount: line.igstAmount || 0,
        netAmount: line.netAmount,
      };
    });
  }

  getInvoiceReturnHistory(invoiceId: string): {
    returns: SalesReturn[];
    exchanges: SalesExchange[];
    totalReturnedAmount: number;
    totalExchangedAmount: number;
  } {
    const sales = this.getSales();
    const invoice = sales.find((s) => s.id === invoiceId || s.invoiceNo === invoiceId);
    if (!invoice) return { returns: [], exchanges: [], totalReturnedAmount: 0, totalExchangedAmount: 0 };

    const returns = this.getSalesReturns().filter(
      (r) => r.originalInvoiceId === invoice.id || r.originalInvoiceNo === invoice.invoiceNo
    );
    const exchanges = this.getSalesExchanges().filter(
      (e) => e.originalInvoiceId === invoice.id || e.originalInvoiceNo === invoice.invoiceNo
    );

    const totalReturnedAmount = returns.reduce((sum, r) => sum + r.grandTotal, 0);
    const totalExchangedAmount = exchanges.reduce((sum, e) => sum + e.returnedTotalValue, 0);

    return {
      returns,
      exchanges,
      totalReturnedAmount: roundTo2(totalReturnedAmount),
      totalExchangedAmount: roundTo2(totalExchangedAmount),
    };
  }

  calculateInvoiceReturnStatus(invoice: SalesInvoice): InvoiceReturnStatus {
    const returns = this.getSalesReturns().filter(
      (r) => r.originalInvoiceId === invoice.id || r.originalInvoiceNo === invoice.invoiceNo
    );
    const exchanges = this.getSalesExchanges().filter(
      (e) => e.originalInvoiceId === invoice.id || e.originalInvoiceNo === invoice.invoiceNo
    );

    if (returns.length === 0 && exchanges.length === 0) {
      return 'NO_RETURN';
    }

    if (!invoice.items || invoice.items.length === 0 || invoice.totalQuantity === 0) {
      return exchanges.length > 0 ? 'EXCHANGED' : 'FULLY_RETURNED';
    }

    return exchanges.length > 0 ? 'PARTIALLY_EXCHANGED' : 'PARTIALLY_RETURNED';
  }

  /**
   * Process and save a pure Sales Return transaction:
   * 1. Validates return quantities against remaining returnable limits.
   * 2. Increases item inventory stock immediately (+qty).
   * 3. Creates StockMovement log entries.
   * 4. If refundMode is Store Credit / Customer Credit, credits customer wallet & records credit transaction.
   * 5. If registered customer and Credit Note, updates outstanding.
   * 6. Appends Ledger Entry for actual transaction date.
   * 7. Updates original invoice status without modifying invoice date or items.
   * 8. Performs atomic Firestore commit.
   */
  saveSalesReturn(sr: SalesReturn): { success: boolean; message: string; returnTransaction?: SalesReturn } {
    try {
      const items = this.getItems();
      const customers = this.getCustomers();
      const returns = this.getSalesReturns();
      const ledgers = this.getLedgers();
      const stockMovements = this.getStockMovements();
      const creditTxns = this.getCustomerCreditTransactions();
      const sales = this.getSales();

      // Check original invoice
      const invoiceIdx = sales.findIndex(
        (s) => s.id === sr.originalInvoiceId || s.invoiceNo === sr.originalInvoiceNo
      );
      if (invoiceIdx < 0) {
        return { success: false, message: `Original invoice ${sr.originalInvoiceNo || sr.originalInvoiceId} not found.` };
      }
      const originalInvoice = sales[invoiceIdx];

      // Validate quantities
      const returnableInfo = this.getReturnableItemQuantities(originalInvoice.id);
      for (const line of sr.items) {
        const qtyToReturn = line.returnQuantity || (line as any).quantity || 0;
        if (qtyToReturn <= 0) {
          return { success: false, message: `Invalid return quantity for item ${line.itemName}. Must be > 0.` };
        }
        const itemInfo = returnableInfo.find((i) => i.itemId === line.itemId || i.itemCode === line.itemCode);
        if (!itemInfo) {
          return { success: false, message: `Item ${line.itemName} was not present in original invoice.` };
        }
        if (qtyToReturn > itemInfo.remainingReturnableQty) {
          return {
            success: false,
            message: `Cannot return ${qtyToReturn} units of ${line.itemName}. Only ${itemInfo.remainingReturnableQty} units remaining returnable.`,
          };
        }
      }

      // 1. Stock Inward for Returned Items
      const createdStockMovements: StockMovement[] = [];
      const updatedItemsList: Item[] = [];

      for (const line of sr.items) {
        const qtyToReturn = line.returnQuantity || (line as any).quantity || 0;
        const it = items.find((i) => i.id === line.itemId || i.itemCode === line.itemCode);
        if (it) {
          it.currentStock = roundTo2(it.currentStock + qtyToReturn);
          updatedItemsList.push(it);

          const movement: StockMovement = {
            id: `SM-RET-${Date.now()}-${line.itemId}`,
            date: sr.returnDate,
            time: sr.returnTime || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
            itemId: it.id,
            itemCode: it.itemCode,
            itemName: it.itemName,
            movementType: 'SALES_RETURN',
            quantity: qtyToReturn,
            referenceNo: sr.returnNo,
            originalInvoiceNo: sr.originalInvoiceNo,
            particulars: `Sales Return against ${sr.originalInvoiceNo} (${sr.reason || 'Customer Return'})`,
            createdAt: new Date().toISOString(),
          };
          stockMovements.push(movement);
          createdStockMovements.push(movement);
        }
      }

      // 2. Recalculate original invoice items and totals
      const updatedInvoiceItems: InvoiceItem[] = [];
      const returnQtyTracker: { [key: string]: number } = {};
      sr.items.forEach((ri) => {
        const k = ri.id || ri.itemId;
        returnQtyTracker[k] = (returnQtyTracker[k] || 0) + (ri.returnQuantity || (ri as any).quantity || 0);
      });

      for (const line of (originalInvoice.items || [])) {
        // Match specific line or item
        const retLine = sr.items.find((ri) => {
          if (line.id && ri.id && line.id === ri.id) {
            return true;
          }
          if (ri.itemId === line.itemId) {
            if (line.itemId === 'ITEM-MANUAL') {
              return ri.itemName === line.itemName;
            }
            return true;
          }
          return false;
        });

        if (retLine) {
          const key = retLine.id || retLine.itemId;
          const availableToReturn = returnQtyTracker[key] || 0;

          if (availableToReturn > 0) {
            const qtyDeducted = Math.min(line.quantity, availableToReturn);
            returnQtyTracker[key] = roundTo2(availableToReturn - qtyDeducted);
            const remainingQty = roundTo2(line.quantity - qtyDeducted);

            if (remainingQty > 0) {
              // Case b: item has remaining quantity > 0, update line quantity as per return
              const rate = line.rate || 0;
              const grossAmount = roundTo2(remainingQty * rate);
              const discountPercent = line.discountPercent || 0;
              const discountAmount = roundTo2((grossAmount * discountPercent) / 100);
              const taxableAmount = roundTo2(grossAmount - discountAmount);
              
              const cgstAmount = line.cgstRate ? roundTo2((taxableAmount * line.cgstRate) / 100) : 0;
              const sgstAmount = line.sgstRate ? roundTo2((taxableAmount * line.sgstRate) / 100) : 0;
              const igstAmount = line.igstRate ? roundTo2((taxableAmount * line.igstRate) / 100) : 0;
              const netAmount = roundTo2(taxableAmount + cgstAmount + sgstAmount + igstAmount);

              updatedInvoiceItems.push({
                ...line,
                quantity: remainingQty,
                grossAmount,
                discountAmount,
                taxableAmount,
                cgstAmount,
                sgstAmount,
                igstAmount,
                netAmount,
              });
            }
            // If remainingQty === 0: Case a & c: item is fully returned and thus removed from the bill
            continue;
          }
        }

        // Line is not returned -> kept on the bill
        updatedInvoiceItems.push({ ...line });
      }

      // Recalculate invoice totals
      const newTotalQty = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.quantity, 0)) : 0;
      const newGrossSubtotal = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.grossAmount, 0)) : 0;
      const newTotalDiscount = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.discountAmount, 0)) : 0;
      const newTotalTaxable = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.taxableAmount, 0)) : 0;
      const newTotalCgst = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.cgstAmount, 0)) : 0;
      const newTotalSgst = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.sgstAmount, 0)) : 0;
      const newTotalIgst = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.igstAmount, 0)) : 0;
      const newTotalTax = roundTo2(newTotalCgst + newTotalSgst + newTotalIgst);
      const rawGrand = newTotalTaxable + newTotalTax;
      const roundedGrand = Math.round(rawGrand);
      const newRoundOff = roundTo2(roundedGrand - rawGrand);
      const newGrandTotal = updatedInvoiceItems.length > 0 ? roundedGrand : 0;

      let newAmountReceived = 0;
      let newBalanceDue = 0;
      if (updatedInvoiceItems.length === 0) {
        // Case c: all items returned, keep bill with zero values
        newAmountReceived = 0;
        newBalanceDue = 0;
      } else {
        if (originalInvoice.paymentMode === 'Credit') {
          newAmountReceived = Math.min(originalInvoice.amountReceived, newGrandTotal);
          newBalanceDue = roundTo2(Math.max(0, newGrandTotal - newAmountReceived));
        } else {
          newAmountReceived = newGrandTotal;
          newBalanceDue = 0;
        }
      }

      const oldBalanceDue = originalInvoice.balanceDue || 0;
      const balanceDueDiff = roundTo2(Math.max(0, oldBalanceDue - newBalanceDue));
      const overpaidAmount = roundTo2(Math.max(0, originalInvoice.amountReceived - newAmountReceived));
      const updatedReturnStatus: InvoiceReturnStatus = updatedInvoiceItems.length === 0 ? 'FULLY_RETURNED' : 'PARTIALLY_RETURNED';

      // 3. Customer Credit & Balance Updates
      let cust = customers.find((c) => c.id === sr.customerId);
      if (!cust && sr.customerMobile) {
        cust = customers.find((c) => c.mobile === sr.customerMobile);
      }
      if (!cust && sr.customerName && sr.customerName !== 'Walk-in Customer' && sr.customerName !== 'Counter Sale') {
        cust = customers.find((c) => c.customerName.toLowerCase() === sr.customerName.toLowerCase());
      }

      const isStoreCredit = sr.refundMode === 'Store Credit' || sr.refundMode === 'Customer Credit' || (sr.storeCreditAmount && sr.storeCreditAmount > 0);
      let creditTxn: CustomerCreditTransaction | null = null;

      if (cust) {
        // Adjust customer outstanding balance if debt has decreased
        if (balanceDueDiff > 0 && cust.id !== 'CUST-000') {
          cust.currentBalance = roundTo2(Math.max(0, cust.currentBalance - balanceDueDiff));
        }

        // Issue Store Credit refund for any overpaid/returned cash
        const refundValue = overpaidAmount > 0 ? overpaidAmount : (originalInvoice.paymentMode === 'Credit' ? 0 : sr.grandTotal);
        if (refundValue > 0 && cust.id !== 'CUST-000') {
          const prevCredit = cust.creditBalance || 0;
          const newCredit = roundTo2(prevCredit + refundValue);
          cust.creditBalance = newCredit;

          creditTxn = {
            id: `CCT-${Date.now()}`,
            customerId: cust.id,
            customerName: cust.customerName,
            transactionDate: sr.returnDate,
            transactionTime: sr.returnTime || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
            type: 'CREDIT_ISSUED',
            amount: refundValue,
            previousBalance: prevCredit,
            newBalance: newCredit,
            referenceType: 'SALES_RETURN',
            referenceNo: sr.returnNo,
            referenceInvoiceNo: sr.originalInvoiceNo,
            narration: `Store Credit issued for Sales Return ${sr.returnNo} against ${sr.originalInvoiceNo}`,
            createdAt: new Date().toISOString(),
          };
          creditTxns.push(creditTxn);
        }
      }

      // 4. Update Ledgers and post Sales Return entry
      // A) Locate and update the original sale ledger entry to keep everything in sync
      const originalSaleLedgerIdx = ledgers.findIndex(
        (l) => l.voucherType === 'Sale' && l.voucherNo === originalInvoice.invoiceNo
      );
      if (originalSaleLedgerIdx >= 0) {
        ledgers[originalSaleLedgerIdx].debit = newGrandTotal;
        ledgers[originalSaleLedgerIdx].credit = newAmountReceived;
        if (cust) {
          ledgers[originalSaleLedgerIdx].runningBalance = cust.currentBalance;
        }
      }

      // B) Post Sales Return entry
      const returnRefundValue = overpaidAmount > 0 ? overpaidAmount : (originalInvoice.paymentMode === 'Credit' ? 0 : sr.grandTotal);
      const ledgerEntry: LedgerEntry = {
        id: `LED-SR-${Date.now()}`,
        date: sr.returnDate,
        partyType: 'Customer',
        partyId: sr.customerId,
        partyName: sr.customerName,
        voucherType: isStoreCredit ? 'Customer Credit' : 'Sale Return',
        voucherNo: sr.returnNo,
        debit: 0,
        credit: returnRefundValue,
        runningBalance: cust ? (cust.creditBalance || 0) : 0,
        narration: `Sales Return against Invoice ${sr.originalInvoiceNo}. Refunded to Wallet: ₹${returnRefundValue}. Reason: ${sr.reason || 'Normal'}`,
      };
      ledgers.push(ledgerEntry);
      returns.push(sr);

      // Update invoice record
      sales[invoiceIdx] = {
        ...originalInvoice,
        items: updatedInvoiceItems,
        totalQuantity: newTotalQty,
        grossSubtotal: newGrossSubtotal,
        totalDiscount: newTotalDiscount,
        totalTaxable: newTotalTaxable,
        totalCgst: newTotalCgst,
        totalSgst: newTotalSgst,
        totalIgst: newTotalIgst,
        totalTax: newTotalTax,
        roundOff: newRoundOff,
        grandTotal: newGrandTotal,
        amountReceived: newAmountReceived,
        balanceDue: newBalanceDue,
        returnStatus: updatedReturnStatus,
      };

      // Persist to local storage
      this.deletedIds.delete(sr.id);
      this.deletedIds.delete(ledgerEntry.id);
      this.setLocalData('SALES_RETURNS', returns);
      this.setLocalData('ITEMS', items);
      this.setLocalData('CUSTOMERS', customers);
      this.setLocalData('LEDGERS', ledgers);
      this.setLocalData('STOCK_MOVEMENTS', stockMovements);
      this.setLocalData('CUSTOMER_CREDIT_TXNS', creditTxns);
      this.setLocalData('SALES', sales);
      this.notify();

      // Async atomic writeBatch to Firestore (if active)
      if (this.getActiveDatabaseType() === 'firebase') {
        const batch = writeBatch(db);
        batch.set(doc(db, COLLECTIONS.SALES_RETURNS, sr.id), sanitizeForFirestore(sr));
        batch.set(doc(db, COLLECTIONS.LEDGERS, ledgerEntry.id), sanitizeForFirestore(ledgerEntry));
        batch.set(doc(db, COLLECTIONS.SALES, originalInvoice.id), sanitizeForFirestore(sales[invoiceIdx]));

        if (originalSaleLedgerIdx >= 0) {
          batch.set(doc(db, COLLECTIONS.LEDGERS, ledgers[originalSaleLedgerIdx].id), sanitizeForFirestore(ledgers[originalSaleLedgerIdx]));
        }
        if (cust) {
          batch.set(doc(db, COLLECTIONS.CUSTOMERS, cust.id), sanitizeForFirestore(cust));
        }
        if (creditTxn) {
          batch.set(doc(db, COLLECTIONS.CUSTOMER_CREDIT_TXNS, creditTxn.id), sanitizeForFirestore(creditTxn));
        }
        for (const sm of createdStockMovements) {
          batch.set(doc(db, COLLECTIONS.STOCK_MOVEMENTS, sm.id), sanitizeForFirestore(sm));
        }
        for (const itm of updatedItemsList) {
          batch.set(doc(db, COLLECTIONS.ITEMS, itm.id), sanitizeForFirestore(itm));
        }
        batch.commit().catch((err) => console.error('Firestore batch commit error in saveSalesReturn:', err));

        // Mirror to defaultDb if available
        if (defaultDb && defaultDb !== db) {
          try {
            const dBatch = writeBatch(defaultDb);
            dBatch.set(doc(defaultDb, COLLECTIONS.SALES_RETURNS, sr.id), sanitizeForFirestore(sr));
            dBatch.set(doc(defaultDb, COLLECTIONS.LEDGERS, ledgerEntry.id), sanitizeForFirestore(ledgerEntry));
            dBatch.set(doc(defaultDb, COLLECTIONS.SALES, originalInvoice.id), sanitizeForFirestore(sales[invoiceIdx]));
            if (originalSaleLedgerIdx >= 0) {
              dBatch.set(doc(defaultDb, COLLECTIONS.LEDGERS, ledgers[originalSaleLedgerIdx].id), sanitizeForFirestore(ledgers[originalSaleLedgerIdx]));
            }
            if (cust) {
              dBatch.set(doc(defaultDb, COLLECTIONS.CUSTOMERS, cust.id), sanitizeForFirestore(cust));
            }
            if (creditTxn) {
              dBatch.set(doc(defaultDb, COLLECTIONS.CUSTOMER_CREDIT_TXNS, creditTxn.id), sanitizeForFirestore(creditTxn));
            }
            for (const sm of createdStockMovements) {
              dBatch.set(doc(defaultDb, COLLECTIONS.STOCK_MOVEMENTS, sm.id), sanitizeForFirestore(sm));
            }
            for (const itm of updatedItemsList) {
              dBatch.set(doc(defaultDb, COLLECTIONS.ITEMS, itm.id), sanitizeForFirestore(itm));
            }
            dBatch.commit().catch(() => {});
          } catch {}
        }
      }

      return {
        success: true,
        message: `Sales Return ${sr.returnNo} recorded successfully! Stock restored and refund issued.`,
        returnTransaction: sr,
      };
    } catch (err: any) {
      return { success: false, message: `Error saving sales return: ${err.message || err}` };
    }
  }

  /**
   * Updates credit amount status for an existing Sales Return transaction.
   */
  updateSalesReturnCreditStatus(returnId: string, status: 'Credit Amount Pending' | 'Credit Amount Taken'): { success: boolean; message: string } {
    try {
      const returns = this.getSalesReturns();
      const idx = returns.findIndex((r) => r.id === returnId);
      if (idx < 0) {
        return { success: false, message: 'Sales Return transaction not found.' };
      }
      returns[idx].creditAmountStatus = status;
      this.setLocalData('SALES_RETURNS', returns);
      this.notify();

      this.safeSyncDocToFirestore(COLLECTIONS.SALES_RETURNS, returns[idx].id, sanitizeForFirestore(returns[idx])).catch(console.error);

      return { success: true, message: `Status updated to "${status}".` };
    } catch (err: any) {
      return { success: false, message: `Error updating return status: ${err.message || err}` };
    }
  }

  /**
   * Process and save a Sales Exchange transaction:
   * 1. Validates returned items <= returnable limit.
   * 2. Validates new exchange items from stock.
   * 3. Increases stock for returned items (+qty) -> 'SALES_RETURN'.
   * 4. Decreases stock for new items (-qty) -> 'EXCHANGE_SALE'.
   * 5. Handles 3 settlement cases:
   *    - Case 1: New > Returned (Customer pays difference via Cash/UPI/Card/Customer Credit).
   *    - Case 2: Returned > New (Customer refunded or Store Credit issued).
   *    - Case 3: New == Returned (Diff = 0).
   * 6. Appends stock movements and ledger entries for actual exchange date.
   * 7. Updates original invoice status.
   * 8. Performs atomic Firestore commit.
   */
  saveSalesExchange(exchange: SalesExchange): { success: boolean; message: string; exchangeTransaction?: SalesExchange } {
    try {
      const items = this.getItems();
      const customers = this.getCustomers();
      const exchanges = this.getSalesExchanges();
      const ledgers = this.getLedgers();
      const stockMovements = this.getStockMovements();
      const creditTxns = this.getCustomerCreditTransactions();
      const sales = this.getSales();

      // Check original invoice
      const invoiceIdx = sales.findIndex(
        (s) => s.id === exchange.originalInvoiceId || s.invoiceNo === exchange.originalInvoiceNo
      );
      if (invoiceIdx < 0) {
        return { success: false, message: `Original invoice ${exchange.originalInvoiceNo || exchange.originalInvoiceId} not found.` };
      }
      const originalInvoice = sales[invoiceIdx];

      // Validate returned items
      const returnableInfo = this.getReturnableItemQuantities(originalInvoice.id);
      for (const line of exchange.returnedItems) {
        const qtyToReturn = line.returnQuantity || (line as any).quantity || 0;
        if (qtyToReturn <= 0) {
          return { success: false, message: `Invalid return quantity for item ${line.itemName}. Must be > 0.` };
        }
        const itemInfo = returnableInfo.find((i) => i.itemId === line.itemId || i.itemCode === line.itemCode);
        if (!itemInfo) {
          return { success: false, message: `Item ${line.itemName} was not present in original invoice.` };
        }
        if (qtyToReturn > itemInfo.remainingReturnableQty) {
          return {
            success: false,
            message: `Cannot return ${qtyToReturn} units of ${line.itemName}. Only ${itemInfo.remainingReturnableQty} units remaining returnable.`,
          };
        }
      }

      // Validate new exchange items
      if (!exchange.newItems || exchange.newItems.length === 0) {
        return { success: false, message: 'Exchange must include at least one new item. For pure returns, use Return mode.' };
      }

      // Stock operations
      const createdStockMovements: StockMovement[] = [];
      const updatedItemsList: Item[] = [];

      // 1. Stock Inward for Returned Items
      for (const line of exchange.returnedItems) {
        const qtyToReturn = line.returnQuantity || (line as any).quantity || 0;
        const it = items.find((i) => i.id === line.itemId || i.itemCode === line.itemCode);
        if (it) {
          it.currentStock = roundTo2(it.currentStock + qtyToReturn);
          updatedItemsList.push(it);

          const movement: StockMovement = {
            id: `SM-EXC-RET-${Date.now()}-${line.itemId}`,
            date: exchange.exchangeDate,
            time: exchange.exchangeTime || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
            itemId: it.id,
            itemCode: it.itemCode,
            itemName: it.itemName,
            movementType: 'SALES_RETURN',
            quantity: qtyToReturn,
            referenceNo: exchange.exchangeNo,
            originalInvoiceNo: exchange.originalInvoiceNo,
            particulars: `Exchange Return against ${exchange.originalInvoiceNo} (${exchange.reason || 'Size/Model Exchange'})`,
            createdAt: new Date().toISOString(),
          };
          stockMovements.push(movement);
          createdStockMovements.push(movement);
        }
      }

      // 2. Stock Outward for New Items
      for (const line of exchange.newItems) {
        const it = items.find((i) => i.id === line.itemId || i.itemCode === line.itemCode);
        if (it) {
          it.currentStock = roundTo2(it.currentStock - line.quantity);
          updatedItemsList.push(it);

          const movement: StockMovement = {
            id: `SM-EXC-NEW-${Date.now()}-${line.itemId}`,
            date: exchange.exchangeDate,
            time: exchange.exchangeTime || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
            itemId: it.id,
            itemCode: it.itemCode,
            itemName: it.itemName,
            movementType: 'EXCHANGE_SALE',
            quantity: -line.quantity,
            referenceNo: exchange.exchangeNo,
            originalInvoiceNo: exchange.originalInvoiceNo,
            particulars: `Exchange Issued against ${exchange.originalInvoiceNo}`,
            createdAt: new Date().toISOString(),
          };
          stockMovements.push(movement);
          createdStockMovements.push(movement);
        }
      }

      // 3. Customer Settlement
      const cust = customers.find((c) => c.id === exchange.customerId);
      const createdCreditTxns: CustomerCreditTransaction[] = [];

      // If customer credit used towards new items
      if (exchange.customerCreditUsed && exchange.customerCreditUsed > 0 && cust) {
        const prevCredit = cust.creditBalance || 0;
        const newCredit = roundTo2(Math.max(0, prevCredit - exchange.customerCreditUsed));
        cust.creditBalance = newCredit;

        const creditUseTxn: CustomerCreditTransaction = {
          id: `CCT-USE-${Date.now()}`,
          customerId: cust.id,
          customerName: cust.customerName,
          transactionDate: exchange.exchangeDate,
          transactionTime: exchange.exchangeTime || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
          type: 'CREDIT_USED',
          amount: exchange.customerCreditUsed,
          previousBalance: prevCredit,
          newBalance: newCredit,
          referenceType: 'SALES_EXCHANGE',
          referenceNo: exchange.exchangeNo,
          referenceInvoiceNo: exchange.originalInvoiceNo,
          narration: `Customer Credit used in Exchange ${exchange.exchangeNo}`,
          createdAt: new Date().toISOString(),
        };
        creditTxns.push(creditUseTxn);
        createdCreditTxns.push(creditUseTxn);
      }

      // If store credit issued to customer
      if (exchange.storeCreditAmount && exchange.storeCreditAmount > 0 && cust) {
        const prevCredit = cust.creditBalance || 0;
        const newCredit = roundTo2(prevCredit + exchange.storeCreditAmount);
        cust.creditBalance = newCredit;

        const creditIssueTxn: CustomerCreditTransaction = {
          id: `CCT-ISS-${Date.now()}`,
          customerId: cust.id,
          customerName: cust.customerName,
          transactionDate: exchange.exchangeDate,
          transactionTime: exchange.exchangeTime || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
          type: 'CREDIT_ISSUED',
          amount: exchange.storeCreditAmount,
          previousBalance: prevCredit,
          newBalance: newCredit,
          referenceType: 'SALES_EXCHANGE',
          referenceNo: exchange.exchangeNo,
          referenceInvoiceNo: exchange.originalInvoiceNo,
          narration: `Store Credit balance issued for Exchange difference ${exchange.exchangeNo}`,
          createdAt: new Date().toISOString(),
        };
        creditTxns.push(creditIssueTxn);
        createdCreditTxns.push(creditIssueTxn);
      }

      // 4. Ledger Entry
      const ledgerEntry: LedgerEntry = {
        id: `LED-EXC-${Date.now()}`,
        date: exchange.exchangeDate,
        partyType: 'Customer',
        partyId: exchange.customerId,
        partyName: exchange.customerName,
        voucherType: 'Sale Exchange',
        voucherNo: exchange.exchangeNo,
        debit: exchange.newTotalValue,
        credit: roundTo2(exchange.returnedTotalValue + (exchange.additionalAmountPaid || 0)),
        runningBalance: cust ? (cust.creditBalance || cust.currentBalance || 0) : 0,
        narration: `Exchange (${exchange.returnedTotalQuantity} returned vs ${exchange.newTotalQuantity} new). Ref: ${exchange.originalInvoiceNo}`,
      };
      this.deletedIds.delete(exchange.id);
      this.deletedIds.delete(ledgerEntry.id);
      ledgers.push(ledgerEntry);
      exchanges.push(exchange);

      this.setLocalData('SALES_EXCHANGES', exchanges);
      const updatedStatus = this.calculateInvoiceReturnStatus(sales[invoiceIdx]);
      sales[invoiceIdx].returnStatus = updatedStatus;

      // Persist to localStorage
      this.setLocalData('ITEMS', items);
      this.setLocalData('CUSTOMERS', customers);
      this.setLocalData('LEDGERS', ledgers);
      this.setLocalData('STOCK_MOVEMENTS', stockMovements);
      this.setLocalData('CUSTOMER_CREDIT_TXNS', creditTxns);
      this.setLocalData('SALES', sales);
      this.notify();

      // Async atomic writeBatch to Firestore (if active)
      if (this.getActiveDatabaseType() === 'firebase') {
        const batch = writeBatch(db);
        batch.set(doc(db, COLLECTIONS.SALES_EXCHANGES, exchange.id), sanitizeForFirestore(exchange));
        batch.set(doc(db, COLLECTIONS.LEDGERS, ledgerEntry.id), sanitizeForFirestore(ledgerEntry));
        batch.set(doc(db, COLLECTIONS.SALES, originalInvoice.id), sanitizeForFirestore(sales[invoiceIdx]));

        if (cust) {
          batch.set(doc(db, COLLECTIONS.CUSTOMERS, cust.id), sanitizeForFirestore(cust));
        }
        for (const ctx of createdCreditTxns) {
          batch.set(doc(db, COLLECTIONS.CUSTOMER_CREDIT_TXNS, ctx.id), sanitizeForFirestore(ctx));
        }
        for (const sm of createdStockMovements) {
          batch.set(doc(db, COLLECTIONS.STOCK_MOVEMENTS, sm.id), sanitizeForFirestore(sm));
        }
        for (const itm of updatedItemsList) {
          batch.set(doc(db, COLLECTIONS.ITEMS, itm.id), sanitizeForFirestore(itm));
        }
        batch.commit().catch((err) => console.error('Firestore batch commit error in saveSalesExchange:', err));

        // Mirror to defaultDb if available
        if (defaultDb && defaultDb !== db) {
          try {
            const dBatch = writeBatch(defaultDb);
            dBatch.set(doc(defaultDb, COLLECTIONS.SALES_EXCHANGES, exchange.id), sanitizeForFirestore(exchange));
            dBatch.set(doc(defaultDb, COLLECTIONS.LEDGERS, ledgerEntry.id), sanitizeForFirestore(ledgerEntry));
            dBatch.set(doc(defaultDb, COLLECTIONS.SALES, originalInvoice.id), sanitizeForFirestore(sales[invoiceIdx]));
            if (cust) {
              dBatch.set(doc(defaultDb, COLLECTIONS.CUSTOMERS, cust.id), sanitizeForFirestore(cust));
            }
            for (const ctx of createdCreditTxns) {
              dBatch.set(doc(defaultDb, COLLECTIONS.CUSTOMER_CREDIT_TXNS, ctx.id), sanitizeForFirestore(ctx));
            }
            for (const sm of createdStockMovements) {
              dBatch.set(doc(defaultDb, COLLECTIONS.STOCK_MOVEMENTS, sm.id), sanitizeForFirestore(sm));
            }
            for (const itm of updatedItemsList) {
              dBatch.set(doc(defaultDb, COLLECTIONS.ITEMS, itm.id), sanitizeForFirestore(itm));
            }
            dBatch.commit().catch(() => {});
          } catch {}
        }
      }

      return {
        success: true,
        message: `Sales Exchange ${exchange.exchangeNo} processed successfully! Inventory updated and settlement recorded.`,
        exchangeTransaction: exchange,
      };
    } catch (err: any) {
      return { success: false, message: `Error saving sales exchange: ${err.message || err}` };
    }
  }

  // --- Sales Exchange Desk Records ---
  saveSalesExchangeDeskRecord(record: SalesExchangeDeskRecord): {
    success: boolean;
    message: string;
    record?: SalesExchangeDeskRecord;
  } {
    try {
      this.deletedIds.delete(record.id);
      const cleanRecord: SalesExchangeDeskRecord = {
        ...record,
        billModifiedDate: record.billModifiedDate || new Date().toISOString().split('T')[0],
      };

      // Guard: Do not save to exchange desk if invoice date and modified date are identical (same-day modification)
      if (cleanRecord.invoiceDate && cleanRecord.billModifiedDate && cleanRecord.invoiceDate === cleanRecord.billModifiedDate) {
        return { success: true, message: 'Skipped exchange desk record for same-day modification', record: cleanRecord };
      }
      const records = this.getSalesExchangeDeskRecords();
      const existingIdx = records.findIndex((r) => r.id === cleanRecord.id);
      if (existingIdx >= 0) {
        records[existingIdx] = cleanRecord;
      } else {
        records.unshift(cleanRecord);
      }
      this.setLocalData('SALES_EXCHANGE_DESK', records);
      this.notify();

      this.safeSyncDocToFirestore(COLLECTIONS.SALES_EXCHANGE_DESK, cleanRecord.id, sanitizeForFirestore(cleanRecord)).catch((err) =>
        console.error('Firestore saveSalesExchangeDeskRecord error:', err)
      );
      return { success: true, message: 'Sales exchange desk record saved successfully', record: cleanRecord };
    } catch (err: any) {
      return { success: false, message: `Error saving exchange record: ${err.message || err}` };
    }
  }

  deleteSalesExchangeDeskRecord(id: string): { success: boolean; message: string } {
    try {
      this.deletedIds.add(id);
      const records = this.getSalesExchangeDeskRecords().filter((r) => r.id !== id);
      this.setLocalData('SALES_EXCHANGE_DESK', records);
      this.notify();

      this.safeSyncDeleteFromFirestore(COLLECTIONS.SALES_EXCHANGE_DESK, id).catch((err) =>
        console.error('Firestore deleteSalesExchangeDeskRecord error:', err)
      );
      return { success: true, message: 'Record deleted' };
    } catch (err: any) {
      return { success: false, message: err.message || err };
    }
  }

  // --- Purchase Returns ---
  getPurchaseReturns(): PurchaseReturn[] {
    return this.getLocalData<PurchaseReturn[]>('PURCHASE_RETURNS', []);
  }

  savePurchaseReturn(pr: PurchaseReturn): { success: boolean; message: string } {
    try {
      const items = this.getItems();
      const suppliers = this.getSuppliers();
      const returns = this.getPurchaseReturns();
      const ledgers = this.getLedgers();

      for (const line of pr.items) {
        const it = items.find((i) => i.id === line.itemId);
        if (it) {
          it.currentStock = roundTo2(it.currentStock - line.quantity);
        }
      }

      const sup = suppliers.find((s) => s.id === pr.supplierId);
      if (sup) {
        sup.currentBalance = roundTo2(sup.currentBalance - pr.grandTotal);
      }

      const ledgerEntry: LedgerEntry = {
        id: `LED-PR-${Date.now()}`,
        date: pr.returnDate,
        partyType: 'Supplier',
        partyId: pr.supplierId,
        partyName: pr.supplierName,
        voucherType: 'Purchase Return',
        voucherNo: pr.returnNo,
        debit: pr.grandTotal,
        credit: 0,
        runningBalance: sup ? sup.currentBalance : 0,
        narration: `Debit Note against Ref ${pr.originalPurchaseNo || 'Direct'}. Reason: ${pr.reason || 'None'}`,
      };
      this.deletedIds.delete(pr.id);
      this.deletedIds.delete(ledgerEntry.id);
      ledgers.push(ledgerEntry);
      returns.push(pr);

      this.setLocalData('ITEMS', items);
      this.setLocalData('SUPPLIERS', suppliers);
      this.setLocalData('PURCHASE_RETURNS', returns);
      this.setLocalData('LEDGERS', ledgers);
      this.notify();

      this.safeSyncDocToFirestore(COLLECTIONS.PURCHASE_RETURNS, pr.id, sanitizeForFirestore(pr)).catch(console.error);
      this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, ledgerEntry.id, sanitizeForFirestore(ledgerEntry)).catch(console.error);

      return { success: true, message: `Purchase Return ${pr.returnNo} recorded.` };
    } catch (err: any) {
      return { success: false, message: `Error saving purchase return: ${err.message || err}` };
    }
  }

  // --- Customer Receipts ---
  getReceipts(): CustomerReceipt[] {
    return this.getLocalData<CustomerReceipt[]>('CUSTOMER_RECEIPTS', []);
  }

  parse2026ReceiptNumber(receiptNo: any): number | null {
    if (!receiptNo || typeof receiptNo !== 'string') return null;
    const trimmed = receiptNo.trim();
    const match = trimmed.match(/^RCT-2026-(\d+)$/i);
    if (match && match[1]) {
      const num = parseInt(match[1], 10);
      return isNaN(num) ? null : num;
    }
    return null;
  }

  getMaxReceiptSeq2026(): number {
    let maxSeq = 0;

    try {
      const stored = localStorage.getItem('arco_max_receipt_seq_2026_v1');
      if (stored) {
        const val = parseInt(stored, 10);
        if (!isNaN(val) && val > maxSeq) {
          maxSeq = val;
        }
      }
    } catch (e) {
      // ignore
    }

    const receipts = this.getReceipts();
    receipts.forEach((r) => {
      if (r && r.receiptNo) {
        const num = this.parse2026ReceiptNumber(r.receiptNo);
        if (num !== null && num > maxSeq) {
          maxSeq = num;
        }
      }
    });

    if (this.deletedIds && this.deletedIds.size > 0) {
      this.deletedIds.forEach((idOrNo) => {
        if (typeof idOrNo === 'string') {
          const num = this.parse2026ReceiptNumber(idOrNo);
          if (num !== null && num > maxSeq) {
            maxSeq = num;
          }
        }
      });
    }

    return maxSeq;
  }

  setMaxReceiptSeq2026(seq: number): void {
    try {
      const current = this.getMaxReceiptSeq2026();
      const newMax = Math.max(current, seq);
      localStorage.setItem('arco_max_receipt_seq_2026_v1', String(newMax));
    } catch (e) {
      // ignore
    }
  }

  getNextReceiptNo(): string {
    const maxSeq = this.getMaxReceiptSeq2026();
    const nextNum = maxSeq + 1;
    return `RCT-2026-${String(nextNum).padStart(3, '0')}`;
  }

  saveCustomerReceipt(rec: CustomerReceipt): { success: boolean; message: string; receiptNo?: string } {
    try {
      let receipts = this.getReceipts();

      // Duplicate & Concurrency check
      let targetNo = rec.receiptNo ? rec.receiptNo.trim() : '';
      let parsedNum = this.parse2026ReceiptNumber(targetNo);

      let isDuplicate =
        !targetNo ||
        receipts.some((r) => r.receiptNo && r.receiptNo.trim().toUpperCase() === targetNo.toUpperCase()) ||
        (this.deletedIds && (this.deletedIds.has(targetNo) || this.deletedIds.has(targetNo.toUpperCase())));

      if (isDuplicate || parsedNum === null) {
        let nextSeq = this.getMaxReceiptSeq2026() + 1;
        let candidate = `RCT-2026-${String(nextSeq).padStart(3, '0')}`;

        while (
          receipts.some((r) => r.receiptNo && r.receiptNo.trim().toUpperCase() === candidate.toUpperCase()) ||
          (this.deletedIds && (this.deletedIds.has(candidate) || this.deletedIds.has(candidate.toUpperCase())))
        ) {
          nextSeq++;
          candidate = `RCT-2026-${String(nextSeq).padStart(3, '0')}`;
        }

        targetNo = candidate;
        parsedNum = nextSeq;
      }

      rec.receiptNo = targetNo;

      if (parsedNum !== null) {
        this.setMaxReceiptSeq2026(parsedNum);
      }

      const customers = this.getCustomers();
      const ledgers = this.getLedgers();

      const cust = customers.find((c) => c.id === rec.customerId);
      const totalRelief = rec.amountReceived + rec.discountAllowed;
      if (cust) {
        cust.currentBalance = roundTo2(cust.currentBalance - totalRelief);
      }

      const ledgerEntry: LedgerEntry = {
        id: `LED-CR-${rec.id}`,
        date: rec.receiptDate,
        partyType: 'Customer',
        partyId: rec.customerId,
        partyName: rec.customerName,
        voucherType: 'Receipt',
        voucherNo: rec.receiptNo,
        debit: 0,
        credit: totalRelief,
        runningBalance: cust ? cust.currentBalance : 0,
        narration: `Payment received (${rec.paymentMode}) Ref: ${rec.referenceNo || 'Cash'}. Disc Allowed: ${rec.discountAllowed}${rec.remarks ? ` - ${rec.remarks}` : ''}`,
      };
      this.deletedIds.delete(rec.id);
      this.deletedIds.delete(ledgerEntry.id);
      ledgers.push(ledgerEntry);
      receipts.push(rec);

      this.setLocalData('CUSTOMERS', customers);
      this.setLocalData('CUSTOMER_RECEIPTS', receipts);
      this.setLocalData('LEDGERS', ledgers);
      this.notify();

      this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMER_RECEIPTS, rec.id, sanitizeForFirestore(rec)).catch(console.error);
      this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, ledgerEntry.id, sanitizeForFirestore(ledgerEntry)).catch(console.error);
      if (cust) {
        this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, cust.id, sanitizeForFirestore(cust)).catch(console.error);
      }

      return { success: true, message: `Receipt ${rec.receiptNo} saved.`, receiptNo: rec.receiptNo };
    } catch (err: any) {
      return { success: false, message: `Error saving receipt: ${err.message || err}` };
    }
  }

  deleteCustomerReceipt(receiptId: string): { success: boolean; message: string } {
    try {
      this.deletedIds.add(receiptId);
      const receipts = this.getReceipts();
      const recIndex = receipts.findIndex((r) => r.id === receiptId);
      if (recIndex === -1) {
        return { success: false, message: 'Receipt record not found.' };
      }
      const rec = receipts[recIndex];
      const totalRelief = (rec.amountReceived || 0) + (rec.discountAllowed || 0);

      this.deletedIds.add(rec.id);
      if (rec.receiptNo) {
        this.deletedIds.add(rec.receiptNo);
        this.deletedIds.add(rec.receiptNo.toUpperCase());
        const num = this.parse2026ReceiptNumber(rec.receiptNo);
        if (num !== null) {
          this.setMaxReceiptSeq2026(num);
        }
      }

      // Revert customer balance
      const customers = this.getCustomers();
      const cust = customers.find((c) => c.id === rec.customerId);
      if (cust) {
        cust.currentBalance = roundTo2((cust.currentBalance || 0) + totalRelief);
        this.setLocalData('CUSTOMERS', customers);
        this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, cust.id, sanitizeForFirestore(cust)).catch(console.error);
      }

      // Remove ledger entries associated with this receipt
      const ledgers = this.getLedgers();
      const recNoUpper = rec.receiptNo ? rec.receiptNo.trim().toUpperCase() : '';
      const ledgersToDelete = ledgers.filter(
        (l) =>
          (l.voucherType === 'Receipt' && l.voucherNo && l.voucherNo.trim().toUpperCase() === recNoUpper) ||
          (l.id && (l.id === `LED-CR-${rec.id}` || l.id === `LED-CR-${rec.receiptNo}`))
      );
      ledgersToDelete.forEach((l) => {
        this.deletedIds.add(l.id);
        this.safeSyncDeleteFromFirestore(COLLECTIONS.LEDGERS, l.id).catch(console.error);
      });

      const updatedLedgers = ledgers.filter(
        (l) =>
          !(
            (l.voucherType === 'Receipt' && l.voucherNo && l.voucherNo.trim().toUpperCase() === recNoUpper) ||
            (l.id && (l.id === `LED-CR-${rec.id}` || l.id === `LED-CR-${rec.receiptNo}`))
          )
      );
      this.setLocalData('LEDGERS', updatedLedgers);

      // Remove from receipts list
      const remainingReceipts = receipts.filter((r) => r.id !== receiptId);
      this.setLocalData('CUSTOMER_RECEIPTS', remainingReceipts);
      this.safeSyncDeleteFromFirestore(COLLECTIONS.CUSTOMER_RECEIPTS, receiptId).catch(console.error);

      this.notify();
      return { success: true, message: `Receipt ${rec.receiptNo} deleted successfully.` };
    } catch (err: any) {
      return { success: false, message: `Error deleting receipt: ${err.message || err}` };
    }
  }

  updateCustomerReceipt(rec: CustomerReceipt): { success: boolean; message: string } {
    try {
      const receipts = this.getReceipts();
      const recIndex = receipts.findIndex((r) => r.id === rec.id);
      if (recIndex === -1) {
        return { success: false, message: 'Receipt record not found.' };
      }
      const oldRec = receipts[recIndex];
      const oldRelief = (oldRec.amountReceived || 0) + (oldRec.discountAllowed || 0);
      const newRelief = (rec.amountReceived || 0) + (rec.discountAllowed || 0);

      const customers = this.getCustomers();

      // Recalculate customer balance
      if (oldRec.customerId !== rec.customerId) {
        const oldCust = customers.find((c) => c.id === oldRec.customerId);
        if (oldCust) {
          oldCust.currentBalance = roundTo2((oldCust.currentBalance || 0) + oldRelief);
          this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, oldCust.id, sanitizeForFirestore(oldCust)).catch(console.error);
        }
        const newCust = customers.find((c) => c.id === rec.customerId);
        if (newCust) {
          newCust.currentBalance = roundTo2((newCust.currentBalance || 0) - newRelief);
          this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, newCust.id, sanitizeForFirestore(newCust)).catch(console.error);
        }
      } else {
        const cust = customers.find((c) => c.id === rec.customerId);
        if (cust) {
          cust.currentBalance = roundTo2((cust.currentBalance || 0) + oldRelief - newRelief);
          this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, cust.id, sanitizeForFirestore(cust)).catch(console.error);
        }
      }
      this.setLocalData('CUSTOMERS', customers);

      const updatedReceipts = receipts.map((r) => (r.id === rec.id ? { ...rec } : r));
      this.setLocalData('CUSTOMER_RECEIPTS', updatedReceipts);
      this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMER_RECEIPTS, rec.id, sanitizeForFirestore(rec)).catch(console.error);

      // Update ledger entry
      const ledgers = this.getLedgers();
      const custObj = customers.find((c) => c.id === rec.customerId);
      const oldRecNoUpper = oldRec.receiptNo ? oldRec.receiptNo.trim().toUpperCase() : '';
      const ledgerIndices = ledgers.map((l, i) => i).filter(
        (i) =>
          (ledgers[i].voucherNo && ledgers[i].voucherNo.trim().toUpperCase() === oldRecNoUpper) ||
          (ledgers[i].id && (ledgers[i].id === `LED-CR-${rec.id}` || ledgers[i].id === rec.id))
      );
      if (ledgerIndices.length > 0) {
        ledgerIndices.forEach((index) => {
          ledgers[index] = {
            ...ledgers[index],
            date: rec.receiptDate,
            partyId: rec.customerId,
            partyName: rec.customerName,
            voucherNo: rec.receiptNo,
            credit: newRelief,
            runningBalance: custObj ? custObj.currentBalance : 0,
            narration: `Payment received (${rec.paymentMode}) Ref: ${rec.referenceNo || 'Cash'}. Disc Allowed: ${rec.discountAllowed}${rec.remarks ? ` - ${rec.remarks}` : ''}`,
          };
          this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, ledgers[index].id, sanitizeForFirestore(ledgers[index])).catch(console.error);
        });
      } else {
        const newLedger: LedgerEntry = {
          id: `LED-CR-${rec.id}`,
          date: rec.receiptDate,
          partyType: 'Customer',
          partyId: rec.customerId,
          partyName: rec.customerName,
          voucherType: 'Receipt',
          voucherNo: rec.receiptNo,
          debit: 0,
          credit: newRelief,
          runningBalance: custObj ? custObj.currentBalance : 0,
          narration: `Payment received (${rec.paymentMode}) Ref: ${rec.referenceNo || 'Cash'}. Disc Allowed: ${rec.discountAllowed}${rec.remarks ? ` - ${rec.remarks}` : ''}`,
        };
        ledgers.push(newLedger);
        this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, newLedger.id, sanitizeForFirestore(newLedger)).catch(console.error);
      }
      this.setLocalData('LEDGERS', ledgers);

      this.notify();
      return { success: true, message: `Receipt ${rec.receiptNo} updated successfully.` };
    } catch (err: any) {
      return { success: false, message: `Error updating receipt: ${err.message || err}` };
    }
  }

  // --- Supplier Payments ---
  getPayments(): SupplierPayment[] {
    const rawList = this.getLocalData<SupplierPayment[]>('PAYMENTS', []);
    const list = rawList.filter((p) => !this.deletedIds.has(p.id) && (!p.voucherNo || (!this.deletedIds.has(p.voucherNo) && !this.deletedIds.has(p.voucherNo.toUpperCase()))));
    // Also include any supplier payment ledgers if not already present in PAYMENTS
    const ledgers = this.getLedgers().filter(
      (l) => l.partyType === 'Supplier' && (l.voucherType?.toUpperCase() === 'PAYMENT') && !this.deletedIds.has(l.id) && (!l.voucherNo || (!this.deletedIds.has(l.voucherNo) && !this.deletedIds.has(l.voucherNo.toUpperCase())))
    );
    const existingVoucherNos = new Set(list.map((p) => p.voucherNo?.toUpperCase()));
    let hasNew = false;
    for (const l of ledgers) {
      const vNoUpper = l.voucherNo?.toUpperCase();
      if (l.voucherNo && !existingVoucherNos.has(vNoUpper) && !this.deletedIds.has(l.voucherNo) && !this.deletedIds.has(vNoUpper)) {
        const sup = this.getSuppliers().find((s) => s.id === l.partyId);
        const synth: SupplierPayment = {
          id: l.id.startsWith('LED-SP-') ? l.id.replace('LED-SP-', '') : `SP-${l.id}`,
          voucherNo: l.voucherNo,
          voucherDate: l.date,
          supplierId: l.partyId,
          supplierName: l.partyName || sup?.supplierName || 'Supplier',
          paymentMode: 'Cash',
          previousBalance: (l.runningBalance || 0) + (l.debit || 0),
          amountPaid: l.debit || 0,
          discountReceived: 0,
          newBalance: l.runningBalance || 0,
          remarks: l.narration,
          createdAt: l.date,
        };
        list.push(synth);
        existingVoucherNos.add(vNoUpper);
        hasNew = true;
      }
    }
    if (hasNew) {
      this.setLocalData('PAYMENTS', list);
    }
    return [...list];
  }

  getNextPaymentVoucherNo(): string {
    const payments = this.getPayments();
    let maxNum = 0;
    const regex = /^PMT-2026-(\d{3,})$/;

    payments.forEach((p) => {
      if (p.voucherNo) {
        const match = p.voucherNo.trim().toUpperCase().match(regex);
        if (match) {
          const num = parseInt(match[1], 10);
          if (!isNaN(num) && num > maxNum) {
            maxNum = num;
          }
        }
      }
    });

    const nextNum = maxNum + 1;
    return `PMT-2026-${String(nextNum).padStart(3, '0')}`;
  }

  saveSupplierPayment(pay: SupplierPayment): { success: boolean; message: string } {
    try {
      // Duplicate check
      const payments = this.getPayments();
      if (payments.some((p) => p.voucherNo === pay.voucherNo)) {
         return { success: false, message: `Voucher number ${pay.voucherNo} already exists.` };
      }
      
      const suppliers = this.getSuppliers();
      const ledgers = this.getLedgers();

      const sup = suppliers.find((s) => s.id === pay.supplierId);
      const totalReduction = pay.amountPaid + pay.discountReceived;
      if (sup) {
        sup.currentBalance = roundTo2(sup.currentBalance - totalReduction);
      }

      const ledgerEntry: LedgerEntry = {
        id: `LED-SP-${pay.id}`,
        date: pay.voucherDate,
        partyType: 'Supplier',
        partyId: pay.supplierId,
        partyName: pay.supplierName,
        voucherType: 'Payment',
        voucherNo: pay.voucherNo,
        debit: totalReduction,
        credit: 0,
        runningBalance: sup ? sup.currentBalance : 0,
        narration: `Payment issued to Supplier (${pay.paymentMode}) Ref: ${pay.referenceNo || 'Cash'}. Disc: ${pay.discountReceived || 0}${pay.remarks ? ` - ${pay.remarks}` : ''}`,
      };
      this.deletedIds.delete(pay.id);
      if (pay.voucherNo) {
        this.deletedIds.delete(pay.voucherNo);
        this.deletedIds.delete(pay.voucherNo.toUpperCase());
      }
      this.deletedIds.delete(ledgerEntry.id);
      ledgers.push(ledgerEntry);
      payments.push(pay);

      this.setLocalData('SUPPLIERS', suppliers);
      this.setLocalData('PAYMENTS', payments);
      this.setLocalData('LEDGERS', ledgers);
      this.notify();

      this.safeSyncDocToFirestore(COLLECTIONS.PAYMENTS, pay.id, sanitizeForFirestore(pay)).catch(console.error);
      this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, ledgerEntry.id, sanitizeForFirestore(ledgerEntry)).catch(console.error);
      if (sup) {
        this.safeSyncDocToFirestore(COLLECTIONS.SUPPLIERS, sup.id, sanitizeForFirestore(sup)).catch(console.error);
      }

      return { success: true, message: `Payment ${pay.voucherNo} saved.` };
    } catch (err: any) {
      return { success: false, message: `Error saving payment: ${err.message || err}` };
    }
  }

  deleteSupplierPayment(paymentId: string): { success: boolean; message: string } {
    try {
      this.deletedIds.add(paymentId);
      const payments = this.getPayments();
      const payIndex = payments.findIndex((p) => p.id === paymentId);
      if (payIndex === -1) {
        return { success: false, message: 'Payment voucher not found.' };
      }
      const pay = payments[payIndex];
      const totalReduction = (pay.amountPaid || 0) + (pay.discountReceived || 0);

      this.deletedIds.add(pay.id);
      if (pay.voucherNo) {
        this.deletedIds.add(pay.voucherNo);
        this.deletedIds.add(pay.voucherNo.toUpperCase());
      }

      // Revert supplier balance
      const suppliers = this.getSuppliers();
      const sup = suppliers.find((s) => s.id === pay.supplierId);
      if (sup) {
        sup.currentBalance = roundTo2((sup.currentBalance || 0) + totalReduction);
        this.setLocalData('SUPPLIERS', suppliers);
        this.safeSyncDocToFirestore(COLLECTIONS.SUPPLIERS, sup.id, sanitizeForFirestore(sup)).catch(console.error);
      }

      // Remove ledger entries associated with this payment
      const ledgers = this.getLedgers();
      const payVchUpper = pay.voucherNo ? pay.voucherNo.trim().toUpperCase() : '';
      const ledgersToDelete = ledgers.filter(
        (l) =>
          (l.voucherType === 'Payment' && l.voucherNo && l.voucherNo.trim().toUpperCase() === payVchUpper) ||
          (l.id && (l.id === `LED-SP-${pay.id}` || l.id === `LED-SP-${pay.voucherNo}`))
      );
      ledgersToDelete.forEach((l) => {
        this.deletedIds.add(l.id);
        this.safeSyncDeleteFromFirestore(COLLECTIONS.LEDGERS, l.id).catch(console.error);
      });

      const updatedLedgers = ledgers.filter(
        (l) =>
          !(
            (l.voucherType === 'Payment' && l.voucherNo && l.voucherNo.trim().toUpperCase() === payVchUpper) ||
            (l.id && (l.id === `LED-SP-${pay.id}` || l.id === `LED-SP-${pay.voucherNo}`))
          )
      );
      this.setLocalData('LEDGERS', updatedLedgers);

      // Remove from payments list
      const remainingPayments = payments.filter((p) => p.id !== paymentId);
      this.setLocalData('PAYMENTS', remainingPayments);
      this.safeSyncDeleteFromFirestore(COLLECTIONS.PAYMENTS, paymentId).catch(console.error);

      this.notify();
      return { success: true, message: `Payment voucher ${pay.voucherNo} deleted successfully.` };
    } catch (err: any) {
      return { success: false, message: `Error deleting payment: ${err.message || err}` };
    }
  }

  updateSupplierPayment(pay: SupplierPayment): { success: boolean; message: string } {
    try {
      const payments = this.getPayments();
      const payIndex = payments.findIndex((p) => p.id === pay.id);
      if (payIndex === -1) {
        return { success: false, message: 'Payment record not found.' };
      }
      const oldPay = payments[payIndex];
      const oldReduction = (oldPay.amountPaid || 0) + (oldPay.discountReceived || 0);
      const newReduction = (pay.amountPaid || 0) + (pay.discountReceived || 0);

      const suppliers = this.getSuppliers();

      // Recalculate supplier balance
      if (oldPay.supplierId !== pay.supplierId) {
        const oldSup = suppliers.find((s) => s.id === oldPay.supplierId);
        if (oldSup) {
          oldSup.currentBalance = roundTo2((oldSup.currentBalance || 0) + oldReduction);
          this.safeSyncDocToFirestore(COLLECTIONS.SUPPLIERS, oldSup.id, sanitizeForFirestore(oldSup)).catch(console.error);
        }
        const newSup = suppliers.find((s) => s.id === pay.supplierId);
        if (newSup) {
          newSup.currentBalance = roundTo2((newSup.currentBalance || 0) - newReduction);
          this.safeSyncDocToFirestore(COLLECTIONS.SUPPLIERS, newSup.id, sanitizeForFirestore(newSup)).catch(console.error);
        }
      } else {
        const sup = suppliers.find((s) => s.id === pay.supplierId);
        if (sup) {
          sup.currentBalance = roundTo2((sup.currentBalance || 0) + oldReduction - newReduction);
          this.safeSyncDocToFirestore(COLLECTIONS.SUPPLIERS, sup.id, sanitizeForFirestore(sup)).catch(console.error);
        }
      }
      this.setLocalData('SUPPLIERS', suppliers);

      const updatedPayments = payments.map((p) => (p.id === pay.id ? { ...pay } : p));
      this.setLocalData('PAYMENTS', updatedPayments);
      this.safeSyncDocToFirestore(COLLECTIONS.PAYMENTS, pay.id, sanitizeForFirestore(pay)).catch(console.error);

      // Update ledger entry
      const ledgers = this.getLedgers();
      const supObj = suppliers.find((s) => s.id === pay.supplierId);
      const oldVchUpper = oldPay.voucherNo ? oldPay.voucherNo.trim().toUpperCase() : '';
      const ledgerIndices = ledgers.map((l, i) => i).filter(
        (i) =>
          (ledgers[i].voucherNo && ledgers[i].voucherNo.trim().toUpperCase() === oldVchUpper) ||
          (ledgers[i].id && (ledgers[i].id === `LED-SP-${pay.id}` || ledgers[i].id === pay.id))
      );
      if (ledgerIndices.length > 0) {
        ledgerIndices.forEach((index) => {
          ledgers[index] = {
            ...ledgers[index],
            date: pay.voucherDate,
            partyId: pay.supplierId,
            partyName: pay.supplierName,
            voucherNo: pay.voucherNo,
            debit: newReduction,
            runningBalance: supObj ? supObj.currentBalance : 0,
            narration: `Payment issued to Supplier (${pay.paymentMode}) Ref: ${pay.referenceNo || 'Cash'}. Disc: ${pay.discountReceived || 0}${pay.remarks ? ` - ${pay.remarks}` : ''}`,
          };
          this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, ledgers[index].id, sanitizeForFirestore(ledgers[index])).catch(console.error);
        });
      } else {
        const newLedger: LedgerEntry = {
          id: `LED-SP-${pay.id}`,
          date: pay.voucherDate,
          partyType: 'Supplier',
          partyId: pay.supplierId,
          partyName: pay.supplierName,
          voucherType: 'Payment',
          voucherNo: pay.voucherNo,
          debit: newReduction,
          credit: 0,
          runningBalance: supObj ? supObj.currentBalance : 0,
          narration: `Payment issued to Supplier (${pay.paymentMode}) Ref: ${pay.referenceNo || 'Cash'}. Disc: ${pay.discountReceived || 0}${pay.remarks ? ` - ${pay.remarks}` : ''}`,
        };
        ledgers.push(newLedger);
        this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, newLedger.id, sanitizeForFirestore(newLedger)).catch(console.error);
      }
      this.setLocalData('LEDGERS', ledgers);

      this.notify();
      return { success: true, message: `Payment voucher ${pay.voucherNo} updated successfully.` };
    } catch (err: any) {
      return { success: false, message: `Error updating payment: ${err.message || err}` };
    }
  }

  // --- Stock Adjustments ---
  getAdjustments(): StockAdjustment[] {
    return this.getLocalData<StockAdjustment[]>('ADJUSTMENTS', []);
  }

  saveStockAdjustment(adj: StockAdjustment): { success: boolean; message: string } {
    try {
      const items = this.getItems();
      const adjustments = this.getAdjustments();

      const it = items.find((i) => i.id === adj.itemId);
      if (it) {
        it.currentStock = adj.physicalStock;
      }

      this.deletedIds.delete(adj.id);
      adjustments.push(adj);

      this.setLocalData('ITEMS', items);
      this.setLocalData('ADJUSTMENTS', adjustments);
      this.notify();

      // Log to Audit Trail
      auditService.log({
        action: 'ADJUST_STOCK',
        entityType: 'STOCK_ADJUSTMENT',
        entityId: adj.id,
        entityName: adj.itemName,
        summary: `Stock adjustment for ${adj.itemName} (${adj.itemCode}): Physical ${adj.physicalStock ?? adj.adjustedStock}, Previous ${adj.previousStock} (Diff: ${(adj.difference ?? adj.differenceQty ?? 0) > 0 ? '+' : ''}${adj.difference ?? adj.differenceQty ?? 0}) - Reason: ${adj.reason}`,
        details: adj,
      });

      this.safeSyncDocToFirestore(COLLECTIONS.ADJUSTMENTS, adj.id, sanitizeForFirestore(adj)).catch(console.error);
      if (it) {
        this.safeSyncDocToFirestore(COLLECTIONS.ITEMS, it.id, sanitizeForFirestore(it)).catch(console.error);
      }

      return { success: true, message: `Stock adjustment for ${adj.itemName} saved.` };
    } catch (err: any) {
      return { success: false, message: `Error saving adjustment: ${err.message || err}` };
    }
  }

  // --- Ledgers ---
  cleanupDuplicatePurchaseLedgers() {
    try {
      const purchases = this.getPurchases();
      const rawLedgers = this.getLocalData<LedgerEntry[]>('LEDGERS', []);
      if (!rawLedgers || rawLedgers.length === 0) return;

      const ledgersToDeleteIds: string[] = [];

      // Target purge for 'jjf' / 'jjg' entries explicitly requested by user to be removed from database
      const jjfPurgedLedgers = rawLedgers.filter((l) => {
        const vNo = (l.voucherNo || '').trim().toLowerCase();
        const narr = (l.narration || '').trim().toLowerCase();
        return (
          vNo === 'jjf' ||
          vNo === 'jjg' ||
          narr.includes('#jjg') ||
          narr.includes('#jjf') ||
          narr.includes('stock inward bill #jjg') ||
          narr.includes('stock inward bill #jjf')
        );
      });

      jjfPurgedLedgers.forEach((l) => {
        ledgersToDeleteIds.push(l.id);
        this.deletedIds.add(l.id);
      });

      const jjfPurgedPurchases = purchases.filter((p) => {
        const pNo = (p.purchaseNo || '').trim().toLowerCase();
        const pInvNo = (p.purchaseInvoiceNo || '').trim().toLowerCase();
        const sBillNo = (p.supplierBillNo || '').trim().toLowerCase();
        return pNo === 'jjf' || pNo === 'jjg' || pInvNo === 'jjf' || pInvNo === 'jjg' || sBillNo === 'jjf' || sBillNo === 'jjg';
      });

      if (jjfPurgedPurchases.length > 0) {
        const remainingPurchases = purchases.filter((p) => !jjfPurgedPurchases.some((jp) => jp.id === p.id));
        this.setLocalData('PURCHASES', remainingPurchases);
        jjfPurgedPurchases.forEach((jp) => {
          this.deletedIds.add(jp.id);
          this.safeSyncDeleteFromFirestore(COLLECTIONS.PURCHASES, jp.id).catch(() => {});
        });
      }

      const purchaseLedgerGroups = new Map<string, LedgerEntry[]>();
      const nonPurchaseLedgers: LedgerEntry[] = [];

      for (const entry of rawLedgers) {
        if (this.deletedIds.has(entry.id)) continue;

        if (entry.partyType === 'Supplier' && entry.voucherType === 'Purchase') {
          const vNoUpper = (entry.voucherNo || '').trim().toUpperCase();
          const narrUpper = (entry.narration || '').trim().toUpperCase();

          const matchPur = purchases.find((p) => {
            const pNo = (p.purchaseNo || '').trim().toUpperCase();
            const pInvNo = (p.purchaseInvoiceNo || '').trim().toUpperCase();
            const sBillNo = (p.supplierBillNo || '').trim().toUpperCase();
            const pId = (p.id || '').trim().toUpperCase();

            return (
              (pNo && vNoUpper === pNo) ||
              (pInvNo && vNoUpper === pInvNo) ||
              (sBillNo && vNoUpper === sBillNo) ||
              (pId && entry.id && entry.id.includes(pId)) ||
              (sBillNo && narrUpper.includes(sBillNo)) ||
              (pNo && narrUpper.includes(pNo))
            );
          });

          const groupKey = matchPur ? matchPur.id : `UNMATCHED_${entry.partyId}_${vNoUpper}`;
          const existingGroup = purchaseLedgerGroups.get(groupKey) || [];
          existingGroup.push(entry);
          purchaseLedgerGroups.set(groupKey, existingGroup);
        } else {
          nonPurchaseLedgers.push(entry);
        }
      }

      const keptPurchaseLedgers: LedgerEntry[] = [];

      purchaseLedgerGroups.forEach((entries, groupKey) => {
        if (entries.length === 1) {
          const single = entries[0];
          const matchPur = purchases.find((p) => p.id === groupKey);
          if (matchPur) {
            const purBillNum = matchPur.purchaseNo || matchPur.purchaseInvoiceNo || matchPur.supplierBillNo;
            single.voucherNo = purBillNum;
            single.credit = matchPur.grandTotal;
            single.debit = matchPur.amountPaid;
            if (matchPur.items && matchPur.items.length > 0) {
              single.narration = `Stock Inward Bill #${purBillNum}. (${matchPur.totalQuantity} items)`;
            } else {
              single.narration = `Direct Purchase Voucher Bill #${purBillNum}`;
            }
          }
          keptPurchaseLedgers.push(single);
          return;
        }

        const matchPur = purchases.find((p) => p.id === groupKey);
        let keptEntry: LedgerEntry;

        if (matchPur && matchPur.items && matchPur.items.length > 0) {
          const inwardEntry = entries.find((e) => e.narration && e.narration.startsWith('Stock Inward'));
          if (inwardEntry) {
            keptEntry = inwardEntry;
          } else {
            const matchCreditEntry = entries.find((e) => e.credit === matchPur.grandTotal);
            keptEntry = matchCreditEntry || entries[entries.length - 1];
          }
        } else if (matchPur) {
          const matchCreditEntry = entries.find((e) => e.credit === matchPur.grandTotal);
          keptEntry = matchCreditEntry || entries[entries.length - 1];
        } else {
          keptEntry = entries[entries.length - 1];
        }

        if (matchPur) {
          const purBillNum = matchPur.purchaseNo || matchPur.purchaseInvoiceNo || matchPur.supplierBillNo;
          keptEntry.voucherNo = purBillNum;
          keptEntry.credit = matchPur.grandTotal;
          keptEntry.debit = matchPur.amountPaid;
          if (matchPur.items && matchPur.items.length > 0) {
            keptEntry.narration = `Stock Inward Bill #${purBillNum}. (${matchPur.totalQuantity} items)`;
          } else {
            keptEntry.narration = `Direct Purchase Voucher Bill #${purBillNum}`;
          }
        }

        keptPurchaseLedgers.push(keptEntry);

        entries.forEach((e) => {
          if (e.id !== keptEntry.id) {
            ledgersToDeleteIds.push(e.id);
            this.deletedIds.add(e.id);
          }
        });
      });

      if (ledgersToDeleteIds.length > 0) {
        const cleanedAll = [...nonPurchaseLedgers, ...keptPurchaseLedgers];
        this.setLocalData('LEDGERS', cleanedAll);
        if (this.getActiveDatabaseType() === 'firebase') {
          ledgersToDeleteIds.forEach((delId) => {
            this.safeSyncDeleteFromFirestore(COLLECTIONS.LEDGERS, delId).catch(() => {});
          });
        }
      }
    } catch (err) {
      console.warn('Error cleaning up duplicate purchase ledgers:', err);
    }
  }

  getLedgers(): LedgerEntry[] {
    this.cleanupDuplicatePurchaseLedgers();
    const raw = this.getLocalData<LedgerEntry[]>('LEDGERS', []);
    const filtered = raw.filter((l) => !this.deletedIds.has(l.id));

    const purchases = this.getPurchases();
    const purchaseMap = new Map<string, PurchaseInvoice>();
    purchases.forEach((p) => {
      if (p.purchaseNo) purchaseMap.set(p.purchaseNo.trim().toUpperCase(), p);
      if (p.purchaseInvoiceNo) purchaseMap.set(p.purchaseInvoiceNo.trim().toUpperCase(), p);
      if (p.supplierBillNo) purchaseMap.set(p.supplierBillNo.trim().toUpperCase(), p);
      if (p.id) purchaseMap.set(p.id.trim().toUpperCase(), p);
    });

    const seenPurchaseLedgers = new Map<string, LedgerEntry>();
    const result: LedgerEntry[] = [];

    for (const entry of filtered) {
      if (entry.partyType === 'Supplier' && entry.voucherType === 'Purchase' && entry.voucherNo) {
        const vKey = entry.voucherNo.trim().toUpperCase();
        const matchPur = purchaseMap.get(vKey);
        const partyKey = matchPur ? matchPur.supplierId : entry.partyId;
        const groupKey = matchPur ? matchPur.id : `${partyKey}_${vKey}`;

        if (!seenPurchaseLedgers.has(groupKey)) {
          seenPurchaseLedgers.set(groupKey, entry);
          result.push(entry);
        } else {
          const existing = seenPurchaseLedgers.get(groupKey)!;
          let keepEntry = entry;
          if (matchPur && existing.credit === matchPur.grandTotal && entry.credit !== matchPur.grandTotal) {
            keepEntry = existing;
          }
          const idx = result.indexOf(existing);
          if (idx >= 0) {
            result[idx] = keepEntry;
            seenPurchaseLedgers.set(groupKey, keepEntry);
          }
        }
      } else {
        result.push(entry);
      }
    }

    return result;
  }

  // Empty backend Firestore database and local storage tables, preserving Admin login credentials and session
  async emptyDatabaseExceptAdmin(): Promise<{ success: boolean; message: string; deletedCount: number }> {
    let totalDeleted = 0;
    try {
      // 1. Gather all local record IDs into deletedIds to prevent realtime listeners from re-syncing during wipe
      const allLocalCollections = [
        this.getItems(),
        this.getCustomers(),
        this.getSuppliers(),
        this.getSales(),
        this.getSalesReturns(),
        this.getSalesExchanges(),
        this.getSalesExchangeDeskRecords(),
        this.getStockMovements(),
        this.getCustomerCreditTransactions(),
        this.getPurchases(),
        this.getPurchaseReturns(),
        this.getReceipts(),
        this.getPayments(),
        this.getAdjustments(),
        this.getLedgers(),
      ];

      for (const list of allLocalCollections) {
        if (Array.isArray(list)) {
          for (const item of list) {
            if (item && typeof item === 'object' && (item as any).id) {
              this.deletedIds.add(String((item as any).id));
            }
          }
        }
      }

      // 2. Wipe local storage entries immediately for all transactional, catalog, and exchange desk data
      localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.SUPPLIERS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.SALES_RETURNS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.SALES_EXCHANGES, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.SALES_EXCHANGE_DESK, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.STOCK_MOVEMENTS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.CUSTOMER_CREDIT_TXNS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.PURCHASES, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.PURCHASE_RETURNS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.RECEIPTS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.ADJUSTMENTS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.LEDGERS, JSON.stringify([]));

      const collectionsToEmpty = [
        COLLECTIONS.ITEMS,
        COLLECTIONS.CUSTOMERS,
        COLLECTIONS.SUPPLIERS,
        COLLECTIONS.SALES,
        COLLECTIONS.SALES_RETURNS,
        COLLECTIONS.SALES_EXCHANGES,
        COLLECTIONS.SALES_EXCHANGE_DESK,
        COLLECTIONS.STOCK_MOVEMENTS,
        COLLECTIONS.CUSTOMER_CREDIT_TXNS,
        COLLECTIONS.PURCHASES,
        COLLECTIONS.PURCHASE_RETURNS,
        COLLECTIONS.RECEIPTS,
        COLLECTIONS.CUSTOMER_RECEIPTS,
        COLLECTIONS.PAYMENTS,
        COLLECTIONS.ADJUSTMENTS,
        COLLECTIONS.LEDGERS,
      ];

      // 3. Wipe each collection from Firestore (both primary and default fallback) in batches
      for (const colName of collectionsToEmpty) {
        try {
          const snap = await getDocs(collection(db, colName));
          if (!snap.empty) {
            const docs = snap.docs;
            // Process in batches of 400 (under Firestore's 500 limit)
            for (let i = 0; i < docs.length; i += 400) {
              const chunk = docs.slice(i, i + 400);
              const batch = writeBatch(db);
              chunk.forEach((docSnap) => {
                this.deletedIds.add(docSnap.id);
                batch.delete(docSnap.ref);
                totalDeleted++;
              });
              await batch.commit();
            }
          }
        } catch (colErr) {
          console.warn(`Error deleting Firestore collection ${colName}:`, colErr);
        }

        if (defaultDb && defaultDb !== db) {
          try {
            const dSnap = await getDocs(collection(defaultDb, colName));
            if (!dSnap.empty) {
              const dDocs = dSnap.docs;
              for (let i = 0; i < dDocs.length; i += 400) {
                const chunk = dDocs.slice(i, i + 400);
                const dBatch = writeBatch(defaultDb);
                chunk.forEach((docSnap) => {
                  dBatch.delete(docSnap.ref);
                });
                await dBatch.commit();
              }
            }
          } catch {}
        }
      }

      // 4. Ensure Admin Credentials remain intact in Firestore & LocalStorage
      const currentSec = this.getSecuritySettings();
      await syncDocToFirestore(COLLECTIONS.SETTINGS, 'security', sanitizeForFirestore(currentSec)).catch(console.error);

      // Notify all subscribers (SalesExchangeDesk, SalesInvoice, etc.) to re-render immediately
      this.notify();

      return {
        success: true,
        message: `Backend database emptied successfully (${totalDeleted} records removed across all collections including Sales Exchange Desk). Admin login preserved.`,
        deletedCount: totalDeleted,
      };
    } catch (err: any) {
      console.error('Error emptying backend database:', err);
      return {
        success: false,
        message: err.message || 'Failed to empty database',
        deletedCount: totalDeleted,
      };
    }
  }

  // Clear all database entries (Clean wipe for user's real business data, preserving admin login)
  async clearAllDataAndReset(): Promise<{ success: boolean; message: string }> {
    return this.emptyDatabaseExceptAdmin();
  }

  // --- Migration & Backup Export / Import ---
  exportFullDatabase(): string {
    const activeDbType = this.getActiveDatabaseType();
    const dump = {
      version: 'ARCO_GST_PORTABLE_V2.0',
      exportedAt: new Date().toISOString(),
      sourceDatabaseType: activeDbType,
      databaseType: activeDbType,
      company: this.getCompany(),
      items: this.getItems(),
      customers: this.getCustomers(),
      suppliers: this.getSuppliers(),
      sales: this.getSales(),
      salesReturns: this.getSalesReturns(),
      salesExchanges: this.getSalesExchanges(),
      salesExchangeDesk: this.getSalesExchangeDeskRecords(),
      stockMovements: this.getStockMovements(),
      customerCreditTxns: this.getCustomerCreditTransactions(),
      purchases: this.getPurchases(),
      purchaseReturns: this.getPurchaseReturns(),
      receipts: this.getReceipts(),
      payments: this.getPayments(),
      adjustments: this.getAdjustments(),
      ledgers: this.getLedgers(),
      security: this.getSecuritySettings(),
    };
    return JSON.stringify(dump, null, 2);
  }

  normalizeBackupPayload(data: any) {
    const normalizeDocId = (doc: any, fallbackPrefix: string): string => {
      if (!doc) return `${fallbackPrefix}-${Date.now()}`;
      return String(doc.id || doc._id || doc.ItemID || doc.CustomerID || doc.SupplierID || doc.InvoiceID || doc.PurchaseID || doc.LedgerID || `${fallbackPrefix}-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`);
    };

    const toNum = (val: any, fallback = 0): number => {
      if (val === null || val === undefined || val === '') return fallback;
      const n = Number(val);
      return isNaN(n) ? fallback : n;
    };

    const toBool = (val: any, fallback = true): boolean => {
      if (val === undefined || val === null) return fallback;
      if (typeof val === 'boolean') return val;
      if (typeof val === 'string') return val.toLowerCase() === 'true' || val === '1';
      return Boolean(val);
    };

    const toIsoStr = (val: any): string => {
      if (!val) return new Date().toISOString();
      if (typeof val === 'object' && 'seconds' in val) {
        return new Date(val.seconds * 1000).toISOString();
      }
      if (typeof val === 'string' && val.trim()) return val;
      if (val instanceof Date) return val.toISOString();
      return new Date().toISOString();
    };

    // Items
    const rawItems = Array.isArray(data.items) ? data.items : (Array.isArray(data.tbl_Items) ? data.tbl_Items : []);
    const items: Item[] = rawItems.map((it: any) => ({
      id: normalizeDocId(it, 'ITM'),
      itemCode: String(it.itemCode || it.ItemCode || it.barcode || it.id || 'ITM'),
      barcode: String(it.barcode || it.itemCode || ''),
      itemName: String(it.itemName || it.ItemName || 'Unnamed Item'),
      category: String(it.category || it.Category || 'General Footwear'),
      unit: String(it.unit || it.Unit || 'Pairs'),
      hsnCode: String(it.hsnCode || it.HSNCode || '6403'),
      purchaseRate: toNum(it.purchaseRate ?? it.PurchaseRate, 0),
      sellingRate: toNum(it.sellingRate ?? it.SellingRate, 0),
      mrp: toNum(it.mrp ?? it.MRP ?? it.sellingRate ?? it.SellingRate, 0),
      gstRate: toNum(it.gstRate ?? it.GSTRate, 18),
      taxType: (it.taxType || it.TaxType) === 'Exclusive' ? 'Exclusive' : 'Inclusive',
      openingStock: toNum(it.openingStock ?? it.OpeningStock, 0),
      openingStockValue: toNum(it.openingStockValue ?? it.OpeningStockValue, 0),
      currentStock: toNum(it.currentStock ?? it.CurrentStock, 0),
      minStockLevel: toNum(it.minStockLevel ?? it.MinStock ?? it.minStock, 5),
      locationRack: it.locationRack ? String(it.locationRack) : undefined,
      isActive: toBool(it.isActive ?? it.IsActive, true),
      notes: it.notes ? String(it.notes) : undefined,
      createdAt: toIsoStr(it.createdAt || it.CreatedAt),
      updatedAt: toIsoStr(it.updatedAt || it.UpdatedAt),
    }));

    // Customers
    const rawCusts = Array.isArray(data.customers) ? data.customers : (Array.isArray(data.tbl_Customers) ? data.tbl_Customers : []);
    const customers: Customer[] = rawCusts.map((c: any) => ({
      id: normalizeDocId(c, 'CUST'),
      customerCode: String(c.customerCode || c.CustomerCode || c.id || 'CUST'),
      customerName: String(c.customerName || c.CustomerName || 'Unnamed Customer'),
      mobile: String(c.mobile || c.Mobile || c.phone || ''),
      phone: String(c.phone || c.Phone || c.mobile || ''),
      email: String(c.email || c.Email || ''),
      addressLine1: String(c.addressLine1 || c.AddressLine1 || c.address || ''),
      addressLine2: String(c.addressLine2 || c.AddressLine2 || ''),
      city: String(c.city || c.City || ''),
      state: String(c.state || c.State || 'Maharashtra'),
      stateCode: String(c.stateCode || c.StateCode || '27'),
      pincode: String(c.pincode || c.Pincode || ''),
      gstin: String(c.gstin || c.GSTIN || ''),
      pan: String(c.pan || c.PAN || ''),
      openingBalance: toNum(c.openingBalance ?? c.OpeningBalance, 0),
      currentBalance: toNum(c.currentBalance ?? c.CurrentBalance, 0),
      creditLimit: toNum(c.creditLimit ?? c.CreditLimit, 0),
      creditDays: toNum(c.creditDays ?? c.CreditDays, 30),
      notes: c.notes ? String(c.notes) : undefined,
      isActive: toBool(c.isActive ?? c.IsActive, true),
      createdAt: toIsoStr(c.createdAt || c.CreatedAt),
      updatedAt: toIsoStr(c.updatedAt || c.UpdatedAt),
    }));

    // Suppliers
    const rawSupps = Array.isArray(data.suppliers) ? data.suppliers : (Array.isArray(data.tbl_Suppliers) ? data.tbl_Suppliers : []);
    const suppliers: Supplier[] = rawSupps.map((s: any) => ({
      id: normalizeDocId(s, 'SUP'),
      supplierCode: String(s.supplierCode || s.SupplierCode || s.id || 'SUP'),
      supplierName: String(s.supplierName || s.SupplierName || 'Unnamed Supplier'),
      contactPerson: String(s.contactPerson || s.ContactPerson || ''),
      mobile: String(s.mobile || s.Mobile || s.phone || ''),
      phone: String(s.phone || s.Phone || s.mobile || ''),
      email: String(s.email || s.Email || ''),
      addressLine1: String(s.addressLine1 || s.AddressLine1 || s.address || ''),
      addressLine2: String(s.addressLine2 || s.AddressLine2 || ''),
      city: String(s.city || s.City || ''),
      state: String(s.state || s.State || 'Maharashtra'),
      stateCode: String(s.stateCode || s.StateCode || '27'),
      pincode: String(s.pincode || s.Pincode || ''),
      gstin: String(s.gstin || s.GSTIN || ''),
      pan: String(s.pan || s.PAN || ''),
      openingBalance: toNum(s.openingBalance ?? s.OpeningBalance, 0),
      currentBalance: toNum(s.currentBalance ?? s.CurrentBalance, 0),
      bankName: String(s.bankName || s.BankName || ''),
      bankAccountNo: String(s.bankAccountNo || s.BankAccountNo || ''),
      bankIfsc: String(s.bankIfsc || s.BankIfsc || ''),
      bankBranch: String(s.bankBranch || s.BankBranch || ''),
      notes: s.notes ? String(s.notes) : undefined,
      isActive: toBool(s.isActive ?? s.IsActive, true),
      createdAt: toIsoStr(s.createdAt || s.CreatedAt),
      updatedAt: toIsoStr(s.updatedAt || s.UpdatedAt),
    }));

    // Sales Invoices
    const rawSales = Array.isArray(data.sales) ? data.sales : (Array.isArray(data.sales_invoices) ? data.sales_invoices : (Array.isArray(data.tbl_SalesMaster) ? data.tbl_SalesMaster : []));
    const sales: SalesInvoice[] = rawSales.map((s: any) => {
      const itemsList = Array.isArray(s.items) ? s.items : [];
      return {
        id: normalizeDocId(s, 'INV'),
        invoiceNo: String(s.invoiceNo || s.InvoiceNo || s.invoice_no || `INV-${Date.now()}`),
        invoiceDate: toIsoStr(s.invoiceDate || s.InvoiceDate || s.date),
        orderNo: s.orderNo ? String(s.orderNo) : undefined,
        customerId: String(s.customerId || s.CustomerID || ''),
        customerName: String(s.customerName || s.CustomerName || 'Cash Sale'),
        customerGstin: String(s.customerGstin || s.CustomerGSTIN || s.gstin || ''),
        customerAddress: String(s.customerAddress || s.CustomerAddress || ''),
        customerStateCode: String(s.customerStateCode || s.CustomerStateCode || '27'),
        customerPhone: String(s.customerPhone || s.CustomerPhone || s.phone || ''),
        taxType: s.taxType || 'Inclusive',
        items: itemsList.map((li: any, idx: number) => ({
          id: String(li.id || `li-${idx}`),
          itemId: String(li.itemId || li.ItemID || ''),
          itemCode: String(li.itemCode || li.ItemCode || ''),
          itemName: String(li.itemName || li.ItemName || 'Item'),
          category: String(li.category || ''),
          hsnCode: String(li.hsnCode || li.HSNCode || '6403'),
          qty: toNum(li.qty ?? li.quantity ?? li.Quantity, 1),
          unit: String(li.unit || 'Pairs'),
          rate: toNum(li.rate ?? li.Rate, 0),
          mrp: toNum(li.mrp ?? li.MRP, 0),
          discountPercent: toNum(li.discountPercent ?? li.DiscountPercent, 0),
          discountAmount: toNum(li.discountAmount ?? li.DiscountAmount, 0),
          taxableAmount: toNum(li.taxableAmount ?? li.TaxableAmount, 0),
          gstRate: toNum(li.gstRate ?? li.GSTRate, 18),
          cgst: toNum(li.cgst ?? li.CGST, 0),
          sgst: toNum(li.sgst ?? li.SGST, 0),
          igst: toNum(li.igst ?? li.IGST, 0),
          total: toNum(li.total ?? li.Total ?? li.netAmount ?? li.NetAmount, 0),
        })),
        subtotal: toNum(s.subtotal ?? s.GrossSubtotal, 0),
        discountAmount: toNum(s.discountAmount ?? s.TotalDiscount, 0),
        taxableAmount: toNum(s.taxableAmount ?? s.TotalTaxable, 0),
        cgstTotal: toNum(s.cgstTotal ?? s.CGSTTotal, 0),
        sgstTotal: toNum(s.sgstTotal ?? s.SGSTTotal, 0),
        igstTotal: toNum(s.igstTotal ?? s.IGSTTotal, 0),
        totalTax: toNum(s.totalTax ?? s.TotalTax, 0),
        roundOff: toNum(s.roundOff ?? s.RoundOff, 0),
        grandTotal: toNum(s.grandTotal ?? s.GrandTotal, 0),
        paidAmount: toNum(s.paidAmount ?? s.PaidAmount, 0),
        balanceAmount: toNum(s.balanceAmount ?? s.BalanceAmount, 0),
        paymentMode: (s.paymentMode || s.PaymentMode || 'Cash') as any,
        status: (s.status || s.Status || 'Paid') as any,
        notes: s.notes ? String(s.notes) : undefined,
        terms: s.terms ? String(s.terms) : undefined,
        createdAt: toIsoStr(s.createdAt || s.CreatedAt),
        updatedAt: toIsoStr(s.updatedAt || s.UpdatedAt),
      };
    });

    // Purchases
    const rawPurchases = Array.isArray(data.purchases) ? data.purchases : (Array.isArray(data.purchase_invoices) ? data.purchase_invoices : (Array.isArray(data.tbl_PurchaseMaster) ? data.tbl_PurchaseMaster : []));
    const purchases: PurchaseInvoice[] = rawPurchases.map((p: any) => {
      const itemsList = Array.isArray(p.items) ? p.items : [];
      return {
        id: normalizeDocId(p, 'PUR'),
        purchaseInvoiceNo: String(p.purchaseInvoiceNo || p.PurchaseInvoiceNo || `PUR-${Date.now()}`),
        supplierBillNo: String(p.supplierBillNo || p.SupplierBillNo || ''),
        purchaseDate: toIsoStr(p.purchaseDate || p.PurchaseDate || p.date),
        supplierId: String(p.supplierId || p.SupplierID || ''),
        supplierName: String(p.supplierName || p.SupplierName || 'Supplier'),
        supplierGstin: String(p.supplierGstin || p.SupplierGSTIN || ''),
        supplierAddress: String(p.supplierAddress || p.SupplierAddress || ''),
        supplierStateCode: String(p.supplierStateCode || p.SupplierStateCode || '27'),
        taxType: p.taxType || 'Inclusive',
        items: itemsList.map((li: any, idx: number) => ({
          id: String(li.id || `pli-${idx}`),
          itemId: String(li.itemId || li.ItemID || ''),
          itemCode: String(li.itemCode || li.ItemCode || ''),
          itemName: String(li.itemName || li.ItemName || 'Item'),
          category: String(li.category || ''),
          hsnCode: String(li.hsnCode || li.HSNCode || '6403'),
          qty: toNum(li.qty ?? li.quantity ?? li.Quantity, 1),
          unit: String(li.unit || 'Pairs'),
          rate: toNum(li.rate ?? li.Rate, 0),
          sellingRate: toNum(li.sellingRate ?? li.SellingRate, 0),
          mrp: toNum(li.mrp ?? li.MRP, 0),
          discountPercent: toNum(li.discountPercent ?? li.DiscountPercent, 0),
          discountAmount: toNum(li.discountAmount ?? li.DiscountAmount, 0),
          taxableAmount: toNum(li.taxableAmount ?? li.TaxableAmount, 0),
          gstRate: toNum(li.gstRate ?? li.GSTRate, 18),
          cgst: toNum(li.cgst ?? li.CGST, 0),
          sgst: toNum(li.sgst ?? li.SGST, 0),
          igst: toNum(li.igst ?? li.IGST, 0),
          total: toNum(li.total ?? li.Total ?? li.netAmount ?? li.NetAmount, 0),
        })),
        subtotal: toNum(p.subtotal ?? p.GrossSubtotal, 0),
        discountAmount: toNum(p.discountAmount ?? p.TotalDiscount, 0),
        taxableAmount: toNum(p.taxableAmount ?? p.TotalTaxable, 0),
        cgstTotal: toNum(p.cgstTotal ?? p.CGSTTotal, 0),
        sgstTotal: toNum(p.sgstTotal ?? p.SGSTTotal, 0),
        igstTotal: toNum(p.igstTotal ?? p.IGSTTotal, 0),
        totalTax: toNum(p.totalTax ?? p.TotalTax, 0),
        roundOff: toNum(p.roundOff ?? p.RoundOff, 0),
        grandTotal: toNum(p.grandTotal ?? p.GrandTotal, 0),
        paidAmount: toNum(p.paidAmount ?? p.PaidAmount, 0),
        balanceAmount: toNum(p.balanceAmount ?? p.BalanceAmount, 0),
        paymentMode: (p.paymentMode || p.PaymentMode || 'Cash') as any,
        status: (p.status || p.Status || 'Paid') as any,
        notes: p.notes ? String(p.notes) : undefined,
        createdAt: toIsoStr(p.createdAt || p.CreatedAt),
        updatedAt: toIsoStr(p.updatedAt || p.UpdatedAt),
      };
    });

    // Sales Returns
    const rawSalesReturns = Array.isArray(data.salesReturns) ? data.salesReturns : (Array.isArray(data.sales_returns) ? data.sales_returns : (Array.isArray(data.tbl_SalesReturns) ? data.tbl_SalesReturns : []));
    const salesReturns: SalesReturn[] = rawSalesReturns.map((sr: any) => ({
      ...sr,
      id: normalizeDocId(sr, 'SR'),
      returnNo: String(sr.returnNo || sr.ReturnNo || `SR-${Date.now()}`),
      returnDate: toIsoStr(sr.returnDate || sr.ReturnDate),
      grandTotal: toNum(sr.grandTotal ?? sr.GrandTotal, 0),
      totalTax: toNum(sr.totalTax ?? sr.TotalTax, 0),
      items: Array.isArray(sr.items) ? sr.items : [],
    }));

    // Purchase Returns
    const rawPurReturns = Array.isArray(data.purchaseReturns) ? data.purchaseReturns : (Array.isArray(data.purchase_returns) ? data.purchase_returns : (Array.isArray(data.tbl_PurchaseReturns) ? data.tbl_PurchaseReturns : []));
    const purchaseReturns: PurchaseReturn[] = rawPurReturns.map((pr: any) => ({
      ...pr,
      id: normalizeDocId(pr, 'PR'),
      returnNo: String(pr.returnNo || pr.ReturnNo || `PR-${Date.now()}`),
      returnDate: toIsoStr(pr.returnDate || pr.ReturnDate),
      grandTotal: toNum(pr.grandTotal ?? pr.GrandTotal, 0),
      totalTax: toNum(pr.totalTax ?? pr.TotalTax, 0),
      items: Array.isArray(pr.items) ? pr.items : [],
    }));

    // Receipts
    const rawReceipts = Array.isArray(data.customerReceipts) ? data.customerReceipts : (Array.isArray(data.receipts) ? data.receipts : (Array.isArray(data.customer_receipts) ? data.customer_receipts : (Array.isArray(data.tbl_CustomerReceipts) ? data.tbl_CustomerReceipts : [])));
    const receipts: CustomerReceipt[] = rawReceipts.map((r: any) => ({
      ...r,
      id: normalizeDocId(r, 'REC'),
      receiptNo: String(r.receiptNo || r.ReceiptNo || `REC-${Date.now()}`),
      receiptDate: toIsoStr(r.receiptDate || r.ReceiptDate || r.date),
      customerId: String(r.customerId || r.CustomerID || ''),
      customerName: String(r.customerName || r.CustomerName || ''),
      amount: toNum(r.amount ?? r.Amount, 0),
      paymentMode: r.paymentMode || 'Cash',
      createdAt: toIsoStr(r.createdAt || r.CreatedAt),
    }));

    // Payments
    const rawPayments = Array.isArray(data.payments) ? data.payments : (Array.isArray(data.supplier_payments) ? data.supplier_payments : (Array.isArray(data.tbl_SupplierPayments) ? data.tbl_SupplierPayments : []));
    const payments: SupplierPayment[] = rawPayments.map((p: any) => ({
      ...p,
      id: normalizeDocId(p, 'PAY'),
      paymentNo: String(p.paymentNo || p.PaymentNo || `PAY-${Date.now()}`),
      paymentDate: toIsoStr(p.paymentDate || p.PaymentDate || p.date),
      supplierId: String(p.supplierId || p.SupplierID || ''),
      supplierName: String(p.supplierName || p.SupplierName || ''),
      amount: toNum(p.amount ?? p.Amount, 0),
      paymentMode: p.paymentMode || 'Cash',
      createdAt: toIsoStr(p.createdAt || p.CreatedAt),
    }));

    // Adjustments
    const rawAdjustments = Array.isArray(data.adjustments) ? data.adjustments : (Array.isArray(data.stock_adjustments) ? data.stock_adjustments : (Array.isArray(data.tbl_StockAdjustments) ? data.tbl_StockAdjustments : []));
    const adjustments: StockAdjustment[] = rawAdjustments.map((a: any) => ({
      ...a,
      id: normalizeDocId(a, 'ADJ'),
      adjustmentNo: String(a.adjustmentNo || a.AdjustmentNo || `ADJ-${Date.now()}`),
      date: toIsoStr(a.date || a.Date),
      itemId: String(a.itemId || a.ItemID || ''),
      itemCode: String(a.itemCode || a.ItemCode || ''),
      itemName: String(a.itemName || a.ItemName || ''),
      adjustedQty: toNum(a.adjustedQty ?? a.AdjustedQty ?? a.quantity, 0),
      type: a.type || 'Add',
      reason: String(a.reason || a.Reason || 'Stock count update'),
      createdAt: toIsoStr(a.createdAt || a.CreatedAt),
    }));

    // Ledgers / Day Book
    const rawLedgers = Array.isArray(data.ledgers) ? data.ledgers : (Array.isArray(data.tbl_DayBook) ? data.tbl_DayBook : (Array.isArray(data.tbl_CustomerLedger) ? data.tbl_CustomerLedger : []));
    const ledgers: LedgerEntry[] = rawLedgers.map((l: any) => ({
      ...l,
      id: normalizeDocId(l, 'LED'),
      date: toIsoStr(l.date || l.Date),
      voucherType: String(l.voucherType || l.VoucherType || 'Sales'),
      voucherNo: String(l.voucherNo || l.VoucherNo || ''),
      partyType: (l.partyType || (l.CustomerID ? 'Customer' : (l.SupplierID ? 'Supplier' : 'Customer'))) as any,
      partyId: String(l.partyId || l.CustomerID || l.SupplierID || ''),
      partyName: String(l.partyName || l.CustomerName || l.SupplierName || ''),
      debit: toNum(l.debit ?? l.Debit, 0),
      credit: toNum(l.credit ?? l.Credit, 0),
      runningBalance: toNum(l.runningBalance ?? l.RunningBalance ?? l.balance, 0),
      narration: String(l.narration || l.Narration || l.particulars || ''),
    }));

    // Extra tables
    const salesExchanges = Array.isArray(data.salesExchanges) ? data.salesExchanges : (Array.isArray(data.exchanges) ? data.exchanges : []);
    const salesExchangeDesk = Array.isArray(data.salesExchangeDesk) ? data.salesExchangeDesk : (Array.isArray(data.exchange_desk) ? data.exchange_desk : []);
    const stockMovements = Array.isArray(data.stockMovements) ? data.stockMovements : (Array.isArray(data.movements) ? data.movements : []);
    const customerCreditTxns = Array.isArray(data.customerCreditTxns) ? data.customerCreditTxns : (Array.isArray(data.credit_txns) ? data.credit_txns : []);

    const company = data.company || data.tbl_CompanyInfo || null;
    const security = data.security || data.tbl_Security || null;
    const admins = Array.isArray(data.admins) ? data.admins : (Array.isArray(data.tbl_Admins) ? data.tbl_Admins : []);

    return {
      items,
      customers,
      suppliers,
      sales,
      purchases,
      salesReturns,
      purchaseReturns,
      receipts,
      customerReceipts: receipts,
      payments,
      adjustments,
      ledgers,
      salesExchanges,
      salesExchangeDesk,
      stockMovements,
      customerCreditTxns,
      company,
      security,
      admins,
    };
  }

  private restoreToMongoDBAdapter(data: ReturnType<typeof this.normalizeBackupPayload>, logs: string[]): void {
    logs.push('2. Restoring to MongoDB engine...');

    // 1. Prepare company with target = 'mongodb'
    const currentComp = this.getCompany();
    const targetCompany: CompanyInfo = {
      ...(currentComp || INITIAL_COMPANY),
      ...(data.company || {}),
      databaseType: 'mongodb', // STRICTLY PRESERVE TARGET DB TYPE
      mongoUri: currentComp?.mongoUri || data.company?.mongoUri || 'mongodb://127.0.0.1:27017',
      mongoDbName: currentComp?.mongoDbName || data.company?.mongoDbName || 'arco_shoes_db',
    };

    // 2. Write to MongoDB Local Storage Keys
    localStorage.setItem(MONGODB_STORAGE_KEYS.COMPANY, JSON.stringify(targetCompany));
    localStorage.setItem(MONGODB_STORAGE_KEYS.ITEMS, JSON.stringify(data.items));
    localStorage.setItem(MONGODB_STORAGE_KEYS.CUSTOMERS, JSON.stringify(data.customers));
    localStorage.setItem(MONGODB_STORAGE_KEYS.SUPPLIERS, JSON.stringify(data.suppliers));
    localStorage.setItem(MONGODB_STORAGE_KEYS.SALES, JSON.stringify(data.sales));
    localStorage.setItem(MONGODB_STORAGE_KEYS.SALES_RETURNS, JSON.stringify(data.salesReturns));
    localStorage.setItem(MONGODB_STORAGE_KEYS.SALES_EXCHANGES, JSON.stringify(data.salesExchanges));
    localStorage.setItem(MONGODB_STORAGE_KEYS.SALES_EXCHANGE_DESK, JSON.stringify(data.salesExchangeDesk));
    localStorage.setItem(MONGODB_STORAGE_KEYS.STOCK_MOVEMENTS, JSON.stringify(data.stockMovements));
    localStorage.setItem(MONGODB_STORAGE_KEYS.CUSTOMER_CREDIT_TXNS, JSON.stringify(data.customerCreditTxns));
    localStorage.setItem(MONGODB_STORAGE_KEYS.PURCHASES, JSON.stringify(data.purchases));
    localStorage.setItem(MONGODB_STORAGE_KEYS.PURCHASE_RETURNS, JSON.stringify(data.purchaseReturns));
    localStorage.setItem(MONGODB_STORAGE_KEYS.RECEIPTS, JSON.stringify(data.receipts));
    localStorage.setItem(MONGODB_STORAGE_KEYS.CUSTOMER_RECEIPTS, JSON.stringify(data.customerReceipts));
    localStorage.setItem(MONGODB_STORAGE_KEYS.PAYMENTS, JSON.stringify(data.payments));
    localStorage.setItem(MONGODB_STORAGE_KEYS.ADJUSTMENTS, JSON.stringify(data.adjustments));
    localStorage.setItem(MONGODB_STORAGE_KEYS.LEDGERS, JSON.stringify(data.ledgers));
    if (data.security) {
      localStorage.setItem(MONGODB_STORAGE_KEYS.SECURITY, JSON.stringify(data.security));
    }

    // Update common key so settings page and app stay in sync with MongoDB mode
    localStorage.setItem(FIREBASE_STORAGE_KEYS.COMPANY, JSON.stringify(targetCompany));

    // Clear deleted markers for clean state
    this.deletedIds.clear();
    localStorage.removeItem('arco_deleted_record_ids_v2');

    this.clearMemoryCache();
    this.cachedCompany = targetCompany;

    logs.push('- MongoDB local storage stores populated.');

    // 3. Send bulk restore payload to MongoDB server
    fetch('/api/mongodb/bulk-restore', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        mongoUri: targetCompany.mongoUri,
        dbName: targetCompany.mongoDbName,
        collections: {
          items: data.items,
          customers: data.customers,
          suppliers: data.suppliers,
          sales: data.sales,
          purchases: data.purchases,
          sales_returns: data.salesReturns,
          purchase_returns: data.purchaseReturns,
          receipts: data.receipts,
          payments: data.payments,
          adjustments: data.adjustments,
          exchanges: data.salesExchanges,
          exchange_desk: data.salesExchangeDesk,
          movements: data.stockMovements,
          credit_txns: data.customerCreditTxns,
          ledgers: data.ledgers,
          company: targetCompany,
          security: data.security,
        },
      }),
    })
      .then((res) => res.json())
      .then((result) => {
        if (result.success) {
          console.log('[MongoDB Bulk Restore Success]:', result.restoredCounts);
        } else {
          console.warn('[MongoDB Bulk Restore Notice]:', result.error);
        }
      })
      .catch((err) => {
        console.warn('[MongoDB Bulk Restore Network Notice]:', err.message || err);
      });

    logs.push('- MongoDB collections synchronized via bulk adapter.');
  }

  private restoreToFirebaseAdapter(data: ReturnType<typeof this.normalizeBackupPayload>, logs: string[]): void {
    logs.push('2. Restoring to Firebase Cloud engine...');

    // 1. Prepare company with target = 'firebase'
    const currentComp = this.getCompany();
    const targetCompany: CompanyInfo = {
      ...(currentComp || INITIAL_COMPANY),
      ...(data.company || {}),
      databaseType: 'firebase', // STRICTLY PRESERVE TARGET DB TYPE
    };

    // 2. Write to Firebase Local Storage Keys
    localStorage.setItem(FIREBASE_STORAGE_KEYS.COMPANY, JSON.stringify(targetCompany));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.ITEMS, JSON.stringify(data.items));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.CUSTOMERS, JSON.stringify(data.customers));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.SUPPLIERS, JSON.stringify(data.suppliers));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.SALES, JSON.stringify(data.sales));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.SALES_RETURNS, JSON.stringify(data.salesReturns));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.SALES_EXCHANGES, JSON.stringify(data.salesExchanges));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.SALES_EXCHANGE_DESK, JSON.stringify(data.salesExchangeDesk));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.STOCK_MOVEMENTS, JSON.stringify(data.stockMovements));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.CUSTOMER_CREDIT_TXNS, JSON.stringify(data.customerCreditTxns));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.PURCHASES, JSON.stringify(data.purchases));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.PURCHASE_RETURNS, JSON.stringify(data.purchaseReturns));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.RECEIPTS, JSON.stringify(data.receipts));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.CUSTOMER_RECEIPTS, JSON.stringify(data.customerReceipts));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.PAYMENTS, JSON.stringify(data.payments));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.ADJUSTMENTS, JSON.stringify(data.adjustments));
    localStorage.setItem(FIREBASE_STORAGE_KEYS.LEDGERS, JSON.stringify(data.ledgers));
    if (data.security) {
      localStorage.setItem(FIREBASE_STORAGE_KEYS.SECURITY, JSON.stringify(data.security));
    }

    // Update common key so settings page and app stay in sync with Firebase mode
    localStorage.setItem(MONGODB_STORAGE_KEYS.COMPANY, JSON.stringify(targetCompany));

    // Clear deleted markers for clean state
    this.deletedIds.clear();
    localStorage.removeItem('arco_deleted_record_ids_v2');

    this.clearMemoryCache();
    this.cachedCompany = targetCompany;

    logs.push('- Firebase local cache stores populated.');

    // 3. Sync to Firestore Cloud collections
    this.safeSyncDocToFirestore(COLLECTIONS.SETTINGS, 'company', sanitizeForFirestore(targetCompany)).catch(console.error);
    if (data.security) {
      this.safeSyncDocToFirestore(COLLECTIONS.SETTINGS, 'security', sanitizeForFirestore(data.security)).catch(console.error);
    }

    data.items.forEach((it) => this.safeSyncDocToFirestore(COLLECTIONS.ITEMS, it.id, sanitizeForFirestore(it)).catch(console.error));
    data.customers.forEach((c) => this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, c.id, sanitizeForFirestore(c)).catch(console.error));
    data.suppliers.forEach((s) => this.safeSyncDocToFirestore(COLLECTIONS.SUPPLIERS, s.id, sanitizeForFirestore(s)).catch(console.error));
    data.sales.forEach((s) => this.safeSyncDocToFirestore(COLLECTIONS.SALES, s.id, sanitizeForFirestore(s)).catch(console.error));
    data.salesReturns.forEach((sr) => this.safeSyncDocToFirestore(COLLECTIONS.SALES_RETURNS, sr.id, sanitizeForFirestore(sr)).catch(console.error));
    data.purchases.forEach((p) => this.safeSyncDocToFirestore(COLLECTIONS.PURCHASES, p.id, sanitizeForFirestore(p)).catch(console.error));
    data.purchaseReturns.forEach((pr) => this.safeSyncDocToFirestore(COLLECTIONS.PURCHASE_RETURNS, pr.id, sanitizeForFirestore(pr)).catch(console.error));
    data.receipts.forEach((r) => this.safeSyncDocToFirestore(COLLECTIONS.RECEIPTS, r.id, sanitizeForFirestore(r)).catch(console.error));
    data.payments.forEach((p) => this.safeSyncDocToFirestore(COLLECTIONS.PAYMENTS, p.id, sanitizeForFirestore(p)).catch(console.error));
    data.adjustments.forEach((a) => this.safeSyncDocToFirestore(COLLECTIONS.ADJUSTMENTS, a.id, sanitizeForFirestore(a)).catch(console.error));
    data.ledgers.forEach((l) => this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, l.id, sanitizeForFirestore(l)).catch(console.error));

    logs.push('- Firestore cloud documents scheduled for synchronization.');
  }

  importDatabase(jsonString: string, targetDbTypeOverride?: 'firebase' | 'mongodb'): MigrationSummary {
    const logs: string[] = [];
    try {
      logs.push('1. Reading portable database backup file...');
      const rawData = JSON.parse(jsonString);

      // Determine source DB type (informational only)
      const rawSource = rawData.sourceDatabaseType || rawData.databaseType || (rawData.version?.includes('FIREBASE') ? 'firebase' : (rawData.version?.includes('MONGO') ? 'mongodb' : 'standard'));
      const sourceDatabaseType = String(rawSource).toLowerCase();

      // STRICT MANDATE: Target database type is determined ONLY by current application setting (or explicit target argument)
      const currentActiveDb = this.getActiveDatabaseType();
      const targetDatabaseType = targetDbTypeOverride || currentActiveDb;

      logs.push(`- Detected Backup Source: ${sourceDatabaseType.toUpperCase()} (Informational only)`);
      logs.push(`- Active Restore Target: ${targetDatabaseType.toUpperCase()} (Determined by Settings)`);

      // Normalize all collections through our portable normalization layer
      const normalized = this.normalizeBackupPayload(rawData);
      logs.push(`- Normalized data: ${normalized.items.length} items, ${normalized.customers.length} customers, ${normalized.suppliers.length} suppliers, ${normalized.sales.length} sales, ${normalized.purchases.length} purchases, ${normalized.ledgers.length} day-book entries.`);

      // Execute restore against the ACTIVE TARGET adapter
      if (targetDatabaseType === 'mongodb') {
        this.restoreToMongoDBAdapter(normalized, logs);
      } else {
        this.restoreToFirebaseAdapter(normalized, logs);
      }

      // Notify UI of updated state
      this.notify();

      const items = this.getItems();
      const customers = this.getCustomers();
      const suppliers = this.getSuppliers();
      const sales = this.getSales();
      const purchases = this.getPurchases();

      logs.push(`- Final verification: Restored database in ${targetDatabaseType.toUpperCase()} mode successfully.`);

      return {
        itemsCount: items.length,
        customersCount: customers.length,
        suppliersCount: suppliers.length,
        salesCount: sales.length,
        purchaseCount: purchases.length,
        totalSalesValue: roundTo2(sales.reduce((acc, s) => acc + (s.grandTotal || 0), 0)),
        totalPurchaseValue: roundTo2(purchases.reduce((acc, p) => acc + (p.grandTotal || 0), 0)),
        totalStockQuantity: roundTo2(items.reduce((acc, i) => acc + (i.currentStock || 0), 0)),
        totalStockCostValue: roundTo2(items.reduce((acc, i) => acc + (i.currentStock || 0) * (i.purchaseRate || 0), 0)),
        totalCustomerOutstanding: roundTo2(customers.reduce((acc, c) => acc + (c.currentBalance || 0), 0)),
        totalSupplierPayable: roundTo2(suppliers.reduce((acc, s) => acc + (s.currentBalance || 0), 0)),
        totalGstCollected: roundTo2(sales.reduce((acc, s) => acc + (s.totalTax || 0), 0)),
        totalGstPaid: roundTo2(purchases.reduce((acc, p) => acc + (p.totalTax || 0), 0)),
        migrationDate: new Date().toISOString(),
        sourceDatabaseType,
        targetDatabaseType,
        status: 'SUCCESS',
        logs,
      };
    } catch (err: any) {
      console.error('Import database error:', err);
      return {
        itemsCount: 0,
        customersCount: 0,
        suppliersCount: 0,
        salesCount: 0,
        purchaseCount: 0,
        totalSalesValue: 0,
        totalPurchaseValue: 0,
        totalStockQuantity: 0,
        totalStockCostValue: 0,
        totalCustomerOutstanding: 0,
        totalSupplierPayable: 0,
        totalGstCollected: 0,
        totalGstPaid: 0,
        migrationDate: new Date().toISOString(),
        status: 'ERROR',
        logs: [`ERROR: ${err.message || err}`],
      };
    }
  }

  // Aliases and Compatibility
  getCompanyInfo(): CompanyInfo {
    return this.getCompany();
  }

  saveCompanyInfo(company: CompanyInfo): void {
    this.saveCompany(company);
  }

  exportDatabaseJson(): string {
    return this.exportFullDatabase();
  }

  importDatabaseJson(jsonString: string, targetDbTypeOverride?: 'firebase' | 'mongodb'): { success: boolean; message: string; summary?: MigrationSummary } {
    const res = this.importDatabase(jsonString, targetDbTypeOverride);
    return {
      success: res.status === 'SUCCESS',
      message: res.status === 'SUCCESS' ? `Database imported and restored into ${res.targetDatabaseType?.toUpperCase() || 'target'} database successfully.` : res.logs.join('\n'),
      summary: res,
    };
  }

  resetToInitialData(): void {
    this.clearAllDataAndReset();
  }

  getCustomerLedgers(): Array<{
    id: string;
    customerId: string;
    date: string;
    voucherType: string;
    voucherNo: string;
    particulars: string;
    debit: number;
    credit: number;
    balance: number;
  }> {
    return this.getLedgers()
      .filter((l) => l.partyType === 'Customer')
      .map((l) => ({
        id: l.id,
        customerId: l.partyId,
        date: l.date,
        voucherType: l.voucherType,
        voucherNo: l.voucherNo,
        particulars: l.narration || `${l.voucherType} ${l.voucherNo}`,
        debit: l.debit,
        credit: l.credit,
        balance: l.runningBalance,
      }));
  }

  getSupplierLedgers(): Array<{
    id: string;
    supplierId: string;
    date: string;
    voucherType: string;
    voucherNo: string;
    particulars: string;
    debit: number;
    credit: number;
    balance: number;
  }> {
    return this.getLedgers()
      .filter((l) => l.partyType === 'Supplier')
      .map((l) => ({
        id: l.id,
        supplierId: l.partyId,
        date: l.date,
        voucherType: l.voucherType,
        voucherNo: l.voucherNo,
        particulars: l.narration || `${l.voucherType} ${l.voucherNo}`,
        debit: l.debit,
        credit: l.credit,
        balance: l.runningBalance,
      }));
  }

  saveCustomerLedger(entry: any): void {
    const ledgers = this.getLedgers();
    const newEntry: LedgerEntry = {
      id: entry.id || `LED-C-${Date.now()}`,
      date: entry.date,
      partyType: 'Customer',
      partyId: entry.customerId,
      partyName: '',
      voucherType: entry.voucherType || 'Receipt',
      voucherNo: entry.voucherNo || '',
      debit: entry.debit || 0,
      credit: entry.credit || 0,
      runningBalance: entry.balance || 0,
      narration: entry.particulars || '',
    };
    ledgers.push(newEntry);
    localStorage.setItem(STORAGE_KEYS.LEDGERS, JSON.stringify(ledgers));
    this.notify();
    syncDocToFirestore(COLLECTIONS.LEDGERS, newEntry.id, sanitizeForFirestore(newEntry)).catch(console.error);
  }

  saveSupplierLedger(entry: any): void {
    const ledgers = this.getLedgers();
    const newEntry: LedgerEntry = {
      id: entry.id || `LED-S-${Date.now()}`,
      date: entry.date,
      partyType: 'Supplier',
      partyId: entry.supplierId,
      partyName: '',
      voucherType: entry.voucherType || 'Payment',
      voucherNo: entry.voucherNo || '',
      debit: entry.debit || 0,
      credit: entry.credit || 0,
      runningBalance: entry.balance || 0,
      narration: entry.particulars || '',
    };
    ledgers.push(newEntry);
    localStorage.setItem(STORAGE_KEYS.LEDGERS, JSON.stringify(ledgers));
    this.notify();
    syncDocToFirestore(COLLECTIONS.LEDGERS, newEntry.id, sanitizeForFirestore(newEntry)).catch(console.error);
  }

  adjustStock(adj: StockAdjustment): { success: boolean; message: string } {
    return this.saveStockAdjustment({
      ...adj,
      physicalStock: adj.adjustedStock !== undefined ? adj.adjustedStock : adj.physicalStock || 0,
      differenceQty: adj.difference !== undefined ? adj.difference : adj.differenceQty || 0,
      itemCost: adj.itemCost || 0,
      adjustmentValue: adj.adjustmentValue || 0,
      reason: (adj.reason as any) || 'Audit Correction',
    });
  }
}

export const dbService = new DBStorageService();
