import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import type {
  TrainingCenter,
  Instructor,
  Scheme,
  Contribution,
  Notice,
  AppSetting,
} from './src/types';
import { DEFAULT_EMPLOYEE_TYPES } from './src/types';

const DATA_DIR = path.join(process.cwd(), 'data');
const TC_FILE = path.join(DATA_DIR, 'trainingCenters.json');
const INST_FILE = path.join(DATA_DIR, 'instructors.json');
const SCHEMES_FILE = path.join(DATA_DIR, 'schemes.json');
const CONTRIB_FILE = path.join(DATA_DIR, 'contributions.json');
const NOTICES_FILE = path.join(DATA_DIR, 'notices.json');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Generic file helpers
function readJsonFile<T>(filePath: string, defaultValue: T): T {
  try {
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, 'utf-8');
      return JSON.parse(content);
    }
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
  }
  return defaultValue;
}

function writeJsonFile<T>(filePath: string, data: T) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
  }
}

function ensureRegistrationNo(inst: Partial<Instructor>): string {
  if (inst.registrationNo && inst.registrationNo.trim() !== '') {
    return inst.registrationNo.trim();
  }
  const id = inst.id || '';

  if (id.startsWith('inst-reg-')) {
    const digits = id.replace(/[^0-9]/g, '');
    if (digits.length >= 6) {
      return `JK-ITI-REG-${digits.slice(-6)}`;
    }
  }

  // Deterministic 6-digit number based on name or ID
  let hash = 0;
  const str = `${id}-${inst.name || ''}`;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  const code = 100000 + (Math.abs(hash) % 900000);
  return `JK-ITI-REG-${code}`;
}

// Blacklist filter for removed instructors
const BLACKLISTED_REG_NUMS = new Set([
  'JK-ITI-REG-590257',
  'JK-ITI-REG-653707',
  'JK-ITI-REG-458440',
  'JK-ITI-REG-400446',
  'JK-ITI-REG-100201',
  'JK-ITI-REG-200301',
  'JK-ITI-REG-475432',
  'JK-ITI-REG-278280',
  'JK-ITI-REG-588361',
  'JK-ITI-REG-200302',
  'JK-ITI-REG-586769',
  'JK-ITI-REG-100203',
  'JK-ITI-REG-100202',
  'JK-ITI-REG-100204',
  'JK-ITI-REG-200303',
  'JK-ITI-REG-289536',
  'JK-ITI-REG-720595',
  'JK-ITI-REG-897772',
  'JK-ITI-REG-264137',
  'JK-ITI-REG-201023',
  'JK-ITI-REG-884610',
  'JK-ITI-REG-146245',
  'JK-ITI-REG-989966',
  'JK-ITI-REG-215382',
  'JK-ITI-REG-963152',
  'JK-ITI-REG-365329',
  'JK-ITI-REG-743734',
  'JK-ITI-REG-750148',
  'JK-ITI-REG-404733',
  'JK-ITI-REG-315825',
  'JK-ITI-REG-296538',
  'JK-ITI-REG-542704',
  'JK-ITI-REG-151822',
  'JK-ITI-REG-918724',
  'JK-ITI-REG-272737',
  'JK-ITI-REG-610272',
  'JK-ITI-REG-486208',
  'JK-ITI-REG-585456',
  'JK-ITI-REG-467560',
]);

const BLACKLISTED_CONTACTS = new Set([
  '7780962505',
  '9596421046',
  '7006167210',
  '8082443922',
  '9419012345',
  '9419167890',
  '8899530284',
  '8491032805',
  '7051378007',
  '9419198765',
  '9682640071',
  '9419211223',
  '9419054321',
  '9419477889',
  '9419344556',
  '9622039007',
  '7006098334',
  '7780951478',
  '9541046073',
  '9596690147',
  '7889443295',
  '6005587785',
  '7889630988',
  '9596289327',
  '9682666099',
  '9018822606',
  '7889592500',
  '6006313259',
  '6006124970',
  '7889947010',
  '9086864004',
  '6005514350',
  '7006480157',
  '8716023554',
  '9906010644',
  '7780801366',
]);

const BLACKLISTED_NAMES = [
  'ayaz ahmad',
  'hurrah nooren',
  'kaiser hafeez',
  'misba abbas',
  'mohammad altaf rather',
  'rajesh kumar sharma',
  'shams ul fajre',
  'shaziya hassan',
  'sukhvinder kour',
  'sunita devi',
  'syed mehvish',
  'tariq hussain shah',
  'bashir ahmad wani',
  'farooq ahmad dar',
  'vikram singh jamwal',
  'yogesh bhran',
  'younis bashir',
  'ashaq hussain sheikh',
  'azad ahmad ganie',
  'bal krishan',
  'farheena jan',
  'humaira tabasum',
  'masood ahmad thoker',
  'mohasin hussain baba',
  'mohd rafee',
  'najeeb ul rehman',
  'naresh kumar',
  'nisar ahmad mir',
  'rahie afzal malik',
  'rahila',
  'rasik nazir bhat',
  'sameer ahmad sofi',
  'sushma kumari',
  'towseef ahmad rather',
  'vijay kumar',
  'vishal sharma',
  'zahoor ahmad ganie',
];

export function isBlacklistedInstructor(inst: Partial<Instructor>): boolean {
  // Never filter out real instructors during imports or restoration
  return false;
}

// In-Memory Stores backed by JSON files
const BACKUP_FILE = path.join(DATA_DIR, 'uploaded_backup.json');

function normalizeStringServer(str?: string): string {
  if (!str) return '';
  return str.toLowerCase().trim().replace(/[^a-z0-9]/g, '');
}

function normalizeContactServer(contact?: string): string {
  if (!contact) return '';
  const digits = contact.replace(/[^0-9]/g, '');
  if (digits.length >= 10) {
    return digits.slice(-10);
  }
  if (digits.length >= 8) {
    return digits;
  }
  return '';
}

export function deduplicateInstructorsServer(list: Instructor[]): Instructor[] {
  if (!Array.isArray(list)) return [];

  const result: Instructor[] = [];

  list.forEach((rawInst) => {
    if (!rawInst || typeof rawInst !== 'object') return;

    const inst: Instructor = {
      ...rawInst,
      name: (rawInst.name || '').trim(),
      employeeType: rawInst.employeeType || 'Vocational Instructor',
      registrationNo: ensureRegistrationNo(rawInst),
      approvalStatus: rawInst.approvalStatus || 'Approved',
      status: rawInst.status || 'Active',
    };

    const instId = (inst.id || '').trim().toLowerCase();
    const instReg = (inst.registrationNo || '').trim().toUpperCase();
    const instPhone = normalizeContactServer(inst.contact);
    const instName = normalizeStringServer(inst.name);
    const instIti = (inst.itiId || '').trim().toLowerCase();

    let matchIdx = -1;
    for (let i = 0; i < result.length; i++) {
      const existing = result[i];
      const exId = (existing.id || '').trim().toLowerCase();
      const exReg = (existing.registrationNo || '').trim().toUpperCase();
      const exPhone = normalizeContactServer(existing.contact);
      const exName = normalizeStringServer(existing.name);
      const exIti = (existing.itiId || '').trim().toLowerCase();

      if (instId && exId && instId === exId) {
        matchIdx = i;
        break;
      }
      if (instReg && exReg && instReg === exReg) {
        matchIdx = i;
        break;
      }
      if (instPhone && exPhone && instPhone === exPhone) {
        matchIdx = i;
        break;
      }
      if (instName && exName && instIti && exIti && instName === exName && instIti === exIti) {
        matchIdx = i;
        break;
      }
    }

    if (matchIdx >= 0) {
      const existing = result[matchIdx];

      const isApproved =
        existing.approvalStatus === 'Approved' ||
        inst.approvalStatus === 'Approved' ||
        (!existing.approvalStatus && !inst.approvalStatus);

      const isPending =
        !isApproved &&
        ((existing.approvalStatus || '').toLowerCase().includes('pending') ||
          (inst.approvalStatus || '').toLowerCase().includes('pending'));

      const mergedApprovalStatus = isApproved
        ? 'Approved'
        : isPending
        ? 'Pending Review (Awaiting Approval)'
        : inst.approvalStatus || existing.approvalStatus || 'Approved';

      let preferredId = existing.id;
      if (existing.id.startsWith('inst-reg-') && !inst.id.startsWith('inst-reg-')) {
        preferredId = inst.id;
      }

      const preferredTrade =
        (inst.trade || '').length > (existing.trade || '').length
          ? inst.trade
          : existing.trade;

      const preferredContact = inst.contact && inst.contact.trim() ? inst.contact.trim() : existing.contact;

      const preferredRegNo =
        inst.registrationNo && inst.registrationNo.startsWith('JK-ITI-REG-')
          ? inst.registrationNo
          : existing.registrationNo;

      result[matchIdx] = {
        ...existing,
        ...inst,
        id: preferredId,
        name: existing.name || inst.name,
        registrationNo: preferredRegNo,
        trade: preferredTrade,
        contact: preferredContact,
        employeeType: inst.employeeType || existing.employeeType || 'Vocational Instructor',
        approvalStatus: mergedApprovalStatus,
        status: existing.status === 'Active' || inst.status === 'Active' ? 'Active' : inst.status || existing.status,
        updatedAt: new Date().toISOString(),
      };
    } else {
      result.push(inst);
    }
  });

  return result
    .filter((inst) => !isBlacklistedInstructor(inst))
    .sort((a, b) => (a.name || '').localeCompare(b.name || ''));
}

let trainingCentersStore: TrainingCenter[] = readJsonFile<TrainingCenter[]>(TC_FILE, []);
let instructorsStore: Instructor[] = deduplicateInstructorsServer(readJsonFile<Instructor[]>(INST_FILE, []));
let schemesStore: Scheme[] = readJsonFile<Scheme[]>(SCHEMES_FILE, []);
let contributionsStore: Contribution[] = readJsonFile<Contribution[]>(CONTRIB_FILE, []);
let noticesStore: Notice[] = readJsonFile<Notice[]>(NOTICES_FILE, []);
let settingsStore: AppSetting = readJsonFile<AppSetting>(SETTINGS_FILE, {
  id: 'general',
  targetAmount: 0,
  appName: "J&K ITI EMPLOYEE'S UNITED FRONT",
  employeeTypes: [...DEFAULT_EMPLOYEE_TYPES],
  updatedAt: new Date().toISOString(),
});

// Ensure default employee types exist
if (!settingsStore.employeeTypes || !Array.isArray(settingsStore.employeeTypes) || settingsStore.employeeTypes.length === 0) {
  settingsStore.employeeTypes = [...DEFAULT_EMPLOYEE_TYPES];
}

// Auto-seed from backup if store is empty
if (trainingCentersStore.length === 0 && fs.existsSync(BACKUP_FILE)) {
  try {
    const backupContent = fs.readFileSync(BACKUP_FILE, 'utf-8');
    const parsedBackup = JSON.parse(backupContent);
    const backupData = parsedBackup.data || parsedBackup;
    if (Array.isArray(backupData.trainingCenters) && backupData.trainingCenters.length > 0) {
      trainingCentersStore = backupData.trainingCenters;
    }
    if (Array.isArray(backupData.instructors) && backupData.instructors.length > 0) {
      instructorsStore = deduplicateInstructorsServer(backupData.instructors);
    }
    if (Array.isArray(backupData.schemes) && backupData.schemes.length > 0) {
      schemesStore = backupData.schemes;
    }
    if (Array.isArray(backupData.contributions) && backupData.contributions.length > 0) {
      contributionsStore = backupData.contributions;
    }
    if (Array.isArray(backupData.notices) && backupData.notices.length > 0) {
      noticesStore = backupData.notices;
    }
    if (backupData.targetAmount !== undefined) {
      settingsStore.targetAmount = Number(backupData.targetAmount);
    }
    writeJsonFile(TC_FILE, trainingCentersStore);
    writeJsonFile(INST_FILE, instructorsStore);
    writeJsonFile(SCHEMES_FILE, schemesStore);
    writeJsonFile(CONTRIB_FILE, contributionsStore);
    writeJsonFile(NOTICES_FILE, noticesStore);
    writeJsonFile(SETTINGS_FILE, settingsStore);
    console.log(`[API] Auto-initialized database from backup: ${trainingCentersStore.length} ITIs, ${instructorsStore.length} instructors.`);
  } catch (err) {
    console.warn('[API] Auto-initialize backup read note:', err);
  }
}

function persistAll() {
  writeJsonFile(TC_FILE, trainingCentersStore);
  writeJsonFile(INST_FILE, instructorsStore);
  writeJsonFile(SCHEMES_FILE, schemesStore);
  writeJsonFile(CONTRIB_FILE, contributionsStore);
  writeJsonFile(NOTICES_FILE, noticesStore);
  writeJsonFile(SETTINGS_FILE, settingsStore);
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Strict No-Cache and No-Cookie Policy on all responses
  app.use((req, res, next) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0, s-maxage=0');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.setHeader('Surrogate-Control', 'no-store');
    res.removeHeader('Set-Cookie');
    next();
  });

  app.use(express.json({ limit: '100mb' }));
  app.use(express.urlencoded({ limit: '100mb', extended: true }));

  // Health
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      counts: {
        trainingCenters: trainingCentersStore.length,
        instructors: instructorsStore.length,
        schemes: schemesStore.length,
        contributions: contributionsStore.length,
        notices: noticesStore.length,
      },
    });
  });

  // ========================
  // TRAINING CENTERS API
  // ========================
  app.get('/api/training-centers', (req, res) => {
    res.json(trainingCentersStore);
  });

  app.post('/api/training-centers', (req, res) => {
    const raw = req.body || {};
    const id = raw.id || `iti-${raw.sNo || Date.now()}`;
    const now = new Date().toISOString();
    const newTC: TrainingCenter = {
      ...raw,
      id,
      sNo: raw.sNo ? Number(raw.sNo) : trainingCentersStore.length + 1,
      createdAt: raw.createdAt || now,
      updatedAt: now,
    };
    // Replace if exists, else append
    const idx = trainingCentersStore.findIndex((t) => t.id === id);
    if (idx !== -1) {
      trainingCentersStore[idx] = newTC;
    } else {
      trainingCentersStore.push(newTC);
    }
    trainingCentersStore.sort((a, b) => (a.sNo || 0) - (b.sNo || 0));
    writeJsonFile(TC_FILE, trainingCentersStore);
    res.status(201).json(newTC);
  });

  app.post('/api/training-centers/batch', (req, res) => {
    const list: TrainingCenter[] = req.body || [];
    if (Array.isArray(list)) {
      const now = new Date().toISOString();
      list.forEach((raw) => {
        const id = raw.id || `iti-${raw.sNo || Date.now()}`;
        const item: TrainingCenter = {
          ...raw,
          id,
          sNo: raw.sNo ? Number(raw.sNo) : trainingCentersStore.length + 1,
          createdAt: raw.createdAt || now,
          updatedAt: now,
        };
        const idx = trainingCentersStore.findIndex((t) => t.id === id);
        if (idx !== -1) {
          trainingCentersStore[idx] = item;
        } else {
          trainingCentersStore.push(item);
        }
      });
      trainingCentersStore.sort((a, b) => (a.sNo || 0) - (b.sNo || 0));
      writeJsonFile(TC_FILE, trainingCentersStore);
    }
    res.json({ success: true, count: trainingCentersStore.length });
  });

  app.put('/api/training-centers/:id', (req, res) => {
    const { id } = req.params;
    const idx = trainingCentersStore.findIndex((t) => t.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Training Center not found' });
    }
    trainingCentersStore[idx] = {
      ...trainingCentersStore[idx],
      ...req.body,
      id,
      updatedAt: new Date().toISOString(),
    };
    trainingCentersStore.sort((a, b) => (a.sNo || 0) - (b.sNo || 0));
    writeJsonFile(TC_FILE, trainingCentersStore);
    res.json(trainingCentersStore[idx]);
  });

  app.delete('/api/training-centers/:id', (req, res) => {
    const { id } = req.params;
    trainingCentersStore = trainingCentersStore.filter((t) => t.id !== id);
    writeJsonFile(TC_FILE, trainingCentersStore);
    res.json({ success: true });
  });

  app.post('/api/training-centers/clear-remarks', (req, res) => {
    const now = new Date().toISOString();
    let count = 0;
    trainingCentersStore.forEach((tc) => {
      if (tc.remarks && tc.remarks.trim() !== '') {
        tc.remarks = '';
        tc.updatedAt = now;
        count++;
      }
    });
    if (count > 0) {
      writeJsonFile(TC_FILE, trainingCentersStore);
    }
    res.json({ success: true, updatedCount: count });
  });

  // ========================
  // INSTRUCTORS API
  // ========================
  app.get('/api/instructors', (req, res) => {
    res.json(instructorsStore);
  });

  app.post('/api/instructors/register', (req, res) => {
    const raw = req.body || {};
    const now = new Date().toISOString();
    const randNum = Math.floor(100000 + Math.random() * 900000);
    const registrationNo = raw.registrationNo || `JK-ITI-REG-${randNum}`;
    const id = raw.id || `inst-reg-${Date.now()}`;

    const newInstructor: Instructor = {
      id,
      name: (raw.name || '').trim(),
      itiId: raw.itiId || 'iti-1',
      itiName: raw.itiName || 'Government ITI',
      division: raw.division || 'Kashmir Division',
      trade: (raw.trade || '').trim(),
      contact: (raw.contact || '').trim(),
      employeeType: raw.employeeType || 'Vocational Instructor',
      joiningDate: raw.joiningDate || now.split('T')[0],
      registrationNo,
      status: raw.status || 'Active',
      approvalStatus: raw.approvalStatus || 'Pending Review (Awaiting Approval)',
      remarks: (raw.remarks || '').trim(),
      createdAt: raw.createdAt || now,
      updatedAt: now,
    };

    instructorsStore = deduplicateInstructorsServer([newInstructor, ...instructorsStore]);
    writeJsonFile(INST_FILE, instructorsStore);

    const savedInstructor = instructorsStore.find((i) => i.id === newInstructor.id || i.registrationNo === newInstructor.registrationNo) || newInstructor;
    console.log(`[API] Instructor registered/deduplicated: ${savedInstructor.name} (${savedInstructor.registrationNo})`);
    res.status(201).json(savedInstructor);
  });

  app.post('/api/instructors', (req, res) => {
    const raw = req.body || {};
    const id = raw.id || `inst-${Date.now()}`;
    const randNum = Math.floor(100000 + Math.random() * 900000);
    const registrationNo = raw.registrationNo || `JK-ITI-REG-${randNum}`;
    const now = new Date().toISOString();

    const inst: Instructor = {
      ...raw,
      id,
      registrationNo,
      employeeType: raw.employeeType || 'Vocational Instructor',
      approvalStatus: raw.approvalStatus || 'Approved',
      status: raw.status || 'Active',
      createdAt: raw.createdAt || now,
      updatedAt: now,
    };

    instructorsStore = deduplicateInstructorsServer([inst, ...instructorsStore]);
    writeJsonFile(INST_FILE, instructorsStore);

    const saved = instructorsStore.find((i) => i.id === inst.id || i.registrationNo === inst.registrationNo) || inst;
    res.status(201).json(saved);
  });

  app.put('/api/instructors/:id', (req, res) => {
    const { id } = req.params;
    const idx = instructorsStore.findIndex((i) => i.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Instructor not found' });
    }

    instructorsStore[idx] = {
      ...instructorsStore[idx],
      ...req.body,
      id,
      updatedAt: new Date().toISOString(),
    };
    writeJsonFile(INST_FILE, instructorsStore);
    res.json(instructorsStore[idx]);
  });

  app.post('/api/instructors/clear-all', (req, res) => {
    instructorsStore = [];
    writeJsonFile(INST_FILE, instructorsStore);
    console.log('[API] All instructors removed from database.');
    res.json({ success: true, count: 0 });
  });

  app.delete('/api/instructors/:id', (req, res) => {
    const { id } = req.params;
    instructorsStore = instructorsStore.filter((i) => i.id !== id);
    writeJsonFile(INST_FILE, instructorsStore);
    res.json({ success: true });
  });

  app.post('/api/instructors/approve', (req, res) => {
    const { id } = req.body;
    const inst = instructorsStore.find((i) => i.id === id);
    if (!inst) {
      return res.status(404).json({ error: 'Instructor not found' });
    }

    inst.approvalStatus = 'Approved';
    inst.status = 'Active';
    inst.updatedAt = new Date().toISOString();
    writeJsonFile(INST_FILE, instructorsStore);

    res.json({ success: true, instructor: inst });
  });

  app.post('/api/instructors/reject', (req, res) => {
    const { id } = req.body;
    const inst = instructorsStore.find((i) => i.id === id);
    if (!inst) {
      return res.status(404).json({ error: 'Instructor not found' });
    }

    inst.approvalStatus = 'Rejected';
    inst.status = 'Inactive';
    inst.updatedAt = new Date().toISOString();
    writeJsonFile(INST_FILE, instructorsStore);

    res.json({ success: true, instructor: inst });
  });

  // ========================
  // SCHEMES API
  // ========================
  app.get('/api/schemes', (req, res) => {
    res.json(schemesStore);
  });

  app.post('/api/schemes', (req, res) => {
    const raw = req.body || {};
    const id = raw.id || `scheme-${Date.now()}`;
    const now = new Date().toISOString();
    const newScheme: Scheme = {
      ...raw,
      id,
      targetAmount: Number(raw.targetAmount) || 0,
      createdAt: raw.createdAt || now,
      updatedAt: now,
    };
    const idx = schemesStore.findIndex((s) => s.id === id);
    if (idx !== -1) {
      schemesStore[idx] = newScheme;
    } else {
      schemesStore.unshift(newScheme);
    }
    writeJsonFile(SCHEMES_FILE, schemesStore);
    res.status(201).json(newScheme);
  });

  app.put('/api/schemes/:id', (req, res) => {
    const { id } = req.params;
    const idx = schemesStore.findIndex((s) => s.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Scheme not found' });
    }
    schemesStore[idx] = {
      ...schemesStore[idx],
      ...req.body,
      id,
      targetAmount: req.body.targetAmount !== undefined ? Number(req.body.targetAmount) : schemesStore[idx].targetAmount,
      updatedAt: new Date().toISOString(),
    };
    writeJsonFile(SCHEMES_FILE, schemesStore);
    res.json(schemesStore[idx]);
  });

  app.delete('/api/schemes/:id', (req, res) => {
    const { id } = req.params;
    schemesStore = schemesStore.filter((s) => s.id !== id);
    writeJsonFile(SCHEMES_FILE, schemesStore);

    // Also delete associated contributions from database
    const prevContribCount = contributionsStore.length;
    contributionsStore = contributionsStore.filter((c) => c.schemeId !== id);
    if (contributionsStore.length !== prevContribCount) {
      writeJsonFile(CONTRIB_FILE, contributionsStore);
    }

    res.json({
      success: true,
      deletedContributionsCount: prevContribCount - contributionsStore.length,
    });
  });

  // ========================
  // CONTRIBUTIONS API
  // ========================
  app.get('/api/contributions', (req, res) => {
    res.json(contributionsStore);
  });

  app.post('/api/contributions', (req, res) => {
    const raw = req.body || {};
    const id = raw.id || `contrib-${Date.now()}`;
    const now = new Date().toISOString();
    const newContrib: Contribution = {
      ...raw,
      id,
      amount: Number(raw.amount) || 0,
      createdAt: raw.createdAt || now,
      updatedAt: now,
    };
    const idx = contributionsStore.findIndex((c) => c.id === id);
    if (idx !== -1) {
      contributionsStore[idx] = newContrib;
    } else {
      contributionsStore.unshift(newContrib);
    }
    writeJsonFile(CONTRIB_FILE, contributionsStore);
    res.status(201).json(newContrib);
  });

  app.put('/api/contributions/:id', (req, res) => {
    const { id } = req.params;
    const idx = contributionsStore.findIndex((c) => c.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Contribution not found' });
    }
    contributionsStore[idx] = {
      ...contributionsStore[idx],
      ...req.body,
      id,
      amount: req.body.amount !== undefined ? Number(req.body.amount) : contributionsStore[idx].amount,
      updatedAt: new Date().toISOString(),
    };
    writeJsonFile(CONTRIB_FILE, contributionsStore);
    res.json(contributionsStore[idx]);
  });

  app.delete('/api/contributions/:id', (req, res) => {
    const { id } = req.params;
    contributionsStore = contributionsStore.filter((c) => c.id !== id);
    writeJsonFile(CONTRIB_FILE, contributionsStore);
    res.json({ success: true });
  });

  app.post('/api/contributions/clear-remarks', (req, res) => {
    const now = new Date().toISOString();
    let count = 0;
    contributionsStore.forEach((c) => {
      if (c.remarks && c.remarks.trim() !== '') {
        c.remarks = '';
        c.updatedAt = now;
        count++;
      }
    });
    if (count > 0) {
      writeJsonFile(CONTRIB_FILE, contributionsStore);
    }
    res.json({ success: true, updatedCount: count });
  });

  // ========================
  // NOTICES API
  // ========================
  app.get('/api/notices', (req, res) => {
    res.json(noticesStore);
  });

  app.post('/api/notices', (req, res) => {
    const raw = req.body || {};
    const id = raw.id || `notice-${Date.now()}`;
    const now = new Date().toISOString();
    const newNotice: Notice = {
      ...raw,
      id,
      createdAt: raw.createdAt || now,
      updatedAt: now,
    };
    const idx = noticesStore.findIndex((n) => n.id === id);
    if (idx !== -1) {
      noticesStore[idx] = newNotice;
    } else {
      noticesStore.unshift(newNotice);
    }
    writeJsonFile(NOTICES_FILE, noticesStore);
    res.status(201).json(newNotice);
  });

  app.put('/api/notices/:id', (req, res) => {
    const { id } = req.params;
    const idx = noticesStore.findIndex((n) => n.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Notice not found' });
    }
    noticesStore[idx] = {
      ...noticesStore[idx],
      ...req.body,
      id,
      updatedAt: new Date().toISOString(),
    };
    writeJsonFile(NOTICES_FILE, noticesStore);
    res.json(noticesStore[idx]);
  });

  app.delete('/api/notices/:id', (req, res) => {
    const { id } = req.params;
    noticesStore = noticesStore.filter((n) => n.id !== id);
    writeJsonFile(NOTICES_FILE, noticesStore);
    res.json({ success: true });
  });

  // ========================
  // SETTINGS API
  // ========================
  app.get('/api/settings', (req, res) => {
    res.json(settingsStore);
  });

  app.post('/api/settings', (req, res) => {
    let employeeTypes: string[] = settingsStore.employeeTypes || [...DEFAULT_EMPLOYEE_TYPES];
    if (Array.isArray(req.body.employeeTypes)) {
      employeeTypes = Array.from(new Set(req.body.employeeTypes.map((t: any) => String(t).trim()))).filter(Boolean) as string[];
    }
    settingsStore = {
      ...settingsStore,
      ...req.body,
      employeeTypes,
      updatedAt: new Date().toISOString(),
    };
    writeJsonFile(SETTINGS_FILE, settingsStore);
    res.json(settingsStore);
  });

  // ========================
  // WIPE ALL DATABASE API (Complete Clean)
  // ========================
  app.post('/api/database/wipe-all', (req, res) => {
    trainingCentersStore = [];
    instructorsStore = [];
    schemesStore = [];
    contributionsStore = [];
    noticesStore = [];
    settingsStore = {
      id: 'general',
      targetAmount: 0,
      appName: "J&K ITI EMPLOYEE'S UNITED FRONT",
      employeeTypes: [...DEFAULT_EMPLOYEE_TYPES],
      updatedAt: new Date().toISOString(),
    };
    persistAll();
    console.log('[API] Database completely wiped. All collections are now empty.');
    res.json({ success: true, message: 'Database wiped clean. 0 records.' });
  });

  // ========================
  // BACKUP & RESTORE API
  // ========================
  app.get('/api/backup', (req, res) => {
    res.json({
      version: '2.0',
      exportedAt: new Date().toISOString(),
      portal: "J&K ITI Employee's United Front",
      metadata: {
        trainingCentersCount: trainingCentersStore.length,
        instructorsCount: instructorsStore.length,
        schemesCount: schemesStore.length,
        contributionsCount: contributionsStore.length,
        noticesCount: noticesStore.length,
        targetAmount: settingsStore.targetAmount || 0,
      },
      data: {
        trainingCenters: trainingCentersStore,
        instructors: instructorsStore,
        schemes: schemesStore,
        contributions: contributionsStore,
        notices: noticesStore,
        targetAmount: settingsStore.targetAmount || 0,
        employeeTypes: settingsStore.employeeTypes || [...DEFAULT_EMPLOYEE_TYPES],
      },
    });
  });

  app.post('/api/backup/restore', (req, res) => {
    try {
      const backup = req.body;
      if (!backup) {
        return res.status(400).json({ error: 'No backup payload provided' });
      }

      // Handle raw array payload or nested wrappers
      let sourceData: any = backup;
      if (backup.data && typeof backup.data === 'object' && !Array.isArray(backup.data)) {
        sourceData = backup.data;
      } else if (backup.backup && typeof backup.backup === 'object' && !Array.isArray(backup.backup)) {
        sourceData = backup.backup.data || backup.backup;
      }

      const now = new Date().toISOString();

      // Extract collections with flexible keywords / aliases
      const getArray = (src: any, keys: string[]): any[] => {
        if (!src || typeof src !== 'object') return [];
        for (const k of keys) {
          if (Array.isArray(src[k])) return src[k];
          if (src[k] && typeof src[k] === 'object') {
            return Object.keys(src[k]).map((idKey) => {
              const item = src[k][idKey];
              return typeof item === 'object' && item !== null ? { ...item, id: item.id || idKey } : item;
            });
          }
        }
        return [];
      };

      let rawTC: any[] = [];
      let rawInst: any[] = [];
      let rawSchemes: any[] = [];
      let rawContribs: any[] = [];
      let rawNotices: any[] = [];
      let targetAmount = 0;

      if (Array.isArray(backup)) {
        // Raw array of records
        backup.forEach((item: any) => {
          if (!item || typeof item !== 'object') return;
          const colType = (item.collection || item._collection || item.type || item.entityType || '').toLowerCase();
          if (colType.includes('tc') || colType.includes('center') || colType.includes('iti')) {
            rawTC.push(item);
          } else if (colType.includes('inst') || colType.includes('teach') || colType.includes('member')) {
            rawInst.push(item);
          } else if (colType.includes('sch') || colType.includes('welfare')) {
            rawSchemes.push(item);
          } else if (colType.includes('contrib') || colType.includes('donat') || colType.includes('fund')) {
            rawContribs.push(item);
          } else if (colType.includes('notice') || colType.includes('announc') || colType.includes('event')) {
            rawNotices.push(item);
          } else if (item.trade || item.registrationNo || item.designation || item.fatherName) {
            rawInst.push(item);
          } else if (item.district || item.division || item.itiCode || (item.name && item.name.includes('ITI'))) {
            rawTC.push(item);
          } else if (item.amount || item.donorName || item.transactionId) {
            rawContribs.push(item);
          } else if (item.title && (item.content || item.publishedDate || item.date)) {
            rawNotices.push(item);
          } else if (item.schemeName || item.coverageDetails) {
            rawSchemes.push(item);
          } else {
            rawInst.push(item);
          }
        });
      } else {
        rawTC = getArray(sourceData, [
          'trainingCenters',
          'training_centers',
          'TrainingCenters',
          'itis',
          'ITIs',
          'centers',
          'institutes',
        ]);
        rawInst = getArray(sourceData, [
          'instructors',
          'Instructors',
          'instructor',
          'vocationalInstructors',
          'vocational_instructors',
          'members',
          'staff',
          'teachers',
          'users',
          'records',
        ]);
        rawSchemes = getArray(sourceData, [
          'schemes',
          'Schemes',
          'welfareSchemes',
          'welfare_schemes',
          'welfare',
          'benefits',
        ]);
        rawContribs = getArray(sourceData, [
          'contributions',
          'Contributions',
          'donations',
          'funds',
          'payments',
          'transactions',
        ]);
        rawNotices = getArray(sourceData, [
          'notices',
          'Notices',
          'announcements',
          'circulars',
          'events',
          'news',
        ]);
        targetAmount =
          sourceData.targetAmount ??
          backup.targetAmount ??
          backup.metadata?.targetAmount ??
          settingsStore.targetAmount ??
          0;
      }

      // Update training centers if supplied in backup
      if (rawTC.length > 0) {
        trainingCentersStore = rawTC.map((tc: any, i: number) => {
          const id = tc.id || tc.code || `tc-${Date.now()}-${i}`;
          return {
            ...tc,
            id,
            sNo: tc.sNo ? Number(tc.sNo) : i + 1,
            district: tc.district || '',
            division: tc.division || 'Kashmir Division',
            name: tc.name || '',
            status: tc.status || 'Active',
            remarks: tc.remarks !== undefined ? tc.remarks : '',
            updatedAt: tc.updatedAt || now,
          };
        });
        trainingCentersStore.sort((a, b) => (a.sNo || 0) - (b.sNo || 0));
      }

      // Update instructors if supplied in backup (never drop instructors)
      if (rawInst.length > 0) {
        instructorsStore = deduplicateInstructorsServer(
          rawInst.map((inst: any, i: number) => ({
            ...inst,
            id: inst.id || `inst-${Date.now()}-${i}`,
            registrationNo: ensureRegistrationNo(inst),
            approvalStatus: inst.approvalStatus || 'Approved',
            status: inst.status || 'Active',
            updatedAt: inst.updatedAt || now,
          }))
        );
      }

      // Update schemes if supplied
      if (rawSchemes.length > 0) {
        schemesStore = rawSchemes.map((s: any, i: number) => ({
          ...s,
          id: s.id || `sch-${Date.now()}-${i}`,
          updatedAt: s.updatedAt || now,
        }));
      }

      // Update contributions if supplied
      if (rawContribs.length > 0) {
        contributionsStore = rawContribs.map((c: any, i: number) => ({
          ...c,
          id: c.id || `contrib-${Date.now()}-${i}`,
          amount: Number(c.amount) || 0,
          updatedAt: c.updatedAt || now,
        }));
      }

      // Update notices if supplied
      if (rawNotices.length > 0) {
        noticesStore = rawNotices.map((n: any, i: number) => ({
          ...n,
          id: n.id || `notice-${Date.now()}-${i}`,
          updatedAt: n.updatedAt || now,
        }));
      }

      // Update settings
      const restoredEmployeeTypes = Array.isArray(sourceData.employeeTypes) && sourceData.employeeTypes.length > 0
        ? sourceData.employeeTypes
        : (settingsStore.employeeTypes || [...DEFAULT_EMPLOYEE_TYPES]);

      settingsStore = {
        id: 'general',
        targetAmount: Number(targetAmount) || settingsStore.targetAmount || 0,
        appName: "J&K ITI EMPLOYEE'S UNITED FRONT",
        employeeTypes: restoredEmployeeTypes,
        isSeeded: true,
        updatedAt: now,
      };

      persistAll();
      console.log(
        `[API] Backup restored successfully: ${trainingCentersStore.length} ITIs, ${instructorsStore.length} Instructors, ${schemesStore.length} Schemes, ${contributionsStore.length} Contributions, ${noticesStore.length} Notices.`
      );

      res.json({
        success: true,
        counts: {
          trainingCenters: trainingCentersStore.length,
          instructors: instructorsStore.length,
          schemes: schemesStore.length,
          contributions: contributionsStore.length,
          notices: noticesStore.length,
          targetAmount: settingsStore.targetAmount,
        },
      });
    } catch (err: any) {
      console.error('Error restoring backup:', err);
      res.status(500).json({ error: err.message || 'Failed to restore backup' });
    }
  });

  // ========================
  // ADMIN ACTIVE SESSION STORE
  // ========================
  interface ActiveAdminSession {
    uid: string;
    email: string;
    sessionId: string;
    lastActiveAt: number;
    loginAt: number;
  }
  const activeAdminSessions = new Map<string, ActiveAdminSession>();
  const SESSION_TIMEOUT_MS = 120 * 1000; // 2 minutes timeout

  app.post('/api/admin/session/register', (req, res) => {
    const { uid, email, sessionId } = req.body || {};
    if (!uid || !sessionId) {
      return res.status(400).json({ error: 'Missing uid or sessionId' });
    }

    const now = Date.now();
    const session: ActiveAdminSession = {
      uid,
      email: email || '',
      sessionId,
      lastActiveAt: now,
      loginAt: now,
    };
    activeAdminSessions.set(uid, session);
    res.json({ success: true, session });
  });

  app.get('/api/admin/session/check/:uid', (req, res) => {
    const { uid } = req.params;
    const clientSessionId = req.query.sessionId as string;
    const session = activeAdminSessions.get(uid);

    if (!session) {
      return res.json({ active: false, reason: 'no_session' });
    }

    const now = Date.now();
    const isTimedOut = now - session.lastActiveAt > SESSION_TIMEOUT_MS;
    if (isTimedOut) {
      activeAdminSessions.delete(uid);
      return res.json({ active: false, reason: 'timeout' });
    }

    if (clientSessionId && session.sessionId !== clientSessionId) {
      return res.json({ active: false, reason: 'superseded', activeSessionId: session.sessionId });
    }

    res.json({
      active: true,
      sessionId: session.sessionId,
      remainingSeconds: Math.max(0, Math.ceil((session.lastActiveAt + SESSION_TIMEOUT_MS - now) / 1000)),
    });
  });

  app.post('/api/admin/session/ping', (req, res) => {
    const { uid, sessionId } = req.body || {};
    if (!uid || !sessionId) {
      return res.status(400).json({ error: 'Missing uid or sessionId' });
    }

    const session = activeAdminSessions.get(uid);
    if (!session) {
      return res.status(404).json({ error: 'Session not found', active: false });
    }

    if (session.sessionId !== sessionId) {
      return res.status(409).json({ error: 'Session superseded', active: false });
    }

    const now = Date.now();
    session.lastActiveAt = now;
    res.json({
      success: true,
      remainingSeconds: Math.max(0, Math.ceil((session.lastActiveAt + SESSION_TIMEOUT_MS - now) / 1000)),
    });
  });

  app.post('/api/admin/session/clear', (req, res) => {
    const { uid, sessionId } = req.body || {};
    if (uid) {
      const current = activeAdminSessions.get(uid);
      if (!sessionId || (current && current.sessionId === sessionId)) {
        activeAdminSessions.delete(uid);
      }
    }
    res.json({ success: true });
  });

  // ========================
  // VITE DEV / PRODUCTION STATIC
  // ========================
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      const indexPath = path.join(distPath, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(200).send('<!doctype html><html><body><h1>Application Initializing...</h1><p>Please refresh in a moment.</p><script>setTimeout(() => location.reload(), 2000);</script></body></html>');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
