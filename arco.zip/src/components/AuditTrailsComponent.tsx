import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Search,
  Filter,
  Download,
  Calendar,
  User,
  Activity,
  FileText,
  Printer,
  Trash2,
  Edit3,
  PlusCircle,
  Database,
  ArrowUpDown,
  RefreshCw,
  Eye,
  SlidersHorizontal,
  FileSpreadsheet,
  CheckCircle2,
  X,
  Clock,
  Layers,
  Sparkles,
  Wrench,
  Cpu,
  AlertTriangle,
  Server,
  ShieldCheck,
  CheckCircle,
  FileCheck,
  Zap,
} from 'lucide-react';
import { AuditLog, AuditAction, AuditEntityType, UserRole } from '../types';
import { auditService } from '../services/auditService';
import { rbacService, ROLE_DESCRIPTIONS } from '../services/rbacService';
import { authService } from '../services/authService';
import { dbService } from '../services/storage';

export const AuditTrailsComponent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'activity_trail' | 'corrections_system_log'>('activity_trail');
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAction, setSelectedAction] = useState<string>('ALL');
  const [selectedEntity, setSelectedEntity] = useState<string>('ALL');
  const [selectedUser, setSelectedUser] = useState<string>('ALL');
  const [dateFilter, setDateFilter] = useState<'ALL' | 'TODAY' | '7_DAYS' | '30_DAYS'>('ALL');
  const [correctionCategory, setCorrectionCategory] = useState<'ALL' | 'STOCK' | 'INVOICE_OVERRIDE' | 'SYSTEM_DIAG' | 'SECURITY_AUTH' | 'REVERSAL'>('ALL');
  
  const [activeLogModal, setActiveLogModal] = useState<AuditLog | null>(null);
  const [logToDelete, setLogToDelete] = useState<AuditLog | null>(null);
  const [showDeleteAllModal, setShowDeleteAllModal] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isRunningDiagnostic, setIsRunningDiagnostic] = useState(false);
  const [diagnosticResult, setDiagnosticResult] = useState<{
    status: 'HEALTHY' | 'WARNING' | 'OPTIMAL';
    timestamp: string;
    itemsChecked: number;
    invoicesVerified: number;
    suppliersVerified: number;
    customersVerified: number;
    issuesFound: string[];
  } | null>(null);
  const [exportFeedback, setExportFeedback] = useState<string | null>(null);

  const currentUser = authService.getActiveAdmin();
  const isSuperAdmin = rbacService.isSuperAdmin();

  useEffect(() => {
    const unsubscribe = auditService.subscribe((updated) => {
      setLogs(updated);
    });
    return () => unsubscribe();
  }, []);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setLogs(auditService.getLogs());
      setIsRefreshing(false);
    }, 400);
  };

  const handleRunDiagnostic = () => {
    setIsRunningDiagnostic(true);
    setTimeout(() => {
      try {
        const items = dbService.getItems();
        const sales = dbService.getSales();
        const purchases = dbService.getPurchases();
        const customers = dbService.getCustomers();
        const suppliers = dbService.getSuppliers();

        const issues: string[] = [];

        // Check for items with negative stock
        const negativeStock = items.filter((it) => (it.currentStock || 0) < 0);
        if (negativeStock.length > 0) {
          issues.push(`${negativeStock.length} items currently have negative stock balances`);
        }

        // Check for duplicate invoice IDs
        const invoiceIds = new Set<string>();
        sales.forEach((s) => {
          if (invoiceIds.has(s.id)) {
            issues.push(`Duplicate invoice reference detected: ${s.id}`);
          }
          invoiceIds.add(s.id);
        });

        const status = issues.length === 0 ? 'OPTIMAL' : 'WARNING';
        const result = {
          status: status as 'HEALTHY' | 'WARNING' | 'OPTIMAL',
          timestamp: new Date().toISOString(),
          itemsChecked: items.length,
          invoicesVerified: sales.length + purchases.length,
          suppliersVerified: suppliers.length,
          customersVerified: customers.length,
          issuesFound: issues,
        };

        setDiagnosticResult(result);

        // Record a system diagnostic audit log
        auditService.log({
          action: 'SYSTEM_CHECK',
          entityType: 'SYSTEM',
          entityId: `SYS-DIAG-${Date.now().toString().slice(-6)}`,
          entityName: 'Core Diagnostic Engine',
          summary: `System integrity & catalog audit: ${status} (${items.length} items, ${sales.length} sales verified)`,
          details: {
            status,
            itemsChecked: items.length,
            invoicesVerified: sales.length,
            issuesCount: issues.length,
            issuesSummary: issues.slice(0, 5),
          },
        });

        setExportFeedback('Diagnostic scan completed and logged to System Logs');
        setTimeout(() => setExportFeedback(null), 3500);
      } catch (err) {
        console.error('Error running system diagnostic:', err);
      } finally {
        setIsRunningDiagnostic(false);
      }
    }, 600);
  };

  const handleDeleteSingleLog = async () => {
    if (!logToDelete) return;
    setIsDeleting(true);
    try {
      await auditService.deleteLog(logToDelete.id);
      setExportFeedback(`Deleted audit log (${logToDelete.entityId}) successfully`);
      setLogToDelete(null);
      setTimeout(() => setExportFeedback(null), 3000);
    } catch (err) {
      console.error('Error deleting audit log:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleDeleteAllActive = async () => {
    if (activeFilteredLogs.length === 0) return;
    setIsDeleting(true);
    try {
      const idsToDelete = activeFilteredLogs.map((l) => l.id);
      const count = await auditService.deleteLogs(idsToDelete);
      setExportFeedback(`Successfully deleted ${count} entries`);
      setShowDeleteAllModal(false);
      setTimeout(() => setExportFeedback(null), 3500);
    } catch (err) {
      console.error('Error deleting audit logs:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  // Helper to determine if a log belongs to Corrections & System Logs
  const isCorrectionOrSystemLog = (log: AuditLog): boolean => {
    if (['UPDATE', 'DELETE', 'ADJUST_STOCK', 'CORRECTION', 'SYSTEM_CHECK', 'OVERRIDE', 'REVERSAL', 'BACKUP', 'RESTORE'].includes(log.action)) {
      return true;
    }
    if (['SETTINGS', 'USER', 'SYSTEM', 'LEDGER_CORRECTION', 'STOCK_ADJUSTMENT'].includes(log.entityType)) {
      return true;
    }
    const sum = (log.summary || '').toLowerCase();
    return sum.includes('edit') || sum.includes('correct') || sum.includes('override') || sum.includes('revers') || sum.includes('adjust') || sum.includes('diagnostic');
  };

  // Base list depending on tab
  const tabBaseLogs = logs.filter((log) => {
    if (activeTab === 'corrections_system_log') {
      return isCorrectionOrSystemLog(log);
    }
    return true; // Activity Trail displays all chronological activity
  });

  // Filtered logs for the active tab
  const activeFilteredLogs = tabBaseLogs.filter((log) => {
    if (activeTab === 'corrections_system_log') {
      if (correctionCategory === 'STOCK' && !(log.action === 'ADJUST_STOCK' || log.entityType === 'STOCK_ADJUSTMENT' || log.entityType === 'ITEM')) return false;
      if (correctionCategory === 'INVOICE_OVERRIDE' && !(log.entityType === 'INVOICE' && (log.action === 'UPDATE' || log.action === 'DELETE' || log.action === 'CORRECTION' || log.action === 'OVERRIDE'))) return false;
      if (correctionCategory === 'SYSTEM_DIAG' && !(log.action === 'SYSTEM_CHECK' || log.action === 'BACKUP' || log.action === 'RESTORE' || log.entityType === 'SYSTEM')) return false;
      if (correctionCategory === 'SECURITY_AUTH' && !(log.action === 'LOGIN' || log.entityType === 'SETTINGS' || log.entityType === 'USER')) return false;
      if (correctionCategory === 'REVERSAL' && !(log.action === 'REVERSAL' || (log.summary && log.summary.toLowerCase().includes('return')))) return false;
    }

    if (selectedAction !== 'ALL' && log.action !== selectedAction) return false;
    if (selectedEntity !== 'ALL' && log.entityType !== selectedEntity) return false;
    if (selectedUser !== 'ALL' && log.userEmail.toLowerCase() !== selectedUser.toLowerCase()) return false;

    if (dateFilter !== 'ALL') {
      const logDate = new Date(log.timestamp);
      const now = new Date();
      if (dateFilter === 'TODAY') {
        if (logDate.toDateString() !== now.toDateString()) return false;
      } else if (dateFilter === '7_DAYS') {
        const diffDays = (now.getTime() - logDate.getTime()) / (1000 * 60 * 60 * 24);
        if (diffDays > 7) return false;
      } else if (dateFilter === '30_DAYS') {
        const diffDays = (now.getTime() - logDate.getTime()) / (1000 * 60 * 60 * 24);
        if (diffDays > 30) return false;
      }
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      return (
        log.summary.toLowerCase().includes(q) ||
        log.entityId.toLowerCase().includes(q) ||
        (log.entityName && log.entityName.toLowerCase().includes(q)) ||
        log.userName.toLowerCase().includes(q) ||
        log.userEmail.toLowerCase().includes(q) ||
        log.action.toLowerCase().includes(q)
      );
    }

    return true;
  });

  // Extract unique users
  const uniqueUsers = Array.from(
    new Set(logs.map((l) => JSON.stringify({ email: l.userEmail, name: l.userName })))
  ).map((s) => JSON.parse(s));

  // Quick stats
  const totalLogs = logs.length;
  const totalCorrections = logs.filter(isCorrectionOrSystemLog).length;
  const invoicesCreated = logs.filter((l) => l.action === 'CREATE' && l.entityType === 'INVOICE').length;
  const invoicesEdited = logs.filter((l) => l.action === 'UPDATE' && l.entityType === 'INVOICE').length;
  const invoicesDeleted = logs.filter((l) => l.action === 'DELETE' && l.entityType === 'INVOICE').length;
  const invoicesPrinted = logs.filter((l) => l.action === 'PRINT' && l.entityType === 'INVOICE').length;
  const stockAdjusted = logs.filter((l) => l.action === 'ADJUST_STOCK').length;
  const systemChecksCount = logs.filter((l) => l.action === 'SYSTEM_CHECK' || l.action === 'BACKUP' || l.action === 'RESTORE').length;

  const handleExportCsv = () => {
    const csv = auditService.exportToCsv(activeFilteredLogs);
    const prefix = activeTab === 'corrections_system_log' ? 'Corrections_System_Log' : 'Audit_Trail';
    const dateStr = new Date().toISOString().slice(0, 10);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${prefix}_${dateStr}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setExportFeedback(`Exported ${activeTab === 'corrections_system_log' ? 'Corrections & System Log' : 'Audit Trail'} to CSV`);
    setTimeout(() => setExportFeedback(null), 3000);
  };

  const handleExportJson = () => {
    const json = auditService.exportToJson(activeFilteredLogs);
    const prefix = activeTab === 'corrections_system_log' ? 'Corrections_System_Log' : 'Audit_Trail';
    const dateStr = new Date().toISOString().slice(0, 10);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${prefix}_${dateStr}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setExportFeedback(`Exported ${activeTab === 'corrections_system_log' ? 'Corrections & System Log' : 'Audit Trail'} to JSON`);
    setTimeout(() => setExportFeedback(null), 3000);
  };

  const getActionBadge = (action: AuditAction) => {
    switch (action) {
      case 'CREATE':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <PlusCircle className="w-3 h-3" />
            CREATED
          </span>
        );
      case 'UPDATE':
      case 'CORRECTION':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30">
            <Edit3 className="w-3 h-3" />
            {action === 'CORRECTION' ? 'CORRECTION' : 'UPDATED'}
          </span>
        );
      case 'DELETE':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
            <Trash2 className="w-3 h-3" />
            DELETED
          </span>
        );
      case 'OVERRIDE':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
            <SlidersHorizontal className="w-3 h-3" />
            OVERRIDE
          </span>
        );
      case 'REVERSAL':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-orange-500/20 text-orange-300 border border-orange-500/30">
            <ArrowUpDown className="w-3 h-3" />
            REVERSAL
          </span>
        );
      case 'SYSTEM_CHECK':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
            <Cpu className="w-3 h-3" />
            DIAGNOSTIC
          </span>
        );
      case 'PRINT':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
            <Printer className="w-3 h-3" />
            PRINTED
          </span>
        );
      case 'ADJUST_STOCK':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
            <ArrowUpDown className="w-3 h-3" />
            STOCK ADJ
          </span>
        );
      case 'BACKUP':
      case 'RESTORE':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30">
            <Database className="w-3 h-3" />
            {action}
          </span>
        );
      case 'LOGIN':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30">
            <User className="w-3 h-3" />
            LOGIN
          </span>
        );
      case 'EXPORT':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
            <Download className="w-3 h-3" />
            EXPORT
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-700 text-slate-300 border border-slate-600">
            {action}
          </span>
        );
    }
  };

  const getRoleBadge = (role: UserRole) => {
    const roleInfo = ROLE_DESCRIPTIONS[role] || {
      badge: role,
      color: 'bg-slate-800 text-slate-300 border-slate-700',
    };
    return (
      <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold border ${roleInfo.color}`}>
        {roleInfo.badge}
      </span>
    );
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      {/* Top Header Card */}
      <div className="bg-slate-900/60 border border-slate-700/60 rounded-2xl p-5 shadow-xl backdrop-blur-md text-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center shadow-inner">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black tracking-tight text-white">Audit Trails</h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Live Tracking Active
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Comprehensive chronological audit logs, operator accountability, corrections history, and diagnostic engine records.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          {activeTab === 'corrections_system_log' && (
            <button
              onClick={handleRunDiagnostic}
              disabled={isRunningDiagnostic}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-200 border border-cyan-500/40 rounded-lg text-xs font-bold transition cursor-pointer disabled:opacity-50"
              title="Run live database integrity and catalog diagnostic check"
            >
              <Cpu className={`w-3.5 h-3.5 text-cyan-400 ${isRunningDiagnostic ? 'animate-spin' : ''}`} />
              <span>{isRunningDiagnostic ? 'Scanning...' : 'Run Diagnostics'}</span>
            </button>
          )}

          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition cursor-pointer"
            title="Refresh logs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600/30 hover:bg-blue-600/50 text-blue-200 border border-blue-500/40 rounded-lg text-xs font-bold transition cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-blue-400" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={handleExportJson}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 border border-purple-500/40 rounded-lg text-xs font-bold transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-purple-400" />
            <span>Export JSON</span>
          </button>

          <button
            onClick={() => setShowDeleteAllModal(true)}
            disabled={activeFilteredLogs.length === 0 || isDeleting}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600/20 hover:bg-rose-600/40 text-rose-300 border border-rose-500/40 rounded-lg text-xs font-bold transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
            title="Delete all active list entries"
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-400" />
            <span>Delete All ({activeFilteredLogs.length})</span>
          </button>
        </div>
      </div>

      {/* Primary Tab Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => {
            setActiveTab('activity_trail');
            setSelectedAction('ALL');
            setSearchQuery('');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer border ${
            activeTab === 'activity_trail'
              ? 'bg-purple-600 text-white border-purple-500 shadow-lg shadow-purple-900/30'
              : 'bg-slate-900/60 hover:bg-slate-800 text-slate-300 border-slate-800'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Activity Trail</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-950/60 border border-white/10 text-slate-200">
            {totalLogs}
          </span>
        </button>

        <button
          onClick={() => {
            setActiveTab('corrections_system_log');
            setSelectedAction('ALL');
            setSearchQuery('');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer border ${
            activeTab === 'corrections_system_log'
              ? 'bg-cyan-600 text-white border-cyan-500 shadow-lg shadow-cyan-900/30'
              : 'bg-slate-900/60 hover:bg-slate-800 text-slate-300 border-slate-800'
          }`}
        >
          <Wrench className="w-4 h-4" />
          <span>Corrections & System Log</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-950/60 border border-white/10 text-cyan-200">
            {totalCorrections}
          </span>
        </button>
      </div>

      {exportFeedback && (
        <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{exportFeedback}</span>
        </div>
      )}

      {/* Tab 1: Activity Trail Summary KPI Cards */}
      {activeTab === 'activity_trail' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-3 text-slate-100">
            <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Total Events</div>
            <div className="text-xl font-black text-white mt-1">{totalLogs}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Tracked in database</div>
          </div>

          <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-3 text-slate-100">
            <div className="text-[11px] font-medium text-emerald-400 uppercase tracking-wider">Bills Created</div>
            <div className="text-xl font-black text-emerald-400 mt-1">{invoicesCreated}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Sales invoices issued</div>
          </div>

          <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-3 text-slate-100">
            <div className="text-[11px] font-medium text-blue-400 uppercase tracking-wider">Bills Edited</div>
            <div className="text-xl font-black text-blue-400 mt-1">{invoicesEdited}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Modifications saved</div>
          </div>

          <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-3 text-slate-100">
            <div className="text-[11px] font-medium text-rose-400 uppercase tracking-wider">Bills Deleted</div>
            <div className="text-xl font-black text-rose-400 mt-1">{invoicesDeleted}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Cancelled or deleted</div>
          </div>

          <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-3 text-slate-100">
            <div className="text-[11px] font-medium text-purple-400 uppercase tracking-wider">Invoices Printed</div>
            <div className="text-xl font-black text-purple-400 mt-1">{invoicesPrinted}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Thermal & A4 copies</div>
          </div>

          <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-3 text-slate-100">
            <div className="text-[11px] font-medium text-amber-400 uppercase tracking-wider">Stock Adjustments</div>
            <div className="text-xl font-black text-amber-400 mt-1">{stockAdjusted}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Inventory variance logs</div>
          </div>
        </div>
      )}

      {/* Tab 2: Corrections & System Log KPI Cards & Diagnostic Bar */}
      {activeTab === 'corrections_system_log' && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-900/40 border border-cyan-900/40 rounded-xl p-3 text-slate-100">
              <div className="text-[11px] font-medium text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                <Wrench className="w-3.5 h-3.5" />
                <span>Total Corrections</span>
              </div>
              <div className="text-xl font-black text-cyan-300 mt-1">{totalCorrections}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">Overrides, edits & system events</div>
            </div>

            <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-3 text-slate-100">
              <div className="text-[11px] font-medium text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                <ArrowUpDown className="w-3.5 h-3.5" />
                <span>Stock Corrections</span>
              </div>
              <div className="text-xl font-black text-amber-400 mt-1">{stockAdjusted}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">Physical count reconciliations</div>
            </div>

            <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-3 text-slate-100">
              <div className="text-[11px] font-medium text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>Bill Alterations</span>
              </div>
              <div className="text-xl font-black text-rose-400 mt-1">{invoicesEdited + invoicesDeleted}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">Invoices modified or removed</div>
            </div>

            <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-3 text-slate-100">
              <div className="text-[11px] font-medium text-teal-400 uppercase tracking-wider flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5" />
                <span>Diagnostics & Backups</span>
              </div>
              <div className="text-xl font-black text-teal-300 mt-1">{systemChecksCount}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">System health & database logs</div>
            </div>
          </div>

          {/* Diagnostic Result Banner (if run) */}
          {diagnosticResult && (
            <div className="p-4 bg-slate-900/80 border border-cyan-500/40 rounded-xl text-slate-100 space-y-2 animate-in fade-in">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-cyan-400" />
                  <span className="font-bold text-sm text-cyan-300">Latest Diagnostic Audit Report</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                    Status: {diagnosticResult.status}
                  </span>
                </div>
                <span className="text-[11px] text-slate-400 font-mono">
                  {new Date(diagnosticResult.timestamp).toLocaleTimeString()}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs pt-1">
                <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Catalog Products:</span>
                  <span className="font-bold text-white">{diagnosticResult.itemsChecked} items verified</span>
                </div>
                <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Invoices & Bills:</span>
                  <span className="font-bold text-white">{diagnosticResult.invoicesVerified} records verified</span>
                </div>
                <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Customer Accounts:</span>
                  <span className="font-bold text-white">{diagnosticResult.customersVerified} verified</span>
                </div>
                <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Supplier Accounts:</span>
                  <span className="font-bold text-white">{diagnosticResult.suppliersVerified} verified</span>
                </div>
              </div>

              {diagnosticResult.issuesFound.length > 0 ? (
                <div className="pt-2 text-xs text-amber-300 space-y-1">
                  <span className="font-bold flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Advisory Notes ({diagnosticResult.issuesFound.length}):</span>
                  </span>
                  <ul className="list-disc list-inside space-y-0.5 text-[11px] text-amber-200/90 pl-1">
                    {diagnosticResult.issuesFound.map((iss, idx) => (
                      <li key={idx}>{iss}</li>
                    ))}
                  </ul>
                </div>
              ) : (
                <div className="pt-1 text-[11px] text-emerald-400 flex items-center gap-1 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>No data inconsistencies or orphan records found. System integrity is 100% optimal.</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-4 space-y-3">
        {/* Sub-Category Pills for Corrections & System Log */}
        {activeTab === 'corrections_system_log' && (
          <div className="flex items-center gap-1.5 flex-wrap pb-2 border-b border-slate-800">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1 flex items-center gap-1">
              <Filter className="w-3 h-3 text-cyan-400" />
              Category:
            </span>
            <button
              onClick={() => setCorrectionCategory('ALL')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition cursor-pointer border ${
                correctionCategory === 'ALL'
                  ? 'bg-cyan-600 text-white border-cyan-500'
                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              All Corrections ({tabBaseLogs.length})
            </button>
            <button
              onClick={() => setCorrectionCategory('STOCK')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition cursor-pointer border ${
                correctionCategory === 'STOCK'
                  ? 'bg-amber-600 text-white border-amber-500'
                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              📦 Stock Adjustments ({stockAdjusted})
            </button>
            <button
              onClick={() => setCorrectionCategory('INVOICE_OVERRIDE')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition cursor-pointer border ${
                correctionCategory === 'INVOICE_OVERRIDE'
                  ? 'bg-rose-600 text-white border-rose-500'
                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              🧾 Bill Edits & Deletions ({invoicesEdited + invoicesDeleted})
            </button>
            <button
              onClick={() => setCorrectionCategory('SYSTEM_DIAG')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition cursor-pointer border ${
                correctionCategory === 'SYSTEM_DIAG'
                  ? 'bg-teal-600 text-white border-teal-500'
                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              ⚙️ System Diagnostics & Backups ({systemChecksCount})
            </button>
            <button
              onClick={() => setCorrectionCategory('SECURITY_AUTH')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition cursor-pointer border ${
                correctionCategory === 'SECURITY_AUTH'
                  ? 'bg-sky-600 text-white border-sky-500'
                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              🔒 Security & Settings
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Keyword Search */}
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={activeTab === 'corrections_system_log' ? "Search correction reason, bill #, stock code..." : "Search by Invoice #, item, user, reason..."}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* Action Filter */}
          <div>
            <select
              value={selectedAction}
              onChange={(e) => setSelectedAction(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-purple-500 cursor-pointer"
            >
              <option value="ALL">All Actions</option>
              {activeTab === 'activity_trail' && <option value="CREATE">CREATE (New Bills & Records)</option>}
              <option value="UPDATE">UPDATE (Edits & Changes)</option>
              <option value="DELETE">DELETE (Removals)</option>
              {activeTab === 'activity_trail' && <option value="PRINT">PRINT (Invoice Copies)</option>}
              <option value="ADJUST_STOCK">ADJUST_STOCK (Inventory Changes)</option>
              <option value="SYSTEM_CHECK">SYSTEM_CHECK (Diagnostic Logs)</option>
              <option value="BACKUP">BACKUP (Snapshots)</option>
              <option value="RESTORE">RESTORE (Recovery)</option>
              <option value="LOGIN">LOGIN (Session Changes)</option>
              {activeTab === 'activity_trail' && <option value="EXPORT">EXPORT (Data Downloads)</option>}
            </select>
          </div>

          {/* User Filter */}
          <div>
            <select
              value={selectedUser}
              onChange={(e) => setSelectedUser(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-purple-500 cursor-pointer"
            >
              <option value="ALL">All Operators</option>
              {uniqueUsers.map((u: any) => (
                <option key={u.email} value={u.email}>
                  {u.name} ({u.email})
                </option>
              ))}
            </select>
          </div>

          {/* Date Filter */}
          <div>
            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value as any)}
              className="w-full px-2.5 py-1.5 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-purple-500 cursor-pointer"
            >
              <option value="ALL">All Time</option>
              <option value="TODAY">Today Only</option>
              <option value="7_DAYS">Last 7 Days</option>
              <option value="30_DAYS">Last 30 Days</option>
            </select>
          </div>
        </div>

        {/* Active Filter Indicators */}
        <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800">
          <div>
            Showing <strong className="text-white">{activeFilteredLogs.length}</strong> of{' '}
            <strong className="text-white">{tabBaseLogs.length}</strong> {activeTab === 'corrections_system_log' ? 'corrections & system' : 'audit'} records
          </div>
          {(selectedAction !== 'ALL' || selectedUser !== 'ALL' || dateFilter !== 'ALL' || searchQuery || correctionCategory !== 'ALL') && (
            <button
              onClick={() => {
                setSelectedAction('ALL');
                setSelectedEntity('ALL');
                setSelectedUser('ALL');
                setDateFilter('ALL');
                setCorrectionCategory('ALL');
                setSearchQuery('');
              }}
              className="text-purple-400 hover:text-purple-300 underline font-semibold cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Main Audit / Corrections Logs Table */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950/80 text-slate-300 text-[11px] uppercase tracking-wider border-b border-slate-800 font-bold">
                <th className="py-3 px-4">Date & Time</th>
                <th className="py-3 px-3">Operator</th>
                <th className="py-3 px-3">Action</th>
                <th className="py-3 px-3">Entity / Ref</th>
                <th className="py-3 px-4">{activeTab === 'corrections_system_log' ? 'Correction / System Event Summary' : 'Summary Activity'}</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs text-slate-300">
              {activeFilteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500">
                    <ShieldAlert className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                    <p className="text-sm font-semibold">
                      {activeTab === 'corrections_system_log' ? 'No corrections or system events found' : 'No audit records match your filters'}
                    </p>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      {activeTab === 'corrections_system_log'
                        ? 'Inventory adjustments, bill edits, and system diagnostic logs will appear here.'
                        : 'Any transaction or inventory changes will be recorded here automatically.'}
                    </p>
                  </td>
                </tr>
              ) : (
                activeFilteredLogs.map((log) => {
                  return (
                    <tr
                      key={log.id}
                      className="hover:bg-slate-800/40 transition border-b border-slate-800/40"
                    >
                      {/* Date & Time */}
                      <td className="py-3 px-4 whitespace-nowrap font-mono text-[11px] text-slate-300">
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3 h-3 text-slate-500" />
                          <span>{new Date(log.timestamp).toLocaleDateString()}</span>
                          <span className="text-slate-500 text-[10px]">
                            {new Date(log.timestamp).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                              second: '2-digit',
                            })}
                          </span>
                        </div>
                      </td>

                      {/* Operator & Role */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        <div className="flex flex-col">
                          <span className="font-bold text-white text-xs">{log.userName}</span>
                          <div className="mt-0.5">{getRoleBadge(log.userRole)}</div>
                        </div>
                      </td>

                      {/* Action */}
                      <td className="py-3 px-3 whitespace-nowrap">{getActionBadge(log.action)}</td>

                      {/* Entity / Reference */}
                      <td className="py-3 px-3 whitespace-nowrap font-mono">
                        <span className="px-2 py-1 rounded bg-slate-950/80 border border-slate-800 text-amber-300 font-bold text-[11px]">
                          {log.entityId || log.entityType}
                        </span>
                        {log.entityName && (
                          <span className="block text-[10px] text-slate-400 font-sans truncate max-w-[130px] mt-0.5">
                            {log.entityName}
                          </span>
                        )}
                      </td>

                      {/* Summary */}
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-200 text-xs max-w-xl">
                          {log.summary}
                        </div>
                        {log.details && (
                          <div className="text-[10px] text-slate-500 font-mono mt-0.5 truncate max-w-md">
                            {Object.entries(log.details)
                              .filter(([k]) => !['items', 'taxes'].includes(k))
                              .map(([k, v]) => `${k}: ${typeof v === 'object' ? JSON.stringify(v) : v}`)
                              .join(' | ')}
                          </div>
                        )}
                      </td>

                      {/* Actions: Inspect + Delete */}
                      <td className="py-3 px-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setActiveLogModal(log)}
                            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-[11px] font-semibold transition cursor-pointer flex items-center gap-1"
                            title="Inspect log details"
                          >
                            <Eye className="w-3 h-3 text-purple-400" />
                            <span>Inspect</span>
                          </button>
                          <button
                            onClick={() => setLogToDelete(log)}
                            className="p-1.5 rounded bg-slate-800 hover:bg-rose-950/60 text-slate-400 hover:text-rose-400 border border-slate-700 hover:border-rose-700/50 transition cursor-pointer"
                            title="Delete this record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Single Log Delete Confirmation Modal */}
      {logToDelete && (
        <div className="fixed inset-0 z-[130] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-500/40 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150 text-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-600/20 text-rose-400 border border-rose-500/30 flex items-center justify-center">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-white">Delete Entry</h3>
                <p className="text-xs text-slate-400">Confirm deletion of this record.</p>
              </div>
            </div>

            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400">Timestamp:</span>
                <span className="font-mono text-slate-200">{new Date(logToDelete.timestamp).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Operator:</span>
                <span className="text-slate-200 font-semibold">{logToDelete.userName} ({logToDelete.userRole})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Reference:</span>
                <span className="font-mono text-amber-300 font-bold">{logToDelete.entityId}</span>
              </div>
              <div className="pt-2 border-t border-slate-800">
                <span className="text-slate-400 block text-[10px] uppercase font-bold mb-0.5">Summary:</span>
                <span className="text-slate-200">{logToDelete.summary}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setLogToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteSingleLog}
                disabled={isDeleting}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isDeleting ? 'Deleting...' : 'Delete Log'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete All Active Entries Modal */}
      {showDeleteAllModal && (
        <div className="fixed inset-0 z-[130] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-500/40 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150 text-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-600/20 text-rose-400 border border-rose-500/30 flex items-center justify-center">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-white">Delete All Active Entries</h3>
                <p className="text-xs text-slate-400">Permanently remove matching log records.</p>
              </div>
            </div>

            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 text-xs space-y-2">
              <p className="text-slate-200">
                Are you sure you want to delete <strong className="text-rose-400 font-black">{activeFilteredLogs.length}</strong> active {activeTab === 'corrections_system_log' ? 'corrections / system' : 'audit'} log {activeFilteredLogs.length === 1 ? 'entry' : 'entries'}?
              </p>
              {(selectedAction !== 'ALL' || selectedUser !== 'ALL' || dateFilter !== 'ALL' || searchQuery || correctionCategory !== 'ALL') ? (
                <p className="text-[11px] text-amber-300 bg-amber-950/30 border border-amber-500/30 p-2 rounded-lg">
                  Note: Only the <strong>{activeFilteredLogs.length}</strong> currently filtered active entries will be deleted.
                </p>
              ) : (
                <p className="text-[11px] text-slate-400">
                  This will remove all {tabBaseLogs.length} records in this view from local storage and the database.
                </p>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteAllModal(false)}
                disabled={isDeleting}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteAllActive}
                disabled={isDeleting}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isDeleting ? 'Deleting All...' : `Confirm Delete (${activeFilteredLogs.length})`}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Inspect Modal */}
      {activeLogModal && (
        <div className="fixed inset-0 z-[120] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-xl w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150 text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center">
                  <Activity className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">Event & Correction Details</h3>
                  <p className="text-xs text-slate-400 font-mono">{activeLogModal.id}</p>
                </div>
              </div>
              <button
                onClick={() => setActiveLogModal(null)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Action Type</span>
                  <div className="mt-1">{getActionBadge(activeLogModal.action)}</div>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Timestamp</span>
                  <span className="font-mono text-slate-200 mt-1 block">
                    {new Date(activeLogModal.timestamp).toLocaleString()}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Operator</span>
                  <span className="font-bold text-white mt-0.5 block">{activeLogModal.userName}</span>
                  <span className="text-[10px] text-slate-400 font-mono">{activeLogModal.userEmail}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Role</span>
                  <div className="mt-1">{getRoleBadge(activeLogModal.userRole)}</div>
                </div>
              </div>

              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold mb-1">Activity / Correction Summary</span>
                <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-slate-200 leading-relaxed">
                  {activeLogModal.summary}
                </div>
              </div>

              {activeLogModal.details && (
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold mb-1">
                    Structured Payload / Snapshot
                  </span>
                  <pre className="p-3 bg-slate-950 border border-slate-800 rounded-xl overflow-x-auto text-[11px] font-mono text-emerald-400 max-h-48">
                    {JSON.stringify(activeLogModal.details, null, 2)}
                  </pre>
                </div>
              )}
            </div>

            <div className="border-t border-slate-800 pt-3 flex justify-end">
              <button
                onClick={() => setActiveLogModal(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-bold transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
