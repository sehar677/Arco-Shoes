import React, { useState, useEffect } from 'react';
import { Printer, X, FileText, CheckCircle2, Boxes, AlertTriangle, Layers, Wallet, ShoppingBag, TrendingUp } from 'lucide-react';
import { CompanyInfo, PurchasedStockItem } from '../types';
import { formatCurrency, roundTo2 } from '../services/gstCalculations';
import { printElement } from '../services/printService';

export interface StockLedgerPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  company: CompanyInfo;
  items: PurchasedStockItem[];
  selectedCategory: string;
  selectedSupplier: string;
  searchQuery?: string;
  showLowStockOnly?: boolean;
  totalStockQty: number;
  totalInwardQty: number;
  totalSoldQty: number;
  totalCostValuation: number;
  totalSellingValuation: number;
  totalMrpValuation: number;
  lowStockCount: number;
}

export const StockLedgerPrintModal: React.FC<StockLedgerPrintModalProps> = ({
  isOpen,
  onClose,
  company,
  items,
  selectedCategory,
  selectedSupplier,
  searchQuery = '',
  showLowStockOnly = false,
  totalStockQty,
  totalInwardQty,
  totalSoldQty,
  totalCostValuation,
  totalSellingValuation,
  totalMrpValuation,
  lowStockCount,
}) => {
  const [printFormat, setPrintFormat] = useState<'Thermal70' | 'Thermal80' | 'A4'>('Thermal80');

  // Listen for Ctrl+P and Escape
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        handlePrint();
      }
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, printFormat, items]);

  if (!isOpen) return null;

  const currentDateStr = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  const currentTimeStr = new Date().toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  const handlePrint = () => {
    printElement({
      elementId: 'printable-stock-ledger-content',
      format: printFormat,
      title: `Stock Sheet - ${company.companyName}`,
    });
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md p-2 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl w-full max-w-5xl max-h-[96vh] flex flex-col text-slate-100 overflow-hidden">
        {/* Modal Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 border-b border-slate-700/70 bg-slate-950/60 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <Boxes className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <span>Print Stock Sheet</span>
                <span className="text-xs font-mono bg-blue-900/60 text-blue-300 px-2 py-0.5 rounded border border-blue-700/50">
                  {items.length} Articles Listed
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Choose format: 70mm POS Thermal, 80mm POS Thermal, or Standard A4 Sheet
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-trigger-stock-print"
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950/30 transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print Now (Ctrl+P)</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
              title="Close (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Format Selector Bar */}
        <div className="px-5 py-2.5 bg-slate-800/50 border-b border-slate-700/50 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-1 text-xs">
            <span className="text-slate-400 font-medium mr-2">Paper Format:</span>
            <button
              type="button"
              onClick={() => setPrintFormat('Thermal70')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                printFormat === 'Thermal70'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-slate-900/80 text-slate-300 hover:bg-slate-700/60 border border-slate-700/50'
              }`}
            >
              <span>70mm Thermal</span>
            </button>
            <button
              type="button"
              onClick={() => setPrintFormat('Thermal80')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                printFormat === 'Thermal80'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-slate-900/80 text-slate-300 hover:bg-slate-700/60 border border-slate-700/50'
              }`}
            >
              <span>80mm Thermal</span>
            </button>
            <button
              type="button"
              onClick={() => setPrintFormat('A4')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                printFormat === 'A4'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-slate-900/80 text-slate-300 hover:bg-slate-700/60 border border-slate-700/50'
              }`}
            >
              <span>Standard A4 Sheet</span>
            </button>
          </div>

          <div className="text-xs text-slate-400 font-mono">
            {printFormat === 'Thermal70' && 'Width: 70mm | Thermal Roll'}
            {printFormat === 'Thermal80' && 'Width: 80mm (3 Inch) | Standard POS'}
            {printFormat === 'A4' && 'Landscape A4 | Multi-column Register'}
          </div>
        </div>

        {/* Printable View Area */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-slate-950 flex justify-center items-start">
          <div
            id="printable-stock-ledger-content"
            className="bg-white text-black shadow-2xl transition-all"
            style={{
              width: printFormat === 'Thermal70' ? '70mm' : printFormat === 'Thermal80' ? '80mm' : '100%',
              minWidth: printFormat === 'Thermal70' ? '70mm' : printFormat === 'Thermal80' ? '80mm' : 'auto',
              maxWidth: printFormat === 'Thermal70' ? '70mm' : printFormat === 'Thermal80' ? '80mm' : '1100px',
            }}
          >
            {/* FORMAT 1: 70mm POS Thermal Slip */}
            {printFormat === 'Thermal70' && (
              <div id="thermal-70mm-stock-slip" className="thermal-70mm-slip bg-white text-black font-mono font-bold p-2 text-[11px] leading-tight select-text">
                {/* Header */}
                <div className="text-center border-b border-dashed border-black pb-1.5 mb-1.5">
                  <div className="text-sm font-black tracking-tight">{company.companyName}</div>
                  {company.tagline && <div className="text-[10px] font-normal">{company.tagline}</div>}
                  <div className="text-[10px]">{company.addressLine1}, {company.city}</div>
                  <div className="text-[10px]">Ph: {company.phone} | GST: {company.gstin}</div>
                  <div className="mt-1 font-black text-[12px] bg-black text-white py-0.5 px-1">
                    STOCK SHEET POS SLIP
                  </div>
                  <div className="flex justify-between text-[10px] mt-1 text-left">
                    <span>Date: {currentDateStr}</span>
                    <span>{currentTimeStr}</span>
                  </div>
                  <div className="text-left text-[10px] mt-0.5">
                    Category: {selectedCategory} | Total Items: {items.length}
                  </div>
                </div>

                {/* Summary Box */}
                <div className="border border-black p-1.5 my-1.5 text-[10px] space-y-0.5">
                  <div className="flex justify-between">
                    <span>TOTAL STOCK ON HAND:</span>
                    <span className="font-black text-[11px]">{totalStockQty} Pcs</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Inward: {totalInwardQty}</span>
                    <span>Total Sold: {totalSoldQty}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>SELLING VALUATION:</span>
                    <span className="font-black">₹{totalSellingValuation.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>MRP VALUATION:</span>
                    <span>₹{totalMrpValuation.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>COST VALUATION:</span>
                    <span>₹{totalCostValuation.toFixed(2)}</span>
                  </div>
                </div>

                {/* Items List */}
                <div className="border-t border-b border-dashed border-black py-1 my-1">
                  <div className="flex justify-between text-[10px] border-b border-black pb-0.5 font-black uppercase">
                    <span>Item / Code</span>
                    <span>Inw/Sold/Stock</span>
                  </div>
                  <div className="divide-y divide-dotted divide-gray-400">
                    {items.map((it, idx) => {
                      const mrpVal = it.currentStock * (it.mrp || it.sellingRate);
                      const costVal = it.currentStock * it.purchaseRate;
                      const saleVal = it.currentStock * it.sellingRate;
                      return (
                        <div key={it.id || idx} className="py-1">
                          <div className="flex justify-between font-black text-[11px]">
                            <span>{it.itemCode}</span>
                            <span className="text-[10px] font-normal">{it.category || 'Footwear'}</span>
                          </div>
                          <div className="text-[10px] truncate">{it.itemName}</div>
                          <div className="flex justify-between text-[10px] mt-0.5">
                            <span>HSN:{it.hsnCode} | GST:{it.gstRate}%</span>
                            <span className="font-black">STK: {it.currentStock} {it.unit}</span>
                          </div>
                          <div className="flex justify-between text-[9px] text-gray-700">
                            <span>In:{it.totalPurchasedQty} | Out:{it.totalSoldQty}</span>
                            <span>Rate: ₹{it.sellingRate.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-[10px] font-black mt-0.5">
                            <span>Val: ₹{saleVal.toFixed(2)}</span>
                            <span className="text-[9px] font-normal">Cost: ₹{costVal.toFixed(2)}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Totals & Footer */}
                <div className="text-center pt-2 space-y-1">
                  <div className="border-t border-black pt-1 flex justify-between font-black text-xs">
                    <span>TOTAL STOCK:</span>
                    <span>{totalStockQty} Units</span>
                  </div>
                  <div className="flex justify-between font-black text-xs">
                    <span>GRAND VALUATION:</span>
                    <span>₹{totalSellingValuation.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-dashed border-black pt-2 mt-2 text-[10px]">
                    *** END OF STOCK SHEET SLIP ***
                  </div>
                  <div className="text-[9px] text-gray-700">Software: DS Inventory & GST Billing</div>
                </div>
              </div>
            )}

            {/* FORMAT 2: 80mm POS Thermal Slip */}
            {printFormat === 'Thermal80' && (
              <div id="thermal-80mm-stock-slip" className="thermal-80mm-slip bg-white text-black font-mono font-bold p-3 text-xs leading-tight select-text">
                {/* Header */}
                <div className="text-center border-b-2 border-black pb-2 mb-2">
                  <div className="text-base font-black tracking-tight">{company.companyName}</div>
                  {company.tagline && <div className="text-[11px] font-normal">{company.tagline}</div>}
                  <div className="text-[11px]">{company.addressLine1}, {company.city} - {company.stateCode}</div>
                  <div className="text-[11px]">Phone: {company.phone} | GSTIN: {company.gstin}</div>
                  <div className="mt-1.5 font-black text-sm bg-black text-white py-1 px-2 uppercase tracking-wide">
                    STOCK SHEET & INVENTORY REPORT
                  </div>
                  <div className="flex justify-between text-[11px] mt-1.5 text-left">
                    <span>Date: {currentDateStr}</span>
                    <span>Time: {currentTimeStr}</span>
                  </div>
                  <div className="flex justify-between text-[11px] mt-0.5 text-left">
                    <span>Category: {selectedCategory}</span>
                    <span>Supplier: {selectedSupplier}</span>
                  </div>
                  {searchQuery && (
                    <div className="text-left text-[11px]">Filter: &quot;{searchQuery}&quot;</div>
                  )}
                </div>

                {/* KPI Valuation Summary Box */}
                <div className="border-2 border-black p-2 my-2 space-y-1 bg-gray-50">
                  <div className="flex justify-between text-xs border-b border-black pb-1">
                    <span>TOTAL ARTICLES LISTED:</span>
                    <span className="font-black">{items.length} Items</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span>TOTAL STOCK ON HAND:</span>
                    <span className="font-black text-sm">{totalStockQty} Pcs/Units</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span>Total Inward: {totalInwardQty}</span>
                    <span>Total Sold: {totalSoldQty}</span>
                    {lowStockCount > 0 && <span className="text-red-700">Low Stock: {lowStockCount}</span>}
                  </div>
                  <div className="border-t border-dotted border-black pt-1 flex justify-between text-xs font-black">
                    <span>SELLING RATE VALUATION:</span>
                    <span>₹{totalSellingValuation.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span>MRP Total Valuation:</span>
                    <span>₹{totalMrpValuation.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span>Cost (Purchase) Valuation:</span>
                    <span>₹{totalCostValuation.toFixed(2)}</span>
                  </div>
                </div>

                {/* Table Breakdown */}
                <div className="border-t-2 border-b-2 border-black py-1 my-2">
                  <table className="w-full text-[11px] border-collapse">
                    <thead>
                      <tr className="border-b-2 border-black text-left font-black uppercase">
                        <th className="py-1 w-1/3">Item/Code</th>
                        <th className="py-1 text-right w-1/6">Inw</th>
                        <th className="py-1 text-right w-1/6">Sold</th>
                        <th className="py-1 text-right w-1/6">Stock</th>
                        <th className="py-1 text-right w-1/4">Valuation</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-300">
                      {items.map((it, idx) => {
                        const mrpVal = it.currentStock * (it.mrp || it.sellingRate);
                        const costVal = it.currentStock * it.purchaseRate;
                        const saleVal = it.currentStock * it.sellingRate;
                        const isLow = it.currentStock <= (it.minStockLevel !== undefined ? it.minStockLevel : 10);
                        return (
                          <tr key={it.id || idx} className="py-1">
                            <td className="py-1 pr-1">
                              <div className="font-black">{it.itemCode}</div>
                              <div className="text-[10px] truncate max-w-[32mm]">{it.itemName}</div>
                              <div className="text-[9px] text-gray-700">HSN: {it.hsnCode} | {it.category}</div>
                            </td>
                            <td className="py-1 text-right">{it.totalPurchasedQty}</td>
                            <td className="py-1 text-right">{it.totalSoldQty}</td>
                            <td className="py-1 text-right font-black text-xs">
                              {it.currentStock} {isLow ? '*' : ''}
                            </td>
                            <td className="py-1 text-right font-black">
                              <div>₹{saleVal.toFixed(2)}</div>
                              <div className="text-[9px] text-gray-700 font-normal">₹{it.sellingRate}/pc</div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Footer Totals */}
                <div className="space-y-1 pt-1">
                  <div className="flex justify-between font-black text-xs border-b border-black pb-1">
                    <span>TOTAL ON-HAND STOCK:</span>
                    <span>{totalStockQty} Units</span>
                  </div>
                  <div className="flex justify-between font-black text-sm">
                    <span>TOTAL SELLING VALUATION:</span>
                    <span>₹{totalSellingValuation.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-gray-800">
                    <span>Total Purchase Cost Valuation:</span>
                    <span>₹{totalCostValuation.toFixed(2)}</span>
                  </div>

                  <div className="pt-6 flex justify-between text-[10px] border-t border-dashed border-black mt-4">
                    <div>
                      <div className="border-t border-black w-24 pt-0.5 text-center">Prepared By</div>
                    </div>
                    <div>
                      <div className="border-t border-black w-28 pt-0.5 text-center">Authorized Signatory</div>
                    </div>
                  </div>

                  <div className="text-center text-[10px] pt-3 text-gray-600">
                    *** End of 80mm Stock Sheet Slip ***
                  </div>
                </div>
              </div>
            )}

            {/* FORMAT 3: Standard A4 Sheet */}
            {printFormat === 'A4' && (
              <div className="a4-print-sheet p-6 sm:p-8 text-black bg-white select-text font-sans">
                {/* A4 Top Header */}
                <div className="border-b-2 border-slate-900 pb-4 mb-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h1 className="text-2xl font-black text-slate-900 tracking-tight">{company.companyName}</h1>
                      {company.tagline && <p className="text-xs text-slate-600 font-medium">{company.tagline}</p>}
                      <p className="text-xs text-slate-700 mt-1 max-w-md">
                        {company.addressLine1}, {company.city} - {company.stateCode}
                      </p>
                      <p className="text-xs text-slate-700">
                        Phone: <span className="font-semibold">{company.phone}</span> | Email: <span className="font-semibold">{company.email}</span>
                      </p>
                    </div>

                    <div className="text-right">
                      <div className="inline-block bg-slate-900 text-white font-bold text-xs uppercase px-3 py-1 rounded tracking-wider mb-1.5">
                        Stock Sheet Inventory Register
                      </div>
                      <div className="text-xs text-slate-700 space-y-0.5">
                        <p>GSTIN: <span className="font-mono font-bold text-slate-900">{company.gstin}</span></p>
                        <p>State Code: <span className="font-mono font-bold text-slate-900">{company.stateCode}</span></p>
                        <p>Report Date: <span className="font-bold text-slate-900">{currentDateStr}</span> ({currentTimeStr})</p>
                      </div>
                    </div>
                  </div>

                  {/* Filter Metadata Bar */}
                  <div className="mt-3 pt-2.5 border-t border-slate-200 flex flex-wrap items-center justify-between text-xs text-slate-600 bg-slate-50 p-2 rounded-lg">
                    <div>
                      <span className="font-semibold text-slate-800">Category:</span> {selectedCategory} |{' '}
                      <span className="font-semibold text-slate-800">Supplier:</span> {selectedSupplier}
                      {searchQuery && (
                        <span> | <span className="font-semibold text-slate-800">Search:</span> &quot;{searchQuery}&quot;</span>
                      )}
                      {showLowStockOnly && (
                        <span className="ml-2 font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                          Low Stock Filter Active
                        </span>
                      )}
                    </div>
                    <div className="font-mono text-slate-800 font-bold">
                      {items.length} Product Articles Listed
                    </div>
                  </div>
                </div>

                {/* Summary KPI Cards for A4 */}
                <div className="grid grid-cols-4 gap-2.5 mb-4 text-xs">
                  <div className="border border-slate-300 rounded-lg p-2.5 bg-slate-50 text-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Total Stock on Hand</span>
                    <span className="text-lg font-black font-mono text-slate-900 block mt-0.5">
                      {totalStockQty.toLocaleString()} <span className="text-xs font-normal">Units</span>
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Inward: {totalInwardQty} | Sold: {totalSoldQty}</span>
                  </div>

                  <div className="border border-slate-300 rounded-lg p-2.5 bg-slate-50 text-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Low Stock Articles</span>
                    <span className="text-lg font-black font-mono text-rose-600 block mt-0.5">
                      {lowStockCount} <span className="text-xs font-normal">Items</span>
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Reorder level reached</span>
                  </div>

                  <div className="border border-slate-300 rounded-lg p-2.5 bg-slate-50 text-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Total Cost Valuation</span>
                    <span className="text-lg font-black font-mono text-emerald-700 block mt-0.5">
                      {formatCurrency(totalCostValuation)}
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Purchase Rate Base</span>
                  </div>

                  <div className="border border-slate-300 rounded-lg p-2.5 bg-slate-50 text-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Total Selling Valuation</span>
                    <span className="text-lg font-black font-mono text-blue-700 block mt-0.5">
                      {formatCurrency(totalSellingValuation)}
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Selling Rate Base</span>
                  </div>
                </div>

                {/* A4 Detailed Inventory Table */}
                <table className="w-full text-xs text-left border border-slate-300 border-collapse mb-4">
                  <thead className="bg-slate-800 text-white text-[10px] uppercase font-bold">
                    <tr>
                      <th className="py-2 px-2 border border-slate-700 w-8 text-center">#</th>
                      <th className="py-2 px-2.5 border border-slate-700">Item Code</th>
                      <th className="py-2 px-2.5 border border-slate-700">Item Name</th>
                      <th className="py-2 px-2 border border-slate-700">Description (HSN / GST / Rack)</th>
                      <th className="py-2 px-2 border border-slate-700">Category</th>
                      <th className="py-2 px-2 border border-slate-700">PURCHASE BILL NO.</th>
                      <th className="py-2 px-2 border border-slate-700">SUPPLIER BILL NO</th>
                      <th className="py-2 px-2 border border-slate-700 text-right">Inward</th>
                      <th className="py-2 px-2 border border-slate-700 text-right">Sold</th>
                      <th className="py-2 px-2 border border-slate-700 text-right font-black">Stock on Hand</th>
                      <th className="py-2 px-2 border border-slate-700 text-right">Cost (₹)</th>
                      <th className="py-2 px-2 border border-slate-700 text-right">Selling (₹)</th>
                      <th className="py-2 px-2.5 border border-slate-700 text-right font-black">Total Value (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                    {items.map((it, idx) => {
                      const costVal = it.currentStock * it.purchaseRate;
                      const saleVal = it.currentStock * it.sellingRate;
                      const isLow = it.currentStock <= (it.minStockLevel !== undefined ? it.minStockLevel : 10);

                      return (
                        <tr key={it.id || idx} className={idx % 2 === 1 ? 'bg-slate-50' : 'bg-white'}>
                          <td className="py-1.5 px-2 border border-slate-200 text-center font-sans text-slate-500">{idx + 1}</td>
                          <td className="py-1.5 px-2.5 border border-slate-200 font-bold text-slate-900">{it.itemCode}</td>
                          <td className="py-1.5 px-2.5 border border-slate-200 font-sans font-semibold text-slate-900">{it.itemName}</td>
                          <td className="py-1.5 px-2 border border-slate-200 text-[10px] text-slate-600 font-sans">
                            HSN: {it.hsnCode} | GST: {it.gstRate}%
                            {it.locationRack ? ` | Rack: ${it.locationRack}` : ''}
                            {it.minStockLevel !== undefined ? ` | Min: ${it.minStockLevel}` : ''}
                          </td>
                          <td className="py-1.5 px-2 border border-slate-200 font-sans text-slate-700">{it.category || 'Footwear'}</td>
                          <td className="py-1.5 px-2 border border-slate-200 text-[10px] text-slate-600">
                            <div>{it.lastPurchaseBillNo || '—'}</div>
                            {it.lastPurchaseDate && <div className="text-slate-400">{it.lastPurchaseDate}</div>}
                          </td>
                          <td className="py-1.5 px-2 border border-slate-200 text-[10px] text-slate-600">
                            <div>{it.lastSupplierBillNo || '—'}</div>
                          </td>
                          <td className="py-1.5 px-2 border border-slate-200 text-right text-slate-700">{it.totalPurchasedQty} {it.unit}</td>
                          <td className="py-1.5 px-2 border border-slate-200 text-right text-slate-700">{it.totalSoldQty} {it.unit}</td>
                          <td className="py-1.5 px-2 border border-slate-200 text-right font-bold text-slate-900">
                            <span className={isLow ? 'text-rose-600 font-black' : ''}>
                              {it.currentStock} {it.unit}
                            </span>
                          </td>
                          <td className="py-1.5 px-2 border border-slate-200 text-right text-slate-700">₹{it.purchaseRate.toFixed(2)}</td>
                          <td className="py-1.5 px-2 border border-slate-200 text-right font-semibold text-slate-900">₹{it.sellingRate.toFixed(2)}</td>
                          <td className="py-1.5 px-2.5 border border-slate-200 text-right font-black text-slate-900">₹{saleVal.toFixed(2)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-100 font-mono font-bold text-slate-900 border-t-2 border-slate-400 text-xs">
                      <td colSpan={5} className="py-2 px-2 text-right font-sans uppercase">
                        Total Stock & Valuation:
                      </td>
                      <td className="border border-slate-300"></td>
                      <td className="border border-slate-300"></td>
                      <td className="py-2 px-2 text-right border border-slate-300">{totalInwardQty}</td>
                      <td className="py-2 px-2 text-right border border-slate-300">{totalSoldQty}</td>
                      <td className="py-2 px-2 text-right border border-slate-300 text-emerald-700 font-black">{totalStockQty}</td>
                      <td className="py-2 px-2 text-right border border-slate-300">₹{totalCostValuation.toFixed(2)}</td>
                      <td className="py-2 px-2 text-right border border-slate-300">₹{totalSellingValuation.toFixed(2)}</td>
                      <td className="py-2 px-2.5 text-right border border-slate-300 text-blue-700 font-black">₹{totalSellingValuation.toFixed(2)}</td>
                    </tr>
                  </tfoot>
                </table>

                {/* Signatures & Footer */}
                <div className="pt-8 mt-6 border-t border-slate-300 grid grid-cols-3 gap-8 text-center text-xs text-slate-700">
                  <div>
                    <div className="border-t border-slate-400 pt-1 font-semibold">Prepared By (Inventory Clerk)</div>
                  </div>
                  <div>
                    <div className="border-t border-slate-400 pt-1 font-semibold">Store Manager / Auditor</div>
                  </div>
                  <div>
                    <div className="border-t border-slate-400 pt-1 font-semibold">For {company.companyName} (Authorized Signatory)</div>
                  </div>
                </div>

                <div className="text-center text-[10px] text-slate-400 mt-6">
                  Generated via DS Inventory & GST Billing Software • System Timestamp: {new Date().toISOString()}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
