import React, { useEffect } from 'react';
import { Printer, X, FileText } from 'lucide-react';
import { CompanyInfo, PurchaseInvoice } from '../types';
import { numberToWords, formatCurrency } from '../services/gstCalculations';
import { printElement } from '../services/printService';

interface PurchasePrintModalProps {
  purchase: PurchaseInvoice;
  company: CompanyInfo;
  onClose: () => void;
}

export const PurchasePrintModal: React.FC<PurchasePrintModalProps> = ({
  purchase,
  company,
  onClose,
}) => {
  const handlePrint = () => {
    printElement({
      elementId: 'printable-purchase-content',
      format: 'A4',
      title: `Purchase Voucher - ${purchase.supplierBillNo || purchase.purchaseNo}`,
    });
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        handlePrint();
      } else if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose, purchase]);

  const items = purchase.items || [];
  const totalQty = purchase.totalQuantity || items.reduce((sum, it) => sum + (it.quantity || 0), 0);
  const taxableTotal = purchase.totalTaxable || items.reduce((sum, it) => sum + (it.taxableAmount || 0), 0);
  const taxTotal = purchase.totalTax || items.reduce((sum, it) => sum + ((it.cgstAmount || 0) + (it.sgstAmount || 0) + (it.igstAmount || 0)), 0);
  const grandTotal = purchase.grandTotal || 0;

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center bg-black/75 backdrop-blur-md p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-slate-900/95 border border-slate-700/60 rounded-xl shadow-2xl backdrop-blur-xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden print:border-none print:shadow-none print:max-h-none print:max-w-none print:w-full print:bg-white print:rounded-none">
        {/* Header Bar */}
        <div className="p-3.5 bg-slate-950 text-white flex items-center justify-between gap-3 border-b border-slate-800 print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <FileText className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <span className="font-bold text-sm block">Purchase Bill Voucher</span>
              <span className="text-[11px] text-slate-400 font-mono">
                Bill #{purchase.supplierBillNo || purchase.purchaseNo}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs shadow transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print [Ctrl+P]</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Content */}
        <div id="printable-purchase-content" className="p-4 sm:p-6 overflow-y-auto flex-1 bg-white text-slate-900 font-sans print:p-0">
          <div className="border border-slate-900 text-[11px] leading-tight text-black max-w-full">
            {/* Company Branding */}
            <div className="border-b border-slate-900 p-3 text-center bg-slate-50">
              <h1 className="text-xl font-black uppercase tracking-wider">{company.companyName || 'ARCO FOOTWEAR'}</h1>
              <p className="text-[10px] text-slate-600 mt-0.5">
                {company.addressLine1 || company.addressLine2 || ''}
                {company.city ? `, ${company.city}` : ''}
                {company.state ? ` - ${company.state}` : ''}
                {company.stateCode ? ` (Code: ${company.stateCode})` : ''}
              </p>
              <p className="text-[10px] font-bold font-mono text-slate-800 mt-0.5">
                GSTIN: {company.gstin || 'N/A'} {company.mobile ? `| Phone: ${company.mobile}` : company.phone ? `| Phone: ${company.phone}` : ''}
              </p>
              <div className="mt-1.5 inline-block text-xs font-black uppercase tracking-wider border-b-2 border-slate-900 pb-0.5">
                PURCHASE INWARD VOUCHER / BILL
              </div>
            </div>

            {/* Supplier & Bill Metadata */}
            <div className="grid grid-cols-2 border-b border-slate-900 p-3 text-xs bg-slate-50/40 gap-4">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-0.5">SUPPLIER DETAILS:</p>
                <p className="font-bold text-sm text-slate-900">{purchase.supplierName || 'Unknown Supplier'}</p>
                <p className="text-slate-700 font-mono text-[11px] font-semibold mt-0.5">
                  GSTIN: {purchase.supplierGstin || 'Unregistered / UR'}
                </p>
                {purchase.supplierAddress && (
                  <p className="text-slate-600 text-[11px] mt-0.5">{purchase.supplierAddress}</p>
                )}
              </div>
              <div className="text-right font-mono text-xs space-y-1">
                <p>
                  <span className="text-slate-500 font-sans font-medium text-[11px]">Supplier Bill No: </span>
                  <strong className="text-indigo-900 text-sm">{purchase.supplierBillNo || 'N/A'}</strong>
                </p>
                <p>
                  <span className="text-slate-500 font-sans font-medium text-[11px]">Purchase Voucher No: </span>
                  <strong className="text-slate-900">{purchase.purchaseNo}</strong>
                </p>
                <p>
                  <span className="text-slate-500 font-sans font-medium text-[11px]">Bill Date: </span>
                  <strong className="text-slate-900">{purchase.purchaseDate}</strong>
                </p>
                <p>
                  <span className="text-slate-500 font-sans font-medium text-[11px]">Purchase Type: </span>
                  <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${
                    (purchase.purchaseType === 'Cash' || purchase.paymentMode === 'Cash')
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-purple-100 text-purple-800'
                  }`}>
                    {purchase.purchaseType || (purchase.paymentMode === 'Cash' ? 'Cash' : 'Credit Line')}
                  </span>
                </p>
                <p>
                  <span className="text-slate-500 font-sans font-medium text-[11px]">Payment Mode: </span>
                  <span className="font-bold px-1.5 py-0.5 rounded bg-slate-200 text-slate-800 text-[10px]">
                    {purchase.paymentMode || 'CASH'}
                  </span>
                </p>
              </div>
            </div>

            {/* Inward Items Table */}
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-slate-100 border-b border-slate-900 font-bold uppercase text-[10px] tracking-wider text-slate-800">
                <tr>
                  <th className="p-2 w-8 text-center border-r border-slate-900">#</th>
                  <th className="p-2 border-r border-slate-900">Description of Goods</th>
                  <th className="p-2 text-center w-16 border-r border-slate-900">HSN</th>
                  <th className="p-2 text-right w-16 border-r border-slate-900">Qty</th>
                  <th className="p-2 text-right w-20 border-r border-slate-900">Rate</th>
                  <th className="p-2 text-right w-24 border-r border-slate-900">Taxable</th>
                  <th className="p-2 text-right w-16 border-r border-slate-900">GST %</th>
                  <th className="p-2 text-right w-24">Total (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-300 font-mono text-xs">
                {items.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-4 text-center text-slate-500 font-sans">
                      No line items recorded for this purchase voucher.
                    </td>
                  </tr>
                ) : (
                  items.map((it, idx) => {
                    const gstRate = (it.cgstRate || 0) + (it.sgstRate || 0) + (it.igstRate || 0);
                    return (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="p-2 text-center border-r border-slate-900">{idx + 1}</td>
                        <td className="p-2 font-sans font-medium border-r border-slate-900 text-slate-900">
                          {it.itemName}
                          {it.itemCode && (
                            <span className="text-[10px] text-slate-500 block font-mono">Code: {it.itemCode}</span>
                          )}
                        </td>
                        <td className="p-2 text-center border-r border-slate-900 text-slate-700">{it.hsnCode || '-'}</td>
                        <td className="p-2 text-right border-r border-slate-900 font-bold text-slate-900">
                          {it.quantity} {it.unit || 'Pair'}
                        </td>
                        <td className="p-2 text-right border-r border-slate-900 text-slate-700">
                          ₹{it.rate ? it.rate.toFixed(2) : '0.00'}
                        </td>
                        <td className="p-2 text-right border-r border-slate-900 text-slate-800">
                          ₹{it.taxableAmount ? it.taxableAmount.toFixed(2) : '0.00'}
                        </td>
                        <td className="p-2 text-right border-r border-slate-900 text-slate-600">
                          {gstRate ? `${gstRate}%` : '0%'}
                        </td>
                        <td className="p-2 text-right font-bold text-slate-950">
                          ₹{it.netAmount ? it.netAmount.toFixed(2) : (it.taxableAmount || 0).toFixed(2)}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
              <tfoot className="border-t border-slate-900 font-bold bg-slate-50 font-mono text-xs">
                <tr>
                  <td colSpan={3} className="p-2 text-right border-r border-slate-900 font-sans uppercase text-[10px] text-slate-600">
                    VOUCHER TOTALS:
                  </td>
                  <td className="p-2 text-right border-r border-slate-900 font-bold text-slate-900">
                    {totalQty}
                  </td>
                  <td className="p-2 border-r border-slate-900"></td>
                  <td className="p-2 text-right border-r border-slate-900 font-bold text-slate-900">
                    ₹{taxableTotal.toFixed(2)}
                  </td>
                  <td className="p-2 border-r border-slate-900 text-right text-slate-600">
                    ₹{taxTotal.toFixed(2)}
                  </td>
                  <td className="p-2 text-right text-slate-950 font-black text-sm">
                    ₹{grandTotal.toFixed(2)}
                  </td>
                </tr>
              </tfoot>
            </table>

            {/* Bottom Details & Signatures */}
            <div className="p-3 border-t border-slate-900 bg-slate-50/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
              <div>
                <p className="font-bold text-slate-700 text-[10px] uppercase tracking-wider">Amount in Words:</p>
                <p className="italic font-medium text-slate-800 text-[11px] mt-0.5">
                  {numberToWords(grandTotal)}
                </p>
                <p className="text-[10px] text-slate-500 mt-1">
                  Tax breakdown: Taxable ₹{taxableTotal.toFixed(2)} + GST ₹{taxTotal.toFixed(2)} = ₹{grandTotal.toFixed(2)}
                </p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-[10px] text-slate-500 mb-8 uppercase tracking-wider">Authorised Signatory</p>
                <p className="font-bold text-xs text-slate-900 uppercase">{company.companyName || 'ARCO FOOTWEAR'}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
