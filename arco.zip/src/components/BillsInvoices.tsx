import React, { useState, useEffect, useMemo } from 'react';
import { 
  FileText, 
  Search, 
  ShoppingCart, 
  Printer, 
  Calendar, 
  ChevronRight,
  ChevronLeft,
  Filter, 
  Hash, 
  ShoppingBag, 
  RotateCcw, 
  Edit3, 
  X,
  Store,
  Users,
  CreditCard,
  ArrowDownLeft,
  ArrowUpRight,
  Landmark,
  TrendingUp,
  Receipt,
  Building2,
  Package,
  Tag
} from 'lucide-react';
import { dbService } from '../services/storage';
import { SalesInvoice, PurchaseInvoice, Customer, Supplier, CompanyInfo } from '../types';
import { InvoicePrintModal } from './InvoicePrintModal';
import { PurchasePrintModal } from './PurchasePrintModal';
import { RegisterPrintModal } from './RegisterPrintModal';

interface BillsInvoicesProps {
  initialTab?: 'SALES' | 'PURCHASES';
  onNavigateToReturnExchange?: (invoiceId: string) => void;
  company?: CompanyInfo;
  onOpenPrintPreviewTab?: (invoice: SalesInvoice, autoPrint?: boolean) => void;
}

type DateFilterPreset = 'today' | 'yesterday' | 'last7' | 'thisMonth' | 'all' | 'custom';

// Helper to get local YYYY-MM-DD
const getLocalTodayDate = (): string => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

// Helper to format date for display (e.g. 14 Sep 2026)
const formatDisplayDate = (dateStr: string): string => {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  const [year, month, day] = parts;
  const dateObj = new Date(Number(year), Number(month) - 1, Number(day));
  if (isNaN(dateObj.getTime())) return dateStr;
  return dateObj.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

export const BillsInvoicesComponent: React.FC<BillsInvoicesProps> = ({ 
  initialTab = 'SALES', 
  onNavigateToReturnExchange, 
  company, 
  onOpenPrintPreviewTab 
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'SALES' | 'PURCHASES'>(initialTab);

  useEffect(() => {
    setActiveSubTab(initialTab);
    const today = getLocalTodayDate();
    if (initialTab === 'PURCHASES') {
      setPurchaseDateFilter(today);
      setPurchaseStartDate(today);
      setPurchaseEndDate(today);
      setPurchaseDatePreset('today');
    }
  }, [initialTab]);

  const [sales, setSales] = useState<SalesInvoice[]>([]);
  const [purchases, setPurchases] = useState<PurchaseInvoice[]>([]);
  const [customersList, setCustomersList] = useState<Customer[]>([]);
  const [suppliersList, setSuppliersList] = useState<Supplier[]>([]);
  const [selectedPrintInvoice, setSelectedPrintInvoice] = useState<SalesInvoice | null>(null);
  const [selectedPrintPurchase, setSelectedPrintPurchase] = useState<PurchaseInvoice | null>(null);
  const [isRegisterPrintModalOpen, setIsRegisterPrintModalOpen] = useState<boolean>(false);
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo>(company || dbService.getCompanyInfo());

  useEffect(() => {
    if (company) {
      setCompanyInfo(company);
    }
  }, [company]);

  // Filter States - Default to today's date for current date invoices on load
  const todayStr = getLocalTodayDate();
  const [datePreset, setDatePreset] = useState<DateFilterPreset>('today');
  const [startDate, setStartDate] = useState<string>(todayStr);
  const [endDate, setEndDate] = useState<string>(todayStr);
  const [selectedCustomerIdFilter, setSelectedCustomerIdFilter] = useState<string>('ALL');
  const [invoiceNoFilter, setInvoiceNoFilter] = useState<string>('');
  const [itemCodeFilter, setItemCodeFilter] = useState<string>('');
  const [itemNameFilter, setItemNameFilter] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState<string>(todayStr);

  // Purchase Register Filter States
  const [purchaseDatePreset, setPurchaseDatePreset] = useState<DateFilterPreset>('today');
  const [purchaseStartDate, setPurchaseStartDate] = useState<string>(todayStr);
  const [purchaseEndDate, setPurchaseEndDate] = useState<string>(todayStr);
  const [selectedSupplierIdFilter, setSelectedSupplierIdFilter] = useState<string>('ALL');
  const [purchaseBillNoFilter, setPurchaseBillNoFilter] = useState<string>('');
  const [purchaseItemNameFilter, setPurchaseItemNameFilter] = useState<string>('');
  const [purchaseSearchTerm, setPurchaseSearchTerm] = useState<string>('');
  const [purchaseDateFilter, setPurchaseDateFilter] = useState<string>(todayStr);

  useEffect(() => {
    const loadBills = () => {
      setSales(dbService.getSales());
      setPurchases(dbService.getPurchases());
      setCustomersList(dbService.getCustomers());
      setSuppliersList(dbService.getSuppliers());
      if (!company) {
        setCompanyInfo(dbService.getCompanyInfo());
      }
    };
    loadBills();
    return dbService.subscribe(loadBills);
  }, [company]);

  const handleDatePresetChange = (preset: DateFilterPreset) => {
    setDatePreset(preset);
    const today = getLocalTodayDate();

    if (preset === 'today') {
      setDateFilter(today);
      setStartDate(today);
      setEndDate(today);
    } else if (preset === 'yesterday') {
      const y = new Date();
      y.setDate(y.getDate() - 1);
      const yYear = y.getFullYear();
      const yMonth = String(y.getMonth() + 1).padStart(2, '0');
      const yDay = String(y.getDate()).padStart(2, '0');
      const yStr = `${yYear}-${yMonth}-${yDay}`;
      setDateFilter(yStr);
      setStartDate(yStr);
      setEndDate(yStr);
    } else if (preset === 'last7') {
      const d7 = new Date();
      d7.setDate(d7.getDate() - 7);
      const d7Year = d7.getFullYear();
      const d7Month = String(d7.getMonth() + 1).padStart(2, '0');
      const d7Day = String(d7.getDate()).padStart(2, '0');
      const d7Str = `${d7Year}-${d7Month}-${d7Day}`;
      setDateFilter('');
      setStartDate(d7Str);
      setEndDate(today);
    } else if (preset === 'thisMonth') {
      const now = new Date();
      const firstDay = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`;
      setDateFilter('');
      setStartDate(firstDay);
      setEndDate(today);
    } else if (preset === 'all') {
      setDateFilter('');
      setStartDate('');
      setEndDate('');
    }
  };

  // Reset all filters and revert active list to current date invoices
  const handleResetFilters = () => {
    const today = getLocalTodayDate();
    setDateFilter(today);
    setDatePreset('today');
    setStartDate(today);
    setEndDate(today);
    setSelectedCustomerIdFilter('ALL');
    setInvoiceNoFilter('');
    setItemCodeFilter('');
    setItemNameFilter('');
    setSearchTerm('');
  };

  // Filter Sales Invoices
  const filteredSales = useMemo(() => {
    return sales.filter(s => {
      // 1. Date Wise single date filter (defaults to today)
      if (dateFilter) {
        if (s.invoiceDate !== dateFilter) return false;
      } else if (datePreset !== 'all') {
        // 2. Date preset & range filtering
        if (startDate && s.invoiceDate < startDate) return false;
        if (endDate && s.invoiceDate > endDate) return false;
      }

      // Customer filter
      if (selectedCustomerIdFilter !== 'ALL') {
        if (selectedCustomerIdFilter === 'CUST-000') {
          if (s.customerId !== 'CUST-000') return false;
        } else {
          if (s.customerId !== selectedCustomerIdFilter) return false;
        }
      }

      // Invoice No filter
      if (invoiceNoFilter.trim()) {
        const q = invoiceNoFilter.trim().toLowerCase();
        if (!s.invoiceNo.toLowerCase().includes(q)) return false;
      }

      // Item Code filter
      if (itemCodeFilter.trim()) {
        const q = itemCodeFilter.trim().toLowerCase();
        const hasCode = (s.items || []).some(
          (it) => it.itemCode && it.itemCode.toLowerCase().includes(q)
        );
        if (!hasCode) return false;
      }

      // Item Name filter
      if (itemNameFilter.trim()) {
        const q = itemNameFilter.trim().toLowerCase();
        const hasItem = (s.items || []).some(
          (it) =>
            it.itemName.toLowerCase().includes(q) ||
            (it.itemCode && it.itemCode.toLowerCase().includes(q))
        );
        if (!hasItem) return false;
      }

      // General search term
      if (searchTerm.trim()) {
        const q = searchTerm.trim().toLowerCase();
        const matchSearch = 
          s.invoiceNo.toLowerCase().includes(q) || 
          s.customerName.toLowerCase().includes(q);
        if (!matchSearch) return false;
      }

      return true;
    }).sort((a, b) => {
      const dateA = a.invoiceDate || '';
      const dateB = b.invoiceDate || '';
      if (dateB !== dateA) {
        return dateB.localeCompare(dateA);
      }
      if (b.createdAt && a.createdAt) {
        const createdComp = b.createdAt.localeCompare(a.createdAt);
        if (createdComp !== 0) return createdComp;
      }
      return (b.invoiceNo || '').localeCompare(a.invoiceNo || '', undefined, { numeric: true });
    });
  }, [sales, dateFilter, datePreset, startDate, endDate, selectedCustomerIdFilter, invoiceNoFilter, itemNameFilter, searchTerm]);

  const handlePurchaseDatePresetChange = (preset: DateFilterPreset) => {
    setPurchaseDatePreset(preset);
    const today = getLocalTodayDate();

    if (preset === 'today') {
      setPurchaseDateFilter(today);
      setPurchaseStartDate(today);
      setPurchaseEndDate(today);
    } else if (preset === 'yesterday') {
      const y = new Date();
      y.setDate(y.getDate() - 1);
      const yYear = y.getFullYear();
      const yMonth = String(y.getMonth() + 1).padStart(2, '0');
      const yDay = String(y.getDate()).padStart(2, '0');
      const yStr = `${yYear}-${yMonth}-${yDay}`;
      setPurchaseDateFilter(yStr);
      setPurchaseStartDate(yStr);
      setPurchaseEndDate(yStr);
    } else if (preset === 'last7') {
      const d7 = new Date();
      d7.setDate(d7.getDate() - 7);
      const d7Year = d7.getFullYear();
      const d7Month = String(d7.getMonth() + 1).padStart(2, '0');
      const d7Day = String(d7.getDate()).padStart(2, '0');
      const d7Str = `${d7Year}-${d7Month}-${d7Day}`;
      setPurchaseDateFilter('');
      setPurchaseStartDate(d7Str);
      setPurchaseEndDate(today);
    } else if (preset === 'thisMonth') {
      const now = new Date();
      const firstDay = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`;
      setPurchaseDateFilter('');
      setPurchaseStartDate(firstDay);
      setPurchaseEndDate(today);
    } else if (preset === 'all') {
      setPurchaseDateFilter('');
      setPurchaseStartDate('');
      setPurchaseEndDate('');
    }
  };

  // Reset all purchase filters and revert active list to current date bills
  const handleResetPurchaseFilters = () => {
    const today = getLocalTodayDate();
    setPurchaseDateFilter(today);
    setPurchaseDatePreset('today');
    setPurchaseStartDate(today);
    setPurchaseEndDate(today);
    setSelectedSupplierIdFilter('ALL');
    setPurchaseBillNoFilter('');
    setPurchaseItemNameFilter('');
    setPurchaseSearchTerm('');
  };

  // Filter Purchase Invoices
  const filteredPurchases = useMemo(() => {
    return purchases.filter(p => {
      // 1. Date Wise single date filter (defaults to today)
      if (purchaseDateFilter) {
        if (p.purchaseDate !== purchaseDateFilter) return false;
      } else if (purchaseDatePreset !== 'all') {
        // 2. Date preset & range filtering
        if (purchaseStartDate && p.purchaseDate < purchaseStartDate) return false;
        if (purchaseEndDate && p.purchaseDate > purchaseEndDate) return false;
      }

      // Supplier filter
      if (selectedSupplierIdFilter !== 'ALL') {
        if (p.supplierId !== selectedSupplierIdFilter) return false;
      }

      // Bill No filter (purchase voucher or supplier bill no)
      if (purchaseBillNoFilter.trim()) {
        const q = purchaseBillNoFilter.trim().toLowerCase();
        const matchVoucher = (p.purchaseNo || '').toLowerCase().includes(q);
        const matchSupplierBill = (p.supplierBillNo || '').toLowerCase().includes(q);
        if (!matchVoucher && !matchSupplierBill) return false;
      }

      // Item Name filter
      if (purchaseItemNameFilter.trim()) {
        const q = purchaseItemNameFilter.trim().toLowerCase();
        const hasItem = (p.items || []).some(
          (it) =>
            it.itemName.toLowerCase().includes(q) ||
            (it.itemCode && it.itemCode.toLowerCase().includes(q))
        );
        if (!hasItem) return false;
      }

      // General search term
      if (purchaseSearchTerm.trim()) {
        const q = purchaseSearchTerm.trim().toLowerCase();
        const matchSearch = 
          (p.purchaseNo || '').toLowerCase().includes(q) || 
          (p.supplierBillNo && p.supplierBillNo.toLowerCase().includes(q)) ||
          (p.supplierName || '').toLowerCase().includes(q);
        if (!matchSearch) return false;
      }

      return true;
    }).sort((a, b) => {
      const dateA = a.purchaseDate || '';
      const dateB = b.purchaseDate || '';
      if (dateB !== dateA) {
        return dateB.localeCompare(dateA);
      }
      if (b.createdAt && a.createdAt) {
        const createdComp = b.createdAt.localeCompare(a.createdAt);
        if (createdComp !== 0) return createdComp;
      }
      return (b.purchaseNo || '').localeCompare(a.purchaseNo || '', undefined, { numeric: true });
    });
  }, [purchases, purchaseDateFilter, purchaseDatePreset, purchaseStartDate, purchaseEndDate, selectedSupplierIdFilter, purchaseBillNoFilter, purchaseItemNameFilter, purchaseSearchTerm]);

  // Calculations for Sales
  const salesSubtotal = filteredSales.reduce((acc, s) => acc + (s.totalTaxable ?? s.grossSubtotal ?? 0), 0);
  const salesTax = filteredSales.reduce((acc, s) => acc + s.totalTax, 0);
  const salesTotal = filteredSales.reduce((acc, s) => acc + s.grandTotal, 0);

  const salesCashTotal = filteredSales
    .filter(s => (s.paymentMode || '').toUpperCase().includes('CASH'))
    .reduce((sum, s) => sum + s.grandTotal, 0);

  const salesCreditTotal = filteredSales
    .filter(s => {
      const pm = (s.paymentMode || '').toUpperCase();
      return pm.includes('CREDIT') || pm.includes('KHATA') || pm.includes('DUE');
    })
    .reduce((sum, s) => sum + s.grandTotal, 0);

  const salesDigitalTotal = filteredSales
    .filter(s => {
      const pm = (s.paymentMode || '').toUpperCase();
      return pm.includes('UPI') || pm.includes('ONLINE') || pm.includes('BANK') || pm.includes('CARD') || pm.includes('GPAY') || pm.includes('PHONEPE');
    })
    .reduce((sum, s) => sum + s.grandTotal, 0);

  const totalItemsSold = filteredSales.reduce(
    (sum, s) => sum + (s.items || []).reduce((iSum, it) => iSum + (it.quantity || 0), 0),
    0
  );

  const cashPercent = salesTotal > 0 ? (salesCashTotal / salesTotal) * 100 : 0;
  const creditPercent = salesTotal > 0 ? (salesCreditTotal / salesTotal) * 100 : 0;
  const digitalPercent = salesTotal > 0 ? (salesDigitalTotal / salesTotal) * 100 : 0;

  // Calculations for Purchases
  const purchaseSubtotal = filteredPurchases.reduce((acc, p) => acc + (p.totalTaxable ?? p.grossSubtotal ?? 0), 0);
  const purchaseTax = filteredPurchases.reduce((acc, p) => acc + (p.totalTax || 0), 0);
  const purchaseTotal = filteredPurchases.reduce((acc, p) => acc + (p.grandTotal || 0), 0);

  const purchaseCashTotal = filteredPurchases
    .filter(p => p.purchaseType === 'Cash' || (p.paymentMode || '').toUpperCase().includes('CASH') || p.supplierId === 'SUP-CASH')
    .reduce((sum, p) => sum + (p.grandTotal || 0), 0);

  const purchaseCreditTotal = filteredPurchases
    .filter(p => {
      if (p.purchaseType === 'Credit Line' || p.purchaseType === 'Credit') return true;
      if (p.purchaseType === 'Cash' || p.supplierId === 'SUP-CASH') return false;
      const pm = (p.paymentMode || '').toUpperCase();
      return pm.includes('CREDIT') || pm.includes('KHATA') || pm.includes('DUE');
    })
    .reduce((sum, p) => sum + (p.grandTotal || 0), 0);

  const purchaseBankTotal = filteredPurchases
    .filter(p => {
      const pm = (p.paymentMode || '').toUpperCase();
      return pm.includes('BANK') || pm.includes('NEFT') || pm.includes('RTGS') || pm.includes('CHEQUE') || pm.includes('ONLINE') || pm.includes('UPI');
    })
    .reduce((sum, p) => sum + (p.grandTotal || 0), 0);

  const totalPurchaseItemsQty = filteredPurchases.reduce(
    (sum, p) => sum + (p.items || []).reduce((iSum, it) => iSum + (it.quantity || 0), 0),
    0
  );

  const purchaseCashPercent = purchaseTotal > 0 ? (purchaseCashTotal / purchaseTotal) * 100 : 0;
  const purchaseCreditPercent = purchaseTotal > 0 ? (purchaseCreditTotal / purchaseTotal) * 100 : 0;
  const purchaseBankPercent = purchaseTotal > 0 ? (purchaseBankTotal / purchaseTotal) * 100 : 0;

  const handlePrint = (invoice: SalesInvoice) => {
    setSelectedPrintInvoice(invoice);
  };

  const selectedSupplierObj = useMemo(() => {
    if (selectedSupplierIdFilter === 'ALL') return null;
    return suppliersList.find((s) => s.id === selectedSupplierIdFilter) || null;
  }, [selectedSupplierIdFilter, suppliersList]);

  const selectedSupplierDisplayName = selectedSupplierObj
    ? selectedSupplierObj.supplierName
    : selectedSupplierIdFilter !== 'ALL'
    ? selectedSupplierIdFilter
    : undefined;

  const selectedCustomerObj = useMemo(() => {
    if (selectedCustomerIdFilter === 'ALL') return null;
    return customersList.find((c) => c.id === selectedCustomerIdFilter) || null;
  }, [selectedCustomerIdFilter, customersList]);

  const selectedCustomerDisplayName = selectedCustomerObj
    ? selectedCustomerObj.customerName
    : selectedCustomerIdFilter === 'CUST-000'
    ? 'Cash / Counter Sale'
    : selectedCustomerIdFilter !== 'ALL'
    ? selectedCustomerIdFilter
    : undefined;

  const getRegisterDateRangeText = () => {
    if (activeSubTab === 'SALES') {
      if (datePreset === 'today') return `Today (${formatDisplayDate(getLocalTodayDate())})`;
      if (datePreset === 'yesterday') return 'Yesterday';
      if (datePreset === 'last7') return 'Last 7 Days';
      if (datePreset === 'thisMonth') return 'This Month';
      if (datePreset === 'custom' && (startDate || endDate)) {
        return `${startDate ? formatDisplayDate(startDate) : 'Start'} to ${endDate ? formatDisplayDate(endDate) : 'End'}`;
      }
      return 'All Filtered Sales Records';
    } else {
      if (purchaseDatePreset === 'today') return `Today (${formatDisplayDate(getLocalTodayDate())})`;
      if (purchaseDatePreset === 'yesterday') return 'Yesterday';
      if (purchaseDatePreset === 'last7') return 'Last 7 Days';
      if (purchaseDatePreset === 'thisMonth') return 'This Month';
      if (purchaseDatePreset === 'custom' && (purchaseStartDate || purchaseEndDate)) {
        return `${purchaseStartDate ? formatDisplayDate(purchaseStartDate) : 'Start'} to ${purchaseEndDate ? formatDisplayDate(purchaseEndDate) : 'End'}`;
      }
      return 'All Filtered Purchase Records';
    }
  };

  const handlePrintRegister = () => {
    setIsRegisterPrintModalOpen(true);
  };

  // Helper for Payment Mode Badge styled identically to Day Book
  const renderPaymentBadge = (mode?: string) => {
    const m = (mode || '').toUpperCase();
    if (m.includes('CASH')) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200/60 whitespace-nowrap">
          {mode || 'CASH'}
        </span>
      );
    }
    if (m.includes('CREDIT') || m.includes('KHATA') || m.includes('DUE') || m.includes('UNPAID')) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-50 text-purple-800 border border-purple-200/60 whitespace-nowrap">
          {mode || 'CREDIT'}
        </span>
      );
    }
    if (m.includes('UPI') || m.includes('GPAY') || m.includes('PHONEPE') || m.includes('PAYTM') || m.includes('ONLINE')) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-800 border border-indigo-200/60 whitespace-nowrap">
          {mode || 'UPI'}
        </span>
      );
    }
    if (m.includes('BANK') || m.includes('CARD') || m.includes('NEFT') || m.includes('RTGS') || m.includes('CHEQUE')) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-sky-50 text-sky-800 border border-sky-200/60 whitespace-nowrap">
          {mode || 'BANK'}
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-700 border border-slate-200/80 whitespace-nowrap">
        {mode || 'N/A'}
      </span>
    );
  };

  return (
    <div 
      id="bills-invoices-page-root" 
      className={`bills-invoices-page space-y-5 print:space-y-3 ${activeSubTab === 'SALES' ? 'customer-invoice-register' : 'purchase-bill-register'}`}
    >
      {/* ==================================================== */}
      {/* 1. TOP PAGE HEADER (Day Book Style)                  */}
      {/* ==================================================== */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-4 sm:p-5 shadow-xs flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 print:hidden">
        {/* Left: Branding & Subtitle */}
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-amber-50 border border-amber-200/70 text-amber-700 flex items-center justify-center shadow-xs shrink-0">
            <FileText className="w-5 h-5 text-amber-700" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
                {activeSubTab === 'SALES' ? 'CUSTOMER BILL REPORTS' : 'SUPPLIER BILL REPORTS'}
              </h1>
              <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-200/80 uppercase tracking-wide">
                Register
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5 font-normal">
              {activeSubTab === 'SALES'
                ? 'Comprehensive audit register of sales invoices & tax billing records'
                : 'Comprehensive audit register of inward supplier purchase bills'}
            </p>
          </div>
        </div>

        {/* Right: Subtab switcher & Print Register button */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Subtab Toggle */}
          <div className="flex items-center bg-slate-100/90 border border-slate-200/80 p-0.5 rounded-lg">
            <button
              id="subtab-sales-invoices"
              type="button"
              onClick={() => setActiveSubTab('SALES')}
              className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all cursor-pointer ${
                activeSubTab === 'SALES'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Sales Invoices
            </button>
            <button
              id="subtab-purchase-bills"
              type="button"
              onClick={() => setActiveSubTab('PURCHASES')}
              className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all cursor-pointer ${
                activeSubTab === 'PURCHASES'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Purchase Bills
            </button>
          </div>

          {/* Print Register Action Button */}
          <button
            id="register-print-ledger-btn"
            onClick={handlePrintRegister}
            type="button"
            className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 active:bg-black text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all cursor-pointer whitespace-nowrap"
          >
            <Printer className="w-4 h-4" />
            <span>PRINT REGISTER</span>
          </button>
        </div>
      </div>

      {/* ==================================================== */}
      {/* 2. FINANCIAL SUMMARY METRIC CARDS (5-Grid)           */}
      {/* ==================================================== */}
      {activeSubTab === 'SALES' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 print:grid-cols-3 print:gap-2">
          {/* Card 1: TOTAL TAXABLE AMOUNT */}
          <div 
            id="card-sales-taxable"
            className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Taxable Subtotal</span>
              <div className="w-7 h-7 rounded-lg bg-blue-50 border border-blue-200/70 text-blue-700 flex items-center justify-center">
                <Store className="w-4 h-4 text-blue-600" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-bold text-slate-800 font-mono tracking-tight">
                ₹{salesSubtotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                Before GST calculation
              </div>
            </div>
          </div>

          {/* Card 2: TOTAL GST TAX */}
          <div 
            id="card-sales-tax"
            className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Total GST Tax</span>
              <div className="w-7 h-7 rounded-lg bg-teal-50 border border-teal-200/70 text-teal-700 flex items-center justify-center">
                <Receipt className="w-4 h-4 text-teal-600" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-bold text-teal-700 font-mono tracking-tight">
                ₹{salesTax.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                CGST + SGST + IGST
              </div>
            </div>
          </div>

          {/* Card 3: CASH SALES */}
          <div 
            id="card-sales-cash"
            className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Cash Billing</span>
              <div className="w-7 h-7 rounded-lg bg-emerald-50 border border-emerald-200/70 text-emerald-700 flex items-center justify-center">
                <ArrowDownLeft className="w-4 h-4 text-emerald-600" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-bold text-emerald-700 font-mono tracking-tight">
                ₹{salesCashTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                {filteredSales.filter(s => (s.paymentMode || '').toUpperCase().includes('CASH')).length} Cash bills
              </div>
            </div>
          </div>

          {/* Card 4: CREDIT / KHATA SALES */}
          <div 
            id="card-sales-credit"
            className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Credit / Khata</span>
              <div className="w-7 h-7 rounded-lg bg-purple-50 border border-purple-200/70 text-purple-700 flex items-center justify-center">
                <Users className="w-4 h-4 text-purple-600" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-bold text-purple-700 font-mono tracking-tight">
                ₹{salesCreditTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
                Customer ledger dues
              </div>
            </div>
          </div>

          {/* Card 5: TOTAL INVOICE VALUE (Highlighted Primary Metric) */}
          <div 
            id="card-sales-grand-total"
            className="bg-white border-2 border-amber-300/80 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between ring-1 ring-amber-200/50"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-800">Total Invoice Value</span>
              <div className="w-7 h-7 rounded-lg bg-amber-100/90 text-amber-800 flex items-center justify-center font-bold">
                <Landmark className="w-4 h-4 text-amber-800" />
              </div>
            </div>
            <div className="mt-2">
              <div className="text-xl font-extrabold text-amber-900 font-mono tracking-tight">
                ₹{salesTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="grid grid-cols-2 gap-1.5 pt-2 mt-2 border-t border-amber-100 text-[10px]">
                <div>
                  <span className="text-slate-400 block font-medium">Invoices</span>
                  <span className="font-bold font-mono text-slate-800">
                    {filteredSales.length} bills
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block font-medium">Qty Sold</span>
                  <span className="font-bold font-mono text-emerald-700">
                    {totalItemsSold} items
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 print:grid-cols-3 print:gap-2">
          {/* Purchase Card 1: Credit Inward (Placed First From Left) */}
          <div 
            id="card-purchase-credit"
            className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Credit Inward</span>
              <div className="w-7 h-7 rounded-lg bg-purple-50 border border-purple-200/70 text-purple-700 flex items-center justify-center">
                <Building2 className="w-4 h-4 text-purple-600" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-bold text-purple-700 font-mono tracking-tight">
                ₹{purchaseCreditTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
                Supplier ledger credit
              </div>
            </div>
          </div>

          {/* Purchase Card 2: Inward Cost */}
          <div 
            id="card-purchase-inward-cost"
            className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Inward Cost</span>
              <div className="w-7 h-7 rounded-lg bg-blue-50 border border-blue-200/70 text-blue-700 flex items-center justify-center">
                <Store className="w-4 h-4 text-blue-600" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-bold text-slate-800 font-mono tracking-tight">
                ₹{purchaseSubtotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                Gross taxable value
              </div>
            </div>
          </div>

          {/* Purchase Card 3: Total ITC Earned */}
          <div 
            id="card-purchase-itc"
            className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Total ITC Earned</span>
              <div className="w-7 h-7 rounded-lg bg-teal-50 border border-teal-200/70 text-teal-700 flex items-center justify-center">
                <Receipt className="w-4 h-4 text-teal-600" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-bold text-teal-700 font-mono tracking-tight">
                ₹{purchaseTax.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                Eligible Input Tax Credit
              </div>
            </div>
          </div>

          {/* Purchase Card 4: Cash Purchases */}
          <div 
            id="card-purchase-cash"
            className="bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Cash Purchases</span>
              <div className="w-7 h-7 rounded-lg bg-emerald-50 border border-emerald-200/70 text-emerald-700 flex items-center justify-center">
                <ArrowDownLeft className="w-4 h-4 text-emerald-600" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-bold text-emerald-700 font-mono tracking-tight">
                ₹{purchaseCashTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                Paid at inward
              </div>
            </div>
          </div>

          {/* Purchase Card 5: HIGHLIGHTED TOTAL PURCHASE VALUE */}
          <div 
            id="card-purchase-grand-total"
            className="bg-white border-2 border-amber-300/80 rounded-xl p-3.5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between ring-1 ring-amber-200/50"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-800">Total Purchase Value</span>
              <div className="w-7 h-7 rounded-lg bg-amber-100/90 text-amber-800 flex items-center justify-center font-bold">
                <ShoppingCart className="w-4 h-4 text-amber-800" />
              </div>
            </div>
            <div className="mt-2">
              <div className="text-xl font-extrabold text-amber-900 font-mono tracking-tight">
                ₹{purchaseTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="grid grid-cols-2 gap-1.5 pt-2 mt-2 border-t border-amber-100 text-[10px]">
                <div>
                  <span className="text-slate-400 block font-medium">Inward Bills</span>
                  <span className="font-bold font-mono text-slate-800">{filteredPurchases.length} bills</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-medium">Items Inward</span>
                  <span className="font-bold font-mono text-emerald-700">
                    {totalPurchaseItemsQty} items
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* 3. VISUAL REGISTER SUMMARY (Progress Breakdown)      */}
      {/* ==================================================== */}
      {activeSubTab === 'SALES' && (
        <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs print:hidden">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-slate-600" />
              <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Register Sales Collection Breakdown</h2>
            </div>
            <span className="text-xs text-slate-500 font-medium">
              Total Invoices: <strong className="text-slate-900 font-mono">{filteredSales.length}</strong> | Gross Turn: <strong className="text-slate-900 font-mono">₹{salesTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</strong>
            </span>
          </div>

          {/* Horizontal Stacked Progress Bar */}
          <div className="w-full bg-slate-100 rounded-full h-3 flex overflow-hidden p-0.5 border border-slate-200">
            {cashPercent > 0 && (
              <div
                style={{ width: `${Math.max(4, cashPercent)}%` }}
                className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                title={`Cash Sales: ${cashPercent.toFixed(1)}%`}
              />
            )}
            {creditPercent > 0 && (
              <div
                style={{ width: `${Math.max(4, creditPercent)}%` }}
                className="bg-purple-500 h-full rounded-full transition-all duration-300 mx-0.5"
                title={`Credit Sales: ${creditPercent.toFixed(1)}%`}
              />
            )}
            {digitalPercent > 0 && (
              <div
                style={{ width: `${Math.max(4, digitalPercent)}%` }}
                className="bg-indigo-500 h-full rounded-full transition-all duration-300"
                title={`Digital / UPI: ${digitalPercent.toFixed(1)}%`}
              />
            )}
          </div>

          {/* Breakdown Indicators */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3 pt-2 text-xs">
            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/70">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <span className="font-semibold text-slate-700">Cash Billing</span>
              </div>
              <div className="text-right font-mono">
                <span className="font-bold text-slate-900">₹{salesCashTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                <span className="text-[10px] text-slate-500 ml-1.5">({cashPercent.toFixed(1)}%)</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/70">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
                <span className="font-semibold text-slate-700">Credit / Khata</span>
              </div>
              <div className="text-right font-mono">
                <span className="font-bold text-slate-900">₹{salesCreditTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                <span className="text-[10px] text-slate-500 ml-1.5">({creditPercent.toFixed(1)}%)</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/70">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-500"></span>
                <span className="font-semibold text-slate-700">UPI / Digital</span>
              </div>
              <div className="text-right font-mono">
                <span className="font-bold text-slate-900">₹{salesDigitalTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                <span className="text-[10px] text-slate-500 ml-1.5">({digitalPercent.toFixed(1)}%)</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Visual Purchase Inward Breakdown */}
      {activeSubTab === 'PURCHASES' && (
        <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs print:hidden">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-slate-600" />
              <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Purchase Inward Payment Mode Breakdown</h2>
            </div>
            <span className="text-xs text-slate-500 font-medium">
              Inward Bills: <strong className="text-slate-900 font-mono">{filteredPurchases.length}</strong> | Total Value: <strong className="text-slate-900 font-mono">₹{purchaseTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</strong>
            </span>
          </div>

          {/* Horizontal Stacked Progress Bar */}
          <div className="w-full bg-slate-100 rounded-full h-3 flex overflow-hidden p-0.5 border border-slate-200">
            {purchaseCashPercent > 0 && (
              <div
                style={{ width: `${Math.max(4, purchaseCashPercent)}%` }}
                className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                title={`Cash Purchases: ${purchaseCashPercent.toFixed(1)}%`}
              />
            )}
            {purchaseCreditPercent > 0 && (
              <div
                style={{ width: `${Math.max(4, purchaseCreditPercent)}%` }}
                className="bg-purple-500 h-full rounded-full transition-all duration-300 mx-0.5"
                title={`Supplier Ledger Credit: ${purchaseCreditPercent.toFixed(1)}%`}
              />
            )}
            {purchaseBankPercent > 0 && (
              <div
                style={{ width: `${Math.max(4, purchaseBankPercent)}%` }}
                className="bg-sky-500 h-full rounded-full transition-all duration-300"
                title={`Bank / NEFT / UPI: ${purchaseBankPercent.toFixed(1)}%`}
              />
            )}
          </div>

          {/* Breakdown Indicators */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3 pt-2 text-xs">
            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/70">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <span className="font-semibold text-slate-700">Cash Payment</span>
              </div>
              <div className="text-right font-mono">
                <span className="font-bold text-slate-900">₹{purchaseCashTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                <span className="text-[10px] text-slate-500 ml-1.5">({purchaseCashPercent.toFixed(1)}%)</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/70">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
                <span className="font-semibold text-slate-700">Supplier Ledger Credit</span>
              </div>
              <div className="text-right font-mono">
                <span className="font-bold text-slate-900">₹{purchaseCreditTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                <span className="text-[10px] text-slate-500 ml-1.5">({purchaseCreditPercent.toFixed(1)}%)</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/70">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-500"></span>
                <span className="font-semibold text-slate-700">Bank / NEFT / UPI</span>
              </div>
              <div className="text-right font-mono">
                <span className="font-bold text-slate-900">₹{purchaseBankTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                <span className="text-[10px] text-slate-500 ml-1.5">({purchaseBankPercent.toFixed(1)}%)</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* 4. FILTER TOOLBAR & REGISTER SEARCH (Day Book Style) */}
      {/* ==================================================== */}
      {activeSubTab === 'SALES' ? (
        <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs space-y-3.5 print:hidden">
          {/* Top Bar: Title, Date Presets, and Reset Filter */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500 uppercase tracking-wider shrink-0 pr-1">
                <Filter className="w-3.5 h-3.5 text-slate-500" />
                <span>FILTER INVOICES:</span>
              </div>
              {/* Presets Chips */}
              <div className="flex items-center gap-1.5 flex-wrap">
                {(['today', 'yesterday', 'last7', 'thisMonth', 'all'] as DateFilterPreset[]).map((p) => {
                  const isActive = datePreset === p;
                  return (
                    <button
                      key={p}
                      id={`sales-preset-${p}`}
                      type="button"
                      onClick={() => handleDatePresetChange(p)}
                      className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                        isActive
                          ? 'bg-slate-900 text-white shadow-xs'
                          : 'bg-slate-100/90 text-slate-600 hover:bg-slate-200/80 border border-slate-200/60'
                      }`}
                    >
                      {p === 'today' && 'Today'}
                      {p === 'yesterday' && 'Yesterday'}
                      {p === 'last7' && 'Last 7 Days'}
                      {p === 'thisMonth' && 'This Month'}
                      {p === 'all' && 'All Dates'}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* General Search and Reset Button */}
            <div className="flex items-center gap-2.5 flex-wrap">
              <div className="relative min-w-[200px]">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search invoice or party..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-7 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white transition-colors"
                />
                {searchTerm && (
                  <button
                    type="button"
                    onClick={() => setSearchTerm('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <button
                id="sales-reset-filter-btn"
                type="button"
                onClick={handleResetFilters}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-xs whitespace-nowrap"
                title="Reset all filters and revert to today's invoices"
              >
                <RotateCcw className="w-3.5 h-3.5 text-rose-600" />
                <span>Reset Filter</span>
              </button>
            </div>
          </div>

          {/* Filter Inputs Grid (Reordered: 1. Customer Wise, 2. Customer Invoice Number, 3. Item Code, 4. Contains Item Name, 5. Date Range) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 text-xs pt-1 border-t border-slate-100">
            {/* 1. Customer Filter */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Customer Wise
              </label>
              <select
                value={selectedCustomerIdFilter}
                onChange={(e) => setSelectedCustomerIdFilter(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:outline-none focus:border-amber-500 focus:bg-white cursor-pointer transition-colors"
              >
                <option value="ALL">All Customers</option>
                <option value="CUST-000">Cash / Counter Sale</option>
                {customersList
                  .filter((c) => c.id !== 'CUST-000')
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.customerName} {c.mobile ? `(${c.mobile})` : ''}
                    </option>
                  ))}
              </select>
            </div>

            {/* 2. Customer Invoice Number */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Customer Invoice Number
              </label>
              <div className="relative">
                <Hash className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="e.g. CUS-INV-001"
                  value={invoiceNoFilter}
                  onChange={(e) => setInvoiceNoFilter(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-6 py-1.5 text-slate-800 focus:outline-none focus:border-amber-500 focus:bg-white placeholder-slate-400 font-mono transition-colors"
                />
                {invoiceNoFilter && (
                  <button
                    type="button"
                    onClick={() => setInvoiceNoFilter('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {/* 3. Item Code */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Item Code
              </label>
              <div className="relative">
                <Tag className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="e.g. ART-001"
                  value={itemCodeFilter}
                  onChange={(e) => setItemCodeFilter(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-6 py-1.5 text-slate-800 focus:outline-none focus:border-amber-500 focus:bg-white placeholder-slate-400 font-mono transition-colors"
                />
                {itemCodeFilter && (
                  <button
                    type="button"
                    onClick={() => setItemCodeFilter('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {/* 4. Contains Item Name */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Contains Item Name
              </label>
              <div className="relative">
                <ShoppingBag className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search Item in Bill..."
                  value={itemNameFilter}
                  onChange={(e) => setItemNameFilter(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-6 py-1.5 text-slate-800 focus:outline-none focus:border-amber-500 focus:bg-white placeholder-slate-400 transition-colors"
                />
                {itemNameFilter && (
                  <button
                    type="button"
                    onClick={() => setItemNameFilter('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {/* 5. Date Range */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Date Range
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                <input
                  type="date"
                  placeholder="From"
                  value={startDate}
                  onChange={(e) => {
                    setStartDate(e.target.value);
                    setDatePreset('custom');
                    setDateFilter('');
                  }}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-slate-800 focus:outline-none focus:border-amber-500 focus:bg-white font-mono text-[11px] transition-colors"
                />
                <input
                  type="date"
                  placeholder="To"
                  value={endDate}
                  onChange={(e) => {
                    setEndDate(e.target.value);
                    setDatePreset('custom');
                    setDateFilter('');
                  }}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-slate-800 focus:outline-none focus:border-amber-500 focus:bg-white font-mono text-[11px] transition-colors"
                />
              </div>
            </div>
          </div>

          {/* Bottom Bar with Active Filter Summary */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2.5 border-t border-slate-100 text-xs">
            <div className="text-slate-500 text-[11px] flex items-center gap-2 flex-wrap">
              <span className="font-semibold text-slate-600">Active Register Filter:</span>
              <span className="font-bold text-amber-800 bg-amber-50 border border-amber-200/70 px-2 py-0.5 rounded">
                {dateFilter
                  ? `Invoices on ${dateFilter === getLocalTodayDate() ? 'Today (' + dateFilter + ')' : dateFilter}`
                  : datePreset !== 'all'
                  ? `${datePreset === 'today' ? "Today's Invoices" : datePreset === 'yesterday' ? "Yesterday's Invoices" : datePreset === 'last7' ? 'Last 7 Days' : datePreset === 'thisMonth' ? 'This Month' : startDate && endDate ? `${startDate} to ${endDate}` : 'Custom Range'}`
                  : 'All Invoices (No Date Filter)'}
              </span>
              {selectedCustomerIdFilter !== 'ALL' && (
                <span className="bg-slate-100 border border-slate-200 px-2 py-0.5 rounded text-[10px] text-slate-700 font-medium">
                  Customer: {customersList.find((c) => c.id === selectedCustomerIdFilter)?.customerName || selectedCustomerIdFilter}
                </span>
              )}
              {invoiceNoFilter && (
                <span className="bg-slate-100 border border-slate-200 px-2 py-0.5 rounded text-[10px] font-mono text-slate-700 font-medium">
                  Inv: {invoiceNoFilter}
                </span>
              )}
              {itemNameFilter && (
                <span className="bg-slate-100 border border-slate-200 px-2 py-0.5 rounded text-[10px] text-slate-700 font-medium">
                  Item: {itemNameFilter}
                </span>
              )}
            </div>

            <div className="text-[11px] text-slate-500">
              Showing <strong className="text-slate-900">{filteredSales.length}</strong> matching sales records
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs space-y-3.5 print:hidden">
          {/* Top Bar: Title, Date Presets, and Reset Filter */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500 uppercase tracking-wider shrink-0 pr-1">
                <Filter className="w-3.5 h-3.5 text-slate-500" />
                <span>FILTER PURCHASE BILLS:</span>
              </div>
              {/* Presets Chips */}
              <div className="flex items-center gap-1.5 flex-wrap">
                {(['today', 'yesterday', 'last7', 'thisMonth', 'all'] as DateFilterPreset[]).map((p) => {
                  const isActive = purchaseDatePreset === p;
                  return (
                    <button
                      key={p}
                      id={`purchase-preset-${p}`}
                      type="button"
                      onClick={() => handlePurchaseDatePresetChange(p)}
                      className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                        isActive
                          ? 'bg-slate-900 text-white shadow-xs'
                          : 'bg-slate-100/90 text-slate-600 hover:bg-slate-200/80 border border-slate-200/60'
                      }`}
                    >
                      {p === 'today' && 'Today'}
                      {p === 'yesterday' && 'Yesterday'}
                      {p === 'last7' && 'Last 7 Days'}
                      {p === 'thisMonth' && 'This Month'}
                      {p === 'all' && 'All Dates'}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* General Search and Reset Button */}
            <div className="flex items-center gap-2.5 flex-wrap">
              <div className="relative min-w-[240px]">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search bill no, supplier, items..."
                  value={purchaseSearchTerm}
                  onChange={(e) => setPurchaseSearchTerm(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-7 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white transition-colors"
                />
                {purchaseSearchTerm && (
                  <button
                    type="button"
                    onClick={() => setPurchaseSearchTerm('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Reset Filter Button */}
              <button
                type="button"
                id="btn-reset-purchase-filters"
                onClick={handleResetPurchaseFilters}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100/80 border border-rose-200/80 transition-colors cursor-pointer shadow-2xs"
                title="Reset all filters back to today's purchase bills"
              >
                <RotateCcw className="w-3.5 h-3.5 text-rose-600" />
                <span>Reset Filter</span>
              </button>
            </div>
          </div>

          {/* 5-Column Filter Inputs Grid: 1. Supplier Wise, 2. Purchase / Bill No, 3. Contains Item Name, 4. Date Wise (Single Day), 5. Date Range */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 pt-1 border-t border-slate-100 text-xs">
            {/* 1. Supplier Wise */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1">
                <Building2 className="w-3 h-3 text-slate-400" />
                <span>Supplier Wise</span>
              </label>
              <select
                id="select-supplier-wise-filter"
                value={selectedSupplierIdFilter}
                onChange={(e) => setSelectedSupplierIdFilter(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-amber-500 focus:bg-white truncate cursor-pointer"
              >
                <option value="ALL">All Suppliers</option>
                {suppliersList.map((sup) => (
                  <option key={sup.id} value={sup.id}>
                    {sup.supplierName}
                  </option>
                ))}
              </select>
            </div>

            {/* 2. Purchase / Bill No */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1">
                <Hash className="w-3 h-3 text-slate-400" />
                <span>Purchase / Bill No</span>
              </label>
              <div className="relative">
                <input
                  id="input-purchase-bill-no-filter"
                  type="text"
                  placeholder="e.g. PUR-001, INV-44..."
                  value={purchaseBillNoFilter}
                  onChange={(e) => setPurchaseBillNoFilter(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-2.5 pr-6 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white font-mono"
                />
                {purchaseBillNoFilter && (
                  <button
                    type="button"
                    onClick={() => setPurchaseBillNoFilter('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {/* 3. Contains Item Name */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1">
                <ShoppingBag className="w-3 h-3 text-slate-400" />
                <span>Contains Item Name</span>
              </label>
              <div className="relative">
                <input
                  id="input-purchase-item-name-filter"
                  type="text"
                  placeholder="e.g. Formal Shoes, Leather..."
                  value={purchaseItemNameFilter}
                  onChange={(e) => setPurchaseItemNameFilter(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-2.5 pr-6 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:bg-white"
                />
                {purchaseItemNameFilter && (
                  <button
                    type="button"
                    onClick={() => setPurchaseItemNameFilter('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {/* 4. Date Wise (Single Day) */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1">
                <Calendar className="w-3 h-3 text-slate-400" />
                <span>Date Wise (Single Day)</span>
              </label>
              <div className="relative">
                <input
                  id="input-purchase-single-date-filter"
                  type="date"
                  value={purchaseDateFilter}
                  onChange={(e) => {
                    setPurchaseDateFilter(e.target.value);
                    setPurchaseDatePreset('custom');
                  }}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-amber-500 focus:bg-white font-mono"
                />
                {purchaseDateFilter && (
                  <button
                    type="button"
                    onClick={() => setPurchaseDateFilter('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    title="Clear single date filter"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {/* 5. Date Range */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1">
                <Calendar className="w-3 h-3 text-slate-400" />
                <span>Date Range</span>
              </label>
              <div className="flex items-center gap-1">
                <input
                  id="input-purchase-range-from"
                  type="date"
                  value={purchaseStartDate}
                  onChange={(e) => {
                    setPurchaseStartDate(e.target.value);
                    setPurchaseDateFilter('');
                    setPurchaseDatePreset('custom');
                  }}
                  className="w-1/2 bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-[11px] text-slate-800 focus:outline-none focus:border-amber-500 focus:bg-white font-mono"
                  placeholder="From"
                />
                <span className="text-slate-400 text-xs">-</span>
                <input
                  id="input-purchase-range-to"
                  type="date"
                  value={purchaseEndDate}
                  onChange={(e) => {
                    setPurchaseEndDate(e.target.value);
                    setPurchaseDateFilter('');
                    setPurchaseDatePreset('custom');
                  }}
                  className="w-1/2 bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-[11px] text-slate-800 focus:outline-none focus:border-amber-500 focus:bg-white font-mono"
                  placeholder="To"
                />
              </div>
            </div>
          </div>

          {/* Active Filter Summary Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs text-slate-500 border-t border-slate-100">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Active Register Filter:</span>
              <span className="bg-amber-50 border border-amber-200/80 text-amber-800 px-2 py-0.5 rounded text-[10px] font-medium">
                {purchaseDateFilter ? (
                  <>Date: <strong>{formatDisplayDate(purchaseDateFilter)}</strong></>
                ) : purchaseStartDate && purchaseEndDate ? (
                  <>Range: <strong>{formatDisplayDate(purchaseStartDate)}</strong> to <strong>{formatDisplayDate(purchaseEndDate)}</strong></>
                ) : (
                  <strong>All Recorded Dates</strong>
                )}
              </span>
              {selectedSupplierIdFilter !== 'ALL' && (
                <span className="bg-purple-50 border border-purple-200 text-purple-800 px-2 py-0.5 rounded text-[10px] font-medium">
                  Supplier: {suppliersList.find(s => s.id === selectedSupplierIdFilter)?.supplierName || selectedSupplierIdFilter}
                </span>
              )}
              {purchaseBillNoFilter && (
                <span className="bg-slate-100 border border-slate-200 px-2 py-0.5 rounded text-[10px] font-mono text-slate-700 font-medium">
                  Bill: {purchaseBillNoFilter}
                </span>
              )}
              {purchaseItemNameFilter && (
                <span className="bg-slate-100 border border-slate-200 px-2 py-0.5 rounded text-[10px] text-slate-700 font-medium">
                  Item: {purchaseItemNameFilter}
                </span>
              )}
            </div>

            <div className="text-[11px] text-slate-500">
              Showing <strong className="text-slate-900">{filteredPurchases.length}</strong> matching purchase records
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* 5. PRINT-ONLY REGISTER HEADER (Visible on window.print)*/}
      {/* ==================================================== */}
      <div className="hidden print:block border-b-2 border-black pb-3 mb-3">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-xl font-bold uppercase tracking-tight text-black">
              {companyInfo.companyName || 'ARCO FOOTWEAR'}
            </h1>
            <p className="text-xs text-gray-700">
              {companyInfo.addressLine1} {companyInfo.addressLine2 ? `, ${companyInfo.addressLine2}` : ''}{companyInfo.city ? `, ${companyInfo.city}` : ''}{companyInfo.pincode ? ` - ${companyInfo.pincode}` : ''}
            </p>
            <p className="text-xs text-gray-700">Phone: {companyInfo.phone || companyInfo.mobile} | Email: {companyInfo.email}</p>
            {companyInfo.gstin && (
              <p className="text-xs font-mono font-bold text-black mt-0.5">GSTIN: {companyInfo.gstin}</p>
            )}
          </div>
          <div className="text-right">
            <h2 className="text-base font-bold uppercase">
              {activeSubTab === 'SALES' ? 'CUSTOMER BILL REPORTS' : 'SUPPLIER BILL REPORTS'}
            </h2>
            <div className="text-xs font-semibold text-gray-700 mt-1">
              Date Filter: {
                activeSubTab === 'SALES'
                  ? (dateFilter ? formatDisplayDate(dateFilter) : startDate && endDate ? `${formatDisplayDate(startDate)} to ${formatDisplayDate(endDate)}` : 'All Dates')
                  : (purchaseDateFilter ? formatDisplayDate(purchaseDateFilter) : purchaseStartDate && purchaseEndDate ? `${formatDisplayDate(purchaseStartDate)} to ${formatDisplayDate(purchaseEndDate)}` : 'All Dates')
              }
            </div>
            <div className="text-[10px] text-gray-500 mt-0.5">
              Print Timestamp: {new Date().toLocaleString('en-IN')}
            </div>
          </div>
        </div>
      </div>

      {/* ==================================================== */}
      {/* 6. TRANSACTION REGISTER TABLE (Day Book Style)       */}
      {/* ==================================================== */}
      <div className="bg-white border border-slate-200/90 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          {activeSubTab === 'SALES' ? (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold uppercase tracking-wider text-slate-600">
                  <th className="py-3 px-3.5 w-28">Date</th>
                  <th className="py-3 px-3.5 w-36">Customer Invoice No</th>
                  <th className="py-3 px-3.5">Customer / Client Name</th>
                  <th className="py-3 px-3.5 w-28">Payment Mode</th>
                  <th className="py-3 px-3.5 text-right w-28">Taxable (₹)</th>
                  <th className="py-3 px-3.5 text-right w-24">GST Tax (₹)</th>
                  <th className="py-3 px-3.5 text-right w-32">Grand Total (₹)</th>
                  <th className="py-3 px-3.5 text-center w-28 print:hidden">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredSales.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-12 px-4 text-slate-500">
                      <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mb-3">
                        <FileText className="w-6 h-6" />
                      </div>
                      <p className="font-semibold text-slate-700 text-sm">No customer invoices found</p>
                      <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                        No sales billing invoices matching criteria were recorded for the active filter.
                      </p>
                    </td>
                  </tr>
                ) : (
                  filteredSales.map((s) => (
                    <tr 
                      key={s.id} 
                      className="transition-colors hover:bg-amber-50/30 group"
                    >
                      {/* Date */}
                      <td className="py-3 px-3.5 font-mono text-xs text-slate-500 whitespace-nowrap">
                        {s.invoiceDate}
                      </td>

                      {/* Invoice No */}
                      <td className="py-3 px-3.5 font-mono font-bold text-xs whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => handlePrint(s)}
                          className="hover:underline text-slate-900 hover:text-amber-800 font-bold flex items-center gap-1.5 cursor-pointer transition-colors text-left group-hover:text-amber-900"
                          title="Click to view & print invoice"
                        >
                          <Printer className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          <span>{s.invoiceNo}</span>
                        </button>
                      </td>

                      {/* Customer Name */}
                      <td className="py-3 px-3.5 font-semibold text-xs text-slate-800">
                        <div>{s.customerName}</div>
                        {s.customerGstin && (
                          <div className="text-[10px] text-emerald-700 font-mono font-medium">GSTIN: {s.customerGstin}</div>
                        )}
                      </td>

                      {/* Payment Mode */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        {renderPaymentBadge(s.paymentMode)}
                      </td>

                      {/* Taxable */}
                      <td className="py-3 px-3.5 text-right font-mono text-xs text-slate-600 whitespace-nowrap">
                        ₹{s.totalTaxable.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>

                      {/* GST Tax */}
                      <td className="py-3 px-3.5 text-right font-mono text-xs text-slate-500 whitespace-nowrap">
                        ₹{s.totalTax.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>

                      {/* Grand Total */}
                      <td className="py-3 px-3.5 text-right font-mono font-bold text-xs tabular-nums text-slate-900 whitespace-nowrap">
                        ₹{s.grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3.5 text-center print:hidden whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => handlePrint(s)}
                            className="px-2.5 py-1 text-[11px] font-bold bg-slate-900 hover:bg-slate-800 text-white rounded-lg flex items-center gap-1 transition-colors cursor-pointer shadow-xs"
                            title="Print GST Invoice"
                          >
                            <Printer className="w-3 h-3 text-amber-400" />
                            <span>Print</span>
                          </button>
                          {onNavigateToReturnExchange && (
                            <button
                              onClick={() => onNavigateToReturnExchange(s.id)}
                              className="px-2.5 py-1 text-[11px] font-bold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200/70 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                              title="Edit Sales Invoice in Sales Register Desk"
                            >
                              <Edit3 className="w-3 h-3 text-amber-700" />
                              <span>Edit</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>

              {/* Table Footer / Totals Row */}
              {filteredSales.length > 0 && (
                <tfoot>
                  <tr className="border-t-2 border-slate-300 bg-slate-50/90 font-bold text-slate-800">
                    <td colSpan={4} className="py-3.5 px-3.5 text-right text-xs uppercase tracking-wider text-slate-500">
                      Filtered Register Total ({filteredSales.length} Invoices):
                    </td>
                    <td className="py-3.5 px-3.5 text-right font-mono text-xs text-slate-700 whitespace-nowrap">
                      ₹{salesSubtotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3.5 px-3.5 text-right font-mono text-xs text-slate-600 whitespace-nowrap">
                      ₹{salesTax.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3.5 px-3.5 text-right text-base text-slate-900 font-black font-mono tabular-nums whitespace-nowrap">
                      ₹{salesTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3.5 px-3.5 print:hidden"></td>
                  </tr>
                </tfoot>
              )}
            </table>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold uppercase tracking-wider text-slate-600">
                  <th className="py-3 px-3.5 w-28">Date</th>
                  <th className="py-3 px-3.5 w-36">Purchase Bill No</th>
                  <th className="py-3 px-3.5 w-32">Supplier Bill No</th>
                  <th className="py-3 px-3.5">Supplier Name</th>
                  <th className="py-3 px-3.5 w-28">Purchase Type</th>
                  <th className="py-3 px-3.5 w-28">Payment Mode</th>
                  <th className="py-3 px-3.5 text-right w-28">Taxable (₹)</th>
                  <th className="py-3 px-3.5 text-right w-28">GST (₹)</th>
                  <th className="py-3 px-3.5 text-right w-32">Grand Total (₹)</th>
                  <th className="py-3 px-3.5 text-center w-28 print:hidden">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredPurchases.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="text-center py-12 px-4 text-slate-500">
                      <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mb-3">
                        <FileText className="w-6 h-6" />
                      </div>
                      <p className="font-semibold text-slate-700 text-sm">No purchase bills found</p>
                      <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                        No purchase billing inward documents found for the active filter.
                      </p>
                    </td>
                  </tr>
                ) : (
                  filteredPurchases.map((p) => (
                    <tr key={p.id} className="transition-colors hover:bg-amber-50/30 group">
                      <td className="py-3 px-3.5 font-mono text-xs text-slate-500 whitespace-nowrap">{p.purchaseDate}</td>
                      <td className="py-3 px-3.5 font-mono font-bold text-xs text-slate-900 whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => setSelectedPrintPurchase(p)}
                          className="hover:text-amber-600 hover:underline cursor-pointer flex items-center gap-1.5 text-left"
                        >
                          <FileText className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-500" />
                          <span>{p.purchaseNo}</span>
                        </button>
                      </td>
                      <td className="py-3 px-3.5 font-mono font-bold text-xs text-indigo-700 whitespace-nowrap">{p.supplierBillNo || 'N/A'}</td>
                      <td className="py-3 px-3.5 text-xs text-slate-800">
                        <span className="font-semibold block">{p.supplierName}</span>
                        {p.supplierGstin && (
                          <span className="text-[10px] text-slate-400 font-mono block">GSTIN: {p.supplierGstin}</span>
                        )}
                      </td>
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold border ${
                          (p.purchaseType === 'Cash' || p.paymentMode === 'Cash' || p.supplierId === 'SUP-CASH')
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-purple-50 text-purple-700 border-purple-200'
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${
                            (p.purchaseType === 'Cash' || p.paymentMode === 'Cash' || p.supplierId === 'SUP-CASH')
                              ? 'bg-emerald-500'
                              : 'bg-purple-500'
                          }`}></span>
                          {p.purchaseType || (p.paymentMode === 'Cash' ? 'Cash' : 'Credit Line')}
                        </span>
                      </td>
                      <td className="py-3 px-3.5 whitespace-nowrap">{renderPaymentBadge(p.paymentMode)}</td>
                      <td className="py-3 px-3.5 text-right font-mono text-xs text-slate-600 whitespace-nowrap">
                        ₹{(p.totalTaxable ?? p.grossSubtotal ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-3 px-3.5 text-right font-mono text-xs text-slate-500 whitespace-nowrap">
                        ₹{(p.totalTax || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-3 px-3.5 text-right font-mono font-bold text-xs tabular-nums text-slate-900 whitespace-nowrap">
                        ₹{p.grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-3 px-3.5 text-center whitespace-nowrap print:hidden">
                        <button
                          type="button"
                          onClick={() => setSelectedPrintPurchase(p)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/80 rounded-md transition-colors border border-slate-200/80 cursor-pointer shadow-2xs"
                          title="View & Print Purchase Inward Voucher"
                        >
                          <FileText className="w-3.5 h-3.5 text-slate-500" />
                          <span>View</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>

              {/* Table Footer / Totals Row */}
              {filteredPurchases.length > 0 && (
                <tfoot>
                  <tr className="border-t-2 border-slate-300 bg-slate-50/90 font-bold text-slate-800">
                    <td colSpan={6} className="py-3.5 px-3.5 text-right text-xs uppercase tracking-wider text-slate-500">
                      Filtered Purchase Total ({filteredPurchases.length} Bills):
                    </td>
                    <td className="py-3.5 px-3.5 text-right font-mono text-xs text-slate-700 whitespace-nowrap">
                      ₹{purchaseSubtotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3.5 px-3.5 text-right font-mono text-xs text-slate-600 whitespace-nowrap">
                      ₹{purchaseTax.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3.5 px-3.5 text-right text-base text-slate-900 font-black font-mono tabular-nums whitespace-nowrap">
                      ₹{purchaseTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3.5 px-3.5 print:hidden"></td>
                  </tr>
                </tfoot>
              )}
            </table>
          )}
        </div>
      </div>

      {/* Print Footer Signatures (Print Only, matching Day Book) */}
      <div className="hidden print:flex justify-between items-center pt-10 text-xs font-semibold text-black">
        <div className="text-center">
          <div className="w-40 border-t border-black pt-1">Prepared By</div>
        </div>
        <div className="text-center">
          <div className="w-40 border-t border-black pt-1">Auditor / Accountant</div>
        </div>
        <div className="text-center">
          <div className="w-40 border-t border-black pt-1">Authorized Signatory</div>
        </div>
      </div>

      {/* Sales Invoice Print Preview Modal (Exact match to Tax Invoice & Retail Billing page) */}
      {selectedPrintInvoice && (
        <InvoicePrintModal
          invoice={selectedPrintInvoice}
          company={companyInfo}
          onClose={() => setSelectedPrintInvoice(null)}
          onAttachToNav={
            onOpenPrintPreviewTab
              ? () => {
                  const inv = selectedPrintInvoice;
                  setSelectedPrintInvoice(null);
                  onOpenPrintPreviewTab(inv, false);
                }
              : undefined
          }
        />
      )}

      {/* Purchase Inward Bill Voucher Print Preview Modal */}
      {selectedPrintPurchase && (
        <PurchasePrintModal
          purchase={selectedPrintPurchase}
          company={companyInfo}
          onClose={() => setSelectedPrintPurchase(null)}
        />
      )}

      {/* Multi-Format Register Print Modal (A4, 80mm POS Slip, 70mm POS Slip) */}
      <RegisterPrintModal
        isOpen={isRegisterPrintModalOpen}
        onClose={() => setIsRegisterPrintModalOpen(false)}
        company={companyInfo}
        type={activeSubTab}
        salesInvoices={filteredSales}
        purchaseInvoices={filteredPurchases}
        dateRangeText={getRegisterDateRangeText()}
        fromDate={
          activeSubTab === 'SALES'
            ? (dateFilter || (startDate ? startDate : undefined))
            : (purchaseDateFilter || (purchaseStartDate ? purchaseStartDate : undefined))
        }
        toDate={
          activeSubTab === 'SALES'
            ? (dateFilter || (endDate ? endDate : undefined))
            : (purchaseDateFilter || (purchaseEndDate ? purchaseEndDate : undefined))
        }
        supplierName={activeSubTab === 'PURCHASES' ? selectedSupplierDisplayName : undefined}
        customerName={activeSubTab === 'SALES' ? selectedCustomerDisplayName : undefined}
        taxableTotal={activeSubTab === 'SALES' ? salesSubtotal : purchaseSubtotal}
        taxTotal={activeSubTab === 'SALES' ? salesTax : purchaseTax}
        grandTotal={activeSubTab === 'SALES' ? salesTotal : purchaseTotal}
        cashTotal={activeSubTab === 'SALES' ? salesCashTotal : purchaseCashTotal}
        creditTotal={activeSubTab === 'SALES' ? salesCreditTotal : purchaseCreditTotal}
        digitalTotal={activeSubTab === 'SALES' ? salesDigitalTotal : purchaseBankTotal}
      />
    </div>
  );
};
