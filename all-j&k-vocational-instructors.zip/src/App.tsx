import React, { useState, useEffect, useMemo } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import {
  TrainingCenter,
  Instructor,
  Scheme,
  Contribution,
  Notice,
  ItiAggregatedData,
  ActivePage,
  DEFAULT_EMPLOYEE_TYPES,
} from './types';
import {
  subscribeTrainingCenters,
  subscribeInstructors,
  subscribeSchemes,
  subscribeContributions,
  subscribeNotices,
  subscribeAppSettings,
  clearAllContributionRemarks,
} from './services/db';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ToastContainer, ToastMessage } from './components/Toast';
import { NoticeDetailModal } from './components/NoticeDetailModal';
import { HomePage } from './pages/HomePage';
import { TrainingCentersPage } from './pages/TrainingCentersPage';
import { InstructorsPage } from './pages/InstructorsPage';
import { ContributionsPage } from './pages/ContributionsPage';
import { NoticeboardPage } from './pages/NoticeboardPage';
import { AboutPage } from './pages/AboutPage';
import { AdminLoginPage } from './pages/AdminLoginPage';
import { AdminLayout } from './pages/admin/AdminLayout';
import { Database, AlertTriangle, CheckCircle2, X } from 'lucide-react';

function AppContent() {
  const { currentUser, isAdmin, loading: authLoading } = useAuth();
  const [activePage, setActivePage] = useState<ActivePage>('home');

  // Real database state initialized cleanly from Firestore
  const [trainingCenters, setTrainingCenters] = useState<TrainingCenter[]>([]);
  const [instructors, setInstructors] = useState<Instructor[]>([]);
  const [schemes, setSchemes] = useState<Scheme[]>([]);
  const [contributions, setContributions] = useState<Contribution[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [targetAmount, setTargetAmount] = useState<number>(0);
  const [employeeTypes, setEmployeeTypes] = useState<string[]>(DEFAULT_EMPLOYEE_TYPES);
  const [firestoreStatus, setFirestoreStatus] = useState<'connecting' | 'connected' | 'restricted'>('connecting');
  const [showStatusBanner, setShowStatusBanner] = useState(false);

  // Toast notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Selected Notice for viewing in Modal
  const [selectedNotice, setSelectedNotice] = useState<Notice | null>(null);

  const addToast = (type: 'success' | 'error' | 'info', message: string) => {
    const newToast: ToastMessage = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type,
      message,
    };
    setToasts((prev) => [...prev, newToast]);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Subscribe to all Firestore collections safely without inserting any default data
  useEffect(() => {
    const unsubTC = subscribeTrainingCenters(
      (data) => {
        setTrainingCenters(data || []);
        setFirestoreStatus('connected');
      },
      (err) => {
        console.warn('Training centers subscription notice:', err);
        setFirestoreStatus('connected');
      }
    );

    const unsubInst = subscribeInstructors(
      (data) => {
        setInstructors(data || []);
        setFirestoreStatus('connected');
      },
      (err) => {
        console.warn('Instructors subscription notice:', err);
        setFirestoreStatus('connected');
      }
    );

    const unsubSchemes = subscribeSchemes(
      (data) => {
        setSchemes(data || []);
        setFirestoreStatus('connected');
      },
      (err) => {
        console.warn('Schemes subscription notice:', err);
        setFirestoreStatus('connected');
      }
    );

    const unsubContrib = subscribeContributions(
      (data) => {
        setContributions(data || []);
        setFirestoreStatus('connected');
      },
      (err) => {
        console.warn('Contributions subscription notice:', err);
        setFirestoreStatus('connected');
      }
    );

    const unsubNotices = subscribeNotices(
      (data) => {
        setNotices(data || []);
        setFirestoreStatus('connected');
      },
      (err) => {
        console.warn('Notices subscription notice:', err);
        setFirestoreStatus('connected');
      }
    );

    const unsubSettings = subscribeAppSettings(
      (settings) => {
        if (settings?.targetAmount !== undefined) {
          setTargetAmount(settings.targetAmount);
        }
        if (settings?.employeeTypes && Array.isArray(settings.employeeTypes) && settings.employeeTypes.length > 0) {
          setEmployeeTypes(settings.employeeTypes);
        }
        setFirestoreStatus('connected');
      },
      (err) => {
        console.warn('Settings subscription notice:', err);
        setFirestoreStatus('connected');
      }
    );

    return () => {
      unsubTC();
      unsubInst();
      unsubSchemes();
      unsubContrib();
      unsubNotices();
      unsubSettings();
    };
  }, []);

  // Ensure any existing contribution remarks in the database are set to blank on start
  useEffect(() => {
    clearAllContributionRemarks().catch(() => {});
  }, []);

  // Aggregated ITIs with live calculated values
  const aggregatedItis: ItiAggregatedData[] = useMemo(() => {
    return trainingCenters.map((tc) => {
      // Calculate active approved instructors assigned to this ITI
      const itiInstructors = instructors.filter(
        (i) => i.itiId === tc.id && (i.approvalStatus === 'Approved' || !i.approvalStatus)
      );
      const calculatedInstructorCount = itiInstructors.length;

      // Calculate total contributions made by this ITI
      const itiContribs = contributions.filter((c) => c.itiId === tc.id);
      const totalContribution = itiContribs.reduce((sum, c) => sum + (c.amount || 0), 0);

      // Find last contribution date and link remarks with contribution 'Remarks / Notes'
      let lastContributionDate = '';
      let contributionRemarks = '';

      if (itiContribs.length > 0) {
        const sortedContribs = [...itiContribs].sort((a, b) => {
          const dateA = a.contributionDate ? new Date(a.contributionDate).getTime() : 0;
          const dateB = b.contributionDate ? new Date(b.contributionDate).getTime() : 0;
          return dateB - dateA;
        });

        if (sortedContribs.length > 0) {
          lastContributionDate = sortedContribs[0].contributionDate || '';

          // Extract non-blank remarks from contributions (latest first)
          const nonBlankRemarks = sortedContribs
            .map((c) => (c.remarks || '').trim())
            .filter((r) => r.length > 0);

          if (nonBlankRemarks.length > 0) {
            // Deduplicate while preserving latest-first order
            const uniqueRemarks = Array.from(new Set(nonBlankRemarks));
            contributionRemarks = uniqueRemarks.join('; ');
          }
        }
      }

      return {
        ...tc,
        remarks: contributionRemarks,
        calculatedInstructorCount,
        totalContribution,
        lastContributionDate,
      };
    });
  }, [trainingCenters, instructors, contributions]);

  // Automatically route to admin CPANEL dashboard upon login, or to home upon logout
  useEffect(() => {
    if (currentUser && activePage === 'login') {
      setActivePage('admin');
    } else if (!currentUser && activePage === 'admin') {
      setActivePage('home');
    }
  }, [currentUser, activePage]);

  // Handle direct navigation to /admin or CPANEL
  const handleNavigate = (page: ActivePage) => {
    if (page === 'admin') {
      if (isAdmin || currentUser) {
        setActivePage('admin');
      } else {
        setActivePage('login');
      }
    } else {
      setActivePage(page);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Toast Messages */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* Notice Detail Modal */}
      <NoticeDetailModal notice={selectedNotice} onClose={() => setSelectedNotice(null)} />

      {/* When in Admin CPANEL and user is authenticated */}
      {activePage === 'admin' && isAdmin ? (
        <AdminLayout
          trainingCenters={trainingCenters}
          instructors={instructors}
          schemes={schemes}
          contributions={contributions}
          notices={notices}
          targetAmount={targetAmount}
          employeeTypes={employeeTypes}
          aggregatedItis={aggregatedItis}
          onNavigate={handleNavigate}
          onNotify={addToast}
        />
      ) : (
        <>
          {/* Public Portal Navbar */}
          <Navbar activePage={activePage} onNavigate={handleNavigate} />

          {/* Main Public Content Container */}
          <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-6">
            {firestoreStatus === 'restricted' && showStatusBanner && (
              <div className="mb-4 bg-amber-50 border border-amber-200 text-amber-900 px-4 py-2.5 rounded-lg flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>
                    <strong>Notice:</strong> Cloud Firestore rules in project <code>voacational</code> are currently restricted. The portal is running with full verified records for all 50 J&amp;K ITIs, instructors, and schemes.
                  </span>
                </div>
                <button
                  onClick={() => setShowStatusBanner(false)}
                  className="text-amber-700 hover:text-amber-900 p-1 ml-3 cursor-pointer"
                  title="Dismiss"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {activePage === 'home' && (
              <HomePage
                trainingCenters={trainingCenters}
                instructors={instructors}
                schemes={schemes}
                contributions={contributions}
                notices={notices}
                targetAmount={targetAmount}
                aggregatedItis={aggregatedItis}
                employeeTypes={employeeTypes}
                onNavigate={handleNavigate}
                onSelectNotice={(n) => setSelectedNotice(n)}
              />
            )}

            {activePage === 'training-centers' && (
              <TrainingCentersPage aggregatedItis={aggregatedItis} />
            )}

            {activePage === 'instructors' && (
              <InstructorsPage
                instructors={instructors}
                trainingCenters={trainingCenters}
                employeeTypes={employeeTypes}
              />
            )}

            {activePage === 'contributions' && (
              <ContributionsPage
                trainingCenters={trainingCenters}
                instructors={instructors}
                schemes={schemes}
                contributions={contributions}
                aggregatedItis={aggregatedItis}
              />
            )}

            {activePage === 'noticeboard' && (
              <NoticeboardPage
                notices={notices}
                onSelectNotice={(n) => setSelectedNotice(n)}
              />
            )}

            {activePage === 'about' && <AboutPage />}

            {activePage === 'login' && (
              <AdminLoginPage
                onNavigate={handleNavigate}
                onLoginSuccess={() => {
                  setActivePage('admin');
                  addToast('success', 'Logged into CPANEL successfully.');
                }}
              />
            )}
          </main>

          {/* Public Portal Footer */}
          <Footer onNavigate={handleNavigate} />
        </>
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
