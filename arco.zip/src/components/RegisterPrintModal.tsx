import React, { useState, useEffect } from 'react';
import { Printer, X, FileText, CheckCircle2, Building2, ShoppingCart, Landmark } from 'lucide-react';
import { CompanyInfo, SalesInvoice, PurchaseInvoice } from '../types';
import { formatCurrency } from '../services/gstCalculations';
import { printElement } from '../services/printService';

export interface RegisterPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  company: CompanyInfo;
  type: 'SALES' | 'PURCHASES';
  salesInvoices?: SalesInvoice[];
  purchaseInvoices?: PurchaseInvoice[];
  dateRangeText?: string;
  fromDate?: string;
  toDate?: string;
  supplierName?: string;
  customerName?: string;
  // Totals
  taxableTotal: number;
  taxTotal: number;
  grandTotal: number;
  cashTotal: number;
  creditTotal: number;
  digitalTotal?: number;
}

export const RegisterPrintModal: React.FC<RegisterPrintModalProps> = ({
  isOpen,
  onClose,
  company,
  type,
  salesInvoices = [],
  purchaseInvoices = [],
  dateRangeText = 'All Filtered Records',
  fromDate,
  toDate,
  supplierName,
  customerName,
  taxableTotal,
  taxTotal,
  grandTotal,
  cashTotal,
  creditTotal,
  digitalTotal = 0,
}) => {
  const [printFormat, setPrintFormat] = useState<'Thermal70' | 'Thermal80' | 'A4'>('Thermal80');

  // Listen for Ctrl+P and Escape keys
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        handlePrint();
      }
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, printFormat]);

  if (!isOpen) return null;

  const isSales = type === 'SALES';
  const registerTitle = isSales ? 'CUSTOMER BILL REPORTS' : 'SUPPLIER BILL REPORTS';
  const itemsCount = isSales ? salesInvoices.length : purchaseInvoices.length;

  // Determine effective From and To dates for print
  const effectiveFromDate = fromDate || (
    isSales
      ? (salesInvoices.length > 0 ? salesInvoices.reduce((min, s) => s.invoiceDate < min ? s.invoiceDate : min, salesInvoices[0].invoiceDate) : '')
      : (purchaseInvoices.length > 0 ? purchaseInvoices.reduce((min, p) => p.purchaseDate < min ? p.purchaseDate : min, purchaseInvoices[0].purchaseDate) : '')
  );

  const effectiveToDate = toDate || (
    isSales
      ? (salesInvoices.length > 0 ? salesInvoices.reduce((max, s) => s.invoiceDate > max ? s.invoiceDate : max, salesInvoices[0].invoiceDate) : '')
      : (purchaseInvoices.length > 0 ? purchaseInvoices.reduce((max, p) => p.purchaseDate > max ? p.purchaseDate : max, purchaseInvoices[0].purchaseDate) : '')
  );

  const handlePrint = () => {
    printElement({
      elementId: 'printable-register-content',
      format: printFormat,
      title: `${registerTitle} - ${company.companyName || 'ARCO FOOTWEAR'}`,
    });
  };

  const formatDateStr = (dateVal: string | Date | undefined) => {
    if (!dateVal) return '-';
    try {
      const d = new Date(dateVal);
      if (isNaN(d.getTime())) return String(dateVal);
      return d.toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      });
    } catch {
      return String(dateVal);
    }
  };

  return (
    <div
      id="register-print-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto"
    >
      <div
        id="register-print-modal-container"
        className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Modal Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 bg-slate-900 text-white shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-400/20 border border-amber-400/40 text-amber-400 flex items-center justify-center font-bold">
              <Printer className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-extrabold tracking-tight text-white flex items-center gap-2">
                <span>Print {registerTitle}</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 uppercase font-mono">
                  {itemsCount} Records
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Choose format below and press Print (Ctrl+P)
              </p>
            </div>
          </div>

          {/* Format Selector Pills */}
          <div className="flex items-center gap-1.5 bg-slate-800 p-1 rounded-xl border border-slate-700/80">
            <button
              id="format-btn-70mm"
              type="button"
              onClick={() => setPrintFormat('Thermal70')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                printFormat === 'Thermal70'
                  ? 'bg-amber-400 text-slate-950 shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
            >
              <span>70mm Thermal</span>
            </button>
            <button
              id="format-btn-80mm"
              type="button"
              onClick={() => setPrintFormat('Thermal80')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                printFormat === 'Thermal80'
                  ? 'bg-amber-400 text-slate-950 shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
            >
              <span>80mm Thermal</span>
            </button>
            <button
              id="format-btn-a4"
              type="button"
              onClick={() => setPrintFormat('A4')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                printFormat === 'A4'
                  ? 'bg-amber-400 text-slate-950 shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
            >
              <span>Standard A4</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="print-action-btn"
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-slate-950 text-xs font-black rounded-lg shadow-sm transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>PRINT (Ctrl+P)</span>
            </button>
            <button
              id="close-print-modal-btn"
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Close (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body / Scrollable Printable Area */}
        <div className="flex-1 overflow-y-auto bg-slate-100 p-3 sm:p-6 flex justify-center items-start">
          <div
            id="printable-register-content"
            className={`bg-white text-black shadow-lg transition-all ${
              printFormat === 'Thermal70'
                ? 'w-[70mm] min-w-[70mm] max-w-[70mm] p-2 text-[11px] font-mono thermal-70mm-slip'
                : printFormat === 'Thermal80'
                ? 'w-[80mm] min-w-[80mm] max-w-[80mm] p-3 text-[12px] font-mono thermal-80mm-slip'
                : 'w-full max-w-[210mm] p-8 text-xs font-sans rounded-sm'
            }`}
            style={{ minHeight: '100px' }}
          >
            {/* ---------------------------------------------------- */}
            {/* FORMAT 1: 70mm POS THERMAL SLIP                      */}
            {/* ---------------------------------------------------- */}
            {printFormat === 'Thermal70' && (
              <div id="thermal-70mm-register-slip" className="space-y-2 leading-tight">
                {/* Header */}
                <div className="text-center border-b border-black pb-1.5">
                  <div className="font-extrabold text-[13px] tracking-tight uppercase">
                    {company.companyName || 'ARCO FOOTWEAR'}
                  </div>
                  {company.addressLine1 && (
                    <div className="text-[9.5px]">
                      {company.addressLine1} {company.addressLine2}
                    </div>
                  )}
                  <div className="text-[9.5px]">
                    {company.city} {company.pincode ? `- ${company.pincode}` : ''}
                  </div>
                  {company.gstin && (
                    <div className="text-[9.5px] font-bold">GSTIN: {company.gstin}</div>
                  )}
                  {company.mobile && (
                    <div className="text-[9.5px]">Tel: {company.mobile}</div>
                  )}
                  <div className="mt-1 pt-1 border-t border-dashed border-black font-extrabold text-[11.5px] uppercase">
                    {registerTitle}
                  </div>
                  <div className="text-[9px] text-gray-700">{dateRangeText}</div>
                  <div className="mt-0.5 text-[9px] font-bold text-black border-t border-dotted border-black pt-0.5 space-y-0.5 text-left">
                    <div className="flex justify-between">
                      <span>From Date:</span>
                      <span>{formatDateStr(effectiveFromDate)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>To Date:</span>
                      <span>{formatDateStr(effectiveToDate)}</span>
                    </div>
                  </div>
                  {!isSales && supplierName && (
                    <div className="mt-1 pt-0.5 border-t border-dotted border-black text-[9.5px] font-bold uppercase text-black">
                      Supplier: {supplierName}
                    </div>
                  )}
                  {isSales && customerName && (
                    <div className="mt-1 pt-0.5 border-t border-dotted border-black text-[9.5px] font-bold uppercase text-black">
                      Customer: {customerName}
                    </div>
                  )}
                </div>

                {/* Summary Metrics */}
                <div className="border-b border-dashed border-black pb-1 text-[10px] space-y-0.5">
                  <div className="flex justify-between font-bold">
                    <span>Total Records:</span>
                    <span>{itemsCount} Bills</span>
                  </div>
                  {!isSales && (
                    <div className="flex justify-between">
                      <span>Credit Inward:</span>
                      <span>₹{creditTotal.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>{isSales ? 'Taxable Subtotal:' : 'Inward Cost:'}</span>
                    <span>₹{taxableTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>{isSales ? 'Total GST Tax:' : 'Total ITC Earned:'}</span>
                    <span>₹{taxTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>{isSales ? 'Cash Billing:' : 'Cash Purchases:'}</span>
                    <span>₹{cashTotal.toFixed(2)}</span>
                  </div>
                  {isSales && (
                    <div className="flex justify-between">
                      <span>Credit / Khata:</span>
                      <span>₹{creditTotal.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-extrabold text-[11px] pt-0.5 border-t border-dotted border-black">
                    <span>{isSales ? 'TOTAL SALES VALUE:' : 'TOTAL PURCHASE VALUE:'}</span>
                    <span>₹{grandTotal.toFixed(2)}</span>
                  </div>
                </div>

                {/* Items List (Compact 70mm table) */}
                <div className="py-1">
                  <div className="text-[9.5px] font-extrabold border-b border-black pb-0.5 uppercase mb-1">
                    TRANSACTION ENTRIES:
                  </div>
                  {isSales ? (
                    <div className="space-y-1.5">
                      {salesInvoices.map((inv, idx) => (
                        <div key={inv.id || idx} className="border-b border-dotted border-gray-400 pb-1 text-[9.5px]">
                          <div className="flex justify-between font-bold">
                            <span>#{inv.invoiceNo || 'INV'}</span>
                            <span>{formatDateStr(inv.invoiceDate)}</span>
                          </div>
                          <div className="truncate font-semibold">{inv.customerName || 'Cash Customer'}</div>
                          <div className="flex justify-between text-[9px] text-gray-800">
                            <span>Mode: {inv.paymentMode || 'CASH'}</span>
                            <span>Taxable: ₹{(inv.totalTaxable ?? inv.grossSubtotal ?? 0).toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between font-bold text-[10px]">
                            <span>GST: ₹{(inv.totalTax || 0).toFixed(2)}</span>
                            <span>Total: ₹{inv.grandTotal.toFixed(2)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-1.5">
                      {purchaseInvoices.map((pur, idx) => (
                        <div key={pur.id || idx} className="border-b border-dotted border-gray-400 pb-1 text-[9.5px]">
                          <div className="flex justify-between font-bold">
                            <span>#{pur.purchaseNo || pur.supplierBillNo || 'PUR'}</span>
                            <span>{formatDateStr(pur.purchaseDate)}</span>
                          </div>
                          <div className="truncate font-semibold">{pur.supplierName || 'Cash Supplier'}</div>
                          {pur.supplierBillNo && (
                            <div className="text-[8.5px] text-gray-700">Ref: {pur.supplierBillNo}</div>
                          )}
                          <div className="flex justify-between text-[9px] text-gray-800">
                            <span>Type: <strong className="text-black">{pur.purchaseType || (pur.paymentMode === 'Cash' ? 'Cash' : 'Credit Line')}</strong></span>
                            <span>Mode: {pur.paymentMode || 'CASH'}</span>
                          </div>
                          <div className="flex justify-between text-[9px] text-gray-800">
                            <span>Taxable: ₹{(pur.totalTaxable ?? pur.grossSubtotal ?? 0).toFixed(2)}</span>
                            <span>ITC: ₹{(pur.totalTax || 0).toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between font-bold text-[10px] text-black">
                            <span>Grand Total:</span>
                            <span>₹{pur.grandTotal.toFixed(2)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Footer */}
                <div className="pt-2 border-t-2 border-black text-center text-[9px] space-y-1">
                  <div className="font-bold">TOTAL REGISTER SUM: ₹{grandTotal.toFixed(2)}</div>
                  <div className="text-gray-600">Printed on {new Date().toLocaleString('en-IN')}</div>
                  <div className="pt-4 flex justify-between px-2 text-[8.5px]">
                    <div>Prepared By</div>
                    <div>Accountant</div>
                  </div>
                </div>
              </div>
            )}

            {/* ---------------------------------------------------- */}
            {/* FORMAT 2: 80mm POS THERMAL SLIP                      */}
            {/* ---------------------------------------------------- */}
            {printFormat === 'Thermal80' && (
              <div id="thermal-80mm-register-slip" className="space-y-2.5 leading-tight">
                {/* Header */}
                <div className="text-center border-b-2 border-black pb-2">
                  <div className="font-extrabold text-[14px] tracking-tight uppercase">
                    {company.companyName || 'ARCO FOOTWEAR'}
                  </div>
                  {company.addressLine1 && (
                    <div className="text-[10px]">
                      {company.addressLine1} {company.addressLine2}
                    </div>
                  )}
                  <div className="text-[10px]">
                    {company.city} {company.pincode ? `- ${company.pincode}` : ''}
                  </div>
                  {company.gstin && (
                    <div className="text-[10px] font-bold">GSTIN: {company.gstin}</div>
                  )}
                  {company.mobile && (
                    <div className="text-[10px]">Mobile: {company.mobile}</div>
                  )}
                  <div className="mt-1 pt-1.5 border-t border-dashed border-black font-black text-[12.5px] uppercase">
                    {registerTitle}
                  </div>
                  <div className="text-[9.5px] text-gray-700">{dateRangeText}</div>
                  <div className="mt-0.5 text-[9.5px] font-bold text-black border-t border-dotted border-black pt-0.5 flex justify-between">
                    <span>From: {formatDateStr(effectiveFromDate)}</span>
                    <span>To: {formatDateStr(effectiveToDate)}</span>
                  </div>
                  {!isSales && supplierName && (
                    <div className="mt-1 pt-1 border-t border-dotted border-black text-[10px] font-bold uppercase text-black">
                      Supplier: {supplierName}
                    </div>
                  )}
                  {isSales && customerName && (
                    <div className="mt-1 pt-1 border-t border-dotted border-black text-[10px] font-bold uppercase text-black">
                      Customer: {customerName}
                    </div>
                  )}
                </div>

                {/* Summary Metrics Box */}
                <div className="border border-black p-1.5 rounded-xs text-[10.5px] space-y-0.5">
                  <div className="flex justify-between font-bold border-b border-dashed border-gray-400 pb-0.5">
                    <span>Total Inward Records:</span>
                    <span>{itemsCount} Bills</span>
                  </div>
                  {!isSales && (
                    <div className="flex justify-between">
                      <span>Credit Inward:</span>
                      <span>₹{creditTotal.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>{isSales ? 'Taxable Subtotal:' : 'Inward Cost (Taxable):'}</span>
                    <span>₹{taxableTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>{isSales ? 'Total GST Tax:' : 'Total ITC Earned:'}</span>
                    <span>₹{taxTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>{isSales ? 'Cash Billing:' : 'Cash Purchases:'}</span>
                    <span>₹{cashTotal.toFixed(2)}</span>
                  </div>
                  {isSales && (
                    <div className="flex justify-between">
                      <span>Credit / Khata:</span>
                      <span>₹{creditTotal.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-extrabold text-[11.5px] pt-1 border-t border-black">
                    <span>{isSales ? 'GRAND TOTAL SALES:' : 'GRAND TOTAL PURCHASES:'}</span>
                    <span>₹{grandTotal.toFixed(2)}</span>
                  </div>
                </div>

                {/* Table Header */}
                <table className="w-full text-left text-[9.5px] border-collapse">
                  <thead>
                    <tr className="border-y border-black font-extrabold text-[9px] uppercase">
                      <th className="py-1 w-14">Date/No</th>
                      <th className="py-1">Party / Type / Mode</th>
                      <th className="py-1 text-right w-16">Taxable</th>
                      <th className="py-1 text-right w-16">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-300">
                    {isSales
                      ? salesInvoices.map((inv, idx) => (
                          <tr key={inv.id || idx}>
                            <td className="py-1 align-top">
                              <div className="font-bold">#{inv.invoiceNo}</div>
                              <div className="text-[8.5px] text-gray-600">{formatDateStr(inv.invoiceDate)}</div>
                            </td>
                            <td className="py-1 align-top">
                              <div className="font-bold truncate max-w-[100px]">{inv.customerName || 'Cash'}</div>
                              <div className="text-[8.5px] text-gray-600">{inv.paymentMode || 'CASH'}</div>
                            </td>
                            <td className="py-1 text-right align-top">
                              ₹{(inv.totalTaxable ?? inv.grossSubtotal ?? 0).toFixed(2)}
                            </td>
                            <td className="py-1 text-right font-bold align-top">
                              ₹{inv.grandTotal.toFixed(2)}
                            </td>
                          </tr>
                        ))
                      : purchaseInvoices.map((pur, idx) => (
                          <tr key={pur.id || idx}>
                            <td className="py-1 align-top">
                              <div className="font-bold">#{pur.purchaseNo || pur.supplierBillNo || 'PUR'}</div>
                              <div className="text-[8.5px] text-gray-600">{formatDateStr(pur.purchaseDate)}</div>
                            </td>
                            <td className="py-1 align-top">
                              <div className="font-bold truncate max-w-[110px]">{pur.supplierName || 'Cash'}</div>
                              <div className="text-[8.5px] text-gray-700 font-semibold">
                                [{pur.purchaseType || (pur.paymentMode === 'Cash' ? 'Cash' : 'Credit Line')}] • {pur.paymentMode || 'CASH'}
                              </div>
                            </td>
                            <td className="py-1 text-right align-top">
                              ₹{(pur.totalTaxable ?? pur.grossSubtotal ?? 0).toFixed(2)}
                            </td>
                            <td className="py-1 text-right font-bold align-top">
                              ₹{pur.grandTotal.toFixed(2)}
                            </td>
                          </tr>
                        ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 border-black font-extrabold text-[10.5px]">
                      <td colSpan={2} className="py-1.5 uppercase">Register Total:</td>
                      <td className="py-1.5 text-right font-bold">₹{taxableTotal.toFixed(2)}</td>
                      <td className="py-1.5 text-right font-bold">₹{grandTotal.toFixed(2)}</td>
                    </tr>
                  </tfoot>
                </table>

                {/* Footer */}
                <div className="pt-2 border-t border-dashed border-black text-center text-[9px] space-y-1">
                  <div className="text-gray-600">Printed on {new Date().toLocaleString('en-IN')}</div>
                  <div className="pt-5 flex justify-between px-2 text-[9px] font-bold">
                    <div>Prepared By</div>
                    <div>Auditor / Sign</div>
                  </div>
                </div>
              </div>
            )}

            {/* ---------------------------------------------------- */}
            {/* FORMAT 3: STANDARD A4 AUDIT REGISTER SHEET           */}
            {/* ---------------------------------------------------- */}
            {printFormat === 'A4' && (
              <div id="standard-a4-register-sheet" className="space-y-4">
                {/* Header */}
                <div className="border-b-2 border-black pb-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h1 className="text-2xl font-black uppercase tracking-tight text-black">
                        {company.companyName || 'ARCO FOOTWEAR'}
                      </h1>
                      <p className="text-xs text-slate-700 mt-0.5">
                        {company.addressLine1} {company.addressLine2}, {company.city} - {company.pincode}
                      </p>
                      <p className="text-xs text-slate-700 font-mono">
                        GSTIN: <span className="font-bold">{company.gstin || 'N/A'}</span> | Phone: {company.mobile || 'N/A'}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="inline-block px-3 py-1 bg-black text-white text-xs font-black uppercase tracking-wider rounded-xs">
                        {registerTitle}
                      </span>
                      <p className="text-xs text-slate-600 mt-1 font-mono">{dateRangeText}</p>
                      <div className="mt-1 text-xs font-mono font-bold text-slate-800">
                        <span>From Date: <span className="font-extrabold text-black">{formatDateStr(effectiveFromDate)}</span></span>
                        <span className="mx-2 text-slate-400">|</span>
                        <span>To Date: <span className="font-extrabold text-black">{formatDateStr(effectiveToDate)}</span></span>
                      </div>
                      {!isSales && supplierName && (
                        <div className="mt-1">
                          <span className="inline-block px-2.5 py-0.5 bg-slate-100 border border-slate-300 rounded text-xs font-bold text-slate-900">
                            Supplier: {supplierName}
                          </span>
                        </div>
                      )}
                      {isSales && customerName && (
                        <div className="mt-1">
                          <span className="inline-block px-2.5 py-0.5 bg-slate-100 border border-slate-300 rounded text-xs font-bold text-slate-900">
                            Customer: {customerName}
                          </span>
                        </div>
                      )}
                      <p className="text-[10px] text-slate-500 mt-0.5">Printed on: {new Date().toLocaleString('en-IN')}</p>
                    </div>
                  </div>
                </div>

                {/* Summary Cards Row (A4 Style) */}
                <div className="grid grid-cols-5 gap-2.5 bg-slate-50 border border-slate-300 p-3 rounded-md">
                  {!isSales ? (
                    <>
                      <div className="border-r border-slate-300 pr-2">
                        <span className="text-[10px] font-bold uppercase text-slate-500 block">Credit Inward</span>
                        <span className="text-sm font-extrabold font-mono text-purple-900">
                          ₹{creditTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div className="border-r border-slate-300 pr-2">
                        <span className="text-[10px] font-bold uppercase text-slate-500 block">Inward Cost</span>
                        <span className="text-sm font-extrabold font-mono text-slate-900">
                          ₹{taxableTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div className="border-r border-slate-300 pr-2">
                        <span className="text-[10px] font-bold uppercase text-slate-500 block">Total ITC Earned</span>
                        <span className="text-sm font-extrabold font-mono text-teal-900">
                          ₹{taxTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div className="border-r border-slate-300 pr-2">
                        <span className="text-[10px] font-bold uppercase text-slate-500 block">Cash Purchases</span>
                        <span className="text-sm font-extrabold font-mono text-emerald-900">
                          ₹{cashTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] font-black uppercase text-amber-800 block">Total Purchase Value</span>
                        <span className="text-base font-black font-mono text-amber-900">
                          ₹{grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="border-r border-slate-300 pr-2">
                        <span className="text-[10px] font-bold uppercase text-slate-500 block">Taxable Subtotal</span>
                        <span className="text-sm font-extrabold font-mono text-slate-900">
                          ₹{taxableTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div className="border-r border-slate-300 pr-2">
                        <span className="text-[10px] font-bold uppercase text-slate-500 block">Total GST Tax</span>
                        <span className="text-sm font-extrabold font-mono text-teal-900">
                          ₹{taxTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div className="border-r border-slate-300 pr-2">
                        <span className="text-[10px] font-bold uppercase text-slate-500 block">Cash Billing</span>
                        <span className="text-sm font-extrabold font-mono text-emerald-900">
                          ₹{cashTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div className="border-r border-slate-300 pr-2">
                        <span className="text-[10px] font-bold uppercase text-slate-500 block">Credit / Khata</span>
                        <span className="text-sm font-extrabold font-mono text-purple-900">
                          ₹{creditTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] font-black uppercase text-amber-800 block">Total Sales Value</span>
                        <span className="text-base font-black font-mono text-amber-900">
                          ₹{grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                    </>
                  )}
                </div>

                {/* Main Detailed Register Table */}
                <table className="w-full text-left text-xs border border-slate-400 border-collapse">
                  <thead>
                    <tr className="bg-slate-200 text-slate-900 font-bold border-b border-slate-400">
                      <th className="py-2 px-2.5 border-r border-slate-300 w-12 text-center">#</th>
                      <th className="py-2 px-2.5 border-r border-slate-300 w-24">Date</th>
                      <th className="py-2 px-2.5 border-r border-slate-300 w-28">
                        {isSales ? 'Invoice No' : 'Voucher No'}
                      </th>
                      {!isSales && (
                        <th className="py-2 px-2.5 border-r border-slate-300 w-28">Supplier Bill No</th>
                      )}
                      <th className="py-2 px-2.5 border-r border-slate-300">
                        {isSales ? 'Customer Name' : 'Supplier Name'}
                      </th>
                      {!isSales && (
                        <th className="py-2 px-2.5 border-r border-slate-300 w-28">Purchase Type</th>
                      )}
                      <th className="py-2 px-2.5 border-r border-slate-300 w-24">Payment Mode</th>
                      <th className="py-2 px-2.5 border-r border-slate-300 text-right w-28">Taxable (₹)</th>
                      <th className="py-2 px-2.5 border-r border-slate-300 text-right w-24">
                        {isSales ? 'GST Tax (₹)' : 'GST ITC (₹)'}
                      </th>
                      <th className="py-2 px-2.5 text-right w-32">Grand Total (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-300">
                    {isSales ? (
                      salesInvoices.length === 0 ? (
                        <tr>
                          <td colSpan={8} className="text-center py-6 text-slate-500 font-medium">
                            No sales invoice records found for this period.
                          </td>
                        </tr>
                      ) : (
                        salesInvoices.map((s, idx) => (
                          <tr key={s.id || idx} className="hover:bg-slate-50">
                            <td className="py-2 px-2.5 border-r border-slate-300 text-center font-mono text-[11px] text-slate-500">
                              {idx + 1}
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 font-mono text-[11px] whitespace-nowrap">
                              {formatDateStr(s.invoiceDate)}
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 font-mono font-bold text-[11px] whitespace-nowrap">
                              {s.invoiceNo}
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 font-medium">
                              <div>{s.customerName || 'Cash Customer'}</div>
                              {s.customerMobile && (
                                <div className="text-[10px] text-slate-500 font-mono">Ph: {s.customerMobile}</div>
                              )}
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 font-bold text-[11px]">
                              {s.paymentMode || 'CASH'}
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 text-right font-mono text-[11px]">
                              ₹{(s.totalTaxable ?? s.grossSubtotal ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 text-right font-mono text-[11px]">
                              ₹{(s.totalTax || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                            <td className="py-2 px-2.5 text-right font-mono font-bold text-[11px]">
                              ₹{s.grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                          </tr>
                        ))
                      )
                    ) : (
                      purchaseInvoices.length === 0 ? (
                        <tr>
                          <td colSpan={10} className="text-center py-6 text-slate-500 font-medium">
                            No purchase bill records found for this period.
                          </td>
                        </tr>
                      ) : (
                        purchaseInvoices.map((p, idx) => (
                          <tr key={p.id || idx} className="hover:bg-slate-50">
                            <td className="py-2 px-2.5 border-r border-slate-300 text-center font-mono text-[11px] text-slate-500">
                              {idx + 1}
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 font-mono text-[11px] whitespace-nowrap">
                              {formatDateStr(p.purchaseDate)}
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 font-mono font-bold text-[11px] whitespace-nowrap">
                              {p.purchaseNo || p.supplierBillNo || 'PUR'}
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 font-mono text-[11px] whitespace-nowrap">
                              {p.supplierBillNo || '-'}
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 font-medium">
                              <div>{p.supplierName || 'Cash Supplier'}</div>
                              {p.supplierGstin && (
                                <div className="text-[10px] text-slate-500 font-mono">GSTIN: {p.supplierGstin}</div>
                              )}
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 font-bold text-[11px]">
                              <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] ${
                                (p.purchaseType === 'Cash' || p.paymentMode === 'Cash')
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-purple-100 text-purple-800'
                              }`}>
                                {p.purchaseType || (p.paymentMode === 'Cash' ? 'Cash' : 'Credit Line')}
                              </span>
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 font-bold text-[11px]">
                              {p.paymentMode || 'CASH'}
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 text-right font-mono text-[11px]">
                              ₹{(p.totalTaxable ?? p.grossSubtotal ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                            <td className="py-2 px-2.5 border-r border-slate-300 text-right font-mono text-[11px]">
                              ₹{(p.totalTax || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                            <td className="py-2 px-2.5 text-right font-mono font-bold text-[11px]">
                              ₹{p.grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                          </tr>
                        ))
                      )
                    )}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 border-slate-500 bg-slate-100 font-black text-slate-900">
                      <td colSpan={isSales ? 5 : 7} className="py-2.5 px-3 text-right uppercase tracking-wider text-xs">
                        Filtered Register Total ({itemsCount} Records):
                      </td>
                      <td className="py-2.5 px-2.5 text-right font-mono text-xs whitespace-nowrap border-r border-slate-300">
                        ₹{taxableTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-2.5 px-2.5 text-right font-mono text-xs whitespace-nowrap border-r border-slate-300">
                        ₹{taxTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-2.5 px-2.5 text-right font-mono text-sm whitespace-nowrap">
                        ₹{grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                    </tr>
                  </tfoot>
                </table>

                {/* Signatures Footer */}
                <div className="pt-10 flex justify-between items-center text-xs font-semibold text-slate-800">
                  <div className="text-center">
                    <div className="w-48 border-t border-black pt-1">Prepared By</div>
                  </div>
                  <div className="text-center">
                    <div className="w-48 border-t border-black pt-1">Auditor / Accountant</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
