import React from 'react';
import {
  TrainingCenter,
  Instructor,
  Scheme,
  Contribution,
  Notice,
  ItiAggregatedData,
  ActivePage,
  DEFAULT_EMPLOYEE_TYPES,
} from '../types';
import { DashboardCards } from '../components/DashboardCards';
import { InstructorsPage } from './InstructorsPage';
import { RecentContributions } from '../components/RecentContributions';
import { LatestNotices } from '../components/LatestNotices';
import { GraduationCap, ShieldCheck, Building2, Users, Layers, Lock, ArrowRight } from 'lucide-react';
import presidentPhoto from '../assets/images/president.jpg';
import chairmanPhoto from '../assets/images/chairman.jpg';

interface HomePageProps {
  trainingCenters: TrainingCenter[];
  instructors: Instructor[];
  schemes: Scheme[];
  contributions: Contribution[];
  notices: Notice[];
  targetAmount: number;
  aggregatedItis: ItiAggregatedData[];
  employeeTypes?: string[];
  onNavigate: (page: ActivePage) => void;
  onSelectNotice: (notice: Notice) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  trainingCenters,
  instructors,
  schemes,
  contributions,
  notices,
  targetAmount,
  aggregatedItis,
  employeeTypes = DEFAULT_EMPLOYEE_TYPES,
  onNavigate,
  onSelectNotice,
}) => {
  const activeInstructorsCount = instructors.filter((i) => i.status === 'Active').length;
  const totalCollection = contributions.reduce((sum, c) => sum + (c.amount || 0), 0);

  return (
    <div className="space-y-8 pb-12">
      {/* Hero Welcome & Administrative Header */}
      <section className="bg-gradient-to-r from-[#0F2942] via-[#163657] to-[#1E3A8A] text-white rounded-2xl p-6 sm:p-8 lg:p-10 shadow-lg border border-blue-900/60 relative overflow-hidden">
        {/* Background decorative watermark */}
        <div className="absolute right-0 bottom-0 translate-x-10 translate-y-10 opacity-5 pointer-events-none">
          <GraduationCap className="w-96 h-96" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row items-center md:items-start gap-6 lg:gap-8">
          {/* Two Photo Cards to the left side of 'Official State Portal • Jammu & Kashmir' title section */}
          <div className="flex flex-row items-stretch gap-3 sm:gap-4 shrink-0">
            {/* President Card */}
            <div className="bg-slate-900/80 backdrop-blur-md border border-amber-400/30 rounded-2xl p-3 sm:p-3.5 flex flex-col items-center text-center w-36 sm:w-40 shadow-xl ring-1 ring-white/10 hover:border-amber-400/60 transition-all">
              <div className="relative mb-2">
                <img
                  src={presidentPhoto}
                  alt="President - J&K ITI Employee's United Front"
                  referrerPolicy="no-referrer"
                  className="w-24 h-24 sm:w-28 sm:h-28 rounded-xl object-cover border-2 border-amber-400/80 shadow-md"
                />
                <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-[9px] px-2.5 py-0.5 rounded-full uppercase tracking-wider whitespace-nowrap shadow-md border border-amber-300">
                  PRESIDENT
                </span>
              </div>
              <h4 className="font-extrabold text-white text-xs sm:text-sm mt-2 leading-tight">
                State President
              </h4>
              <p className="text-[10px] text-amber-300 font-semibold leading-tight mt-0.5">
                J&amp;K ITI Employee&#39;s United Front
              </p>
            </div>

            {/* Chairman Card */}
            <div className="bg-slate-900/80 backdrop-blur-md border border-amber-400/30 rounded-2xl p-3 sm:p-3.5 flex flex-col items-center text-center w-36 sm:w-40 shadow-xl ring-1 ring-white/10 hover:border-amber-400/60 transition-all">
              <div className="relative mb-2">
                <img
                  src={chairmanPhoto}
                  alt="Chairman - J&K ITI Employee's United Front"
                  referrerPolicy="no-referrer"
                  className="w-24 h-24 sm:w-28 sm:h-28 rounded-xl object-cover border-2 border-amber-400/80 shadow-md"
                />
                <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-[9px] px-2.5 py-0.5 rounded-full uppercase tracking-wider whitespace-nowrap shadow-md border border-amber-300">
                  CHAIRMAN
                </span>
              </div>
              <h4 className="font-extrabold text-white text-xs sm:text-sm mt-2 leading-tight">
                State Chairman
              </h4>
              <p className="text-[10px] text-amber-300 font-semibold leading-tight mt-0.5">
                J&amp;K ITI Employee&#39;s United Front
              </p>
            </div>
          </div>

          {/* Title & Description Section */}
          <div className="flex-1 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-bold tracking-wide uppercase">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>Official State Portal • Jammu &amp; Kashmir</span>
            </div>

            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight uppercase leading-tight text-white">
              J&amp;K ITI EMPLOYEE&#39;S UNITED FRONT
            </h2>
            <p className="text-amber-400 text-sm sm:text-base font-semibold tracking-wide">
              Industrial Training Institutes of Jammu &amp; Kashmir
            </p>

            <p className="text-slate-200 text-xs sm:text-sm leading-relaxed max-w-2xl font-normal">
              Centralized platform for managing Skill Development Employees, Training Centers, Schemes and Industrial Training Institutes of Jammu &amp; Kashmir.
            </p>

            {/* Quick Shortcuts */}
            <div className="pt-2 flex flex-wrap items-center gap-3 text-xs">
              <button
                type="button"
                id="hero-view-itis-btn"
                onClick={() => onNavigate('training-centers')}
                className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold transition-colors flex items-center gap-2 shadow-sm cursor-pointer"
              >
                <Building2 className="w-4 h-4" />
                <span>Explore ITIs {trainingCenters.length > 0 ? `(${trainingCenters.length})` : ''}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                id="hero-view-instructors-btn"
                onClick={() => onNavigate('instructors')}
                className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold border border-white/20 transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Users className="w-4 h-4" />
                <span>Skill Development Employees</span>
              </button>
              <button
                type="button"
                id="hero-cpanel-btn"
                onClick={() => onNavigate('login')}
                className="px-4 py-2 rounded-lg bg-[#071727] hover:bg-[#0b2038] text-amber-400 font-bold border border-amber-500/40 transition-colors flex items-center gap-2 ml-auto cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>Admin CPANEL</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Live Dashboard Cards */}
      <section aria-label="Dashboard Metrics">
        <div className="flex items-center justify-between mb-3 px-1">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            Live Institutional Metrics
          </h3>
          <span className="text-[11px] text-slate-400 font-mono">
            Synced with State Firestore DB
          </span>
        </div>
        <DashboardCards
          totalItis={trainingCenters.length}
          totalInstructors={activeInstructorsCount}
          totalSchemes={schemes.length}
        />
      </section>

      {/* Skill Development Employees Directory Main Section */}
      <section aria-label="Skill Development Employees Directory">
        <InstructorsPage
          instructors={instructors}
          trainingCenters={trainingCenters}
          employeeTypes={employeeTypes}
        />
      </section>

      {/* Two Column Grid: Recent Contributions & Latest Notices */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <RecentContributions
          contributions={contributions}
          schemes={schemes}
          onNavigate={onNavigate}
        />
        <LatestNotices
          notices={notices}
          onNavigate={onNavigate}
          onSelectNotice={onSelectNotice}
        />
      </section>
    </div>
  );
};
