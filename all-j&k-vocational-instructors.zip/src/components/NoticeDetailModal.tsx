import React from 'react';
import { Notice } from '../types';
import { formatDate } from '../utils/format';
import { X, Calendar, User, FileText, ExternalLink, AlertCircle } from 'lucide-react';

interface NoticeDetailModalProps {
  notice: Notice | null;
  onClose: () => void;
}

export const NoticeDetailModal: React.FC<NoticeDetailModalProps> = ({ notice, onClose }) => {
  if (!notice) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-2xl w-full overflow-hidden animate-scaleUp">
        {/* Header */}
        <div className="bg-[#0F2942] text-white p-5 flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-700 text-blue-100 uppercase tracking-wide">
                {notice.category}
              </span>
              {notice.isImportant && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-600 text-white uppercase tracking-wide flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  High Priority
                </span>
              )}
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white leading-snug">
              {notice.title}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Metadata Strip */}
        <div className="bg-slate-100 px-5 py-2.5 border-b border-slate-200 flex flex-wrap items-center justify-between text-xs text-slate-600 gap-3">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 font-mono">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              Published: {formatDate(notice.publishDate)}
            </span>
            {notice.eventDate && (
              <span className="flex items-center gap-1.5 font-mono text-purple-700 font-semibold">
                <Calendar className="w-3.5 h-3.5 text-purple-600" />
                Event Date: {formatDate(notice.eventDate)}
              </span>
            )}
          </div>
          <div className="flex items-center gap-1.5 text-slate-700 font-medium">
            <User className="w-3.5 h-3.5 text-slate-400" />
            <span>{notice.publishedBy || 'Directorate of Skill Development J&K'}</span>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line">
          {notice.description}

          {notice.attachmentUrl && (
            <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold text-blue-900">
                <FileText className="w-4 h-4 text-blue-700" />
                <span>Official Document Attachment</span>
              </div>
              <a
                href={notice.attachmentUrl}
                target="_blank"
                rel="noreferrer"
                className="text-xs font-bold text-blue-700 hover:underline flex items-center gap-1"
              >
                <span>Open Link</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
