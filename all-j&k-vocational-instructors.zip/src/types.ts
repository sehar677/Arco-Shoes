export type Division = 'Kashmir Division' | 'Jammu Division';

export interface TrainingCenter {
  id: string;
  sNo: number;
  name: string;
  division: Division;
  location: string;
  instructorCount: number;
  status: 'Active' | 'Inactive';
  remarks: string;
  createdAt?: string;
  updatedAt?: string;
}

export const DEFAULT_EMPLOYEE_TYPES: string[] = [
  'Vocational Instructor',
  'Senior Vocational Instructor',
  'Junior Vocational Instructor',
  'Workshop Attendant',
  'Group Instructor',
  'Drawing Instructor',
  'Maths / Science Instructor',
  'Employability Skills Instructor',
  'Technical Assistant',
  'Superintendent',
  'Supervisor',
  'Contractual Instructor',
  'Guest Faculty',
  'Ministerial / Office Staff',
];

export interface Instructor {
  id: string;
  name: string;
  itiId: string;
  itiName: string;
  division: Division;
  trade: string;
  contact: string;
  joiningDate: string;
  registrationNo?: string;
  employeeType?: string;
  status: 'Active' | 'On Leave' | 'Transferred' | 'Inactive';
  approvalStatus?: 'Approved' | 'Pending' | 'Pending Review (Awaiting Approval)' | 'Rejected';
  remarks: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Scheme {
  id: string;
  name: string;
  description: string;
  targetAmount: number;
  startDate: string;
  endDate?: string;
  status: 'Active' | 'Upcoming' | 'Completed' | 'Inactive' | 'Pending';
  remarks?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Contribution {
  id: string;
  itiId: string;
  itiName: string;
  division: Division;
  schemeId: string;
  schemeName: string;
  amount: number;
  contributionDate: string;
  receiptNumber: string;
  mode: 'Bank Transfer' | 'NEFT/RTGS' | 'Cheque' | 'Treasury Challan' | 'Cash/Draft' | 'Online' | 'Cash';
  remarks?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Notice {
  id: string;
  title: string;
  description: string;
  category: 'Notice' | 'Event' | 'Notification' | 'Circular' | 'Meeting';
  publishDate: string;
  eventDate?: string;
  attachmentUrl?: string;
  isImportant: boolean;
  status: 'Published' | 'Draft' | 'Archived';
  publishedBy: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface AppSetting {
  id: string;
  targetAmount: number;
  appName?: string;
  employeeTypes?: string[];
  isSeeded?: boolean;
  updatedAt?: string;
}

export interface ItiAggregatedData extends TrainingCenter {
  totalContribution: number;
  lastContributionDate: string;
  calculatedInstructorCount: number;
}

export type ActivePage = 
  | 'home'
  | 'training-centers'
  | 'instructors'
  | 'contributions'
  | 'noticeboard'
  | 'about'
  | 'login'
  | 'admin';

export type AdminTab =
  | 'overview'
  | 'dashboard'
  | 'training-centers'
  | 'add-training-center'
  | 'instructors'
  | 'pending-instructors'
  | 'add-instructor'
  | 'schemes'
  | 'contributions'
  | 'notices'
  | 'reports'
  | 'settings';

export interface OfficialIti {
  sNo: number;
  name: string;
  division: Division;
  district: string;
  location: string;
}

export interface AdminSession {
  id: string;
  uid: string;
  email: string;
  sessionId: string;
  lastActiveAt: number;
  loginAt: number;
  ipOrDevice?: string;
}

export interface DatabaseBackup {
  version: string;
  exportedAt: string;
  portal: string;
  metadata: {
    trainingCentersCount: number;
    instructorsCount: number;
    schemesCount: number;
    contributionsCount: number;
    noticesCount: number;
    targetAmount: number;
  };
  data: {
    trainingCenters: TrainingCenter[];
    instructors: Instructor[];
    schemes: Scheme[];
    contributions: Contribution[];
    notices: Notice[];
    targetAmount: number;
    appSettings?: Record<string, any>;
  };
}

export const OFFICIAL_JK_ITIS: OfficialIti[] = [
  // Kashmir Division (1-24)
  { sNo: 1, name: 'Govt. ITI Srinagar', division: 'Kashmir Division', district: 'Srinagar', location: 'Bagh-i-Ali Mardan Khan, Srinagar, Kashmir' },
  { sNo: 2, name: 'Govt. ITI Baramulla', division: 'Kashmir Division', district: 'Baramulla', location: 'Kanispora, Baramulla, Kashmir' },
  { sNo: 3, name: 'Govt. ITI Anantnag', division: 'Kashmir Division', district: 'Anantnag', location: 'Ashajipora, Anantnag, Kashmir' },
  { sNo: 4, name: 'Govt. ITI Budgam', division: 'Kashmir Division', district: 'Budgam', location: 'Budgam Main, Kashmir' },
  { sNo: 5, name: 'Govt. ITI Pattan', division: 'Kashmir Division', district: 'Baramulla', location: 'Pattan, Baramulla, Kashmir' },
  { sNo: 6, name: 'Govt. ITI Bandipora', division: 'Kashmir Division', district: 'Bandipora', location: 'Bandipora Town, Kashmir' },
  { sNo: 7, name: 'Govt. ITI Hajin', division: 'Kashmir Division', district: 'Bandipora', location: 'Hajin, Sonawari, Bandipora, Kashmir' },
  { sNo: 8, name: 'Govt. ITI Gurez', division: 'Kashmir Division', district: 'Bandipora', location: 'Dawar, Gurez, Bandipora, Kashmir' },
  { sNo: 9, name: 'Govt. ITI Uri', division: 'Kashmir Division', district: 'Baramulla', location: 'Uri, Baramulla, Kashmir' },
  { sNo: 10, name: 'Govt. ITI Kulgam', division: 'Kashmir Division', district: 'Kulgam', location: 'Chawalgam, Kulgam, Kashmir' },
  { sNo: 11, name: 'Govt. ITI Pulwama', division: 'Kashmir Division', district: 'Pulwama', location: 'Pulwama Town, Kashmir' },
  { sNo: 12, name: 'Govt. ITI Kangan', division: 'Kashmir Division', district: 'Ganderbal', location: 'Kangan, Ganderbal, Kashmir' },
  { sNo: 13, name: 'Govt. ITI Chrar-e-Sharief', division: 'Kashmir Division', district: 'Budgam', location: 'Chrar-e-Sharief, Budgam, Kashmir' },
  { sNo: 14, name: 'Govt. ITI Sopore', division: 'Kashmir Division', district: 'Baramulla', location: 'Sopore, Baramulla, Kashmir' },
  { sNo: 15, name: 'Govt. ITI Pampore', division: 'Kashmir Division', district: 'Pulwama', location: 'Pampore, Pulwama, Kashmir' },
  { sNo: 16, name: 'Govt. ITI Rohama', division: 'Kashmir Division', district: 'Baramulla', location: 'Rohama, Rafiabad, Baramulla, Kashmir' },
  { sNo: 17, name: 'Govt. ITI Kund', division: 'Kashmir Division', district: 'Kulgam', location: 'Kund Valley, Kulgam, Kashmir' },
  { sNo: 18, name: 'Govt. ITI Tral', division: 'Kashmir Division', district: 'Pulwama', location: 'Tral, Pulwama, Kashmir' },
  { sNo: 19, name: 'Govt. ITI KB Pora', division: 'Kashmir Division', district: 'Kulgam', location: 'K.B. Pora, Kulgam, Kashmir' },
  { sNo: 20, name: 'Govt. ITI Handwara', division: 'Kashmir Division', district: 'Kupwara', location: 'Handwara, Kupwara, Kashmir' },
  { sNo: 21, name: 'Govt. ITI Seer Hamadan', division: 'Kashmir Division', district: 'Anantnag', location: 'Seer Hamadan, Mattan, Anantnag, Kashmir' },
  { sNo: 22, name: 'Govt. ITI Kupwara', division: 'Kashmir Division', district: 'Kupwara', location: 'Kupwara Town, Kashmir' },
  { sNo: 23, name: 'Govt. ITI Shopian', division: 'Kashmir Division', district: 'Shopian', location: 'Shopian Town, Kashmir' },
  { sNo: 24, name: 'Govt. ITI Lalpora', division: 'Kashmir Division', district: 'Kupwara', location: 'Lalpora, Lolab Valley, Kupwara, Kashmir' },

  // Jammu Division (25-50)
  { sNo: 25, name: 'Govt. ITI Jammu', division: 'Jammu Division', district: 'Jammu', location: 'Bakshi Nagar, Jammu, J&K' },
  { sNo: 26, name: "Govt. Women's ITI Jammu", division: 'Jammu Division', district: 'Jammu', location: 'Lower Shiv Nagar, Jammu, J&K' },
  { sNo: 27, name: 'Govt. ITI R.S. Pura', division: 'Jammu Division', district: 'Jammu', location: 'R.S. Pura, Jammu, J&K' },
  { sNo: 28, name: 'Govt. ITI Udhampur', division: 'Jammu Division', district: 'Udhampur', location: 'Dhar Road, Udhampur, J&K' },
  { sNo: 29, name: 'Govt. ITI Kishtwar', division: 'Jammu Division', district: 'Kishtwar', location: 'Kishtwar Town, J&K' },
  { sNo: 30, name: 'Govt. ITI Rajouri', division: 'Jammu Division', district: 'Rajouri', location: 'Rajouri Town, J&K' },
  { sNo: 31, name: 'Govt. ITI Sunderbani', division: 'Jammu Division', district: 'Rajouri', location: 'Sunderbani, Rajouri, J&K' },
  { sNo: 32, name: 'Govt. ITI Kalakote', division: 'Jammu Division', district: 'Rajouri', location: 'Kalakote, Rajouri, J&K' },
  { sNo: 33, name: 'Govt. ITI Nowshera', division: 'Jammu Division', district: 'Rajouri', location: 'Nowshera, Rajouri, J&K' },
  { sNo: 34, name: 'Govt. ITI Doda', division: 'Jammu Division', district: 'Doda', location: 'Doda Town, J&K' },
  { sNo: 35, name: 'Govt. ITI Bhaderwah', division: 'Jammu Division', district: 'Doda', location: 'Bhaderwah, Doda, J&K' },
  { sNo: 36, name: 'Govt. ITI Bhallessa', division: 'Jammu Division', district: 'Doda', location: 'Gandoh Bhallessa, Doda, J&K' },
  { sNo: 37, name: 'Govt. ITI Poonch', division: 'Jammu Division', district: 'Poonch', location: 'Poonch Town, J&K' },
  { sNo: 38, name: 'Govt. ITI Mendhar', division: 'Jammu Division', district: 'Poonch', location: 'Mendhar, Poonch, J&K' },
  { sNo: 39, name: 'Govt. ITI Surankote', division: 'Jammu Division', district: 'Poonch', location: 'Surankote, Poonch, J&K' },
  { sNo: 40, name: 'Govt. ITI Samba', division: 'Jammu Division', district: 'Samba', location: 'Samba Town, J&K' },
  { sNo: 41, name: 'Govt. ITI Reasi', division: 'Jammu Division', district: 'Reasi', location: 'Reasi Town, J&K' },
  { sNo: 42, name: 'Govt. ITI Kathua', division: 'Jammu Division', district: 'Kathua', location: 'Govt. College Road, Kathua, J&K' },
  { sNo: 43, name: 'Govt. ITI Hiranagar', division: 'Jammu Division', district: 'Kathua', location: 'Hiranagar, Kathua, J&K' },
  { sNo: 44, name: 'Govt. ITI Bhaddu Billawar', division: 'Jammu Division', district: 'Kathua', location: 'Bhaddu, Billawar, Kathua, J&K' },
  { sNo: 45, name: 'Govt. ITI Basholi', division: 'Jammu Division', district: 'Kathua', location: 'Basohli (Basholi), Kathua, J&K' },
  { sNo: 46, name: 'Govt. ITI Bani', division: 'Jammu Division', district: 'Kathua', location: 'Bani, Kathua, J&K' },
  { sNo: 47, name: 'Govt. ITI Ramban', division: 'Jammu Division', district: 'Ramban', location: 'Ramban Town, J&K' },
  { sNo: 48, name: 'Govt. ITI Banihal', division: 'Jammu Division', district: 'Ramban', location: 'Banihal, Ramban, J&K' },
  { sNo: 49, name: 'Govt. ITI Gool', division: 'Jammu Division', district: 'Ramban', location: 'Gool, Ramban, J&K' },
  { sNo: 50, name: 'Govt. ITI Dharmari', division: 'Jammu Division', district: 'Reasi', location: 'Dharmari, Reasi, J&K' },
];

export const INITIAL_ITIS: { sNo: number; name: string; division: Division }[] = OFFICIAL_JK_ITIS.map((iti) => ({
  sNo: iti.sNo,
  name: iti.name,
  division: iti.division,
}));
