import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Enforce No-Cookie and No-Cache policy in client browser
if (typeof document !== 'undefined') {
  try {
    // Clear all existing cookies
    document.cookie.split(';').forEach((c) => {
      const eqPos = c.indexOf('=');
      const name = eqPos > -1 ? c.substring(0, eqPos).trim() : c.trim();
      if (name) {
        document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;SameSite=Strict`;
        document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=${window.location.hostname};SameSite=Strict`;
      }
    });
    // Prevent subsequent cookies from being set
    Object.defineProperty(document, 'cookie', {
      get: () => '',
      set: () => '',
      configurable: true,
    });
  } catch {}

  // Clear CacheStorage API if available
  if (typeof window !== 'undefined' && 'caches' in window) {
    window.caches.keys().then((names) => {
      names.forEach((name) => window.caches.delete(name));
    }).catch(() => {});
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
