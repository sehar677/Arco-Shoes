import React, { useState, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  TrainingCenter,
  Instructor,
  Scheme,
  Contribution,
  Notice,
  DatabaseBackup,
  DEFAULT_EMPLOYEE_TYPES,
} from '../../types';
import {
  updateTargetAmount,
  updateEmployeeTypes,
  clearAllDatabaseCollections,
  createNewAdminAccount,
  exportDatabaseBackup,
  restoreDatabaseFromBackup,
  refreshFirebaseConnection,
  updateInstructor,
} from '../../services/db';
import { ConfirmModal } from '../../components/ConfirmModal';
import { formatCurrency, formatNumber } from '../../utils/format';
import {
  Settings,
  Shield,
  Target,
  Database,
  RefreshCw,
  Trash2,
  UserPlus,
  Mail,
  KeyRound,
  Download,
  Upload,
  Copy,
  CheckCircle2,
  AlertTriangle,
  FileCode,
  FileJson,
  Check,
  HardDrive,
  Layers,
  Users,
  Building2,
  IndianRupee,
  Bell,
  X,
  Briefcase,
  Plus,
  RotateCcw,
  Pencil,
} from 'lucide-react';

interface AdminSettingsProps {
  targetAmount: number;
  employeeTypes?: string[];
  trainingCenters?: TrainingCenter[];
  instructors?: Instructor[];
  schemes?: Scheme[];
  contributions?: Contribution[];
  notices?: Notice[];
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const AdminSettings: React.FC<AdminSettingsProps> = ({
  targetAmount: targetAmountProp,
  employeeTypes: employeeTypesProp,
  trainingCenters: trainingCentersProp = [],
  instructors: instructorsProp = [],
  schemes: schemesProp = [],
  contributions: contributionsProp = [],
  notices: noticesProp = [],
  onNotify,
}) => {
  const trainingCenters = trainingCentersProp;
  const instructors = instructorsProp;
  const schemes = schemesProp;
  const contributions = contributionsProp;
  const notices = noticesProp;
  const targetAmount = targetAmountProp;

  const { currentUser, currentSessionId, sessionRemainingSeconds, extendSession } = useAuth();
  const [isClearing, setIsClearing] = useState(false);
  const [showClearModal, setShowClearModal] = useState(false);
  const [isRefreshingFirebase, setIsRefreshingFirebase] = useState(false);

  // Employee Types Configuration State
  const [employeeTypesList, setEmployeeTypesList] = useState<string[]>(
    employeeTypesProp && employeeTypesProp.length > 0 ? employeeTypesProp : DEFAULT_EMPLOYEE_TYPES
  );
  const [newEmployeeTypeInput, setNewEmployeeTypeInput] = useState('');
  const [isUpdatingEmployeeTypes, setIsUpdatingEmployeeTypes] = useState(false);
  const [typeToDelete, setTypeToDelete] = useState<string | null>(null);
  const [editingType, setEditingType] = useState<string | null>(null);
  const [editingTypeValue, setEditingTypeValue] = useState<string>('');

  // Keep employeeTypesList in sync when prop changes
  React.useEffect(() => {
    if (employeeTypesProp && employeeTypesProp.length > 0) {
      setEmployeeTypesList(employeeTypesProp);
    }
  }, [employeeTypesProp]);

  // Handle Start Editing
  const handleStartEditType = (currentType: string) => {
    setEditingType(currentType);
    setEditingTypeValue(currentType);
  };

  // Handle Cancel Editing
  const handleCancelEditType = () => {
    setEditingType(null);
    setEditingTypeValue('');
  };

  // Handle Save Edited Employee Type
  const handleSaveEditType = async (oldType: string) => {
    const trimmed = editingTypeValue.trim();
    if (!trimmed) {
      onNotify('error', 'Employee Type designation name cannot be empty.');
      return;
    }
    if (
      trimmed.toLowerCase() !== oldType.toLowerCase() &&
      employeeTypesList.some((t) => t.toLowerCase() === trimmed.toLowerCase())
    ) {
      onNotify('error', `Employee Type "${trimmed}" already exists in the list.`);
      return;
    }

    if (trimmed === oldType) {
      setEditingType(null);
      setEditingTypeValue('');
      return;
    }

    const updated = employeeTypesList.map((t) => (t === oldType ? trimmed : t));
    setEmployeeTypesList(updated);
    setIsUpdatingEmployeeTypes(true);

    try {
      await updateEmployeeTypes(updated);

      // Cascade update to any active instructors with this designation
      const affected = instructors.filter(
        (i) => (i.employeeType || 'Vocational Instructor').toLowerCase() === oldType.toLowerCase()
      );
      if (affected.length > 0) {
        for (const inst of affected) {
          try {
            await updateInstructor(inst.id, {
              ...inst,
              employeeType: trimmed,
              updatedAt: new Date().toISOString(),
            });
          } catch {
            // ignore individual sync issue
          }
        }
      }

      onNotify('success', `Updated Employee Type from "${oldType}" to "${trimmed}".`);
      setEditingType(null);
      setEditingTypeValue('');
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to update Employee Type.');
    } finally {
      setIsUpdatingEmployeeTypes(false);
    }
  };

  // Handle Add Employee Type
  const handleAddEmployeeType = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newEmployeeTypeInput.trim();
    if (!trimmed) {
      onNotify('error', 'Please enter a name for the Employee Type.');
      return;
    }
    if (employeeTypesList.some((t) => t.toLowerCase() === trimmed.toLowerCase())) {
      onNotify('error', `Employee Type "${trimmed}" already exists in the list.`);
      return;
    }

    const updated = [...employeeTypesList, trimmed];
    setEmployeeTypesList(updated);
    setNewEmployeeTypeInput('');
    setIsUpdatingEmployeeTypes(true);

    try {
      await updateEmployeeTypes(updated);
      onNotify('success', `Added "${trimmed}" to the Employee Type dropdown list.`);
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to save Employee Type.');
    } finally {
      setIsUpdatingEmployeeTypes(false);
    }
  };

  // Handle Delete Employee Type
  const handleDeleteEmployeeType = async (typeName: string) => {
    if (employeeTypesList.length <= 1) {
      onNotify('error', 'Cannot delete the last remaining Employee Type. At least one type must exist.');
      return;
    }

    const updated = employeeTypesList.filter((t) => t !== typeName);
    setEmployeeTypesList(updated);
    setIsUpdatingEmployeeTypes(true);

    try {
      await updateEmployeeTypes(updated);
      onNotify('success', `Removed "${typeName}" from the Employee Type dropdown list.`);
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to delete Employee Type.');
    } finally {
      setIsUpdatingEmployeeTypes(false);
      setTypeToDelete(null);
    }
  };

  // Handle Reset to Default Employee Types
  const handleResetDefaultTypes = async () => {
    setEmployeeTypesList([...DEFAULT_EMPLOYEE_TYPES]);
    setIsUpdatingEmployeeTypes(true);

    try {
      await updateEmployeeTypes([...DEFAULT_EMPLOYEE_TYPES]);
      onNotify('success', 'Reset Employee Types list to standard official ITI designations.');
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to reset Employee Types.');
    } finally {
      setIsUpdatingEmployeeTypes(false);
    }
  };

  // Backup & Restore State
  const [isExporting, setIsExporting] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [copiedBackup, setCopiedBackup] = useState(false);
  const [uploadedBackup, setUploadedBackup] = useState<DatabaseBackup | null>(null);
  const [pasteJson, setPasteJson] = useState('');
  const [showRestoreModal, setShowRestoreModal] = useState(false);
  const [jsonParseError, setJsonParseError] = useState<string | null>(null);
  const [isDraggingFile, setIsDraggingFile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Add new admin state
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminPassword, setNewAdminPassword] = useState('');
  const [isCreatingAdmin, setIsCreatingAdmin] = useState(false);

  const handleRefreshFirebase = async () => {
    setIsRefreshingFirebase(true);
    try {
      const res = await refreshFirebaseConnection();
      if (res.connected) {
        onNotify(
          'success',
          `Successfully connected to Firebase Firestore! Refreshed: ${res.counts.trainingCenters || 0} ITIs, ${res.counts.instructors || 0} Instructors, ${res.counts.schemes || 0} Schemes, ${res.counts.contributions || 0} Contributions, ${res.counts.notices || 0} Notices.`
        );
      } else {
        onNotify('error', res.error || 'Failed to connect to Firebase database.');
      }
    } catch (err: any) {
      onNotify('error', err.message || 'Error connecting to Firebase database.');
    } finally {
      setIsRefreshingFirebase(false);
    }
  };

  const handleCreateAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminEmail || !newAdminPassword) {
      onNotify('error', 'Please provide both email and password for the new admin.');
      return;
    }
    if (newAdminPassword.length < 6) {
      onNotify('error', 'Password must be at least 6 characters long.');
      return;
    }

    setIsCreatingAdmin(true);
    try {
      await createNewAdminAccount(newAdminEmail.trim(), newAdminPassword);
      onNotify('success', `Successfully created new administrator account for "${newAdminEmail}".`);
      setNewAdminEmail('');
      setNewAdminPassword('');
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to create administrator account.');
    } finally {
      setIsCreatingAdmin(false);
    }
  };

  const handleConfirmClear = async () => {
    setShowClearModal(false);
    setIsClearing(true);
    try {
      const res = await clearAllDatabaseCollections();
      if (res.cleared) {
        onNotify('success', 'All database records have been deleted. Database is now completely empty.');
      } else {
        onNotify('error', res.error || 'Failed to clear database.');
      }
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to clear database.');
    } finally {
      setIsClearing(false);
    }
  };

  // ========================
  // BACKUP & RESTORE HANDLERS
  // ========================

  const handleDownloadBackup = async () => {
    setIsExporting(true);
    try {
      const backup = await exportDatabaseBackup({
        trainingCenters,
        instructors,
        schemes,
        contributions,
        notices,
        targetAmount,
      });

      const jsonStr = JSON.stringify(backup, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const now = new Date();
      const dateStr = now.toISOString().split('T')[0];
      const timeStr = `${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}`;
      const filename = `jk_iti_database_backup_${dateStr}_${timeStr}.json`;

      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      onNotify(
        'success',
        `Database backup successfully generated and downloaded (${backup.metadata.trainingCentersCount} ITIs, ${backup.metadata.instructorsCount} Instructors, ${backup.metadata.contributionsCount} Contributions).`
      );
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to generate database backup.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleCopyBackup = async () => {
    setIsExporting(true);
    try {
      const backup = await exportDatabaseBackup({
        trainingCenters,
        instructors,
        schemes,
        contributions,
        notices,
        targetAmount,
      });
      const jsonStr = JSON.stringify(backup, null, 2);
      await navigator.clipboard.writeText(jsonStr);
      setCopiedBackup(true);
      setTimeout(() => setCopiedBackup(false), 3000);
      onNotify('success', 'Database JSON backup copied to clipboard.');
    } catch (err: any) {
      onNotify('error', 'Failed to copy backup to clipboard.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownloadTemplate = () => {
    try {
      const template = {
        version: '2.0',
        exportedAt: new Date().toISOString(),
        portal: "J&K ITI Employee's United Front",
        metadata: {
          trainingCentersCount: trainingCentersProp.length,
          instructorsCount: instructorsProp.length,
          schemesCount: schemesProp.length,
          contributionsCount: contributionsProp.length,
          noticesCount: noticesProp.length,
          targetAmount: targetAmountProp || 0,
        },
        data: {
          trainingCenters: trainingCentersProp,
          instructors: instructorsProp,
          schemes: schemesProp,
          contributions: contributionsProp,
          notices: noticesProp,
          targetAmount: targetAmountProp || 0,
        },
      };
      const blob = new Blob([JSON.stringify(template, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `SAMPLE_TEMPLATE_BACKUP_${new Date().toISOString().slice(0, 10)}.json`;
      link.click();
      URL.revokeObjectURL(url);
      onNotify('success', 'Sample backup JSON template downloaded.');
    } catch {
      onNotify('error', 'Failed to generate sample template.');
    }
  };

  const toArrayHelper = (val: any): any[] => {
    if (!val) return [];
    if (Array.isArray(val)) return val;
    if (typeof val === 'object') {
      return Object.keys(val).map((k) => {
        const item = val[k];
        return typeof item === 'object' && item !== null ? { ...item, id: item.id || k } : item;
      });
    }
    return [];
  };

  const extractArrayByKeywords = (source: any, keywords: string[]): any[] => {
    if (!source || typeof source !== 'object') return [];
    for (const k of keywords) {
      if (source[k] !== undefined) {
        const arr = toArrayHelper(source[k]);
        if (arr.length > 0) return arr;
      }
    }
    const keys = Object.keys(source);
    for (const k of keywords) {
      const norm = k.toLowerCase().replace(/[^a-z0-9]/g, '');
      const found = keys.find((key) => key.toLowerCase().replace(/[^a-z0-9]/g, '') === norm);
      if (found && source[found] !== undefined) {
        const arr = toArrayHelper(source[found]);
        if (arr.length > 0) return arr;
      }
    }
    return [];
  };

  const validateAndSetBackupJson = (text: string) => {
    setJsonParseError(null);
    try {
      if (!text || !text.trim()) {
        setUploadedBackup(null);
        return;
      }

      let cleanText = text.trim();
      // Remove UTF-8 Byte Order Mark
      if (cleanText.charCodeAt(0) === 0xfeff) {
        cleanText = cleanText.slice(1).trim();
      }
      // Strip markdown code fences ```json ... ```
      if (cleanText.startsWith('```')) {
        cleanText = cleanText.replace(/^```[a-zA-Z0-9_-]*\s*/i, '').replace(/\s*```$/, '').trim();
      }

      let parsed: any;
      try {
        parsed = JSON.parse(cleanText);
      } catch (parseErr: any) {
        // Attempt removing trailing commas (e.g. [1, 2, ] or {"a": 1, })
        try {
          const noTrailingCommas = cleanText.replace(/,\s*([\]}])/g, '$1');
          parsed = JSON.parse(noTrailingCommas);
        } catch {
          // Attempt parsing newline-delimited JSON (NDJSON)
          const lines = cleanText.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
          if (lines.length > 1) {
            const ndItems: any[] = [];
            for (const line of lines) {
              try {
                ndItems.push(JSON.parse(line));
              } catch {}
            }
            if (ndItems.length > 0) {
              parsed = ndItems;
            }
          }
          if (!parsed) {
            throw new Error(`Invalid JSON format: ${parseErr.message}. Please ensure the file contains valid JSON.`);
          }
        }
      }

      if (!parsed || (typeof parsed !== 'object' && !Array.isArray(parsed))) {
        throw new Error('Provided content is not a valid JSON object or array.');
      }

      let parsedTC: any[] = [];
      let parsedInst: any[] = [];
      let parsedSchemes: any[] = [];
      let parsedContribs: any[] = [];
      let parsedNotices: any[] = [];
      let parsedTarget = 0;

      if (Array.isArray(parsed)) {
        parsed.forEach((item: any) => {
          if (!item || typeof item !== 'object') return;
          const colType = (item.collection || item._collection || item.type || item.entityType || '').toLowerCase();
          if (colType.includes('tc') || colType.includes('center') || colType.includes('iti')) {
            parsedTC.push(item);
          } else if (colType.includes('inst') || colType.includes('teach') || colType.includes('member')) {
            parsedInst.push(item);
          } else if (colType.includes('sch') || colType.includes('welfare')) {
            parsedSchemes.push(item);
          } else if (colType.includes('contrib') || colType.includes('donat') || colType.includes('fund')) {
            parsedContribs.push(item);
          } else if (colType.includes('notice') || colType.includes('announc') || colType.includes('event')) {
            parsedNotices.push(item);
          } else if (item.trade || item.registrationNo || item.designation || item.fatherName || item.dob) {
            parsedInst.push(item);
          } else if (item.district || item.division || item.itiCode || item.code || (item.name && item.name.includes('ITI'))) {
            parsedTC.push(item);
          } else if (item.amount || item.donorName || item.transactionId || item.utrNumber) {
            parsedContribs.push(item);
          } else if (item.title && (item.content || item.publishedDate || item.date)) {
            parsedNotices.push(item);
          } else if (item.schemeName || item.coverageDetails) {
            parsedSchemes.push(item);
          } else {
            parsedInst.push(item);
          }
        });
      } else {
        const sourceData = parsed.data || parsed.backup || parsed.records || parsed;

        parsedTC = extractArrayByKeywords(sourceData, [
          'trainingCenters',
          'training_centers',
          'TrainingCenters',
          'trainingcenters',
          'itis',
          'ITIs',
          'iti',
          'centers',
          'institutes',
        ]);
        if (parsedTC.length === 0 && sourceData !== parsed) {
          parsedTC = extractArrayByKeywords(parsed, [
            'trainingCenters',
            'training_centers',
            'TrainingCenters',
            'itis',
            'ITIs',
            'centers',
          ]);
        }

        parsedInst = extractArrayByKeywords(sourceData, [
          'instructors',
          'Instructors',
          'instructor',
          'vocationalInstructors',
          'members',
          'staff',
          'teachers',
          'users',
          'employees',
          'records',
        ]);
        if (parsedInst.length === 0 && sourceData !== parsed) {
          parsedInst = extractArrayByKeywords(parsed, [
            'instructors',
            'Instructors',
            'instructor',
            'members',
            'staff',
            'teachers',
            'users',
          ]);
        }

        parsedSchemes = extractArrayByKeywords(sourceData, [
          'schemes',
          'Schemes',
          'welfareSchemes',
          'welfare_schemes',
          'welfare',
          'benefits',
        ]);
        if (parsedSchemes.length === 0 && sourceData !== parsed) {
          parsedSchemes = extractArrayByKeywords(parsed, ['schemes', 'Schemes', 'welfareSchemes', 'welfare']);
        }

        parsedContribs = extractArrayByKeywords(sourceData, [
          'contributions',
          'Contributions',
          'funds',
          'donations',
          'payments',
          'transactions',
        ]);
        if (parsedContribs.length === 0 && sourceData !== parsed) {
          parsedContribs = extractArrayByKeywords(parsed, ['contributions', 'Contributions', 'funds', 'donations']);
        }

        parsedNotices = extractArrayByKeywords(sourceData, [
          'notices',
          'Notices',
          'announcements',
          'circulars',
          'events',
          'news',
        ]);
        if (parsedNotices.length === 0 && sourceData !== parsed) {
          parsedNotices = extractArrayByKeywords(parsed, ['notices', 'Notices', 'announcements', 'events']);
        }

        parsedTarget = sourceData.targetAmount ?? parsed.targetAmount ?? (parsed.metadata?.targetAmount ?? 0);
      }

      // Check if at least one item was parsed
      if (
        parsedTC.length === 0 &&
        parsedInst.length === 0 &&
        parsedSchemes.length === 0 &&
        parsedContribs.length === 0 &&
        parsedNotices.length === 0
      ) {
        throw new Error('No recognisable database records found in the provided JSON file. Please verify the JSON structure.');
      }

      // If partial backup is provided (e.g. user imported an instructor roster or ITI list only),
      // preserve existing active records for the other collections to prevent unintended loss
      const effectiveTC = parsedTC.length > 0 ? parsedTC : trainingCentersProp;
      const effectiveInst = parsedInst.length > 0 ? parsedInst : instructorsProp;
      const effectiveSchemes = parsedSchemes.length > 0 ? parsedSchemes : schemesProp;
      const effectiveContribs = parsedContribs.length > 0 ? parsedContribs : contributionsProp;
      const effectiveNotices = parsedNotices.length > 0 ? parsedNotices : noticesProp;

      // Standardize format
      const normalizedBackup: DatabaseBackup = {
        version: parsed.version || '2.0',
        exportedAt: parsed.exportedAt || new Date().toISOString(),
        portal: parsed.portal || "J&K ITI Employee's United Front",
        metadata: {
          trainingCentersCount: effectiveTC.length,
          instructorsCount: effectiveInst.length,
          schemesCount: effectiveSchemes.length,
          contributionsCount: effectiveContribs.length,
          noticesCount: effectiveNotices.length,
          targetAmount: Number(parsedTarget) || targetAmountProp || 0,
        },
        data: {
          trainingCenters: effectiveTC,
          instructors: effectiveInst,
          schemes: effectiveSchemes,
          contributions: effectiveContribs,
          notices: effectiveNotices,
          targetAmount: Number(parsedTarget) || targetAmountProp || 0,
        },
      };

      setUploadedBackup(normalizedBackup);
    } catch (err: any) {
      setUploadedBackup(null);
      setJsonParseError(err.message || 'Invalid JSON format');
    }
  };

  const handleFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = (e.target?.result as string) || '';
      setPasteJson(content);
      validateAndSetBackupJson(content);
    };
    reader.onerror = () => {
      onNotify('error', 'Failed to read the selected backup file.');
    };
    reader.readAsText(file);
  };

  const handleConfirmRestore = async () => {
    if (!uploadedBackup) {
      onNotify('error', 'No valid backup selected for restoration.');
      return;
    }

    setIsRestoring(true);
    try {
      const result = await restoreDatabaseFromBackup(uploadedBackup);
      if (result.success) {
        setShowRestoreModal(false);
        onNotify(
          'success',
          `Database successfully restored! (${result.counts.instructors || 0} instructors, ${result.counts.trainingCenters || 0} ITIs, ${result.counts.contributions || 0} contributions, ${result.counts.schemes || 0} schemes, ${result.counts.notices || 0} notices synchronized).`
        );
        setUploadedBackup(null);
        setPasteJson('');
      } else {
        onNotify('error', result.error || 'Failed to restore database.');
      }
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to restore database.');
    } finally {
      setIsRestoring(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <h2 className="text-lg font-black text-[#0F2942] uppercase tracking-wide">
          SYSTEM SETTINGS &amp; ADMINISTRATIVE CONFIGURATION
        </h2>
        <p className="text-xs text-slate-500">
          Manage Employee Types, database backup and restoration, administrator credentials, and master records.
        </p>
      </div>

      {/* EMPLOYEE TYPE FIELD LIST CONFIGURATION (Added / Deleted from settings & SYNC) */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5 text-[#0F2942]">
            <div className="w-9 h-9 rounded-lg bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-700">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black uppercase tracking-wide text-slate-900 flex items-center gap-2">
                <span>EMPLOYEE TYPE DROPDOWN LIST CONFIGURATION</span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                  {employeeTypesList.length} Types
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                Manage the designations available in the 'Employee Type' dropdown list when adding or editing Skill Development Employees.
              </p>
            </div>
          </div>

          <button
            type="button"
            id="admin-reset-default-employee-types-btn"
            disabled={isUpdatingEmployeeTypes}
            onClick={handleResetDefaultTypes}
            className="px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs uppercase tracking-wider transition-colors flex items-center gap-1.5 self-start sm:self-auto cursor-pointer shadow-2xs disabled:opacity-50"
            title="Reset to official default designations"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
            <span>Reset Defaults</span>
          </button>
        </div>

        {/* Add New Employee Type Form */}
        <form onSubmit={handleAddEmployeeType} className="space-y-2">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
            Add New Employee Type Designation:
          </label>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            <div className="relative flex-1">
              <Briefcase className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                id="admin-new-employee-type-input"
                required
                value={newEmployeeTypeInput}
                onChange={(e) => setNewEmployeeTypeInput(e.target.value)}
                placeholder="e.g. Workshop Instructor, Vocational Instructor, Group Instructor..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-medium focus:bg-white focus:outline-hidden"
              />
            </div>
            <button
              type="submit"
              id="admin-add-employee-type-btn"
              disabled={isUpdatingEmployeeTypes || !newEmployeeTypeInput.trim()}
              className="px-5 py-2 rounded-lg bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 shadow-xs disabled:opacity-50 cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>{isUpdatingEmployeeTypes ? 'Saving...' : 'ADD EMPLOYEE TYPE'}</span>
            </button>
          </div>
          <p className="text-[11px] text-slate-500">
            New employee types added here are immediately saved to database settings and available in the 'ADD SKILL DEVELOPMENT EMPLOYEEE' registration modal.
          </p>
        </form>

        {/* Configured Employee Types List / Badges */}
        <div className="space-y-2 pt-1">
          <div className="flex items-center justify-between text-xs text-slate-600 font-semibold">
            <span>Currently Configured Types ({employeeTypesList.length}):</span>
            <span className="text-[11px] text-slate-500 italic">Use edit icon to rename or delete icon to remove</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {employeeTypesList.map((type, idx) => {
              const assignedCount = instructors.filter(
                (i) => (i.employeeType || 'Vocational Instructor').toLowerCase() === type.toLowerCase()
              ).length;
              const isEditing = editingType === type;

              return (
                <div
                  key={type}
                  className={`p-2.5 rounded-lg border transition-all ${
                    isEditing
                      ? 'bg-amber-50/70 border-amber-300 ring-2 ring-amber-400/50 shadow-sm'
                      : 'bg-slate-50 border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/30 group'
                  }`}
                >
                  {isEditing ? (
                    <div className="space-y-2">
                      <div className="flex items-center gap-1.5">
                        <input
                          type="text"
                          id={`admin-edit-employee-type-input-${idx}`}
                          value={editingTypeValue}
                          onChange={(e) => setEditingTypeValue(e.target.value)}
                          className="w-full px-2.5 py-1 text-xs bg-white border border-indigo-400 rounded-md font-semibold text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                          autoFocus
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleSaveEditType(type);
                            } else if (e.key === 'Escape') {
                              handleCancelEditType();
                            }
                          }}
                        />
                      </div>
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="text-slate-500">
                          {assignedCount} {assignedCount === 1 ? 'employee' : 'employees'} will sync
                        </span>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={handleCancelEditType}
                            className="px-2 py-0.5 rounded bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold cursor-pointer"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSaveEditType(type)}
                            disabled={isUpdatingEmployeeTypes || !editingTypeValue.trim()}
                            className="px-2.5 py-0.5 rounded bg-indigo-700 hover:bg-indigo-800 text-white font-bold disabled:opacity-50 cursor-pointer"
                          >
                            {isUpdatingEmployeeTypes ? 'Saving...' : 'Save'}
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 min-w-0 pr-2">
                        <span className="w-6 h-6 rounded-md bg-white border border-slate-200 flex items-center justify-center text-[10px] font-bold text-slate-500 shrink-0">
                          {idx + 1}
                        </span>
                        <div className="min-w-0">
                          <span className="text-xs font-bold text-slate-900 block truncate" title={type}>
                            {type}
                          </span>
                          <span className="text-[10px] text-slate-500 font-medium">
                            {assignedCount} {assignedCount === 1 ? 'employee' : 'employees'}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-0.5 shrink-0">
                        {/* Edit Action Icon */}
                        <button
                          type="button"
                          id={`admin-edit-employee-type-${idx}`}
                          disabled={isUpdatingEmployeeTypes}
                          onClick={() => handleStartEditType(type)}
                          className="p-1.5 rounded-md text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors cursor-pointer shrink-0 disabled:opacity-30"
                          title={`Edit "${type}"`}
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>

                        {/* Delete Action Icon */}
                        <button
                          type="button"
                          id={`admin-delete-employee-type-${idx}`}
                          disabled={isUpdatingEmployeeTypes || employeeTypesList.length <= 1}
                          onClick={() => {
                            if (assignedCount > 0) {
                              if (
                                confirm(
                                  `Notice: ${assignedCount} existing employee(s) currently have "${type}" as their type. Are you sure you want to remove it from the dropdown list?`
                                )
                              ) {
                                handleDeleteEmployeeType(type);
                              }
                            } else {
                              handleDeleteEmployeeType(type);
                            }
                          }}
                          className="p-1.5 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer shrink-0 disabled:opacity-30"
                          title={employeeTypesList.length <= 1 ? 'Cannot delete the only remaining type' : `Delete "${type}"`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* DATABASE BACKUP & RESTORE SECTION */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5 text-[#0F2942]">
            <div className="w-9 h-9 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700">
              <HardDrive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black uppercase tracking-wide text-slate-900">
                DATABASE BACKUP &amp; RESTORE CONTROLS
              </h3>
              <p className="text-xs text-slate-500">
                Export complete snapshots of all records (ITIs, Skill Development Employees, Schemes, Contributions, Notices) and restore anytime.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              id="admin-refresh-firebase-header-btn"
              disabled={isRefreshingFirebase}
              onClick={handleRefreshFirebase}
              className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs uppercase tracking-wider transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer disabled:opacity-50"
              title="Refresh & Connect Firebase Database"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingFirebase ? 'animate-spin' : ''}`} />
              <span>{isRefreshingFirebase ? 'Connecting...' : 'REFRESH FIREBASE DATABASE'}</span>
            </button>
            <span className="hidden sm:inline-flex px-2.5 py-1.5 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold text-[11px] items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Live Sync Active</span>
            </span>
          </div>
        </div>

        {/* Current Database Summary Chips */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5 text-xs">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Training Centers</span>
            <span className="text-base font-black text-slate-900 mt-0.5 block">{trainingCenters.length}</span>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Instructors</span>
            <span className="text-base font-black text-indigo-700 mt-0.5 block">{instructors.length}</span>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Pending Review</span>
            <span className="text-base font-black text-amber-600 mt-0.5 block">
              {instructors.filter((i) => i.approvalStatus?.toLowerCase().includes('pending')).length}
            </span>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Schemes</span>
            <span className="text-base font-black text-slate-900 mt-0.5 block">{schemes.length}</span>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Contributions</span>
            <span className="text-base font-black text-emerald-700 mt-0.5 block">{contributions.length}</span>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Notices</span>
            <span className="text-base font-black text-slate-900 mt-0.5 block">{notices.length}</span>
          </div>
        </div>

        {/* Two-Column Grid: Backup Left, Restore Right */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          {/* Option A: Backup Database */}
          <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center gap-2 text-indigo-900 font-bold text-xs uppercase tracking-wider mb-1.5">
                <Download className="w-4 h-4 text-indigo-600" />
                <span>1. Export Database Backup</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Generate a complete, self-contained JSON backup file containing all 50 ITI records, registered skill development employees, contributions, and active schemes.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-2">
              <button
                type="button"
                id="admin-download-backup-btn"
                disabled={isExporting}
                onClick={handleDownloadBackup}
                className="px-4 py-2.5 rounded-lg bg-[#0F2942] hover:bg-[#16385a] text-amber-400 font-bold text-xs uppercase tracking-wider transition-colors flex items-center gap-2 shadow-xs disabled:opacity-50 cursor-pointer"
              >
                <Download className={`w-4 h-4 ${isExporting ? 'animate-bounce' : ''}`} />
                <span>{isExporting ? 'Generating...' : 'DOWNLOAD BACKUP FILE (.JSON)'}</span>
              </button>

              <button
                type="button"
                id="admin-copy-backup-btn"
                disabled={isExporting}
                onClick={handleCopyBackup}
                className="px-3.5 py-2.5 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
                title="Copy JSON to Clipboard"
              >
                {copiedBackup ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span className="text-emerald-700">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-slate-500" />
                    <span>Copy JSON</span>
                  </>
                )}
              </button>

              <button
                type="button"
                id="admin-download-template-btn"
                onClick={handleDownloadTemplate}
                className="px-3.5 py-2.5 rounded-lg bg-white hover:bg-slate-100 text-indigo-700 border border-indigo-200 font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
                title="Download Sample JSON Format"
              >
                <FileJson className="w-4 h-4 text-indigo-600" />
                <span>Sample Format (.json)</span>
              </button>
            </div>
          </div>

          {/* Option B: Restore Database */}
          <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center gap-2 text-emerald-900 font-bold text-xs uppercase tracking-wider mb-1.5">
                <Upload className="w-4 h-4 text-emerald-600" />
                <span>2. Restore Database From Backup</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Upload a previously saved <code className="font-mono text-indigo-700 bg-indigo-50 px-1 rounded">.json</code> backup file or paste its JSON code to restore your system data.
              </p>
            </div>

            {/* File Dropzone */}
            <div>
              <input
                type="file"
                ref={fileInputRef}
                accept=".json,.JSON,.txt,text/plain,application/json"
                onClick={(e) => {
                  (e.target as HTMLInputElement).value = '';
                }}
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFileUpload(file);
                }}
                className="hidden"
                id="admin-restore-file-input"
              />

              <div
                onClick={() => fileInputRef.current?.click()}
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDraggingFile(true);
                }}
                onDragLeave={() => setIsDraggingFile(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDraggingFile(false);
                  const file = e.dataTransfer.files?.[0];
                  if (file) handleFileUpload(file);
                }}
                className={`border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors ${
                  isDraggingFile
                    ? 'border-indigo-500 bg-indigo-50/50'
                    : 'border-slate-300 hover:border-slate-400 bg-white'
                }`}
              >
                <Upload className="w-6 h-6 text-slate-400 mx-auto mb-1.5" />
                <span className="text-xs font-bold text-slate-700 block">
                  Click to Browse or Drag &amp; Drop Backup File
                </span>
                <span className="text-[10px] text-slate-400">Supports .json backup files</span>
              </div>
            </div>
          </div>
        </div>

        {/* Direct JSON Paste Area (Collapsible / Optional) */}
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <label className="block text-[11px] font-bold text-slate-700 uppercase">
            Or Paste JSON Backup Content Directly:
          </label>
          <textarea
            id="admin-restore-json-textarea"
            rows={3}
            value={pasteJson}
            onChange={(e) => {
              setPasteJson(e.target.value);
              validateAndSetBackupJson(e.target.value);
            }}
            placeholder='Paste {"version": "2.0", "data": { ... }} backup JSON string here...'
            className="w-full p-2.5 font-mono text-[11px] bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden"
          />

          {jsonParseError && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{jsonParseError}</span>
            </div>
          )}
        </div>

        {/* Backup Validation Preview Card */}
        {uploadedBackup && (
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-300 space-y-3 animate-fadeIn">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-emerald-900 font-bold text-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Valid Database Backup Recognized</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setUploadedBackup(null);
                  setPasteJson('');
                }}
                className="p-1 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 text-[11px]">
              <div className="p-2 bg-white rounded border border-emerald-200 text-center">
                <span className="text-slate-500 block">ITIs</span>
                <strong className="text-slate-900 font-black">{uploadedBackup.metadata.trainingCentersCount}</strong>
              </div>
              <div className="p-2 bg-white rounded border border-emerald-200 text-center">
                <span className="text-slate-500 block">Instructors</span>
                <strong className="text-indigo-700 font-black">{uploadedBackup.metadata.instructorsCount}</strong>
              </div>
              <div className="p-2 bg-white rounded border border-emerald-200 text-center">
                <span className="text-slate-500 block">Schemes</span>
                <strong className="text-slate-900 font-black">{uploadedBackup.metadata.schemesCount}</strong>
              </div>
              <div className="p-2 bg-white rounded border border-emerald-200 text-center">
                <span className="text-slate-500 block">Contributions</span>
                <strong className="text-emerald-700 font-black">{uploadedBackup.metadata.contributionsCount}</strong>
              </div>
              <div className="p-2 bg-white rounded border border-emerald-200 text-center">
                <span className="text-slate-500 block">Notices</span>
                <strong className="text-slate-900 font-black">{uploadedBackup.metadata.noticesCount}</strong>
              </div>
              <div className="p-2 bg-white rounded border border-emerald-200 text-center">
                <span className="text-slate-500 block">Target</span>
                <strong className="text-slate-900 font-black">₹{formatNumber(uploadedBackup.metadata.targetAmount)}</strong>
              </div>
            </div>

            <div className="flex justify-end pt-1">
              <button
                type="button"
                id="admin-execute-restore-btn"
                onClick={() => setShowRestoreModal(true)}
                className="px-5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs uppercase tracking-wider transition-colors shadow-xs flex items-center gap-2 cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>CONFIRM &amp; RESTORE THIS BACKUP</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Administrator Profile Details & Single Active Session Policy */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
            <Shield className="w-5 h-5" />
            <h3 className="uppercase tracking-wide text-slate-900">
              Administrator Authentication &amp; Session Security
            </h3>
          </div>
          <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold font-mono">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Single Session Enforced</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-slate-500 block">Authenticated Admin:</span>
            <span className="font-mono font-bold text-slate-900 mt-1 block truncate">
              {currentUser?.email || 'Authenticated Administrator'}
            </span>
          </div>
          <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-slate-500 block">Single Active Session Rule:</span>
            <span className="font-bold text-indigo-700 mt-1 block">
              1 Login Per Account
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">New login invalidates previous sessions</span>
          </div>
          <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-slate-500 block">Inactivity Timeout:</span>
            <span className="font-bold text-amber-700 mt-1 block">
              2 Minutes (120 Seconds)
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">Resets on mouse/key interaction</span>
          </div>
          <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 flex flex-col justify-between">
            <div>
              <span className="text-slate-500 block">Active Session Token:</span>
              <span className="font-mono font-bold text-slate-700 mt-1 block text-[11px] truncate" title={currentSessionId || 'Active'}>
                {currentSessionId ? `${currentSessionId.substring(0, 18)}...` : 'Active'}
              </span>
            </div>
            <div className="mt-1 flex items-center justify-between">
              <span className="text-[11px] font-mono text-emerald-600 font-bold">
                {Math.floor(sessionRemainingSeconds / 60)}:{String(sessionRemainingSeconds % 60).padStart(2, '0')} remaining
              </span>
              <button
                type="button"
                onClick={extendSession}
                className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold underline cursor-pointer"
              >
                Reset Timer
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Add New Administrator (CPANEL Managed) */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2 text-[#0F2942] font-bold text-sm">
          <UserPlus className="w-5 h-5 text-amber-500" />
          <h3 className="uppercase tracking-wide text-slate-900">
            Add New Departmental Administrator
          </h3>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          Create new administrative credentials directly from the CPANEL. The newly added administrator will be able to log in securely with their email and password.
        </p>

        <form onSubmit={handleCreateAdmin} className="space-y-3 pt-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block text-slate-700 font-bold uppercase mb-1 text-[11px]">
                New Admin Email *
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  id="new-admin-email-input"
                  value={newAdminEmail}
                  onChange={(e) => setNewAdminEmail(e.target.value)}
                  placeholder="admin.name@jk.gov.in"
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden text-slate-900"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-bold uppercase mb-1 text-[11px]">
                New Admin Password *
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  id="new-admin-password-input"
                  value={newAdminPassword}
                  onChange={(e) => setNewAdminPassword(e.target.value)}
                  placeholder="Minimum 6 characters"
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden text-slate-900"
                />
              </div>
            </div>
          </div>

          <div className="pt-2 flex justify-start">
            <button
              type="submit"
              id="admin-create-new-user-btn"
              disabled={isCreatingAdmin}
              className="px-5 py-2 rounded-lg bg-[#0F2942] hover:bg-[#16385a] text-amber-400 font-bold text-xs uppercase tracking-wider transition-colors flex items-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>{isCreatingAdmin ? 'Creating Administrator...' : 'CREATE ADMINISTRATOR ACCOUNT'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Database Management Controls */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2 text-slate-800 font-bold text-sm">
          <Database className="w-5 h-5" />
          <h3 className="uppercase tracking-wide text-slate-900">
            Database Maintenance &amp; Reset Tools
          </h3>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          Default seed data is <strong>never</strong> automatically re-inserted once changes are made in the portal or in Firestore. You can manage maintenance tasks below:
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          {/* Refresh & Connect Firebase Database */}
          <button
            type="button"
            id="admin-refresh-firebase-btn"
            disabled={isRefreshingFirebase}
            onClick={handleRefreshFirebase}
            className="px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs uppercase tracking-wider transition-colors flex items-center gap-2 disabled:opacity-50 cursor-pointer shadow-xs"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshingFirebase ? 'animate-spin' : ''}`} />
            <span>{isRefreshingFirebase ? 'Connecting to Firebase...' : 'REFRESH FIREBASE DATABASE'}</span>
          </button>

          {/* Empty / Clear Database Button */}
          <button
            type="button"
            id="admin-clear-db-btn"
            disabled={isClearing}
            onClick={() => setShowClearModal(true)}
            className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs uppercase tracking-wider transition-colors flex items-center gap-2 disabled:opacity-50 cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
            <span>{isClearing ? 'Clearing Database...' : 'EMPTY / WIPE ENTIRE DATABASE'}</span>
          </button>
        </div>
      </div>

      {/* Restore Database Confirmation Modal */}
      {showRestoreModal && uploadedBackup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden animate-scaleUp">
            <div className="bg-[#0F2942] text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Upload className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-bold uppercase tracking-wide">
                  Confirm Database Restoration
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowRestoreModal(false)}
                className="p-1 text-slate-300 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-900 flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                <p className="text-[11px] leading-relaxed">
                  <strong>Warning:</strong> Restoring this backup will replace current records with the contents of the backup file across the portal, server storage, and Firestore database.
                </p>
              </div>

              <div className="space-y-2 bg-slate-50 p-3.5 rounded-lg border border-slate-200">
                <span className="font-bold text-slate-800 text-xs block">
                  Backup Summary to Apply:
                </span>
                <ul className="space-y-1.5 text-slate-600 text-[11px]">
                  <li className="flex justify-between">
                    <span>Exported Date:</span>
                    <strong className="text-slate-900">{new Date(uploadedBackup.exportedAt).toLocaleString('en-IN')}</strong>
                  </li>
                  <li className="flex justify-between">
                    <span>Training Centers:</span>
                    <strong className="text-slate-900">{uploadedBackup.metadata.trainingCentersCount} ITIs</strong>
                  </li>
                  <li className="flex justify-between">
                    <span>Skill Development Employees:</span>
                    <strong className="text-indigo-700">{uploadedBackup.metadata.instructorsCount} Employees</strong>
                  </li>
                  <li className="flex justify-between">
                    <span>Schemes:</span>
                    <strong className="text-slate-900">{uploadedBackup.metadata.schemesCount} Schemes</strong>
                  </li>
                  <li className="flex justify-between">
                    <span>Contributions:</span>
                    <strong className="text-emerald-700">{uploadedBackup.metadata.contributionsCount} Records</strong>
                  </li>
                  <li className="flex justify-between">
                    <span>Notices:</span>
                    <strong className="text-slate-900">{uploadedBackup.metadata.noticesCount} Notices</strong>
                  </li>
                  <li className="flex justify-between">
                    <span>Target Amount:</span>
                    <strong className="text-slate-900">{formatCurrency(uploadedBackup.metadata.targetAmount)}</strong>
                  </li>
                </ul>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowRestoreModal(false)}
                  className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  id="admin-confirm-restore-btn"
                  disabled={isRestoring}
                  onClick={handleConfirmRestore}
                  className="px-5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold transition-colors shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isRestoring ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Restoring Database...</span>
                    </>
                  ) : (
                    <span>Proceed &amp; Restore</span>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Empty Database Confirmation */}
      <ConfirmModal
        isOpen={showClearModal}
        title="Confirm Empty / Wipe Database"
        message="Are you sure you want to delete all training centers, instructors, schemes, contributions, and notices from Firestore? The database will be completely empty."
        confirmText="Yes, Empty Entire Database"
        cancelText="Cancel"
        isDanger={true}
        onConfirm={handleConfirmClear}
        onCancel={() => setShowClearModal(false)}
      />
    </div>
  );
};
