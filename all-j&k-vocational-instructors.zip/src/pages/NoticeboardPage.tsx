import React, { useState, useMemo } from 'react';
import { Notice } from '../types';
import { formatDate } from '../utils/format';
import {
  Bell,
  Search,
  Calendar,
  AlertCircle,
  FileText,
  User,
  ExternalLink,
  ChevronRight,
  Filter,
} from 'lucide-react';

interface NoticeboardPageProps {
  notices: Notice[];
  onSelectNotice: (notice: Notice) => void;
}

type FilterCategory = 'All' | 'Notice' | 'Circular' | 'Event' | 'Notification' | 'Meeting' | 'Important';

export const NoticeboardPage: React.FC<NoticeboardPageProps> = ({ notices, onSelectNotice }) => {
  const [activeCategory, setActiveCategory] = useState<FilterCategory>('All');
  const [searchTerm, setSearchTerm] = useState('');

  const categoryBadges: Record<string, string> = {
    Notice: 'bg-blue-100 text-blue-800 border-blue-200',
    Event: 'bg-purple-100 text-purple-800 border-purple-200',
    Notification: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    Circular: 'bg-amber-100 text-amber-800 border-amber-200',
    Meeting: 'bg-rose-100 text-rose-800 border-rose-200',
  };

  const filteredNotices = useMemo(() => {
    return notices
      .filter((n) => n.status === 'Published')
      .filter((n) => {
        const matchesSearch =
          n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          n.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (n.publishedBy && n.publishedBy.toLowerCase().includes(searchTerm.toLowerCase()));

        if (!matchesSearch) return false;

        if (activeCategory === 'All') return true;
        if (activeCategory === 'Important') return n.isImportant;
        return n.category === activeCategory;
      })
      .sort((a, b) => new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime());
  }, [notices, searchTerm, activeCategory]);

  return (
    <div className="space-y-8 pb-12">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-700"></span>
              <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
                Directorate of Skill Development • Jammu &amp; Kashmir
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-[#0F2942] uppercase tracking-tight">
              OFFICIAL NOTICEBOARD
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Departmental notifications, circulars, meeting notices and vocational events for all 50 J&amp;K ITIs
            </p>
          </div>

          <div className="bg-blue-50 border border-blue-200 px-5 py-3 rounded-lg text-center">
            <span className="block text-2xl font-black text-blue-950">
              {notices.filter((n) => n.status === 'Published').length}
            </span>
            <span className="text-[10px] uppercase font-bold text-blue-700 tracking-wider">
              Published Notices
            </span>
          </div>
        </div>

        {/* Filters and Search Bar */}
        <div className="mt-6 pt-6 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-lg text-xs font-bold">
            <button
              type="button"
              id="notice-tab-all"
              onClick={() => setActiveCategory('All')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeCategory === 'All'
                  ? 'bg-[#0F2942] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Notices
            </button>
            <button
              type="button"
              id="notice-tab-notices"
              onClick={() => setActiveCategory('Notice')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeCategory === 'Notice'
                  ? 'bg-blue-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-blue-900'
              }`}
            >
              Notices
            </button>
            <button
              type="button"
              id="notice-tab-circulars"
              onClick={() => setActiveCategory('Circular')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeCategory === 'Circular'
                  ? 'bg-amber-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-amber-800'
              }`}
            >
              Circulars
            </button>
            <button
              type="button"
              id="notice-tab-events"
              onClick={() => setActiveCategory('Event')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeCategory === 'Event'
                  ? 'bg-purple-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-purple-900'
              }`}
            >
              Events
            </button>
            <button
              type="button"
              id="notice-tab-notifications"
              onClick={() => setActiveCategory('Notification')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeCategory === 'Notification'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-emerald-900'
              }`}
            >
              Notifications
            </button>
            <button
              type="button"
              id="notice-tab-meetings"
              onClick={() => setActiveCategory('Meeting')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeCategory === 'Meeting'
                  ? 'bg-rose-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-rose-900'
              }`}
            >
              Meetings
            </button>
            <button
              type="button"
              id="notice-tab-important"
              onClick={() => setActiveCategory('Important')}
              className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-1 ${
                activeCategory === 'Important'
                  ? 'bg-rose-700 text-white shadow-xs'
                  : 'text-rose-700 hover:bg-rose-50'
              }`}
            >
              <AlertCircle className="w-3.5 h-3.5" />
              <span>Important</span>
            </button>
          </div>

          {/* Search */}
          <div className="relative min-w-[260px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="notice-search-input"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search circulars, events, meetings..."
              className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden text-slate-800"
            />
          </div>
        </div>
      </div>

      {/* Notices Card List */}
      <div className="space-y-4">
        {filteredNotices.length === 0 ? (
          <div className="bg-white rounded-xl border border-slate-200 p-12 text-center text-xs text-slate-500">
            No notices found for the selected category or search keywords.
          </div>
        ) : (
          filteredNotices.map((notice) => {
            return (
              <div
                key={notice.id}
                id={`notice-card-${notice.id}`}
                onClick={() => onSelectNotice(notice)}
                className="bg-white rounded-xl border border-slate-200 hover:border-blue-300 shadow-xs hover:shadow-md transition-all p-5 cursor-pointer group flex flex-col sm:flex-row items-start justify-between gap-4"
              >
                <div className="space-y-2 flex-1">
                  {/* Category, Date and Priority Badges */}
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase tracking-wider ${
                        categoryBadges[notice.category] || 'bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      {notice.category}
                    </span>

                    {notice.isImportant && (
                      <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-rose-600 text-white uppercase tracking-wider flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        Priority Notice
                      </span>
                    )}

                    <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {formatDate(notice.publishDate)}
                    </span>

                    {notice.eventDate && (
                      <span className="text-xs font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200 flex items-center gap-1 font-mono">
                        <Calendar className="w-3.5 h-3.5 text-purple-600" />
                        Event Scheduled: {formatDate(notice.eventDate)}
                      </span>
                    )}
                  </div>

                  {/* Notice Title */}
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 group-hover:text-blue-900 transition-colors leading-snug">
                    {notice.title}
                  </h3>

                  {/* Notice Snippet */}
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {notice.description}
                  </p>

                  {/* Issuer & Attachment info */}
                  <div className="flex flex-wrap items-center gap-4 pt-1 text-xs text-slate-500">
                    <span className="flex items-center gap-1 font-medium text-slate-700">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      {notice.publishedBy || 'Directorate of Skill Development J&K'}
                    </span>
                    {notice.attachmentUrl && (
                      <span className="flex items-center gap-1 text-blue-700 font-medium">
                        <FileText className="w-3.5 h-3.5" />
                        Attachment Available
                      </span>
                    )}
                  </div>
                </div>

                <div className="shrink-0 sm:self-center">
                  <div className="w-9 h-9 rounded-full bg-slate-100 group-hover:bg-blue-900 group-hover:text-white text-slate-600 flex items-center justify-center transition-colors">
                    <ChevronRight className="w-5 h-5" />
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
