import React from 'react';
import { Notice, ActivePage } from '../types';
import { formatDate } from '../utils/format';
import { Bell, ArrowRight, Calendar, AlertCircle } from 'lucide-react';

interface LatestNoticesProps {
  notices: Notice[];
  onNavigate: (page: ActivePage) => void;
  onSelectNotice?: (notice: Notice) => void;
}

export const LatestNotices: React.FC<LatestNoticesProps> = ({
  notices,
  onNavigate,
  onSelectNotice,
}) => {
  const publishedNotices = notices
    .filter((n) => n.status === 'Published')
    .slice(0, 4);

  const categoryColors: Record<string, string> = {
    Notice: 'bg-blue-100 text-blue-800 border-blue-200',
    Event: 'bg-purple-100 text-purple-800 border-purple-200',
    Notification: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    Circular: 'bg-amber-100 text-amber-800 border-amber-200',
    Meeting: 'bg-rose-100 text-rose-800 border-rose-200',
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
      <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-900 flex items-center justify-center">
            <Bell className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-extrabold text-[#0F2942] uppercase tracking-wide">
              LATEST NOTICES &amp; CIRCULARS
            </h3>
            <p className="text-xs text-slate-500">
              Departmental notifications, circulars and instructor meetings
            </p>
          </div>
        </div>

        <button
          type="button"
          id="view-all-notices-btn"
          onClick={() => onNavigate('noticeboard')}
          className="text-xs font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-md transition-colors"
        >
          <span>VIEW ALL NOTICES</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="divide-y divide-slate-100">
        {publishedNotices.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-500">
            No active notices published at this moment.
          </div>
        ) : (
          publishedNotices.map((n) => (
            <div
              key={n.id}
              className="p-4 hover:bg-slate-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer"
              onClick={() => {
                if (onSelectNotice) {
                  onSelectNotice(n);
                } else {
                  onNavigate('noticeboard');
                }
              }}
            >
              <div className="flex items-start gap-3">
                {n.isImportant && (
                  <span className="shrink-0 mt-0.5" title="High Priority / Important">
                    <AlertCircle className="w-4 h-4 text-rose-600 animate-pulse" />
                  </span>
                )}
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                        categoryColors[n.category] || 'bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      {n.category}
                    </span>
                    {n.isImportant && (
                      <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-rose-600 text-white tracking-wider uppercase">
                        Important
                      </span>
                    )}
                    <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                      <Calendar className="w-3 h-3" />
                      {formatDate(n.publishDate)}
                    </span>
                  </div>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900 hover:text-blue-900 transition-colors">
                    {n.title}
                  </h4>
                  <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">
                    {n.description}
                  </p>
                </div>
              </div>

              <div className="shrink-0 text-right sm:self-center">
                <span className="text-xs font-semibold text-blue-700 hover:underline inline-flex items-center gap-1">
                  Read notice &rarr;
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
