import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  where,
  writeBatch,
} from 'firebase/firestore';
import { initializeApp, getApps } from 'firebase/app';
import {
  getAuth as getSecondaryAuth,
  createUserWithEmailAndPassword,
  signOut as secondarySignOut,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import {
  TrainingCenter,
  Instructor,
  Scheme,
  Contribution,
  Notice,
  AppSetting,
  DatabaseBackup,
  AdminSession,
  OFFICIAL_JK_ITIS,
  DEFAULT_EMPLOYEE_TYPES,
} from '../types';

export const COLLECTIONS = {
  TRAINING_CENTERS: 'trainingCenters',
  INSTRUCTORS: 'instructors',
  SCHEMES: 'schemes',
  CONTRIBUTIONS: 'contributions',
  NOTICES: 'notices',
  SETTINGS: 'settings',
  ADMIN_SESSIONS: 'admin_sessions',
};

/**
 * Sanitizes object data before writing to Firestore, eliminating any undefined values.
 */
function sanitizeData<T extends Record<string, any>>(data: T): Record<string, any> {
  const result: Record<string, any> = {};
  for (const [key, value] of Object.entries(data)) {
    if (value !== undefined) {
      result[key] = value;
    }
  }
  return result;
}

export function toSafeDocId(rawId: any, fallbackPrefix: string, index: number): string {
  if (!rawId) {
    return `${fallbackPrefix}-${Date.now()}-${index}`;
  }
  // Replace anything that is not alphanumeric, hyphen, or underscore so it strictly passes Firestore rules
  const sanitized = String(rawId)
    .trim()
    .replace(/[^a-zA-Z0-9_\-]/g, '_')
    .slice(0, 120);
  return sanitized.length > 0 ? sanitized : `${fallbackPrefix}-${Date.now()}-${index}`;
}

export function deepSanitizeData(obj: any): any {
  if (obj === null || obj === undefined) return null;
  if (typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) {
    return obj.map(deepSanitizeData);
  }
  const res: Record<string, any> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined && typeof v !== 'function') {
      res[k] = typeof v === 'object' && v !== null ? deepSanitizeData(v) : v;
    }
  }
  return res;
}

/**
 * Non-blocking background sync runner
 */
function runBackgroundSync(task: () => Promise<any>, timeoutMs: number = 3000): void {
  try {
    Promise.race([
      task(),
      new Promise((resolve) => setTimeout(resolve, timeoutMs)),
    ]).catch((err) => {
      console.warn('Background sync note:', err);
    });
  } catch (err) {
    console.warn('Background sync dispatch note:', err);
  }
}

// Circuit breaker for Firestore quota exhaustion
let isFirestoreQuotaExhausted = false;

export function isQuotaExhausted(): boolean {
  return isFirestoreQuotaExhausted;
}

// ========================
// SEED & WIPE DATABASE UTILITIES
// ========================

/**
 * Wipes/clears all database collections in Firestore AND server backend storage,
 * leaving the database 100% clean with 0 records.
 */
export async function clearAllDatabaseCollections(): Promise<{ cleared: boolean; error?: string }> {
  try {
    // 1. Wipe server-side data files
    try {
      await fetch('/api/database/wipe-all', { method: 'POST' });
    } catch (apiErr) {
      console.warn('API wipe note:', apiErr);
    }

    // 2. Clear browser localStorage keys
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem('pending_instructor_registrations');
      localStorage.removeItem('tc_cache');
      localStorage.removeItem('schemes_cache');
      localStorage.removeItem('contributions_cache');
      localStorage.removeItem('notices_cache');
      try {
        localStorage.clear();
      } catch {}
    }

    // 3. Clear Firestore collections if connected
    if (!isFirestoreQuotaExhausted) {
      try {
        const collectionsToClear = [
          COLLECTIONS.TRAINING_CENTERS,
          COLLECTIONS.INSTRUCTORS,
          COLLECTIONS.SCHEMES,
          COLLECTIONS.CONTRIBUTIONS,
          COLLECTIONS.NOTICES,
        ];

        for (const colName of collectionsToClear) {
          const snap = await getDocs(collection(db, colName));
          if (!snap.empty) {
            const docs = snap.docs;
            for (let i = 0; i < docs.length; i += 400) {
              const chunk = docs.slice(i, i + 400);
              const batch = writeBatch(db);
              chunk.forEach((docSnap) => {
                batch.delete(docSnap.ref);
              });
              await batch.commit();
            }
          }
        }

        // Reset settings document
        const settingsDocRef = doc(db, COLLECTIONS.SETTINGS, 'general');
        await setDoc(settingsDocRef, {
          isSeeded: false,
          targetAmount: 0,
          appName: "J&K ITI EMPLOYEE'S UNITED FRONT",
          updatedAt: new Date().toISOString(),
        });
      } catch (fsErr) {
        console.warn('Firestore wipe collections note:', fsErr);
      }
    }

    // Reset all in-memory arrays and notify all subscribers immediately
    latestTrainingCenters = [];
    notifyTcSubscribers();

    latestFirestoreInstructors = [];
    saveLocalStoredInstructors([]);
    notifyInstructorSubscribers();

    latestSchemes = [];
    notifySchemesSubscribers();

    latestContributions = [];
    notifyContribSubscribers();

    latestNotices = [];
    notifyNoticesSubscribers();

    latestSettings = {
      id: 'general',
      targetAmount: 0,
      appName: "J&K ITI EMPLOYEE'S UNITED FRONT",
      isSeeded: false,
      updatedAt: new Date().toISOString(),
    };
    notifySettingsSubscribers();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('database_wiped'));
    }

    return { cleared: true };
  } catch (error) {
    console.error('Error clearing database:', error);
    return {
      cleared: false,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

/**
 * Never inserts default or mock entries.
 */
export async function seedInitialDatabase(force: boolean = false): Promise<{ seeded: boolean; reason?: string }> {
  return { seeded: true, reason: 'no_default_records' };
}

// ========================
// TRAINING CENTERS (ITIs)
// ========================

let latestTrainingCenters: TrainingCenter[] = [];
let tcSubscribers: Array<(itis: TrainingCenter[]) => void> = [];

function notifyTcSubscribers() {
  tcSubscribers.forEach((cb) => {
    try {
      cb(latestTrainingCenters);
    } catch (e) {
      console.error(e);
    }
  });
}

export function subscribeTrainingCenters(
  callback: (itis: TrainingCenter[]) => void,
  onError?: (err: unknown) => void
) {
  tcSubscribers.push(callback);
  callback(latestTrainingCenters);

  // 1. Initial bootstrap from server
  const fetchFromServer = async () => {
    try {
      const res = await fetch('/api/training-centers');
      if (res.ok) {
        const data: TrainingCenter[] = await res.json();
        if (Array.isArray(data)) {
          if (latestTrainingCenters.length === 0 && data.length > 0) {
            latestTrainingCenters = data;
            callback(data);
          }
        }
      }
    } catch {
      // Ignore
    }
  };

  fetchFromServer();

  // 2. Firestore onSnapshot (real-time stream)
  let unsubFirestore = () => {};
  if (!isFirestoreQuotaExhausted) {
    try {
      const q = query(collection(db, COLLECTIONS.TRAINING_CENTERS), orderBy('sNo', 'asc'));
      unsubFirestore = onSnapshot(
        q,
        (snapshot) => {
          const items: TrainingCenter[] = [];
          snapshot.forEach((docSnap) => {
            items.push({ ...(docSnap.data() as TrainingCenter), id: docSnap.id });
          });
          latestTrainingCenters = items;
          callback(items);
        },
        (error: any) => {
          if (
            error?.code === 'resource-exhausted' ||
            (error?.message && error.message.includes('Quota exceeded'))
          ) {
            isFirestoreQuotaExhausted = true;
          }
          if (onError) onError(error);
        }
      );
    } catch (err) {
      console.warn('Firestore TC subscribe note:', err);
    }
  }

  return () => {
    tcSubscribers = tcSubscribers.filter((cb) => cb !== callback);
    unsubFirestore();
  };
}

export async function addTrainingCenter(iti: Omit<TrainingCenter, 'id'>): Promise<string> {
  const id = `iti-${iti.sNo || Date.now()}`;
  const now = new Date().toISOString();
  const data: TrainingCenter = { ...iti, id, createdAt: now, updatedAt: now };

  latestTrainingCenters.push(data);
  latestTrainingCenters.sort((a, b) => (a.sNo || 0) - (b.sNo || 0));
  notifyTcSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch('/api/training-centers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    } catch (err) {
      console.warn('API add TC note:', err);
    }

    try {
      const ref = doc(db, COLLECTIONS.TRAINING_CENTERS, id);
      await setDoc(ref, sanitizeData(data));
    } catch (err) {
      console.warn('Firestore add TC note:', err);
    }
  });

  return id;
}

export async function batchAddTrainingCenters(itis: Omit<TrainingCenter, 'id'>[]): Promise<number> {
  const now = new Date().toISOString();
  let count = 0;
  const newItems: TrainingCenter[] = [];

  for (const iti of itis) {
    const id = `iti-${iti.sNo || Date.now() + count}`;
    const item: TrainingCenter = { ...iti, id, createdAt: now, updatedAt: now };
    newItems.push(item);
    count++;
  }

  latestTrainingCenters = [...latestTrainingCenters, ...newItems];
  latestTrainingCenters.sort((a, b) => (a.sNo || 0) - (b.sNo || 0));
  notifyTcSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch('/api/training-centers/batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newItems),
      });
    } catch (err) {
      console.warn('API batch add TC note:', err);
    }

    try {
      const batch = writeBatch(db);
      for (const item of newItems) {
        const ref = doc(db, COLLECTIONS.TRAINING_CENTERS, item.id);
        batch.set(ref, sanitizeData(item), { merge: true });
      }
      await batch.commit();
    } catch (err) {
      console.warn('Firestore batch add TC note:', err);
    }
  });

  return count;
}

export async function updateTrainingCenter(id: string, iti: Partial<TrainingCenter>): Promise<void> {
  const now = new Date().toISOString();
  const idx = latestTrainingCenters.findIndex((t) => t.id === id);
  if (idx !== -1) {
    latestTrainingCenters[idx] = { ...latestTrainingCenters[idx], ...iti, updatedAt: now };
    latestTrainingCenters.sort((a, b) => (a.sNo || 0) - (b.sNo || 0));
    notifyTcSubscribers();
  }

  runBackgroundSync(async () => {
    try {
      await fetch(`/api/training-centers/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(iti),
      });
    } catch (err) {
      console.warn('API update TC note:', err);
    }

    try {
      const ref = doc(db, COLLECTIONS.TRAINING_CENTERS, id);
      await setDoc(ref, sanitizeData({ ...iti, updatedAt: now }), { merge: true });
    } catch (err) {
      console.warn('Firestore update TC note:', err);
    }
  });
}

export async function deleteTrainingCenter(id: string): Promise<void> {
  latestTrainingCenters = latestTrainingCenters.filter((t) => t.id !== id);
  notifyTcSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch(`/api/training-centers/${id}`, { method: 'DELETE' });
    } catch (err) {
      console.warn('API delete TC note:', err);
    }

    try {
      const ref = doc(db, COLLECTIONS.TRAINING_CENTERS, id);
      await deleteDoc(ref);
    } catch (err) {
      console.warn('Firestore delete TC note:', err);
    }
  });
}

export async function clearAllTrainingCenterRemarks(): Promise<{ updatedCount: number; error?: string }> {
  const now = new Date().toISOString();
  let count = 0;
  latestTrainingCenters.forEach((tc) => {
    if (tc.remarks && tc.remarks.trim() !== '') {
      tc.remarks = '';
      tc.updatedAt = now;
      count++;
    }
  });
  notifyTcSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch('/api/training-centers/clear-remarks', { method: 'POST' });
    } catch (err) {
      console.warn('API clear TC remarks note:', err);
    }

    try {
      const snap = await getDocs(collection(db, COLLECTIONS.TRAINING_CENTERS));
      if (!snap.empty) {
        const batch = writeBatch(db);
        snap.docs.forEach((docSnap) => {
          const data = docSnap.data();
          if (data.remarks && data.remarks.trim() !== '') {
            batch.update(docSnap.ref, { remarks: '', updatedAt: now });
          }
        });
        await batch.commit();
      }
    } catch (err) {
      console.warn('Firestore clear TC remarks note:', err);
    }
  });

  return { updatedCount: count };
}

// ========================
// INSTRUCTORS
// ========================

const LOCAL_INSTRUCTORS_STORAGE_KEY = 'pending_instructor_registrations';

// Blacklist filter for explicitly removed instructors
const BLACKLISTED_REG_NUMS = new Set([
  'JK-ITI-REG-590257',
  'JK-ITI-REG-653707',
  'JK-ITI-REG-458440',
  'JK-ITI-REG-400446',
  'JK-ITI-REG-100201',
  'JK-ITI-REG-200301',
  'JK-ITI-REG-475432',
  'JK-ITI-REG-278280',
  'JK-ITI-REG-588361',
  'JK-ITI-REG-200302',
  'JK-ITI-REG-586769',
  'JK-ITI-REG-100203',
  'JK-ITI-REG-100202',
  'JK-ITI-REG-100204',
  'JK-ITI-REG-200303',
  'JK-ITI-REG-289536',
  'JK-ITI-REG-720595',
  'JK-ITI-REG-897772',
  'JK-ITI-REG-264137',
  'JK-ITI-REG-201023',
  'JK-ITI-REG-884610',
  'JK-ITI-REG-146245',
  'JK-ITI-REG-989966',
  'JK-ITI-REG-215382',
  'JK-ITI-REG-963152',
  'JK-ITI-REG-365329',
  'JK-ITI-REG-743734',
  'JK-ITI-REG-750148',
  'JK-ITI-REG-404733',
  'JK-ITI-REG-315825',
  'JK-ITI-REG-296538',
  'JK-ITI-REG-542704',
  'JK-ITI-REG-151822',
  'JK-ITI-REG-918724',
  'JK-ITI-REG-272737',
  'JK-ITI-REG-610272',
  'JK-ITI-REG-486208',
  'JK-ITI-REG-585456',
  'JK-ITI-REG-467560',
]);

const BLACKLISTED_CONTACTS = new Set([
  '7780962505',
  '9596421046',
  '7006167210',
  '8082443922',
  '9419012345',
  '9419167890',
  '8899530284',
  '8491032805',
  '7051378007',
  '9419198765',
  '9682640071',
  '9419211223',
  '9419054321',
  '9419477889',
  '9419344556',
  '9622039007',
  '7006098334',
  '7780951478',
  '9541046073',
  '9596690147',
  '7889443295',
  '6005587785',
  '7889630988',
  '9596289327',
  '9682666099',
  '9018822606',
  '7889592500',
  '6006313259',
  '6006124970',
  '7889947010',
  '9086864004',
  '6005514350',
  '7006480157',
  '8716023554',
  '9906010644',
  '7780801366',
]);

const BLACKLISTED_NAMES = [
  'ayaz ahmad',
  'hurrah nooren',
  'kaiser hafeez',
  'misba abbas',
  'mohammad altaf rather',
  'rajesh kumar sharma',
  'shams ul fajre',
  'shaziya hassan',
  'sukhvinder kour',
  'sunita devi',
  'syed mehvish',
  'tariq hussain shah',
  'bashir ahmad wani',
  'farooq ahmad dar',
  'vikram singh jamwal',
  'yogesh bhran',
  'younis bashir',
  'ashaq hussain sheikh',
  'azad ahmad ganie',
  'bal krishan',
  'farheena jan',
  'humaira tabasum',
  'masood ahmad thoker',
  'mohasin hussain baba',
  'mohd rafee',
  'najeeb ul rehman',
  'naresh kumar',
  'nisar ahmad mir',
  'rahie afzal malik',
  'rahila',
  'rasik nazir bhat',
  'sameer ahmad sofi',
  'sushma kumari',
  'towseef ahmad rather',
  'vijay kumar',
  'vishal sharma',
  'zahoor ahmad ganie',
];

export function isBlacklistedInstructor(inst: Partial<Instructor>): boolean {
  // Never filter out real instructors during imports, restoration, or browsing
  return false;
}

function normalizeStringClient(str?: string): string {
  if (!str) return '';
  return str.toLowerCase().trim().replace(/[^a-z0-9]/g, '');
}

function normalizeContactClient(contact?: string): string {
  if (!contact) return '';
  const digits = contact.replace(/[^0-9]/g, '');
  if (digits.length >= 10) {
    return digits.slice(-10);
  }
  if (digits.length >= 8) {
    return digits;
  }
  return '';
}

export function deduplicateInstructors(list: Instructor[]): Instructor[] {
  if (!Array.isArray(list)) return [];

  const result: Instructor[] = [];

  list.forEach((rawInst) => {
    if (!rawInst || typeof rawInst !== 'object') return;

    const inst: Instructor = {
      ...rawInst,
      name: (rawInst.name || '').trim(),
      registrationNo: ensureInstructorRegistrationNo(rawInst),
      approvalStatus: rawInst.approvalStatus || 'Approved',
      status: rawInst.status || 'Active',
    };

    const instId = (inst.id || '').trim().toLowerCase();
    const instReg = (inst.registrationNo || '').trim().toUpperCase();
    const instPhone = normalizeContactClient(inst.contact);
    const instName = normalizeStringClient(inst.name);
    const instIti = (inst.itiId || '').trim().toLowerCase();

    let matchIdx = -1;
    for (let i = 0; i < result.length; i++) {
      const existing = result[i];
      const exId = (existing.id || '').trim().toLowerCase();
      const exReg = (existing.registrationNo || '').trim().toUpperCase();
      const exPhone = normalizeContactClient(existing.contact);
      const exName = normalizeStringClient(existing.name);
      const exIti = (existing.itiId || '').trim().toLowerCase();

      if (instId && exId && instId === exId) {
        matchIdx = i;
        break;
      }
      if (instReg && exReg && instReg === exReg) {
        matchIdx = i;
        break;
      }
      if (instPhone && exPhone && instPhone === exPhone) {
        matchIdx = i;
        break;
      }
      if (instName && exName && instIti && exIti && instName === exName && instIti === exIti) {
        matchIdx = i;
        break;
      }
    }

    if (matchIdx >= 0) {
      const existing = result[matchIdx];

      const isApproved =
        existing.approvalStatus === 'Approved' ||
        inst.approvalStatus === 'Approved' ||
        (!existing.approvalStatus && !inst.approvalStatus);

      const isPending =
        !isApproved &&
        (((existing.approvalStatus || '').toLowerCase().includes('pending')) ||
          ((inst.approvalStatus || '').toLowerCase().includes('pending')));

      const mergedApprovalStatus = isApproved
        ? 'Approved'
        : isPending
        ? 'Pending Review (Awaiting Approval)'
        : inst.approvalStatus || existing.approvalStatus || 'Approved';

      let preferredId = existing.id;
      if (existing.id.startsWith('inst-reg-') && !inst.id.startsWith('inst-reg-')) {
        preferredId = inst.id;
      }

      const preferredTrade =
        (inst.trade || '').length > (existing.trade || '').length
          ? inst.trade
          : existing.trade;

      const preferredContact = inst.contact && inst.contact.trim() ? inst.contact.trim() : existing.contact;

      const preferredRegNo =
        inst.registrationNo && inst.registrationNo.startsWith('JK-ITI-REG-')
          ? inst.registrationNo
          : existing.registrationNo;

      result[matchIdx] = {
        ...existing,
        ...inst,
        id: preferredId,
        name: existing.name || inst.name,
        registrationNo: preferredRegNo,
        trade: preferredTrade,
        contact: preferredContact,
        employeeType: inst.employeeType || existing.employeeType || 'Vocational Instructor',
        approvalStatus: mergedApprovalStatus,
        status: existing.status === 'Active' || inst.status === 'Active' ? 'Active' : inst.status || existing.status,
        updatedAt: new Date().toISOString(),
      };
    } else {
      result.push(inst);
    }
  });

  return result
    .filter((inst) => !isBlacklistedInstructor(inst))
    .sort((a, b) => (a.name || '').localeCompare(b.name || ''));
}

function getLocalStoredInstructors(): Instructor[] {
  try {
    const raw = localStorage.getItem(LOCAL_INSTRUCTORS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return deduplicateInstructors(parsed);
  } catch {
    return [];
  }
}

function saveLocalStoredInstructors(list: Instructor[]): void {
  try {
    const filtered = deduplicateInstructors(list);
    localStorage.setItem(LOCAL_INSTRUCTORS_STORAGE_KEY, JSON.stringify(filtered));
    if (typeof BroadcastChannel !== 'undefined') {
      try {
        const bc = new BroadcastChannel('instructors_sync_channel');
        bc.postMessage({ type: 'SYNC_INSTRUCTORS', count: filtered.length });
        bc.close();
      } catch {
        // Ignore
      }
    }
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('instructors_local_change'));
    }
  } catch {
    // Ignore
  }
}

export function ensureInstructorRegistrationNo(inst: Partial<Instructor>): string {
  if (inst.registrationNo && inst.registrationNo.trim() !== '') {
    return inst.registrationNo.trim();
  }
  const id = inst.id || '';

  if (id.startsWith('inst-reg-')) {
    const digits = id.replace(/[^0-9]/g, '');
    if (digits.length >= 6) {
      return `JK-ITI-REG-${digits.slice(-6)}`;
    }
  }

  let hash = 0;
  const str = `${id}-${inst.name || ''}`;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  const code = 100000 + (Math.abs(hash) % 900000);
  return `JK-ITI-REG-${code}`;
}

let instructorSubscribers: Array<(instructors: Instructor[]) => void> = [];
let latestFirestoreInstructors: Instructor[] = [];

function mergeInstructorsWithLocal(serverList: Instructor[]): Instructor[] {
  const localList = getLocalStoredInstructors();
  return deduplicateInstructors([...serverList, ...localList]);
}

function notifyInstructorSubscribers(): void {
  const merged = mergeInstructorsWithLocal(latestFirestoreInstructors);
  instructorSubscribers.forEach((subscriber) => {
    try {
      subscriber(merged);
    } catch (e) {
      console.error('Error notifying instructor subscriber:', e);
    }
  });
}

export function subscribeInstructors(
  callback: (instructors: Instructor[]) => void,
  onError?: (err: unknown) => void
) {
  instructorSubscribers.push(callback);
  callback(mergeInstructorsWithLocal(latestFirestoreInstructors));

  // 1. Initial bootstrap from server
  const fetchFromServer = async () => {
    try {
      const res = await fetch('/api/instructors');
      if (res.ok) {
        const serverInstructors: Instructor[] = await res.json();
        if (Array.isArray(serverInstructors)) {
          if (latestFirestoreInstructors.length === 0 && serverInstructors.length > 0) {
            latestFirestoreInstructors = serverInstructors;
            const merged = mergeInstructorsWithLocal(serverInstructors);
            callback(merged);
          }
        }
      }
    } catch {
      // Ignore
    }
  };

  fetchFromServer();

  const onStorageChange = (e: StorageEvent) => {
    if (e.key === LOCAL_INSTRUCTORS_STORAGE_KEY) {
      notifyInstructorSubscribers();
    }
  };
  const onLocalEvent = () => {
    notifyInstructorSubscribers();
  };

  if (typeof window !== 'undefined') {
    window.addEventListener('storage', onStorageChange);
    window.addEventListener('instructors_local_change', onLocalEvent);
  }

  let unsubscribeFirestore = () => {};
  if (!isFirestoreQuotaExhausted) {
    try {
      const q = query(collection(db, COLLECTIONS.INSTRUCTORS), orderBy('name', 'asc'));
      unsubscribeFirestore = onSnapshot(
        q,
        (snapshot) => {
          const items: Instructor[] = [];
          snapshot.forEach((docSnap) => {
            items.push({ ...(docSnap.data() as Instructor), id: docSnap.id });
          });
          latestFirestoreInstructors = items;
          callback(mergeInstructorsWithLocal(items));
        },
        (error: any) => {
          if (
            error?.code === 'resource-exhausted' ||
            (error?.message && error.message.includes('Quota exceeded'))
          ) {
            isFirestoreQuotaExhausted = true;
          }
          if (onError) onError(error);
        }
      );
    } catch (err) {
      console.warn('Firestore subscription setup note:', err);
    }
  }

  return () => {
    instructorSubscribers = instructorSubscribers.filter((cb) => cb !== callback);
    if (typeof window !== 'undefined') {
      window.removeEventListener('storage', onStorageChange);
      window.removeEventListener('instructors_local_change', onLocalEvent);
    }
    unsubscribeFirestore();
  };
}

export async function syncPendingInstructorsToFirestore(): Promise<void> {
  const localList = getLocalStoredInstructors();
  for (const inst of localList) {
    try {
      const ref = doc(db, COLLECTIONS.INSTRUCTORS, inst.id);
      await setDoc(ref, sanitizeData(inst), { merge: true });
    } catch {
      // Handled by local persistence
    }
  }
}

export async function addInstructor(instructor: Omit<Instructor, 'id'>): Promise<string> {
  const localList = getLocalStoredInstructors();
  const allCurrent = deduplicateInstructors([...latestFirestoreInstructors, ...localList]);

  const normName = normalizeStringClient(instructor.name);
  const normPhone = normalizeContactClient(instructor.contact);
  const normReg = (instructor.registrationNo || '').trim().toUpperCase();
  const normIti = (instructor.itiId || '').trim().toLowerCase();

  const existingIdx = allCurrent.findIndex((i) => {
    const exReg = (i.registrationNo || '').trim().toUpperCase();
    const exPhone = normalizeContactClient(i.contact);
    const exName = normalizeStringClient(i.name);
    const exIti = (i.itiId || '').trim().toLowerCase();

    return (
      (normReg && exReg && normReg === exReg) ||
      (normPhone && exPhone && normPhone === exPhone) ||
      (normName && exName && normIti && exIti && normName === exName && normIti === exIti)
    );
  });

  const now = new Date().toISOString();
  let data: Instructor;

  if (existingIdx >= 0) {
    const existing = allCurrent[existingIdx];
    data = {
      ...existing,
      ...instructor,
      name: instructor.name.trim(),
      trade: instructor.trade.trim(),
      contact: instructor.contact.trim() || existing.contact,
      employeeType: instructor.employeeType || existing.employeeType || 'Vocational Instructor',
      approvalStatus: instructor.approvalStatus || existing.approvalStatus || 'Approved',
      status: instructor.status || existing.status || 'Active',
      updatedAt: now,
    };
  } else {
    const id = `inst-${Date.now()}`;
    const randNum = Math.floor(100000 + Math.random() * 900000);
    const registrationNo = instructor.registrationNo || `JK-ITI-REG-${randNum}`;
    data = {
      ...instructor,
      id,
      registrationNo,
      employeeType: instructor.employeeType || 'Vocational Instructor',
      approvalStatus: instructor.approvalStatus || 'Approved',
      createdAt: now,
      updatedAt: now,
    };
  }

  const updatedList = deduplicateInstructors([data, ...allCurrent]);
  latestFirestoreInstructors = updatedList;
  saveLocalStoredInstructors(updatedList);
  notifyInstructorSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch('/api/instructors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    } catch (apiErr) {
      console.warn('API addInstructor note:', apiErr);
    }

    try {
      const ref = doc(db, COLLECTIONS.INSTRUCTORS, data.id);
      await setDoc(ref, sanitizeData(data), { merge: true });
    } catch (error) {
      console.warn('Firestore write note for addInstructor:', error);
    }
  });

  return data.id;
}

export async function registerInstructor(
  instructor: Omit<Instructor, 'id' | 'approvalStatus' | 'createdAt' | 'updatedAt'>
): Promise<Instructor> {
  const localList = getLocalStoredInstructors();
  const allCurrent = deduplicateInstructors([...latestFirestoreInstructors, ...localList]);

  const normName = normalizeStringClient(instructor.name);
  const normPhone = normalizeContactClient(instructor.contact);
  const normReg = (instructor.registrationNo || '').trim().toUpperCase();
  const normIti = (instructor.itiId || '').trim().toLowerCase();

  const existingIdx = allCurrent.findIndex((i) => {
    const exReg = (i.registrationNo || '').trim().toUpperCase();
    const exPhone = normalizeContactClient(i.contact);
    const exName = normalizeStringClient(i.name);
    const exIti = (i.itiId || '').trim().toLowerCase();

    return (
      (normReg && exReg && normReg === exReg) ||
      (normPhone && exPhone && normPhone === exPhone) ||
      (normName && exName && normIti && exIti && normName === exName && normIti === exIti)
    );
  });

  const now = new Date().toISOString();
  let data: Instructor;

  if (existingIdx >= 0) {
    const existing = allCurrent[existingIdx];
    data = {
      ...existing,
      ...instructor,
      name: instructor.name.trim(),
      trade: instructor.trade.trim(),
      contact: instructor.contact.trim() || existing.contact,
      employeeType: instructor.employeeType || existing.employeeType || 'Vocational Instructor',
      status: instructor.status || existing.status || 'Active',
      updatedAt: now,
    };
  } else {
    const id = `inst-reg-${Date.now()}`;
    const randNum = Math.floor(100000 + Math.random() * 900000);
    const registrationNo = instructor.registrationNo || `JK-ITI-REG-${randNum}`;
    data = {
      ...instructor,
      id,
      registrationNo,
      employeeType: instructor.employeeType || 'Vocational Instructor',
      status: instructor.status || 'Active',
      approvalStatus: 'Pending Review (Awaiting Approval)',
      createdAt: now,
      updatedAt: now,
    };
  }

  const updatedList = deduplicateInstructors([data, ...allCurrent]);
  latestFirestoreInstructors = updatedList;
  saveLocalStoredInstructors(updatedList);
  notifyInstructorSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch('/api/instructors/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    } catch (apiErr) {
      console.warn('Server API registerInstructor note:', apiErr);
    }

    try {
      const ref = doc(db, COLLECTIONS.INSTRUCTORS, data.id);
      await setDoc(ref, sanitizeData(data), { merge: true });
    } catch {
      // Ignore
    }
  });

  return data;
}

export async function approveInstructor(id: string): Promise<void> {
  const now = new Date().toISOString();
  const fsIdx = latestFirestoreInstructors.findIndex((i) => i.id === id);
  if (fsIdx >= 0) {
    latestFirestoreInstructors[fsIdx] = {
      ...latestFirestoreInstructors[fsIdx],
      approvalStatus: 'Approved',
      status: 'Active',
      updatedAt: now,
    };
  }

  const localList = getLocalStoredInstructors();
  const instIdx = localList.findIndex((i) => i.id === id);
  if (instIdx >= 0) {
    localList[instIdx].approvalStatus = 'Approved';
    localList[instIdx].status = 'Active';
    localList[instIdx].updatedAt = now;
    saveLocalStoredInstructors(localList);
  }
  notifyInstructorSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch('/api/instructors/approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
    } catch (apiErr) {
      console.warn('Server API approve note:', apiErr);
    }

    try {
      const ref = doc(db, COLLECTIONS.INSTRUCTORS, id);
      await setDoc(ref, sanitizeData({ approvalStatus: 'Approved', status: 'Active', updatedAt: now }), { merge: true });
    } catch {
      // Ignore
    }
  });
}

export async function rejectInstructor(id: string): Promise<void> {
  const now = new Date().toISOString();
  const fsIdx = latestFirestoreInstructors.findIndex((i) => i.id === id);
  if (fsIdx >= 0) {
    latestFirestoreInstructors[fsIdx] = {
      ...latestFirestoreInstructors[fsIdx],
      approvalStatus: 'Rejected',
      status: 'Inactive',
      updatedAt: now,
    };
  }

  const localList = getLocalStoredInstructors();
  const instIdx = localList.findIndex((i) => i.id === id);
  if (instIdx >= 0) {
    localList[instIdx].approvalStatus = 'Rejected';
    localList[instIdx].status = 'Inactive';
    localList[instIdx].updatedAt = now;
    saveLocalStoredInstructors(localList);
  }
  notifyInstructorSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch('/api/instructors/reject', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
    } catch (apiErr) {
      console.warn('Server API reject note:', apiErr);
    }

    try {
      const ref = doc(db, COLLECTIONS.INSTRUCTORS, id);
      await setDoc(ref, sanitizeData({ approvalStatus: 'Rejected', status: 'Inactive', updatedAt: now }), { merge: true });
    } catch {
      // Ignore
    }
  });
}

export async function updateInstructor(id: string, instructor: Partial<Instructor>): Promise<void> {
  const now = new Date().toISOString();
  const fsIdx = latestFirestoreInstructors.findIndex((i) => i.id === id);
  if (fsIdx >= 0) {
    latestFirestoreInstructors[fsIdx] = {
      ...latestFirestoreInstructors[fsIdx],
      ...instructor,
      updatedAt: now,
    };
  }

  const localList = getLocalStoredInstructors();
  const instIdx = localList.findIndex((i) => i.id === id);
  if (instIdx >= 0) {
    Object.assign(localList[instIdx], instructor, { updatedAt: now });
    saveLocalStoredInstructors(localList);
  }
  notifyInstructorSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch(`/api/instructors/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(instructor),
      });
    } catch (apiErr) {
      console.warn('Server API update note:', apiErr);
    }

    try {
      const ref = doc(db, COLLECTIONS.INSTRUCTORS, id);
      await setDoc(ref, sanitizeData({ ...instructor, updatedAt: now }), { merge: true });
    } catch (error) {
      console.warn('Firestore update note for updateInstructor:', error);
    }
  });
}

export async function deleteInstructor(id: string): Promise<void> {
  latestFirestoreInstructors = latestFirestoreInstructors.filter((i) => i.id !== id);
  const localList = getLocalStoredInstructors().filter((i) => i.id !== id);
  saveLocalStoredInstructors(localList);
  notifyInstructorSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch(`/api/instructors/${id}`, { method: 'DELETE' });
    } catch (apiErr) {
      console.warn('Server API delete note:', apiErr);
    }

    try {
      const ref = doc(db, COLLECTIONS.INSTRUCTORS, id);
      await deleteDoc(ref);
    } catch (error) {
      console.warn('Firestore delete note for deleteInstructor:', error);
    }
  });
}

export async function clearAllInstructors(): Promise<{ cleared: boolean; error?: string }> {
  try {
    latestFirestoreInstructors = [];
    saveLocalStoredInstructors([]);
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem(LOCAL_INSTRUCTORS_STORAGE_KEY);
    }
    notifyInstructorSubscribers();

    runBackgroundSync(async () => {
      try {
        await fetch('/api/instructors/clear-all', { method: 'POST' });
      } catch (err) {
        console.warn('Server clear instructors API note:', err);
      }

      if (!isFirestoreQuotaExhausted) {
        try {
          const snap = await getDocs(collection(db, COLLECTIONS.INSTRUCTORS));
          if (!snap.empty) {
            const batch = writeBatch(db);
            snap.docs.forEach((docSnap) => {
              batch.delete(docSnap.ref);
            });
            await batch.commit();
          }
        } catch (fsErr) {
          console.warn('Firestore clear instructors note:', fsErr);
        }
      }
    });

    return { cleared: true };
  } catch (error) {
    console.error('Error clearing all instructors:', error);
    return {
      cleared: false,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

// ========================
// SCHEMES
// ========================

let latestSchemes: Scheme[] = [];
let schemesSubscribers: Array<(schemes: Scheme[]) => void> = [];

function notifySchemesSubscribers() {
  schemesSubscribers.forEach((cb) => {
    try {
      cb(latestSchemes);
    } catch (e) {
      console.error(e);
    }
  });
}

export function subscribeSchemes(
  callback: (schemes: Scheme[]) => void,
  onError?: (err: unknown) => void
) {
  schemesSubscribers.push(callback);
  callback(latestSchemes);

  // 1. Initial bootstrap from server
  const fetchFromServer = async () => {
    try {
      const res = await fetch('/api/schemes');
      if (res.ok) {
        const data: Scheme[] = await res.json();
        if (Array.isArray(data)) {
          if (latestSchemes.length === 0 && data.length > 0) {
            latestSchemes = data;
            callback(data);
          }
        }
      }
    } catch {
      // Ignore
    }
  };

  fetchFromServer();

  // 2. Firestore onSnapshot (real-time stream)
  let unsubFirestore = () => {};
  if (!isFirestoreQuotaExhausted) {
    try {
      const q = query(collection(db, COLLECTIONS.SCHEMES), orderBy('createdAt', 'desc'));
      unsubFirestore = onSnapshot(
        q,
        (snapshot) => {
          const items: Scheme[] = [];
          snapshot.forEach((docSnap) => {
            items.push({ ...(docSnap.data() as Scheme), id: docSnap.id });
          });
          latestSchemes = items;
          callback(items);
        },
        (error: any) => {
          if (
            error?.code === 'resource-exhausted' ||
            (error?.message && error.message.includes('Quota exceeded'))
          ) {
            isFirestoreQuotaExhausted = true;
          }
          if (onError) onError(error);
        }
      );
    } catch (err) {
      console.warn('Firestore schemes subscribe note:', err);
    }
  }

  return () => {
    schemesSubscribers = schemesSubscribers.filter((cb) => cb !== callback);
    unsubFirestore();
  };
}

export async function addScheme(scheme: Omit<Scheme, 'id'>): Promise<string> {
  const id = `scheme-${Date.now()}`;
  const now = new Date().toISOString();
  const data: Scheme = { ...scheme, id, createdAt: now, updatedAt: now };

  latestSchemes.unshift(data);
  notifySchemesSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch('/api/schemes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    } catch (err) {
      console.warn('API add scheme note:', err);
    }

    try {
      const ref = doc(db, COLLECTIONS.SCHEMES, id);
      await setDoc(ref, sanitizeData(data));
    } catch (err) {
      console.warn('Firestore add scheme note:', err);
    }
  });

  return id;
}

export async function updateScheme(id: string, scheme: Partial<Scheme>): Promise<void> {
  const now = new Date().toISOString();
  const idx = latestSchemes.findIndex((s) => s.id === id);
  if (idx !== -1) {
    latestSchemes[idx] = { ...latestSchemes[idx], ...scheme, updatedAt: now };
    notifySchemesSubscribers();
  }

  runBackgroundSync(async () => {
    try {
      await fetch(`/api/schemes/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(scheme),
      });
    } catch (err) {
      console.warn('API update scheme note:', err);
    }

    try {
      const ref = doc(db, COLLECTIONS.SCHEMES, id);
      await setDoc(ref, sanitizeData({ ...scheme, updatedAt: now }), { merge: true });
    } catch (err) {
      console.warn('Firestore update scheme note:', err);
    }
  });
}

export async function deleteScheme(id: string): Promise<void> {
  latestSchemes = latestSchemes.filter((s) => s.id !== id);
  notifySchemesSubscribers();

  // Cascade delete associated contributions locally
  const hadMatchingContribs = latestContributions.some((c) => c.schemeId === id);
  if (hadMatchingContribs) {
    latestContributions = latestContributions.filter((c) => c.schemeId !== id);
    notifyContribSubscribers();
  }

  runBackgroundSync(async () => {
    try {
      await fetch(`/api/schemes/${id}`, { method: 'DELETE' });
    } catch (err) {
      console.warn('API delete scheme note:', err);
    }

    try {
      const ref = doc(db, COLLECTIONS.SCHEMES, id);
      await deleteDoc(ref);
    } catch (err) {
      console.warn('Firestore delete scheme note:', err);
    }

    // Cascade delete associated contributions in Firestore
    try {
      const contribQuery = query(
        collection(db, COLLECTIONS.CONTRIBUTIONS),
        where('schemeId', '==', id)
      );
      const contribSnap = await getDocs(contribQuery);
      if (!contribSnap.empty) {
        const batch = writeBatch(db);
        contribSnap.docs.forEach((docSnap) => {
          batch.delete(docSnap.ref);
        });
        await batch.commit();
      }
    } catch (err) {
      console.warn('Firestore cascade delete contributions note:', err);
    }
  });
}

// ========================
// CONTRIBUTIONS
// ========================

let latestContributions: Contribution[] = [];
let contribSubscribers: Array<(contributions: Contribution[]) => void> = [];

function notifyContribSubscribers() {
  contribSubscribers.forEach((cb) => {
    try {
      cb(latestContributions);
    } catch (e) {
      console.error(e);
    }
  });
}

export function subscribeContributions(
  callback: (contributions: Contribution[]) => void,
  onError?: (err: unknown) => void
) {
  contribSubscribers.push(callback);
  callback(latestContributions);

  // 1. Initial bootstrap from server
  const fetchFromServer = async () => {
    try {
      const res = await fetch('/api/contributions');
      if (res.ok) {
        const data: Contribution[] = await res.json();
        if (Array.isArray(data)) {
          if (latestContributions.length === 0 && data.length > 0) {
            latestContributions = data;
            callback(data);
          }
        }
      }
    } catch {
      // Ignore
    }
  };

  fetchFromServer();

  // 2. Firestore onSnapshot (real-time stream)
  let unsubFirestore = () => {};
  if (!isFirestoreQuotaExhausted) {
    try {
      const q = query(collection(db, COLLECTIONS.CONTRIBUTIONS), orderBy('contributionDate', 'desc'));
      unsubFirestore = onSnapshot(
        q,
        (snapshot) => {
          const items: Contribution[] = [];
          snapshot.forEach((docSnap) => {
            items.push({ ...(docSnap.data() as Contribution), id: docSnap.id });
          });
          latestContributions = items;
          callback(items);
        },
        (error: any) => {
          if (
            error?.code === 'resource-exhausted' ||
            (error?.message && error.message.includes('Quota exceeded'))
          ) {
            isFirestoreQuotaExhausted = true;
          }
          if (onError) onError(error);
        }
      );
    } catch (err) {
      console.warn('Firestore contributions subscribe note:', err);
    }
  }

  return () => {
    contribSubscribers = contribSubscribers.filter((cb) => cb !== callback);
    unsubFirestore();
  };
}

export async function addContribution(contribution: Omit<Contribution, 'id'>): Promise<string> {
  const id = `contrib-${Date.now()}`;
  const now = new Date().toISOString();
  const data: Contribution = { ...contribution, id, createdAt: now, updatedAt: now };

  latestContributions.unshift(data);
  notifyContribSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch('/api/contributions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    } catch (err) {
      console.warn('API add contrib note:', err);
    }

    try {
      const ref = doc(db, COLLECTIONS.CONTRIBUTIONS, id);
      await setDoc(ref, sanitizeData(data));
    } catch (err) {
      console.warn('Firestore add contrib note:', err);
    }
  });

  return id;
}

export async function updateContribution(id: string, contribution: Partial<Contribution>): Promise<void> {
  const now = new Date().toISOString();
  const idx = latestContributions.findIndex((c) => c.id === id);
  if (idx !== -1) {
    latestContributions[idx] = { ...latestContributions[idx], ...contribution, updatedAt: now };
    notifyContribSubscribers();
  }

  runBackgroundSync(async () => {
    try {
      await fetch(`/api/contributions/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(contribution),
      });
    } catch (err) {
      console.warn('API update contrib note:', err);
    }

    try {
      const ref = doc(db, COLLECTIONS.CONTRIBUTIONS, id);
      await setDoc(ref, sanitizeData({ ...contribution, updatedAt: now }), { merge: true });
    } catch (err) {
      console.warn('Firestore update contrib note:', err);
    }
  });
}

export async function deleteContribution(id: string): Promise<void> {
  latestContributions = latestContributions.filter((c) => c.id !== id);
  notifyContribSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch(`/api/contributions/${id}`, { method: 'DELETE' });
    } catch (err) {
      console.warn('API delete contrib note:', err);
    }

    try {
      const ref = doc(db, COLLECTIONS.CONTRIBUTIONS, id);
      await deleteDoc(ref);
    } catch (err) {
      console.warn('Firestore delete contrib note:', err);
    }
  });
}

export async function clearAllContributionRemarks(): Promise<number> {
  const now = new Date().toISOString();
  let count = 0;
  latestContributions.forEach((c) => {
    if (c.remarks && c.remarks.trim() !== '') {
      c.remarks = '';
      c.updatedAt = now;
      count++;
    }
  });
  notifyContribSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch('/api/contributions/clear-remarks', { method: 'POST' });
    } catch (err) {
      console.warn('API clear contrib remarks note:', err);
    }

    try {
      const snap = await getDocs(collection(db, COLLECTIONS.CONTRIBUTIONS));
      if (!snap.empty) {
        const batch = writeBatch(db);
        snap.forEach((d) => {
          const data = d.data() as Contribution;
          if (data.remarks && data.remarks.trim() !== '') {
            batch.update(doc(db, COLLECTIONS.CONTRIBUTIONS, d.id), {
              remarks: '',
              updatedAt: now,
            });
          }
        });
        await batch.commit();
      }
    } catch (err) {
      console.warn('Firestore clear contrib remarks note:', err);
    }
  });

  return count;
}

// ========================
// NOTICES
// ========================

let latestNotices: Notice[] = [];
let noticesSubscribers: Array<(notices: Notice[]) => void> = [];

function notifyNoticesSubscribers() {
  noticesSubscribers.forEach((cb) => {
    try {
      cb(latestNotices);
    } catch (e) {
      console.error(e);
    }
  });
}

export function subscribeNotices(
  callback: (notices: Notice[]) => void,
  onError?: (err: unknown) => void
) {
  noticesSubscribers.push(callback);
  callback(latestNotices);

  // 1. Initial bootstrap from server
  const fetchFromServer = async () => {
    try {
      const res = await fetch('/api/notices');
      if (res.ok) {
        const data: Notice[] = await res.json();
        if (Array.isArray(data)) {
          if (latestNotices.length === 0 && data.length > 0) {
            latestNotices = data;
            callback(data);
          }
        }
      }
    } catch {
      // Ignore
    }
  };

  fetchFromServer();

  // 2. Firestore onSnapshot (real-time stream)
  let unsubFirestore = () => {};
  if (!isFirestoreQuotaExhausted) {
    try {
      const q = query(collection(db, COLLECTIONS.NOTICES), orderBy('publishDate', 'desc'));
      unsubFirestore = onSnapshot(
        q,
        (snapshot) => {
          const items: Notice[] = [];
          snapshot.forEach((docSnap) => {
            items.push({ ...(docSnap.data() as Notice), id: docSnap.id });
          });
          latestNotices = items;
          callback(items);
        },
        (error: any) => {
          if (
            error?.code === 'resource-exhausted' ||
            (error?.message && error.message.includes('Quota exceeded'))
          ) {
            isFirestoreQuotaExhausted = true;
          }
          if (onError) onError(error);
        }
      );
    } catch (err) {
      console.warn('Firestore notices subscribe note:', err);
    }
  }

  return () => {
    noticesSubscribers = noticesSubscribers.filter((cb) => cb !== callback);
    unsubFirestore();
  };
}

export async function addNotice(notice: Omit<Notice, 'id'>): Promise<string> {
  const id = `notice-${Date.now()}`;
  const now = new Date().toISOString();
  const data: Notice = { ...notice, id, createdAt: now, updatedAt: now };

  latestNotices.unshift(data);
  notifyNoticesSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch('/api/notices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    } catch (err) {
      console.warn('API add notice note:', err);
    }

    try {
      const ref = doc(db, COLLECTIONS.NOTICES, id);
      await setDoc(ref, sanitizeData(data));
    } catch (err) {
      console.warn('Firestore add notice note:', err);
    }
  });

  return id;
}

export async function updateNotice(id: string, notice: Partial<Notice>): Promise<void> {
  const now = new Date().toISOString();
  const idx = latestNotices.findIndex((n) => n.id === id);
  if (idx !== -1) {
    latestNotices[idx] = { ...latestNotices[idx], ...notice, updatedAt: now };
    notifyNoticesSubscribers();
  }

  runBackgroundSync(async () => {
    try {
      await fetch(`/api/notices/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(notice),
      });
    } catch (err) {
      console.warn('API update notice note:', err);
    }

    try {
      const ref = doc(db, COLLECTIONS.NOTICES, id);
      await setDoc(ref, sanitizeData({ ...notice, updatedAt: now }), { merge: true });
    } catch (err) {
      console.warn('Firestore update notice note:', err);
    }
  });
}

export async function deleteNotice(id: string): Promise<void> {
  latestNotices = latestNotices.filter((n) => n.id !== id);
  notifyNoticesSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch(`/api/notices/${id}`, { method: 'DELETE' });
    } catch (err) {
      console.warn('API delete notice note:', err);
    }

    try {
      const ref = doc(db, COLLECTIONS.NOTICES, id);
      await deleteDoc(ref);
    } catch (err) {
      console.warn('Firestore delete notice note:', err);
    }
  });
}

// ========================
// SETTINGS
// ========================

let latestSettings: AppSetting = {
  id: 'general',
  targetAmount: 0,
  appName: "J&K ITI EMPLOYEE'S UNITED FRONT",
  employeeTypes: [...DEFAULT_EMPLOYEE_TYPES],
  updatedAt: new Date().toISOString(),
};
let settingsSubscribers: Array<(settings: AppSetting | null) => void> = [];

function notifySettingsSubscribers() {
  settingsSubscribers.forEach((cb) => {
    try {
      cb(latestSettings);
    } catch (e) {
      console.error(e);
    }
  });
}

export function subscribeSettings(
  callback: (settings: AppSetting | null) => void,
  onError?: (err: unknown) => void
) {
  settingsSubscribers.push(callback);
  callback(latestSettings);

  // 1. Initial bootstrap from server
  const fetchFromServer = async () => {
    try {
      const res = await fetch('/api/settings');
      if (res.ok) {
        const data: AppSetting = await res.json();
        if (data && data.targetAmount !== undefined) {
          if (!data.employeeTypes || data.employeeTypes.length === 0) {
            data.employeeTypes = [...DEFAULT_EMPLOYEE_TYPES];
          }
          latestSettings = data;
          callback(data);
        }
      }
    } catch {
      // Ignore
    }
  };

  fetchFromServer();

  // 2. Firestore onSnapshot (real-time stream)
  let unsubFirestore = () => {};
  if (!isFirestoreQuotaExhausted) {
    try {
      const ref = doc(db, COLLECTIONS.SETTINGS, 'general');
      unsubFirestore = onSnapshot(
        ref,
        (docSnap) => {
          if (docSnap && docSnap.exists()) {
            const data = { ...(docSnap.data() as AppSetting), id: docSnap.id };
            if (!data.employeeTypes || data.employeeTypes.length === 0) {
              data.employeeTypes = [...DEFAULT_EMPLOYEE_TYPES];
            }
            latestSettings = data;
            callback(data);
          }
        },
        (error: any) => {
          if (onError) onError(error);
        }
      );
    } catch (err) {
      console.warn('Firestore settings subscribe note:', err);
    }
  }

  return () => {
    settingsSubscribers = settingsSubscribers.filter((cb) => cb !== callback);
    unsubFirestore();
  };
}

export async function updateSettings(settings: Partial<AppSetting>): Promise<void> {
  const now = new Date().toISOString();
  latestSettings = { ...latestSettings, ...settings, updatedAt: now };
  notifySettingsSubscribers();

  runBackgroundSync(async () => {
    try {
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
    } catch (err) {
      console.warn('API update settings note:', err);
    }

    try {
      const ref = doc(db, COLLECTIONS.SETTINGS, 'general');
      await setDoc(ref, { ...settings, updatedAt: now }, { merge: true });
    } catch (err) {
      console.warn('Firestore update settings note:', err);
    }
  });
}

export async function updateEmployeeTypes(employeeTypes: string[]): Promise<void> {
  const sanitized = Array.from(new Set(employeeTypes.map((t) => t.trim()))).filter(Boolean);
  await updateSettings({ employeeTypes: sanitized });
}

export function getLatestEmployeeTypes(): string[] {
  if (latestSettings.employeeTypes && latestSettings.employeeTypes.length > 0) {
    return latestSettings.employeeTypes;
  }
  return [...DEFAULT_EMPLOYEE_TYPES];
}

export async function updateTargetAmount(targetAmount: number): Promise<void> {
  await updateSettings({ targetAmount });
}

export const subscribeAppSettings = subscribeSettings;

export async function createNewAdminAccount(email: string, pass: string): Promise<void> {
  const secondaryAppName = 'SecondaryAdminCreationApp';
  let secondaryApp;
  const existingApps = getApps();
  const found = existingApps.find((a) => a.name === secondaryAppName);
  if (found) {
    secondaryApp = found;
  } else {
    secondaryApp = initializeApp(firebaseConfig, secondaryAppName);
  }
  const secAuth = getSecondaryAuth(secondaryApp);
  await createUserWithEmailAndPassword(secAuth, email, pass);
  await secondarySignOut(secAuth);
}

export const isPendingApproval = (inst: { approvalStatus?: string }): boolean => {
  if (!inst.approvalStatus) return false;
  const s = inst.approvalStatus.trim().toLowerCase();
  return (
    s.includes('pending') ||
    s.includes('awaiting') ||
    (s.includes('review') && !s.includes('approved'))
  );
};

// ========================
// DATABASE BACKUP & RESTORE
// ========================

export async function exportDatabaseBackup(currentData?: {
  trainingCenters?: TrainingCenter[];
  instructors?: Instructor[];
  schemes?: Scheme[];
  contributions?: Contribution[];
  notices?: Notice[];
  targetAmount?: number;
}): Promise<DatabaseBackup> {
  let tcList = currentData?.trainingCenters && currentData.trainingCenters.length > 0 ? currentData.trainingCenters : latestTrainingCenters;
  let instList =
    currentData?.instructors && currentData.instructors.length > 0
      ? currentData.instructors
      : mergeInstructorsWithLocal(latestFirestoreInstructors);
  let schList = currentData?.schemes && currentData.schemes.length > 0 ? currentData.schemes : latestSchemes;
  let contList = currentData?.contributions && currentData.contributions.length > 0 ? currentData.contributions : latestContributions;
  let notList = currentData?.notices && currentData.notices.length > 0 ? currentData.notices : latestNotices;
  let targetVal = currentData?.targetAmount ?? latestSettings.targetAmount ?? 0;

  const backup: DatabaseBackup = {
    version: '2.0',
    exportedAt: new Date().toISOString(),
    portal: "J&K ITI Employee's United Front",
    metadata: {
      trainingCentersCount: tcList.length,
      instructorsCount: instList.length,
      schemesCount: schList.length,
      contributionsCount: contList.length,
      noticesCount: notList.length,
      targetAmount: targetVal,
    },
    data: {
      trainingCenters: tcList,
      instructors: instList,
      schemes: schList,
      contributions: contList,
      notices: notList,
      targetAmount: targetVal,
    },
  };

  return backup;
}

export async function restoreDatabaseFromBackup(
  backup: DatabaseBackup
): Promise<{ success: boolean; counts: Record<string, number>; error?: string }> {
  try {
    if (!backup) {
      throw new Error('Invalid backup file format. Expected a valid database backup object.');
    }

    const rawBackup = backup as any;
    let sourceData: any = rawBackup.data || rawBackup;
    if (rawBackup.backup && typeof rawBackup.backup === 'object') {
      sourceData = rawBackup.backup.data || rawBackup.backup;
    }

    const now = new Date().toISOString();

    const getArray = (src: any, keys: string[]): any[] => {
      if (!src || typeof src !== 'object') return [];
      for (const k of keys) {
        if (Array.isArray(src[k])) return src[k];
        if (src[k] && typeof src[k] === 'object') {
          return Object.keys(src[k]).map((idKey) => {
            const item = src[k][idKey];
            return typeof item === 'object' && item !== null ? { ...item, id: item.id || idKey } : item;
          });
        }
      }
      return [];
    };

    let trainingCenters: any[] = [];
    let instructors: any[] = [];
    let schemes: any[] = [];
    let contributions: any[] = [];
    let notices: any[] = [];
    let targetAmount: any = 0;

    if (Array.isArray(backup)) {
      backup.forEach((item: any) => {
        if (!item || typeof item !== 'object') return;
        const colType = (item.collection || item._collection || item.type || item.entityType || '').toLowerCase();
        if (colType.includes('tc') || colType.includes('center') || colType.includes('iti')) {
          trainingCenters.push(item);
        } else if (colType.includes('inst') || colType.includes('teach') || colType.includes('member')) {
          instructors.push(item);
        } else if (colType.includes('sch') || colType.includes('welfare')) {
          schemes.push(item);
        } else if (colType.includes('contrib') || colType.includes('donat') || colType.includes('fund')) {
          contributions.push(item);
        } else if (colType.includes('notice') || colType.includes('announc') || colType.includes('event')) {
          notices.push(item);
        } else if (item.trade || item.registrationNo || item.designation || item.fatherName) {
          instructors.push(item);
        } else if (item.district || item.division || item.itiCode || (item.name && item.name.includes('ITI'))) {
          trainingCenters.push(item);
        } else if (item.amount || item.donorName || item.transactionId) {
          contributions.push(item);
        } else if (item.title && (item.content || item.publishedDate || item.date)) {
          notices.push(item);
        } else if (item.schemeName || item.coverageDetails) {
          schemes.push(item);
        } else {
          instructors.push(item);
        }
      });
    } else {
      trainingCenters = getArray(sourceData, [
        'trainingCenters',
        'training_centers',
        'TrainingCenters',
        'itis',
        'ITIs',
        'centers',
        'institutes',
      ]);
      instructors = getArray(sourceData, [
        'instructors',
        'Instructors',
        'instructor',
        'vocationalInstructors',
        'vocational_instructors',
        'members',
        'staff',
        'teachers',
        'users',
        'records',
      ]);
      schemes = getArray(sourceData, [
        'schemes',
        'Schemes',
        'welfareSchemes',
        'welfare_schemes',
        'welfare',
        'benefits',
      ]);
      contributions = getArray(sourceData, [
        'contributions',
        'Contributions',
        'donations',
        'funds',
        'payments',
        'transactions',
      ]);
      notices = getArray(sourceData, [
        'notices',
        'Notices',
        'announcements',
        'circulars',
        'events',
        'news',
      ]);
      targetAmount =
        sourceData.targetAmount ??
        rawBackup.targetAmount ??
        rawBackup.metadata?.targetAmount ??
        latestSettings.targetAmount ??
        0;
    }

    // 1. Prepare normalized records with guaranteed safe document IDs
    let normalizedTC: TrainingCenter[] = [];
    if (trainingCenters.length > 0) {
      normalizedTC = trainingCenters.map((tc: any, i: number) => {
        const safeId = toSafeDocId(tc.id || tc.code, 'tc', i);
        return {
          ...tc,
          id: safeId,
          sNo: tc.sNo ? Number(tc.sNo) : i + 1,
          name: tc.name || '',
          division: tc.division || 'Kashmir Division',
          location: tc.location || tc.district || '',
          instructorCount: Number(tc.instructorCount) || 0,
          status: tc.status || 'Active',
          remarks: tc.remarks !== undefined ? tc.remarks : '',
          updatedAt: tc.updatedAt || now,
        };
      });
      normalizedTC.sort((a: any, b: any) => (a.sNo || 0) - (b.sNo || 0));
    } else if (latestTrainingCenters.length > 0) {
      normalizedTC = [...latestTrainingCenters];
    } else {
      normalizedTC = OFFICIAL_JK_ITIS.map((iti) => ({
        id: `iti-${iti.sNo}`,
        sNo: iti.sNo,
        name: iti.name,
        division: iti.division,
        location: iti.location,
        instructorCount: 0,
        status: 'Active',
        remarks: '',
        createdAt: now,
        updatedAt: now,
      }));
    }

    let normalizedInst: Instructor[] = [];
    if (instructors.length > 0) {
      normalizedInst = deduplicateInstructors(
        instructors.map((inst: any, i: number) => {
          const safeId = toSafeDocId(inst.id || inst.registrationNo, 'inst', i);
          return {
            ...inst,
            id: safeId,
            registrationNo: ensureInstructorRegistrationNo(inst),
            approvalStatus: inst.approvalStatus || 'Approved',
            status: inst.status || 'Active',
            updatedAt: inst.updatedAt || now,
          };
        })
      );
    } else {
      normalizedInst = deduplicateInstructors([...latestFirestoreInstructors]);
    }

    let normalizedSchemes: Scheme[] = [];
    if (schemes.length > 0) {
      normalizedSchemes = schemes.map((s: any, i: number) => {
        const safeId = toSafeDocId(s.id || s.schemeName, 'sch', i);
        return {
          ...s,
          id: safeId,
          updatedAt: s.updatedAt || now,
        };
      });
    } else {
      normalizedSchemes = [...latestSchemes];
    }

    let normalizedContribs: Contribution[] = [];
    if (contributions.length > 0) {
      normalizedContribs = contributions.map((c: any, i: number) => {
        const safeId = toSafeDocId(c.id, 'contrib', i);
        return {
          ...c,
          id: safeId,
          amount: Number(c.amount) || 0,
          updatedAt: c.updatedAt || now,
        };
      });
    } else {
      normalizedContribs = [...latestContributions];
    }

    let normalizedNotices: Notice[] = [];
    if (notices.length > 0) {
      normalizedNotices = notices.map((n: any, i: number) => {
        const safeId = toSafeDocId(n.id, 'notice', i);
        return {
          ...n,
          id: safeId,
          updatedAt: n.updatedAt || now,
        };
      });
    } else {
      normalizedNotices = [...latestNotices];
    }

    // 2. Update in-memory & broadcast immediately
    latestTrainingCenters = [...normalizedTC];
    notifyTcSubscribers();

    saveLocalStoredInstructors(normalizedInst);
    latestFirestoreInstructors = [...normalizedInst];
    notifyInstructorSubscribers();

    latestSchemes = [...normalizedSchemes];
    notifySchemesSubscribers();

    latestContributions = [...normalizedContribs];
    notifyContribSubscribers();

    latestNotices = [...normalizedNotices];
    notifyNoticesSubscribers();

    latestSettings = {
      id: 'general',
      targetAmount: Number(targetAmount) || latestSettings.targetAmount || 0,
      appName: "J&K ITI EMPLOYEE'S UNITED FRONT",
      isSeeded: true,
      updatedAt: now,
    };
    notifySettingsSubscribers();

    // 3. Save to server backend
    const serverPayload = {
      version: backup.version || '2.0',
      exportedAt: backup.exportedAt || now,
      portal: backup.portal || "J&K ITI Employee's United Front",
      data: {
        trainingCenters: normalizedTC,
        instructors: normalizedInst,
        schemes: normalizedSchemes,
        contributions: normalizedContribs,
        notices: normalizedNotices,
        targetAmount: Number(targetAmount) || latestSettings.targetAmount || 0,
      },
    };

    try {
      await fetch('/api/backup/restore', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(serverPayload),
      });
    } catch (err) {
      console.warn('Server restore sync note:', err);
    }

    // 4. Save to Firestore safely using merge: true without destructive pre-deletions
    isFirestoreQuotaExhausted = false;
    try {
      const collectionsToSync = [
        { name: COLLECTIONS.TRAINING_CENTERS, items: normalizedTC },
        { name: COLLECTIONS.INSTRUCTORS, items: normalizedInst },
        { name: COLLECTIONS.SCHEMES, items: normalizedSchemes },
        { name: COLLECTIONS.CONTRIBUTIONS, items: normalizedContribs },
        { name: COLLECTIONS.NOTICES, items: normalizedNotices },
      ];

      for (const col of collectionsToSync) {
        const items = col.items;
        for (let i = 0; i < items.length; i += 400) {
          const chunk = items.slice(i, i + 400);
          const batch = writeBatch(db);
          for (let itemIdx = 0; itemIdx < chunk.length; itemIdx++) {
            const item = chunk[itemIdx];
            if (item && item.id) {
              const safeDocId = toSafeDocId(item.id, col.name, i + itemIdx);
              const docRef = doc(db, col.name, safeDocId);
              batch.set(docRef, deepSanitizeData({ ...item, id: safeDocId }), { merge: true });
            }
          }
          await batch.commit();
        }
      }

      const settingsRef = doc(db, COLLECTIONS.SETTINGS, 'general');
      await setDoc(
        settingsRef,
        { id: 'general', targetAmount: Number(targetAmount) || latestSettings.targetAmount || 0, isSeeded: true, updatedAt: now },
        { merge: true }
      );
    } catch (fsErr) {
      console.warn('Firestore restore write note:', fsErr);
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('database_restored'));
      window.dispatchEvent(new CustomEvent('instructors_local_change'));
    }

    return {
      success: true,
      counts: {
        trainingCenters: latestTrainingCenters.length,
        instructors: latestFirestoreInstructors.length,
        schemes: latestSchemes.length,
        contributions: latestContributions.length,
        notices: latestNotices.length,
      },
    };
  } catch (err: any) {
    console.error('Error in restoreDatabaseFromBackup:', err);
    return {
      success: false,
      counts: {},
      error: err.message || 'Failed to restore database from backup',
    };
  }
}

// ========================
// REFRESH & RECONNECT FIREBASE DATABASE
// ========================

export async function refreshFirebaseConnection(): Promise<{
  connected: boolean;
  counts: Record<string, number>;
  error?: string;
}> {
  try {
    isFirestoreQuotaExhausted = false;

    // 1. Fetch Training Centers from Firestore
    try {
      const tcSnap = await getDocs(collection(db, COLLECTIONS.TRAINING_CENTERS));
      const tcList: TrainingCenter[] = [];
      tcSnap.forEach((d) => {
        tcList.push({ ...(d.data() as TrainingCenter), id: d.id });
      });
      if (tcList.length > 0) {
        latestTrainingCenters = tcList;
        notifyTcSubscribers();
      }
    } catch (e) {
      console.warn('Firestore TC read note:', e);
    }

    // 2. Fetch Instructors from Firestore
    try {
      const instSnap = await getDocs(collection(db, COLLECTIONS.INSTRUCTORS));
      const instList: Instructor[] = [];
      instSnap.forEach((d) => {
        const item = { ...(d.data() as Instructor), id: d.id };
        instList.push(item);
      });
      if (instList.length > 0) {
        latestFirestoreInstructors = instList;
        saveLocalStoredInstructors(instList);
        notifyInstructorSubscribers();
      }
    } catch (e) {
      console.warn('Firestore Instructors read note:', e);
    }

    // 3. Fetch Schemes from Firestore
    try {
      const schSnap = await getDocs(collection(db, COLLECTIONS.SCHEMES));
      const schList: Scheme[] = [];
      schSnap.forEach((d) => {
        schList.push({ ...(d.data() as Scheme), id: d.id });
      });
      if (schList.length > 0) {
        latestSchemes = schList;
        notifySchemesSubscribers();
      }
    } catch (e) {}

    // 4. Fetch Contributions from Firestore
    try {
      const contSnap = await getDocs(collection(db, COLLECTIONS.CONTRIBUTIONS));
      const contList: Contribution[] = [];
      contSnap.forEach((d) => {
        contList.push({ ...(d.data() as Contribution), id: d.id });
      });
      if (contList.length > 0) {
        latestContributions = contList;
        notifyContribSubscribers();
      }
    } catch (e) {}

    // 5. Fetch Notices from Firestore
    try {
      const notSnap = await getDocs(collection(db, COLLECTIONS.NOTICES));
      const notList: Notice[] = [];
      notSnap.forEach((d) => {
        notList.push({ ...(d.data() as Notice), id: d.id });
      });
      if (notList.length > 0) {
        latestNotices = notList;
        notifyNoticesSubscribers();
      }
    } catch (e) {}

    // 6. Fetch Settings from Firestore
    try {
      const settingsSnap = await getDoc(doc(db, COLLECTIONS.SETTINGS, 'general'));
      if (settingsSnap.exists()) {
        const sData = settingsSnap.data() as AppSetting;
        latestSettings = { ...sData, id: 'general' };
        notifySettingsSubscribers();
      }
    } catch {}

    // 7. If Firestore was empty or failed, fetch latest from server API
    if (latestTrainingCenters.length === 0 || latestFirestoreInstructors.length === 0) {
      try {
        const [tcRes, instRes] = await Promise.all([
          fetch('/api/training-centers'),
          fetch('/api/instructors'),
        ]);
        if (tcRes.ok) {
          const tcs = await tcRes.json();
          if (Array.isArray(tcs) && tcs.length > 0) {
            latestTrainingCenters = tcs;
            notifyTcSubscribers();
          }
        }
        if (instRes.ok) {
          const insts = await instRes.json();
          if (Array.isArray(insts) && insts.length > 0) {
            latestFirestoreInstructors = insts;
            saveLocalStoredInstructors(insts);
            notifyInstructorSubscribers();
          }
        }
      } catch (err) {
        console.warn('Server fallback fetch note:', err);
      }
    }

    return {
      connected: true,
      counts: {
        trainingCenters: latestTrainingCenters.length,
        instructors: latestFirestoreInstructors.length,
        schemes: latestSchemes.length,
        contributions: latestContributions.length,
        notices: latestNotices.length,
      },
    };
  } catch (err: any) {
    console.error('Failed to refresh Firebase database:', err);
    return {
      connected: false,
      counts: {
        trainingCenters: latestTrainingCenters.length,
        instructors: latestFirestoreInstructors.length,
        schemes: latestSchemes.length,
        contributions: latestContributions.length,
        notices: latestNotices.length,
      },
      error: err?.message || 'Failed to connect to Firebase database',
    };
  }
}

// ========================
// ADMIN ACTIVE SESSION STORE
// ========================

export async function registerAdminSession(uid: string, email: string, sessionId: string): Promise<void> {
  try {
    const now = Date.now();
    const sessionData: AdminSession = {
      id: uid,
      uid,
      email: email || '',
      sessionId,
      lastActiveAt: now,
      loginAt: now,
    };

    try {
      const docRef = doc(db, COLLECTIONS.ADMIN_SESSIONS, uid);
      await setDoc(docRef, sanitizeData(sessionData), { merge: true });
    } catch {
      // Ignore
    }

    try {
      await fetch('/api/admin/session/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid, email, sessionId }),
      });
    } catch {
      // Ignore
    }
  } catch (err) {
    console.error('Error registering admin session:', err);
  }
}

export function subscribeAdminSession(
  uid: string,
  callback: (session: AdminSession | null) => void
): () => void {
  try {
    const docRef = doc(db, COLLECTIONS.ADMIN_SESSIONS, uid);
    return onSnapshot(
      docRef,
      (docSnap) => {
        if (docSnap.exists()) {
          callback(docSnap.data() as AdminSession);
        } else {
          callback(null);
        }
      },
      () => {}
    );
  } catch {
    return () => {};
  }
}

export async function pingAdminSession(uid: string, sessionId: string): Promise<void> {
  try {
    const now = Date.now();
    try {
      const docRef = doc(db, COLLECTIONS.ADMIN_SESSIONS, uid);
      await updateDoc(docRef, { lastActiveAt: now });
    } catch {
      // Ignore
    }

    try {
      await fetch('/api/admin/session/ping', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid, sessionId }),
      });
    } catch {
      // Ignore
    }
  } catch {
    // Ignore
  }
}

export async function clearAdminSession(uid: string, sessionId?: string): Promise<void> {
  try {
    try {
      const docRef = doc(db, COLLECTIONS.ADMIN_SESSIONS, uid);
      await deleteDoc(docRef);
    } catch {
      // Ignore
    }

    try {
      await fetch('/api/admin/session/clear', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid, sessionId }),
      });
    } catch {
      // Ignore
    }
  } catch {
    // Ignore
  }
}
