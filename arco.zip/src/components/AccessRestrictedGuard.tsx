import React from 'react';
import { ShieldAlert, Lock, ArrowLeft, RefreshCw, KeyRound, Check, X } from 'lucide-react';
import { ModuleTab, CompanyInfo, AdminUser } from '../types';
import { rbacService, ROLE_PERMISSIONS, ROLE_DESCRIPTIONS } from '../services/rbacService';
import { authService } from '../services/authService';

interface AccessRestrictedGuardProps {
  tab: ModuleTab;
  company: CompanyInfo;
  onNavigateToSales: () => void;
  onOpenSwitchAdmin?: () => void;
}

export const AccessRestrictedGuard: React.FC<AccessRestrictedGuardProps> = ({
  tab,
  company,
  onNavigateToSales,
  onOpenSwitchAdmin,
}) => {
  const activeUser = authService.getActiveAdmin();
  const roleInfo = rbacService.getActiveRoleInfo();
  const req = rbacService.getRequiredPermissionForTab(tab);
  const permissions = rbacService.getPermissions(activeUser);

  const getModuleTitle = (tabId: ModuleTab): string => {
    switch (tabId) {
      case 'company_settings':
        return 'Company Settings & Staff Roles';
      case 'audit_logs':
        return 'Audit Trail & Security Logs';
      case 'backup_center':
        return 'Cloud Backups & Restore Center';
      case 'purchase_entry':
        return 'Inward Purchases & Bills';
      case 'bills':
        return 'Supplier Bills & Purchases';
      case 'purchase_return':
        return 'Purchase Returns Register';
      case 'supplier_master':
        return 'Supplier Registry';
      case 'supplier_payment':
        return 'Supplier Voucher Payments';
      case 'supplier_ledger':
        return 'Supplier Accounts Ledger';
      case 'customer_ledger':
        return 'Customer Accounts Ledger';
      case 'cash_ledger':
        return 'Cash & Bank Register';
      case 'day_book':
        return 'Day Book & Transaction Log';
      case 'gst_reports':
        return 'GST Tax Reports & GSTR Filings';
      case 'stock_adjustment':
        return 'Physical Stock Adjustments';
      default:
        return 'Administrative Module';
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-12 px-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-8 text-slate-100 relative overflow-hidden">
        {/* Glow Header Accent */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-rose-500 via-amber-500 to-purple-500"></div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5 border-b border-slate-800 pb-6 mb-6">
          <div className="w-14 h-14 rounded-2xl bg-rose-950/60 border border-rose-600/40 text-rose-400 flex items-center justify-center shrink-0 shadow-lg">
            <ShieldAlert className="w-8 h-8" />
          </div>

          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <span className="px-2 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/40">
                Access Restricted
              </span>
              <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${roleInfo.color}`}>
                Active Role: {roleInfo.badge}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {getModuleTitle(tab)}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Role-Based Access Control (RBAC) is active. Your assigned staff role does not have permission to access this module.
            </p>
          </div>
        </div>

        {/* User Session Info Card */}
        <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-4 mb-6 text-xs space-y-2">
          <div className="flex justify-between items-center text-slate-400">
            <span>Signed In Staff Account:</span>
            <span className="font-bold text-slate-200">{activeUser.name || 'Staff User'}</span>
          </div>
          <div className="flex justify-between items-center text-slate-400">
            <span>Staff Email:</span>
            <span className="font-mono text-slate-300">{activeUser.email}</span>
          </div>
          <div className="flex justify-between items-center text-slate-400">
            <span>Assigned Role:</span>
            <span className="font-bold text-amber-300">{roleInfo.role}</span>
          </div>
          {req && (
            <div className="flex justify-between items-center text-slate-400 pt-2 border-t border-slate-800/60">
              <span className="text-rose-400 font-semibold">Required Permission:</span>
              <span className="font-mono font-bold text-rose-300 bg-rose-950/40 px-2 py-0.5 rounded border border-rose-800/50">
                {req.label} ({req.permission})
              </span>
            </div>
          )}
        </div>

        {/* Role Privileges Overview Grid */}
        <div className="mb-6 space-y-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Privileges Matrix for {roleInfo.role}
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
            <div className={`p-2.5 rounded-lg border flex items-center gap-2 ${permissions.canViewPurchasePrice ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300' : 'bg-slate-950/50 border-slate-800/60 text-slate-400'}`}>
              {permissions.canViewPurchasePrice ? <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> : <X className="w-3.5 h-3.5 text-rose-400 shrink-0" />}
              <span>View Purchase Rates / Wholesale Costs</span>
            </div>
            <div className={`p-2.5 rounded-lg border flex items-center gap-2 ${permissions.canBackdateBills ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300' : 'bg-slate-950/50 border-slate-800/60 text-slate-400'}`}>
              {permissions.canBackdateBills ? <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> : <X className="w-3.5 h-3.5 text-rose-400 shrink-0" />}
              <span>Backdate Invoices</span>
            </div>
            <div className={`p-2.5 rounded-lg border flex items-center gap-2 ${permissions.canCreatePurchases ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300' : 'bg-slate-950/50 border-slate-800/60 text-slate-400'}`}>
              {permissions.canCreatePurchases ? <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> : <X className="w-3.5 h-3.5 text-rose-400 shrink-0" />}
              <span>Inward Purchases & Bills</span>
            </div>
            <div className={`p-2.5 rounded-lg border flex items-center gap-2 ${permissions.canAccessCompanySettings ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300' : 'bg-slate-950/50 border-slate-800/60 text-slate-400'}`}>
              {permissions.canAccessCompanySettings ? <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> : <X className="w-3.5 h-3.5 text-rose-400 shrink-0" />}
              <span>Company Settings & Staff Roles</span>
            </div>
            <div className={`p-2.5 rounded-lg border flex items-center gap-2 ${permissions.canAccessAuditTrail ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300' : 'bg-slate-950/50 border-slate-800/60 text-slate-400'}`}>
              {permissions.canAccessAuditTrail ? <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> : <X className="w-3.5 h-3.5 text-rose-400 shrink-0" />}
              <span>Audit Trail & Security Logs</span>
            </div>
            <div className={`p-2.5 rounded-lg border flex items-center gap-2 ${permissions.canAccessBackups ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300' : 'bg-slate-950/50 border-slate-800/60 text-slate-400'}`}>
              {permissions.canAccessBackups ? <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> : <X className="w-3.5 h-3.5 text-rose-400 shrink-0" />}
              <span>Cloud Backups & Restore</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-800">
          <button
            onClick={onNavigateToSales}
            className="w-full sm:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Sales Billing (F1)</span>
          </button>

          {onOpenSwitchAdmin && (
            <button
              onClick={onOpenSwitchAdmin}
              className="w-full sm:w-auto px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 border border-slate-700 transition cursor-pointer"
            >
              <KeyRound className="w-4 h-4 text-amber-400" />
              <span>Switch User Account</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
