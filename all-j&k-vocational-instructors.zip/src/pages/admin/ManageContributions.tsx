import React, { useState, useMemo } from 'react';
import { Contribution, TrainingCenter, Scheme, Division } from '../../types';
import {
  addContribution,
  updateContribution,
  deleteContribution,
  updateScheme,
} from '../../services/db';
import { ConfirmModal } from '../../components/ConfirmModal';
import { formatCurrency, formatDate } from '../../utils/format';
import {
  Search,
  Plus,
  Edit2,
  Trash2,
  IndianRupee,
  X,
  Layers,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Clock,
  RefreshCw,
  Sparkles,
  Filter,
  Check,
  Power,
  ChevronDown,
  Building2,
  Receipt,
} from 'lucide-react';

interface ManageContributionsProps {
  contributions: Contribution[];
  trainingCenters: TrainingCenter[];
  schemes: Scheme[];
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const ManageContributions: React.FC<ManageContributionsProps> = ({
  contributions,
  trainingCenters,
  schemes,
  onNotify,
}) => {
  // Search and filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [itiFilter, setItiFilter] = useState('All');
  const [schemeFilter, setSchemeFilter] = useState('All');
  const [schemeStatusFilter, setSchemeStatusFilter] = useState<'All' | 'Active' | 'Completed' | 'Pending' | 'Inactive'>('All');
  const [divisionFilter, setDivisionFilter] = useState<'All' | Division>('All');
  const [showSchemeCards, setShowSchemeCards] = useState(true);

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingContribution, setEditingContribution] = useState<Contribution | null>(null);

  // Form states
  const [selectedItiId, setSelectedItiId] = useState('');
  const [selectedSchemeId, setSelectedSchemeId] = useState('');
  const [amount, setAmount] = useState<number | ''>('');
  const [contributionDate, setContributionDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [receiptNumber, setReceiptNumber] = useState('');
  const [mode, setMode] = useState<
    'Bank Transfer' | 'NEFT/RTGS' | 'Cheque' | 'Treasury Challan' | 'Cash/Draft' | 'Online' | 'Cash'
  >('Bank Transfer');
  const [remarks, setRemarks] = useState('');
  const [autoUpdateSchemeStatus, setAutoUpdateSchemeStatus] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSyncingSchemes, setIsSyncingSchemes] = useState(false);

  // Delete modal state
  const [deleteTarget, setDeleteTarget] = useState<Contribution | null>(null);

  // Map scheme ID to live scheme object for fast lookup
  const schemesMap = useMemo(() => {
    const map = new Map<string, Scheme>();
    schemes.forEach((s) => map.set(s.id, s));
    return map;
  }, [schemes]);

  // Map ITI ID to training center object
  const itisMap = useMemo(() => {
    const map = new Map<string, TrainingCenter>();
    trainingCenters.forEach((tc) => map.set(tc.id, tc));
    return map;
  }, [trainingCenters]);

  // Aggregate contributions per scheme for live calculations
  const schemeAggregates = useMemo(() => {
    const aggregates = new Map<
      string,
      { totalCollected: number; count: number; lastDate: string }
    >();

    // Initialize all schemes
    schemes.forEach((s) => {
      aggregates.set(s.id, { totalCollected: 0, count: 0, lastDate: '' });
    });

    contributions.forEach((c) => {
      const existing = aggregates.get(c.schemeId);
      if (existing) {
        existing.totalCollected += c.amount || 0;
        existing.count += 1;
        if (!existing.lastDate || c.contributionDate > existing.lastDate) {
          existing.lastDate = c.contributionDate;
        }
      } else {
        aggregates.set(c.schemeId, {
          totalCollected: c.amount || 0,
          count: 1,
          lastDate: c.contributionDate,
        });
      }
    });

    return aggregates;
  }, [schemes, contributions]);

  // Total collected funds across all contributions
  const totalFundsCollected = useMemo(() => {
    return contributions.reduce((acc, c) => acc + (c.amount || 0), 0);
  }, [contributions]);

  // Total targets across all schemes in database
  const totalTargetSum = useMemo(() => {
    return schemes.reduce((acc, s) => acc + (s.targetAmount || 0), 0);
  }, [schemes]);

  // Overall achievement percentage
  const overallAchievementPercent = useMemo(() => {
    if (totalTargetSum <= 0) return 0;
    return Math.min(100, (totalFundsCollected / totalTargetSum) * 100);
  }, [totalFundsCollected, totalTargetSum]);

  // Find schemes that reached target but are not marked 'Completed', or vice-versa
  const outOfSyncSchemesCount = useMemo(() => {
    return schemes.filter((s) => {
      const agg = schemeAggregates.get(s.id);
      const collected = agg ? agg.totalCollected : 0;
      const reachedTarget = collected >= s.targetAmount && s.targetAmount > 0;
      return (reachedTarget && s.status !== 'Completed') || (!reachedTarget && s.status === 'Completed' && s.targetAmount > 0);
    }).length;
  }, [schemes, schemeAggregates]);

  // Filtered contributions list
  const filteredContributions = useMemo(() => {
    return contributions.filter((c) => {
      // Resolve live scheme
      const liveScheme = schemesMap.get(c.schemeId);
      const liveSchemeName = liveScheme ? liveScheme.name : c.schemeName;
      const liveSchemeStatus = liveScheme ? liveScheme.status : 'Pending';

      // Resolve live ITI
      const liveIti = itisMap.get(c.itiId);
      const liveDivision = liveIti ? liveIti.division : c.division;

      const matchesSearch =
        c.itiName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        liveSchemeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (c.receiptNumber && c.receiptNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (c.remarks && c.remarks.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesIti = itiFilter === 'All' || c.itiId === itiFilter;
      const matchesScheme = schemeFilter === 'All' || c.schemeId === schemeFilter;
      const matchesDivision = divisionFilter === 'All' || liveDivision === divisionFilter;
      const matchesStatus =
        schemeStatusFilter === 'All' || liveSchemeStatus === schemeStatusFilter;

      return matchesSearch && matchesIti && matchesScheme && matchesDivision && matchesStatus;
    });
  }, [contributions, schemesMap, itisMap, searchTerm, itiFilter, schemeFilter, divisionFilter, schemeStatusFilter]);

  // Current ITI in modal
  const currentModalIti = useMemo(
    () => trainingCenters.find((tc) => tc.id === selectedItiId),
    [trainingCenters, selectedItiId]
  );

  // Current Scheme in modal
  const currentModalScheme = useMemo(
    () => schemes.find((s) => s.id === selectedSchemeId),
    [schemes, selectedSchemeId]
  );

  // Current Scheme aggregated stats in modal
  const currentModalSchemeAgg = useMemo(() => {
    if (!selectedSchemeId) return null;
    const agg = schemeAggregates.get(selectedSchemeId);
    const existingCollected = agg ? agg.totalCollected : 0;
    // If editing, subtract old contribution amount from baseline
    const baseline = editingContribution && editingContribution.schemeId === selectedSchemeId
      ? Math.max(0, existingCollected - (editingContribution.amount || 0))
      : existingCollected;
    const inputAmount = Number(amount) || 0;
    const projectedTotal = baseline + inputAmount;
    const target = currentModalScheme?.targetAmount || 1;
    const projectedPercent = Math.min(100, (projectedTotal / target) * 100);
    const remaining = Math.max(0, target - projectedTotal);
    const willAchieveTarget = projectedTotal >= target && target > 0;

    return {
      currentCollected: baseline,
      projectedTotal,
      projectedPercent,
      remaining,
      willAchieveTarget,
      target,
    };
  }, [selectedSchemeId, schemeAggregates, editingContribution, amount, currentModalScheme]);

  const handleOpenAdd = () => {
    setEditingContribution(null);
    const defaultIti = trainingCenters[0]?.id || '';
    // Prefer the first active scheme
    const activeScheme = schemes.find((s) => s.status === 'Active') || schemes[0];
    const defaultScheme = activeScheme?.id || '';

    setSelectedItiId(defaultIti);
    setSelectedSchemeId(defaultScheme);
    setAmount('');
    setContributionDate(new Date().toISOString().split('T')[0]);
    // Generate auto receipt number suggestion
    const rand = Math.floor(100 + Math.random() * 900);
    setReceiptNumber(`JK-ITI-${new Date().getFullYear()}-${rand}`);
    setMode('Bank Transfer');
    setRemarks('');
    setAutoUpdateSchemeStatus(true);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (c: Contribution) => {
    setEditingContribution(c);
    setSelectedItiId(c.itiId);
    setSelectedSchemeId(c.schemeId);
    setAmount(c.amount);
    setContributionDate(c.contributionDate || new Date().toISOString().split('T')[0]);
    setReceiptNumber(c.receiptNumber || '');
    setMode(c.mode || 'Bank Transfer');
    setRemarks(c.remarks || '');
    setAutoUpdateSchemeStatus(true);
    setIsModalOpen(true);
  };

  // One-click quick update of a scheme's status directly from this page
  const handleUpdateSchemeStatusDirect = async (
    schemeId: string,
    newStatus: Scheme['status'],
    schemeName: string
  ) => {
    try {
      await updateScheme(schemeId, { status: newStatus });
      onNotify('success', `Scheme "${schemeName}" status updated to ${newStatus} in database.`);
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to update scheme status in database.');
    }
  };

  // Synchronize all scheme statuses with actual contribution data in database
  const handleSyncAllSchemeStatuses = async () => {
    setIsSyncingSchemes(true);
    let updatedCount = 0;
    try {
      for (const scheme of schemes) {
        const agg = schemeAggregates.get(scheme.id);
        const collected = agg ? agg.totalCollected : 0;
        const reachedTarget = collected >= scheme.targetAmount && scheme.targetAmount > 0;

        if (reachedTarget && scheme.status !== 'Completed') {
          await updateScheme(scheme.id, { status: 'Completed' });
          updatedCount++;
        } else if (!reachedTarget && scheme.status === 'Completed' && scheme.targetAmount > 0) {
          await updateScheme(scheme.id, { status: 'Active' });
          updatedCount++;
        }
      }

      if (updatedCount > 0) {
        onNotify('success', `Successfully synchronized ${updatedCount} scheme status(es) in database based on actual collected contributions.`);
      } else {
        onNotify('info', 'All scheme statuses are already perfectly in sync with collected contributions in database.');
      }
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to sync scheme statuses in database.');
    } finally {
      setIsSyncingSchemes(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = Number(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      onNotify('error', 'Contribution amount must be a positive number greater than 0.');
      return;
    }
    if (!selectedItiId) {
      onNotify('error', 'Please select an ITI.');
      return;
    }
    if (!selectedSchemeId) {
      onNotify('error', 'Please select a scheme.');
      return;
    }

    const itiObj = trainingCenters.find((tc) => tc.id === selectedItiId);
    const itiName = itiObj ? itiObj.name : 'Unknown ITI';
    const division: Division = itiObj ? itiObj.division : 'Kashmir Division';

    // Always fetch latest name from live schemes in database
    const schemeObj = schemes.find((s) => s.id === selectedSchemeId);
    const schemeName = schemeObj ? schemeObj.name : 'Unknown Scheme';

    setIsSubmitting(true);
    try {
      if (editingContribution) {
        await updateContribution(editingContribution.id, {
          itiId: selectedItiId,
          itiName,
          division,
          schemeId: selectedSchemeId,
          schemeName,
          amount: numAmount,
          contributionDate,
          receiptNumber: receiptNumber.trim(),
          mode,
          remarks: remarks.trim(),
        });
        onNotify('success', `Updated contribution of ${formatCurrency(numAmount)} for ${itiName}.`);
      } else {
        await addContribution({
          itiId: selectedItiId,
          itiName,
          division,
          schemeId: selectedSchemeId,
          schemeName,
          amount: numAmount,
          contributionDate,
          receiptNumber: receiptNumber.trim(),
          mode,
          remarks: remarks.trim(),
        });
        onNotify('success', `Recorded contribution of ${formatCurrency(numAmount)} for ${itiName}.`);
      }

      // Check if we should automatically update the scheme's status in database
      if (autoUpdateSchemeStatus && schemeObj && schemeObj.targetAmount > 0) {
        const existingAgg = schemeAggregates.get(selectedSchemeId);
        const prevCollected = existingAgg ? existingAgg.totalCollected : 0;
        const baseline = editingContribution && editingContribution.schemeId === selectedSchemeId
          ? Math.max(0, prevCollected - (editingContribution.amount || 0))
          : prevCollected;
        const newTotal = baseline + numAmount;

        if (newTotal >= schemeObj.targetAmount && schemeObj.status !== 'Completed') {
          await updateScheme(schemeObj.id, { status: 'Completed' });
          onNotify('info', `Target achieved! Scheme "${schemeObj.name}" status updated to "Completed" in database.`);
        }
      }

      setIsModalOpen(false);
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to record contribution.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteContribution(deleteTarget.id);
      onNotify('success', `Deleted contribution record of ${formatCurrency(deleteTarget.amount)}.`);
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to delete contribution.');
    } finally {
      setDeleteTarget(null);
    }
  };

  const renderStatusBadge = (status: Scheme['status']) => {
    switch (status) {
      case 'Active':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
            <span>ACTIVE</span>
          </span>
        );
      case 'Completed':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-blue-100 text-blue-800 border border-blue-200">
            <Check className="w-3 h-3 text-blue-700" />
            <span>COMPLETED</span>
          </span>
        );
      case 'Pending':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-800 border border-amber-200">
            <Clock className="w-3 h-3 text-amber-700" />
            <span>PENDING</span>
          </span>
        );
      case 'Upcoming':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-purple-100 text-purple-800 border border-purple-200">
            <Sparkles className="w-3 h-3 text-purple-700" />
            <span>UPCOMING</span>
          </span>
        );
      case 'Inactive':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-700 border border-slate-300">
            <span>INACTIVE</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-[#0F2942] text-white p-6 rounded-xl border border-blue-900 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
              <Layers className="w-4 h-4" />
              <span>Directorate of Skill Development &bull; Scheme Fund Remittances</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black uppercase tracking-tight">
              MANAGE SCHEME CONTRIBUTIONS &amp; REAL-TIME STATUS
            </h2>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl">
              Record fund remittances from ITIs, connect directly with live schemes in the database, monitor target achievement, and maintain synchronized scheme statuses.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              id="admin-record-contribution-btn"
              onClick={handleOpenAdd}
              className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>RECORD NEW CONTRIBUTION</span>
            </button>

            <button
              type="button"
              disabled={isSyncingSchemes}
              onClick={handleSyncAllSchemeStatuses}
              className="px-3.5 py-2 rounded-lg bg-blue-800 hover:bg-blue-700 text-amber-300 font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs disabled:opacity-50"
              title="Automatically synchronize scheme statuses with collected contributions in Firestore"
            >
              <RefreshCw className={`w-4 h-4 ${isSyncingSchemes ? 'animate-spin' : ''}`} />
              <span>SYNC SCHEME STATUSES</span>
            </button>
          </div>
        </div>

        {/* Global Financial Metrics Cards */}
        <div className="mt-5 pt-4 border-t border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700">
            <span className="text-[11px] text-slate-400 block font-semibold">Total Collections</span>
            <span className="text-base sm:text-lg font-black font-mono text-emerald-400">
              {formatCurrency(totalFundsCollected)}
            </span>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700">
            <span className="text-[11px] text-slate-400 block font-semibold">Total Scheme Target</span>
            <span className="text-base sm:text-lg font-black font-mono text-amber-300">
              {formatCurrency(totalTargetSum)}
            </span>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700">
            <span className="text-[11px] text-slate-400 block font-semibold">Overall Progress</span>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-base sm:text-lg font-black font-mono text-blue-300">
                {overallAchievementPercent.toFixed(1)}%
              </span>
              <div className="flex-1 bg-slate-700 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-blue-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${overallAchievementPercent}%` }}
                ></div>
              </div>
            </div>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700">
            <span className="text-[11px] text-slate-400 block font-semibold">Active / Total Schemes</span>
            <span className="text-base sm:text-lg font-black font-mono text-white">
              {schemes.filter((s) => s.status === 'Active').length} / {schemes.length} Schemes
            </span>
          </div>
        </div>

        {/* Out of Sync Warning Banner */}
        {outOfSyncSchemesCount > 0 && (
          <div className="mt-4 bg-amber-950/80 border border-amber-700 p-3 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-amber-300">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>{outOfSyncSchemesCount} scheme(s)</strong> have completed target contributions but need their status synchronized in database.
              </span>
            </div>
            <button
              type="button"
              disabled={isSyncingSchemes}
              onClick={handleSyncAllSchemeStatuses}
              className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded text-xs transition-colors self-start sm:self-auto"
            >
              Sync Now ({outOfSyncSchemesCount})
            </button>
          </div>
        )}
      </div>

      {/* ======================================================== */}
      {/* LIVE SCHEMES DATABASE STATUS & PROGRESS CARDS           */}
      {/* ======================================================== */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-blue-700" />
            <h3 className="font-bold text-xs uppercase tracking-wide text-slate-900">
              Current Database Schemes &amp; Status ({schemes.length})
            </h3>
            <span className="text-[11px] text-slate-500 hidden sm:inline">
              &bull; Click any card to filter contributions or toggle scheme status
            </span>
          </div>
          <button
            type="button"
            onClick={() => setShowSchemeCards(!showSchemeCards)}
            className="text-xs text-blue-700 hover:text-blue-900 font-bold flex items-center gap-1"
          >
            <span>{showSchemeCards ? 'Hide Cards' : 'Show Cards'}</span>
            <ChevronDown
              className={`w-3.5 h-3.5 transition-transform ${
                showSchemeCards ? 'rotate-180' : ''
              }`}
            />
          </button>
        </div>

        {showSchemeCards && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 pt-1">
            {schemes.map((s) => {
              const agg = schemeAggregates.get(s.id);
              const collected = agg ? agg.totalCollected : 0;
              const count = agg ? agg.count : 0;
              const percent =
                s.targetAmount > 0
                  ? Math.min(100, (collected / s.targetAmount) * 100)
                  : 0;
              const isSelected = schemeFilter === s.id;
              const isTargetAchieved = collected >= s.targetAmount && s.targetAmount > 0;

              return (
                <div
                  key={s.id}
                  className={`p-4 rounded-xl border transition-all flex flex-col justify-between ${
                    isSelected
                      ? 'bg-blue-50/80 border-blue-500 ring-2 ring-blue-300'
                      : 'bg-slate-50/50 border-slate-200 hover:border-slate-300 hover:bg-white'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-1.5">
                        {renderStatusBadge(s.status)}
                        {isTargetAchieved && s.status !== 'Completed' && (
                          <span className="text-[10px] font-black text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded">
                            Target Met
                          </span>
                        )}
                      </div>

                      {/* Direct status switcher dropdown for quick updates */}
                      <select
                        value={s.status}
                        onChange={(e) =>
                          handleUpdateSchemeStatusDirect(
                            s.id,
                            e.target.value as Scheme['status'],
                            s.name
                          )
                        }
                        className="text-[11px] bg-white border border-slate-300 rounded px-1.5 py-0.5 font-bold text-slate-700 hover:border-blue-500 focus:outline-hidden"
                        title="Change scheme status in Firestore database"
                      >
                        <option value="Active">Active</option>
                        <option value="Completed">Completed</option>
                        <option value="Pending">Pending</option>
                        <option value="Upcoming">Upcoming</option>
                        <option value="Inactive">Inactive</option>
                      </select>
                    </div>

                    <h4 className="font-bold text-xs text-[#0F2942] line-clamp-1" title={s.name}>
                      {s.name}
                    </h4>

                    {s.description && (
                      <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                        {s.description}
                      </p>
                    )}

                    {/* Progress Bar & Amounts */}
                    <div className="mt-3 space-y-1.5">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-600 font-semibold">
                          Collected: <strong className="font-mono text-emerald-700">{formatCurrency(collected)}</strong>
                        </span>
                        <span className="text-slate-500 font-mono">
                          Target: {formatCurrency(s.targetAmount)}
                        </span>
                      </div>

                      <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${
                            percent >= 100
                              ? 'bg-blue-600'
                              : percent >= 50
                              ? 'bg-emerald-600'
                              : 'bg-amber-500'
                          }`}
                          style={{ width: `${percent}%` }}
                        ></div>
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-slate-500 pt-0.5">
                        <span>{percent.toFixed(1)}% Realized</span>
                        <span>{count} Remittances</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-slate-200/80 flex items-center justify-between gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => setSchemeFilter(isSelected ? 'All' : s.id)}
                      className={`px-2.5 py-1 rounded text-[11px] font-bold transition-colors ${
                        isSelected
                          ? 'bg-blue-700 text-white'
                          : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {isSelected ? '✓ Filtering' : 'Filter Table'}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setSelectedSchemeId(s.id);
                        handleOpenAdd();
                      }}
                      className="px-2.5 py-1 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-[11px] flex items-center gap-1 transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                      <span>+ Remit</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ======================================================== */}
      {/* FILTER TOOLBAR                                          */}
      {/* ======================================================== */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3 text-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* Search box */}
          <div className="relative w-full lg:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="admin-contrib-search"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search ITI, scheme, receipt, remarks..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs focus:bg-white focus:outline-hidden text-slate-800"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Division Filter */}
            <select
              value={divisionFilter}
              onChange={(e) => setDivisionFilter(e.target.value as any)}
              className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 font-semibold focus:outline-hidden"
            >
              <option value="All">All Divisions</option>
              <option value="Kashmir Division">Kashmir Division (ITIs 1–24)</option>
              <option value="Jammu Division">Jammu Division (ITIs 25–50)</option>
            </select>

            {/* ITI Filter */}
            <select
              id="admin-contrib-iti-filter"
              value={itiFilter}
              onChange={(e) => setItiFilter(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-hidden max-w-[180px]"
            >
              <option value="All">All ITIs (50)</option>
              {trainingCenters.map((tc) => (
                <option key={tc.id} value={tc.id}>
                  {tc.sNo}. {tc.name}
                </option>
              ))}
            </select>

            {/* Scheme Filter */}
            <select
              id="admin-contrib-scheme-filter"
              value={schemeFilter}
              onChange={(e) => setSchemeFilter(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 font-semibold focus:outline-hidden max-w-[200px]"
            >
              <option value="All">All Schemes ({schemes.length})</option>
              {schemes.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} [{s.status}]
                </option>
              ))}
            </select>

            {/* Scheme Status Filter */}
            <select
              value={schemeStatusFilter}
              onChange={(e) => setSchemeStatusFilter(e.target.value as any)}
              className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 font-semibold focus:outline-hidden"
            >
              <option value="All">All Scheme Statuses</option>
              <option value="Active">Active Schemes</option>
              <option value="Completed">Completed Schemes</option>
              <option value="Pending">Pending Schemes</option>
              <option value="Inactive">Inactive Schemes</option>
            </select>

            {(searchTerm || itiFilter !== 'All' || schemeFilter !== 'All' || divisionFilter !== 'All' || schemeStatusFilter !== 'All') && (
              <button
                type="button"
                onClick={() => {
                  setSearchTerm('');
                  setItiFilter('All');
                  setSchemeFilter('All');
                  setDivisionFilter('All');
                  setSchemeStatusFilter('All');
                }}
                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-lg text-xs"
              >
                Reset Filters
              </button>
            )}
          </div>
        </div>

        {/* Active Filter Chips */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-[11px] text-slate-500">
          <span>Showing <strong>{filteredContributions.length}</strong> of {contributions.length} total remittances</span>
          {schemeFilter !== 'All' && (
            <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded font-bold flex items-center gap-1">
              Scheme: {schemesMap.get(schemeFilter)?.name || schemeFilter}
              <button onClick={() => setSchemeFilter('All')} className="hover:text-blue-950 font-black">×</button>
            </span>
          )}
          {schemeStatusFilter !== 'All' && (
            <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-bold flex items-center gap-1">
              Status: {schemeStatusFilter}
              <button onClick={() => setSchemeStatusFilter('All')} className="hover:text-amber-950 font-black">×</button>
            </span>
          )}
        </div>
      </div>

      {/* ======================================================== */}
      {/* CONTRIBUTIONS TABLE                                      */}
      {/* ======================================================== */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                <th className="py-3 px-3.5 text-center w-12">#</th>
                <th className="py-3 px-4 min-w-[200px]">Training Center (ITI)</th>
                <th className="py-3 px-4 min-w-[240px]">Scheme &amp; Database Status</th>
                <th className="py-3 px-4 text-right">Amount Remitted (₹)</th>
                <th className="py-3 px-4 text-center">Date</th>
                <th className="py-3 px-4">Receipt / Mode</th>
                <th className="py-3 px-4">Remarks</th>
                <th className="py-3 px-4 text-right w-24">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredContributions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-slate-500">
                    <Receipt className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="font-semibold text-slate-700">No contribution records match the current filters.</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">Click "RECORD NEW CONTRIBUTION" above to add new fund entries.</p>
                  </td>
                </tr>
              ) : (
                filteredContributions.map((c, idx) => {
                  // Resolve live scheme data from current database
                  const liveScheme = schemesMap.get(c.schemeId);
                  const schemeName = liveScheme ? liveScheme.name : c.schemeName;
                  const schemeStatus = liveScheme ? liveScheme.status : 'Pending';
                  const schemeTarget = liveScheme?.targetAmount || 0;
                  const agg = schemeAggregates.get(c.schemeId);
                  const schemeTotalCollected = agg ? agg.totalCollected : 0;
                  const schemePercent = schemeTarget > 0 ? ((schemeTotalCollected / schemeTarget) * 100).toFixed(0) : '0';

                  return (
                    <tr
                      key={c.id}
                      className={`hover:bg-slate-50 transition-colors ${
                        idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/40'
                      }`}
                    >
                      <td className="py-2.5 px-3.5 text-center font-bold text-slate-500">
                        {idx + 1}
                      </td>

                      <td className="py-2.5 px-4 font-bold text-slate-900">
                        <div className="flex flex-col">
                          <span>{c.itiName}</span>
                          <span className="text-[10px] text-slate-500 font-semibold">{c.division}</span>
                        </div>
                      </td>

                      {/* Connected Scheme column with live status badge */}
                      <td className="py-2.5 px-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            {renderStatusBadge(schemeStatus)}
                            <span className="font-bold text-slate-800 text-xs">
                              {schemeName}
                            </span>
                          </div>

                          {schemeTarget > 0 && (
                            <div className="text-[10px] text-slate-500 flex items-center gap-2">
                              <span>Scheme Total: <strong>{formatCurrency(schemeTotalCollected)}</strong> / {formatCurrency(schemeTarget)}</span>
                              <span className="font-bold text-blue-700">({schemePercent}%)</span>
                            </div>
                          )}
                        </div>
                      </td>

                      <td className="py-2.5 px-4 text-right font-mono font-black text-emerald-700 text-sm">
                        {formatCurrency(c.amount)}
                      </td>

                      <td className="py-2.5 px-4 text-center font-mono text-slate-600 whitespace-nowrap">
                        {formatDate(c.contributionDate)}
                      </td>

                      <td className="py-2.5 px-4 text-slate-600">
                        <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded text-slate-800 font-semibold">
                          {c.receiptNumber || 'N/A'}
                        </span>
                        <span className="ml-1.5 text-[10px] text-slate-500 block sm:inline">
                          ({c.mode || 'Bank Transfer'})
                        </span>
                      </td>

                      <td className="py-2.5 px-4 text-slate-500 text-[11px] truncate max-w-xs">
                        {c.remarks || '—'}
                      </td>

                      <td className="py-2.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            id={`edit-contrib-${c.id}`}
                            onClick={() => handleOpenEdit(c)}
                            className="p-1 text-blue-700 hover:bg-blue-50 rounded"
                            title="Edit Contribution"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            id={`delete-contrib-${c.id}`}
                            onClick={() => setDeleteTarget(c)}
                            className="p-1 text-rose-700 hover:bg-rose-50 rounded"
                            title="Delete Contribution"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ======================================================== */}
      {/* RECORD / EDIT CONTRIBUTION MODAL                         */}
      {/* ======================================================== */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden animate-scaleUp">
            <div className="bg-[#0F2942] text-white p-5 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold uppercase">
                  {editingContribution ? 'EDIT SCHEME CONTRIBUTION' : 'RECORD NEW SCHEME CONTRIBUTION'}
                </h3>
                <p className="text-[11px] text-slate-300">
                  Connect remittance with current event in Firestore database
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
              {/* ITI Selection */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Select Training Center (ITI) *
                  </label>
                  <select
                    required
                    value={selectedItiId}
                    onChange={(e) => setSelectedItiId(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 font-semibold"
                  >
                    {trainingCenters.map((tc) => (
                      <option key={tc.id} value={tc.id}>
                        {tc.sNo}. {tc.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Division (Auto-set)
                  </label>
                  <input
                    type="text"
                    disabled
                    value={currentModalIti?.division || 'Kashmir Division'}
                    className="w-full p-2 bg-slate-100 border border-slate-300 rounded-lg text-slate-600 font-bold"
                  />
                </div>
              </div>

              {/* Event Selection */}
              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  SELECT EVENT *
                </label>
                <select
                  required
                  value={selectedSchemeId}
                  onChange={(e) => setSelectedSchemeId(e.target.value)}
                  className="w-full p-2 bg-blue-50/80 border border-blue-300 rounded-lg text-slate-900 font-bold"
                >
                  <optgroup label="ACTIVE EVENTS">
                    {schemes
                      .filter((s) => s.status === 'Active')
                      .map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name} (Target: {formatCurrency(s.targetAmount)}) [ACTIVE]
                        </option>
                      ))}
                  </optgroup>
                  <optgroup label="OTHER EVENTS (Pending / Completed)">
                    {schemes
                      .filter((s) => s.status !== 'Active')
                      .map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name} (Target: {formatCurrency(s.targetAmount)}) [{s.status}]
                        </option>
                      ))}
                  </optgroup>
                </select>
              </div>

              {/* Real-time Connected Scheme Status Box in Modal */}
              {currentModalScheme && currentModalSchemeAgg && (
                <div className="bg-slate-50 border border-blue-200 rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] uppercase font-bold text-slate-500">Live Status:</span>
                      {renderStatusBadge(currentModalScheme.status)}
                    </div>
                    <span className="font-mono text-slate-600 text-[11px]">
                      Target: <strong>{formatCurrency(currentModalScheme.targetAmount)}</strong>
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-slate-200">
                    <div>
                      <span className="text-slate-500 block">Collected So Far:</span>
                      <strong className="font-mono text-emerald-700">
                        {formatCurrency(currentModalSchemeAgg.currentCollected)}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Projected with this Entry:</span>
                      <strong className="font-mono text-blue-700">
                        {formatCurrency(currentModalSchemeAgg.projectedTotal)} ({currentModalSchemeAgg.projectedPercent.toFixed(1)}%)
                      </strong>
                    </div>
                  </div>

                  {currentModalSchemeAgg.willAchieveTarget && (
                    <div className="bg-emerald-100 text-emerald-900 border border-emerald-300 px-2.5 py-1.5 rounded text-[11px] font-bold flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                      <span>This remittance will complete 100% of the scheme target!</span>
                    </div>
                  )}
                </div>
              )}

              {/* Amount and Date */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Contribution Amount (₹) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="1"
                    required
                    value={amount}
                    onChange={(e) =>
                      setAmount(e.target.value === '' ? '' : Number(e.target.value))
                    }
                    placeholder="e.g. 50000"
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono font-bold text-emerald-800 text-sm"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Contribution Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={contributionDate}
                    onChange={(e) => setContributionDate(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 font-semibold"
                  />
                </div>
              </div>

              {/* Receipt and Mode */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Receipt / Reference No.
                  </label>
                  <input
                    type="text"
                    value={receiptNumber}
                    onChange={(e) => setReceiptNumber(e.target.value)}
                    placeholder="e.g. REC-2025-001"
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-800"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Payment Mode
                  </label>
                  <select
                    value={mode}
                    onChange={(e) => setMode(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 font-semibold"
                  >
                    <option value="Bank Transfer">Bank Transfer (NEFT/RTGS)</option>
                    <option value="Online">Online / UPI Portal</option>
                    <option value="Cheque">Cheque / Demand Draft</option>
                    <option value="Treasury Challan">Treasury Challan</option>
                    <option value="Cash">Cash (Counter Deposit)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Remarks / Notes
                </label>
                <input
                  type="text"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="e.g. First installment deposited via J&K Bank"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800"
                />
              </div>

              {/* Auto update scheme status checkbox */}
              <div className="pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-slate-700 font-semibold">
                  <input
                    type="checkbox"
                    checked={autoUpdateSchemeStatus}
                    onChange={(e) => setAutoUpdateSchemeStatus(e.target.checked)}
                    className="w-4 h-4 rounded text-blue-700 focus:ring-blue-500"
                  />
                  <span>Auto-update Scheme status to 'Completed' in database if target is reached</span>
                </label>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold disabled:opacity-50 flex items-center gap-1.5 shadow-sm"
                >
                  {isSubmitting ? 'Recording...' : editingContribution ? 'Update Contribution' : 'Save Contribution'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={!!deleteTarget}
        title="Confirm Contribution Deletion"
        message={`Are you sure you want to delete this contribution of ${formatCurrency(
          deleteTarget?.amount
        )} for ${deleteTarget?.itiName}? This action will adjust the scheme's collected total in the database.`}
        confirmText="Yes, Delete Record"
        cancelText="Cancel"
        isDanger={true}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};
