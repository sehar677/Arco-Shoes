import React, { useState, useMemo, useEffect } from 'react';
import { TrainingCenter, Division, OFFICIAL_JK_ITIS, OfficialIti } from '../../types';
import {
  addTrainingCenter,
  batchAddTrainingCenters,
  updateTrainingCenter,
  deleteTrainingCenter,
  refreshFirebaseConnection,
} from '../../services/db';
import { ConfirmModal } from '../../components/ConfirmModal';
import {
  Search,
  Plus,
  Edit2,
  Trash2,
  Building2,
  MapPin,
  X,
  CheckCircle2,
  Layers,
  ArrowLeft,
  Sparkles,
  RefreshCw,
  PlusCircle,
  Check,
} from 'lucide-react';

interface ManageTrainingCentersProps {
  trainingCenters: TrainingCenter[];
  initialView?: 'list' | 'add';
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const ManageTrainingCenters: React.FC<ManageTrainingCentersProps> = ({
  trainingCenters,
  initialView = 'list',
  onNotify,
}) => {
  const [currentView, setCurrentView] = useState<'list' | 'add'>(initialView);

  useEffect(() => {
    if (initialView) {
      setCurrentView(initialView);
    }
  }, [initialView]);

  // List view state
  const [searchTerm, setSearchTerm] = useState('');
  const [divisionFilter, setDivisionFilter] = useState<'All' | Division>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCenter, setEditingCenter] = useState<TrainingCenter | null>(null);

  // Form states (used in both modal and dedicated Add page)
  const [name, setName] = useState('');
  const [division, setDivision] = useState<Division>('Kashmir Division');
  const [location, setLocation] = useState('');
  const [status, setStatus] = useState<'Active' | 'Inactive'>('Active');
  const [remarks, setRemarks] = useState('');
  const [sNo, setSNo] = useState<number>(51);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isBatchAdding, setIsBatchAdding] = useState(false);
  const [isRefreshingFirebase, setIsRefreshingFirebase] = useState(false);

  // Add Page catalog filter states
  const [catalogDivisionFilter, setCatalogDivisionFilter] = useState<'All' | Division>('All');
  const [catalogSearch, setCatalogSearch] = useState('');

  // Delete modal state
  const [deleteTarget, setDeleteTarget] = useState<TrainingCenter | null>(null);

  // Set of existing ITI names for fast lookup
  const existingNamesSet = useMemo(() => {
    return new Set(
      trainingCenters.map((tc) => tc.name.toLowerCase().trim().replace(/\s+/g, ' '))
    );
  }, [trainingCenters]);

  const existingSNoSet = useMemo(() => {
    return new Set(trainingCenters.map((tc) => tc.sNo));
  }, [trainingCenters]);

  // Check if an official ITI is already added
  const isItiInSystem = (official: OfficialIti) => {
    const normalized = official.name.toLowerCase().trim().replace(/\s+/g, ' ');
    return existingNamesSet.has(normalized) || existingSNoSet.has(official.sNo);
  };

  const filteredCenters = useMemo(() => {
    return trainingCenters.filter((tc) => {
      const matchesSearch =
        tc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tc.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (tc.remarks && tc.remarks.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchesDivision = divisionFilter === 'All' || tc.division === divisionFilter;
      return matchesSearch && matchesDivision;
    });
  }, [trainingCenters, searchTerm, divisionFilter]);

  // Filtered official ITIs for the Add page catalog
  const filteredOfficialCatalog = useMemo(() => {
    return OFFICIAL_JK_ITIS.filter((iti) => {
      const matchesDiv =
        catalogDivisionFilter === 'All' || iti.division === catalogDivisionFilter;
      const matchesSearch =
        iti.name.toLowerCase().includes(catalogSearch.toLowerCase()) ||
        iti.district.toLowerCase().includes(catalogSearch.toLowerCase()) ||
        iti.location.toLowerCase().includes(catalogSearch.toLowerCase()) ||
        iti.sNo.toString().includes(catalogSearch);
      return matchesDiv && matchesSearch;
    });
  }, [catalogDivisionFilter, catalogSearch]);

  const kashmirOfficial = useMemo(
    () => OFFICIAL_JK_ITIS.filter((i) => i.division === 'Kashmir Division'),
    []
  );
  const jammuOfficial = useMemo(
    () => OFFICIAL_JK_ITIS.filter((i) => i.division === 'Jammu Division'),
    []
  );

  const missingKashmirCount = useMemo(
    () => kashmirOfficial.filter((i) => !isItiInSystem(i)).length,
    [kashmirOfficial, existingNamesSet, existingSNoSet]
  );
  const missingJammuCount = useMemo(
    () => jammuOfficial.filter((i) => !isItiInSystem(i)).length,
    [jammuOfficial, existingNamesSet, existingSNoSet]
  );
  const missingTotalCount = missingKashmirCount + missingJammuCount;

  const handleOpenAddModal = () => {
    setEditingCenter(null);
    setName('');
    setDivision('Kashmir Division');
    setLocation('');
    setStatus('Active');
    setRemarks('');
    const maxSNo = trainingCenters.reduce((max, c) => Math.max(max, c.sNo || 0), 0);
    setSNo(maxSNo + 1);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (tc: TrainingCenter) => {
    setEditingCenter(tc);
    setName(tc.name);
    setDivision(tc.division);
    setLocation(tc.location || '');
    setStatus(tc.status);
    setRemarks(tc.remarks || '');
    setSNo(tc.sNo);
    setIsModalOpen(true);
  };

  // Populate form with an official ITI's exact values with blank remarks
  const handleSelectOfficialIti = (official: OfficialIti) => {
    setName(official.name);
    setDivision(official.division);
    setLocation(official.location);
    setSNo(official.sNo);
    setStatus('Active');
    setRemarks('');
    onNotify('info', `Loaded details for "${official.name}". Ready to save.`);
  };

  // Quick 1-click add for a single official ITI with blank remarks
  const handleQuickAddSingle = async (official: OfficialIti) => {
    setIsSubmitting(true);
    try {
      await addTrainingCenter({
        sNo: official.sNo,
        name: official.name,
        division: official.division,
        location: official.location,
        status: 'Active',
        remarks: '',
        instructorCount: 0,
      });
      onNotify('success', `Added "${official.name}" to training centers with blank remarks.`);
    } catch (err: any) {
      onNotify('error', err.message || `Failed to add ${official.name}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Batch add missing ITIs with blank remarks
  const handleBatchAdd = async (divFilter?: Division) => {
    let targets = OFFICIAL_JK_ITIS.filter((i) => !isItiInSystem(i));
    if (divFilter) {
      targets = targets.filter((i) => i.division === divFilter);
    }

    if (targets.length === 0) {
      onNotify('info', 'All ITIs in this category are already present in the database.');
      return;
    }

    setIsBatchAdding(true);
    try {
      const itemsToAdd = targets.map((official) => ({
        sNo: official.sNo,
        name: official.name,
        division: official.division,
        location: official.location,
        status: 'Active' as const,
        remarks: '',
        instructorCount: 0,
      }));

      const addedCount = await batchAddTrainingCenters(itemsToAdd);
      onNotify(
        'success',
        `Successfully added ${addedCount || targets.length} ITIs (${
          divFilter || 'All Official J&K ITIs'
        }) to records with blank remarks.`
      );
    } catch (err: any) {
      onNotify('error', err.message || 'Batch addition error occurred.');
    } finally {
      setIsBatchAdding(false);
    }
  };

  // Refresh and reconnect to Firebase Database
  const handleRefreshFirebase = async () => {
    setIsRefreshingFirebase(true);
    try {
      const res = await refreshFirebaseConnection();
      if (res.connected) {
        onNotify(
          'success',
          `Connected to Firebase database! (${res.counts.trainingCenters || 0} ITIs, ${res.counts.instructors || 0} instructors synchronized).`
        );
      } else {
        onNotify('error', res.error || 'Failed to connect to Firebase database.');
      }
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to connect to Firebase database.');
    } finally {
      setIsRefreshingFirebase(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      onNotify('error', 'ITI Name is required');
      return;
    }

    setIsSubmitting(true);
    try {
      if (editingCenter) {
        await updateTrainingCenter(editingCenter.id, {
          name: name.trim(),
          division,
          location: location.trim() || 'Not Available',
          status,
          remarks: remarks.trim(),
          sNo: Number(sNo) || editingCenter.sNo,
        });
        onNotify('success', `Updated "${name}" successfully.`);
        setIsModalOpen(false);
      } else {
        await addTrainingCenter({
          sNo: Number(sNo) || trainingCenters.length + 1,
          name: name.trim(),
          division,
          location: location.trim() || 'Not Available',
          status,
          remarks: remarks.trim(),
          instructorCount: 0,
        });
        onNotify('success', `Added new ITI "${name}" successfully.`);
        setIsModalOpen(false);
        // Clear form
        setName('');
        setLocation('');
        setRemarks('');
      }
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to save Training Center.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteTrainingCenter(deleteTarget.id);
      onNotify('success', `Deleted ITI "${deleteTarget.name}".`);
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to delete Training Center.');
    } finally {
      setDeleteTarget(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* View Switcher Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setCurrentView('list')}
            className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
              currentView === 'list'
                ? 'bg-[#0F2942] text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>ALL TRAINING CENTERS ({trainingCenters.length})</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setCurrentView('add');
              handleOpenAddModal();
              setIsModalOpen(false); // keep on dedicated page view
            }}
            className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
              currentView === 'add'
                ? 'bg-blue-800 text-amber-300 shadow-xs ring-2 ring-blue-700'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Plus className="w-4 h-4 text-amber-500" />
            <span>ADD NEW TRAINING CENTER</span>
            {missingTotalCount > 0 && (
              <span className="bg-amber-500 text-slate-950 px-1.5 py-0.5 rounded-full text-[10px] font-black">
                {missingTotalCount} missing
              </span>
            )}
          </button>
        </div>

        {currentView === 'list' ? (
          <button
            type="button"
            id="admin-add-iti-btn"
            onClick={() => setCurrentView('add')}
            className="px-4 py-2 rounded-lg bg-[#0F2942] hover:bg-[#183d63] text-amber-400 font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Open Add Center Page</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setCurrentView('list')}
            className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Table</span>
          </button>
        )}
      </div>

      {/* ======================================================== */}
      {/* VIEW: ADD NEW TRAINING CENTER PAGE                      */}
      {/* ======================================================== */}
      {currentView === 'add' && (
        <div className="space-y-6">
          {/* Header Card */}
          <div className="bg-[#0F2942] text-white p-6 rounded-xl border border-blue-900 shadow-md">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
                  <Sparkles className="w-4 h-4" />
                  <span>Directorate of Skill Development &bull; Jammu &amp; Kashmir</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black uppercase tracking-tight">
                  ADD NEW TRAINING CENTER (ITI)
                </h2>
                <p className="text-xs text-slate-300 mt-1">
                  Select and register official Government ITIs for Kashmir Division (1–24) and Jammu Division (25–50), or input custom vocational institutes.
                </p>
              </div>

              {/* Summary Stats & Batch Actions */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="bg-slate-800/90 border border-slate-700 px-3.5 py-2 rounded-lg text-center">
                  <span className="block text-lg font-black text-amber-400">
                    {trainingCenters.length} / 50
                  </span>
                  <span className="text-[10px] uppercase font-bold text-slate-400">
                    Registered ITIs
                  </span>
                </div>
                <div className="bg-blue-950/80 border border-blue-800 px-3.5 py-2 rounded-lg text-center">
                  <span className="block text-lg font-black text-blue-300">
                    {kashmirOfficial.length - missingKashmirCount} / 24
                  </span>
                  <span className="text-[10px] uppercase font-bold text-blue-300">Kashmir Div</span>
                </div>
                <div className="bg-emerald-950/80 border border-emerald-800 px-3.5 py-2 rounded-lg text-center">
                  <span className="block text-lg font-black text-emerald-300">
                    {jammuOfficial.length - missingJammuCount} / 26
                  </span>
                  <span className="text-[10px] uppercase font-bold text-emerald-300">Jammu Div</span>
                </div>
              </div>
            </div>

          </div>

          {/* TWO COLUMN WORKSPACE: Registration Form (Left) & Official Catalog (Right) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Registration Form Card */}
            <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden sticky top-20">
              <div className="bg-[#0F2942] text-white px-5 py-4 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wide">
                    Training Center Details Form
                  </h3>
                  <p className="text-[11px] text-slate-300">
                    Input details below or click any official ITI on the right to pre-fill
                  </p>
                </div>
                <Building2 className="w-5 h-5 text-amber-400 shrink-0" />
              </div>

              <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
                {/* Fast Preset Selector */}
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Quick Preset from Official Catalog
                  </label>
                  <select
                    onChange={(e) => {
                      const selectedSNo = Number(e.target.value);
                      const found = OFFICIAL_JK_ITIS.find((i) => i.sNo === selectedSNo);
                      if (found) handleSelectOfficialIti(found);
                    }}
                    value={
                      OFFICIAL_JK_ITIS.find((i) => i.name === name && i.sNo === sNo)?.sNo || ''
                    }
                    className="w-full p-2.5 bg-blue-50/70 border border-blue-300 rounded-lg text-slate-800 font-medium focus:bg-white focus:outline-blue-800"
                  >
                    <option value="">-- Choose from 50 Official J&amp;K ITIs --</option>
                    <optgroup label="KASHMIR DIVISION (ITIs 1–24)">
                      {kashmirOfficial.map((i) => (
                        <option key={`opt-${i.sNo}`} value={i.sNo}>
                          #{i.sNo} {i.name} ({i.district}) {isItiInSystem(i) ? '✓' : ''}
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="JAMMU DIVISION (ITIs 25–50)">
                      {jammuOfficial.map((i) => (
                        <option key={`opt-${i.sNo}`} value={i.sNo}>
                          #{i.sNo} {i.name} ({i.district}) {isItiInSystem(i) ? '✓' : ''}
                        </option>
                      ))}
                    </optgroup>
                  </select>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="col-span-1">
                    <label className="block font-bold text-slate-700 uppercase mb-1">
                      S.No *
                    </label>
                    <input
                      type="number"
                      required
                      min={1}
                      value={sNo}
                      onChange={(e) => setSNo(Number(e.target.value))}
                      className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-800 focus:bg-white"
                    />
                  </div>

                  <div className="col-span-2">
                    <label className="block font-bold text-slate-700 uppercase mb-1">
                      Division *
                    </label>
                    <select
                      value={division}
                      onChange={(e) => setDivision(e.target.value as Division)}
                      className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 font-semibold focus:bg-white"
                    >
                      <option value="Kashmir Division">Kashmir Division (ITIs 1–24)</option>
                      <option value="Jammu Division">Jammu Division (ITIs 25–50)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Name of ITI *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Govt. ITI Srinagar, Govt. ITI Jammu"
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 font-semibold focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Location / Specific Address
                  </label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g. Bagh-i-Ali Mardan Khan, Srinagar, Kashmir"
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 uppercase mb-1">
                      Status
                    </label>
                    <select
                      value={status}
                      onChange={(e) => setStatus(e.target.value as any)}
                      className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white"
                    >
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 uppercase mb-1">
                      Remarks / Affiliation
                    </label>
                    <input
                      type="text"
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      placeholder="e.g. Affiliated to DSD J&K"
                      className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setName('');
                      setLocation('');
                      setRemarks('');
                      setSNo(trainingCenters.length + 1);
                    }}
                    className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold"
                  >
                    Clear Form
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-5 py-2 rounded-lg bg-[#0F2942] hover:bg-[#183d63] text-amber-400 font-bold disabled:opacity-50 flex items-center gap-1.5 shadow-sm"
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>{isSubmitting ? 'Saving...' : 'Add Training Center'}</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Official Directory Quick-Select & Explorer Panel (Right) */}
            <div className="lg:col-span-7 space-y-4">
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <h3 className="font-bold text-slate-800 uppercase tracking-wide flex items-center gap-2">
                    <Layers className="w-4 h-4 text-blue-700" />
                    <span>Official J&amp;K ITI Directory Catalog</span>
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Click "Quick Add" to save instantly, or "Pre-fill" to adjust details first
                  </p>
                </div>

                <div className="relative w-full sm:w-56">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={catalogSearch}
                    onChange={(e) => setCatalogSearch(e.target.value)}
                    placeholder="Search 50 ITIs or District..."
                    className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:bg-white"
                  />
                </div>
              </div>

              {/* Division Segment Filters */}
              <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setCatalogDivisionFilter('All')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    catalogDivisionFilter === 'All'
                      ? 'bg-[#0F2942] text-white shadow-xs'
                      : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  All 50 ITIs
                </button>
                <button
                  type="button"
                  onClick={() => setCatalogDivisionFilter('Kashmir Division')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    catalogDivisionFilter === 'Kashmir Division'
                      ? 'bg-blue-800 text-white shadow-xs'
                      : 'bg-white text-slate-700 border border-slate-200 hover:bg-blue-50'
                  }`}
                >
                  Kashmir Division (1–24)
                </button>
                <button
                  type="button"
                  onClick={() => setCatalogDivisionFilter('Jammu Division')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    catalogDivisionFilter === 'Jammu Division'
                      ? 'bg-emerald-800 text-white shadow-xs'
                      : 'bg-white text-slate-700 border border-slate-200 hover:bg-emerald-50'
                  }`}
                >
                  Jammu Division (25–50)
                </button>
              </div>

              {/* Grid of Official ITIs */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[620px] overflow-y-auto pr-1">
                {filteredOfficialCatalog.map((official) => {
                  const alreadyAdded = isItiInSystem(official);
                  const isSelectedInForm = name === official.name;

                  return (
                    <div
                      key={`cat-${official.sNo}`}
                      className={`p-3.5 rounded-xl border transition-all flex flex-col justify-between ${
                        isSelectedInForm
                          ? 'bg-amber-50/80 border-amber-400 ring-2 ring-amber-300'
                          : alreadyAdded
                          ? 'bg-white border-slate-200'
                          : 'bg-blue-50/30 border-blue-200'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <span className="font-mono text-xs font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                            #{official.sNo}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              official.division === 'Kashmir Division'
                                ? 'bg-blue-50 text-blue-800 border border-blue-200'
                                : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            }`}
                          >
                            {official.division}
                          </span>
                        </div>

                        <h4 className="font-bold text-slate-900 text-xs">{official.name}</h4>
                        <p className="text-[11px] text-slate-500 flex items-center gap-1 mt-1">
                          <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                          <span className="truncate">{official.location}</span>
                        </p>
                        <span className="inline-block mt-1 text-[10px] text-slate-400 font-semibold">
                          District: {official.district}
                        </span>
                      </div>

                      <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
                        {alreadyAdded ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-1 rounded-md">
                            <Check className="w-3 h-3 text-emerald-600" />
                            <span>In Database</span>
                          </span>
                        ) : (
                          <button
                            type="button"
                            disabled={isSubmitting}
                            onClick={() => handleQuickAddSingle(official)}
                            className="px-2.5 py-1 rounded bg-blue-700 hover:bg-blue-800 text-white text-[11px] font-bold flex items-center gap-1 transition-colors"
                          >
                            <Plus className="w-3 h-3" />
                            <span>Quick Add</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => handleSelectOfficialIti(official)}
                          className={`px-2.5 py-1 rounded text-[11px] font-bold transition-colors ${
                            isSelectedInForm
                              ? 'bg-amber-400 text-slate-950'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                          }`}
                        >
                          {isSelectedInForm ? 'Selected' : 'Pre-fill Form'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* VIEW: ALL TRAINING CENTERS LIST TABLE                   */}
      {/* ======================================================== */}
      {currentView === 'list' && (
        <div className="space-y-6">
          {/* Top Header Card */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-black text-[#0F2942] uppercase tracking-wide">
                MANAGE TRAINING CENTERS (ITIs)
              </h2>
              <p className="text-xs text-slate-500">
                Directory of Government Industrial Training Institutes in Jammu &amp; Kashmir ({trainingCenters.length} active records)
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                id="admin-refresh-firebase-tc-btn"
                disabled={isRefreshingFirebase}
                onClick={handleRefreshFirebase}
                className="px-3.5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer shadow-xs"
                title="Refresh and connect Firebase database"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingFirebase ? 'animate-spin' : ''}`} />
                <span>{isRefreshingFirebase ? 'Connecting...' : 'REFRESH FIREBASE DATABASE'}</span>
              </button>

              <button
                type="button"
                id="admin-add-iti-btn"
                onClick={handleOpenAddModal}
                className="px-4 py-2 rounded-lg bg-[#0F2942] hover:bg-[#183d63] text-amber-400 font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Quick Add ITI</span>
              </button>
            </div>
          </div>

          {/* Filter Toolbar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                id="admin-tc-search"
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search ITI name, district or location..."
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs focus:bg-white focus:outline-hidden text-slate-800"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-slate-500 text-xs">Filter Division:</span>
              <select
                id="admin-tc-div-filter"
                value={divisionFilter}
                onChange={(e) => setDivisionFilter(e.target.value as any)}
                className="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-700 focus:outline-hidden"
              >
                <option value="All">All Divisions ({trainingCenters.length})</option>
                <option value="Kashmir Division">Kashmir Division (ITIs 1–24)</option>
                <option value="Jammu Division">Jammu Division (ITIs 25–50)</option>
              </select>
            </div>
          </div>

          {/* ITI Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                    <th className="py-3 px-3.5 text-center w-14">S.No</th>
                    <th className="py-3 px-4">Division</th>
                    <th className="py-3 px-4 min-w-[220px]">Name of ITI</th>
                    <th className="py-3 px-4">Location / Address</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4">Remarks</th>
                    <th className="py-3 px-4 text-right w-28">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredCenters.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-500">
                        No ITIs found matching the search criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredCenters.map((tc, idx) => (
                      <tr
                        key={tc.id}
                        className={`hover:bg-slate-50 transition-colors ${
                          idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/40'
                        }`}
                      >
                        <td className="py-2.5 px-3.5 text-center font-bold text-slate-600">
                          {tc.sNo}
                        </td>
                        <td className="py-2.5 px-4">
                          <span
                            className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                              tc.division === 'Kashmir Division'
                                ? 'bg-blue-50 text-blue-800 border border-blue-200'
                                : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            }`}
                          >
                            {tc.division}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 font-bold text-slate-900">{tc.name}</td>
                        <td className="py-2.5 px-4 text-slate-600">{tc.location || 'Not Available'}</td>
                        <td className="py-2.5 px-4 text-center">
                          <span
                            className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              tc.status === 'Active'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {tc.status}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 text-slate-500 text-[11px] truncate max-w-xs">
                          {tc.remarks || '—'}
                        </td>
                        <td className="py-2.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              id={`edit-tc-${tc.sNo}`}
                              onClick={() => handleOpenEditModal(tc)}
                              className="p-1 text-blue-700 hover:bg-blue-50 rounded"
                              title="Edit ITI"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              id={`delete-tc-${tc.sNo}`}
                              onClick={() => setDeleteTarget(tc)}
                              className="p-1 text-rose-700 hover:bg-rose-50 rounded"
                              title="Delete ITI"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* QUICK ADD / EDIT MODAL                                  */}
      {/* ======================================================== */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden animate-scaleUp">
            <div className="bg-[#0F2942] text-white p-5 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold uppercase">
                  {editingCenter ? 'EDIT TRAINING CENTER' : 'ADD NEW TRAINING CENTER'}
                </h3>
                <p className="text-[11px] text-slate-300">
                  Official Government ITI Registration Portal
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
              {/* Preset selection dropdown in modal */}
              {!editingCenter && (
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Select from 50 Official J&amp;K ITIs (Auto-fill)
                  </label>
                  <select
                    onChange={(e) => {
                      const selectedSNo = Number(e.target.value);
                      const found = OFFICIAL_JK_ITIS.find((i) => i.sNo === selectedSNo);
                      if (found) {
                        setName(found.name);
                        setDivision(found.division);
                        setLocation(found.location);
                        setSNo(found.sNo);
                        setRemarks('');
                      }
                    }}
                    value={
                      OFFICIAL_JK_ITIS.find((i) => i.name === name && i.sNo === sNo)?.sNo || ''
                    }
                    className="w-full p-2 bg-blue-50 border border-blue-300 rounded-lg text-slate-800 font-semibold"
                  >
                    <option value="">-- Choose official ITI to pre-fill --</option>
                    <optgroup label="KASHMIR DIVISION (1–24)">
                      {kashmirOfficial.map((i) => (
                        <option key={`m-opt-${i.sNo}`} value={i.sNo}>
                          #{i.sNo} {i.name} ({i.district}) {isItiInSystem(i) ? '✓' : ''}
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="JAMMU DIVISION (25–50)">
                      {jammuOfficial.map((i) => (
                        <option key={`m-opt-${i.sNo}`} value={i.sNo}>
                          #{i.sNo} {i.name} ({i.district}) {isItiInSystem(i) ? '✓' : ''}
                        </option>
                      ))}
                    </optgroup>
                  </select>
                </div>
              )}

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-1">
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    S.No *
                  </label>
                  <input
                    type="number"
                    required
                    value={sNo}
                    onChange={(e) => setSNo(Number(e.target.value))}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 font-bold"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Division *
                  </label>
                  <select
                    value={division}
                    onChange={(e) => setDivision(e.target.value as Division)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 font-semibold"
                  >
                    <option value="Kashmir Division">Kashmir Division (ITIs 1–24)</option>
                    <option value="Jammu Division">Jammu Division (ITIs 25–50)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Name of ITI *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Govt. ITI Srinagar, Govt. ITI Jammu"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 font-semibold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Location / Address
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Bagh-i-Ali Mardan Khan, Srinagar"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Remarks
                  </label>
                  <input
                    type="text"
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    placeholder="Leave blank or enter remarks"
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-lg bg-[#0F2942] hover:bg-[#183d63] text-amber-400 font-bold disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving...' : editingCenter ? 'Update ITI' : 'Create ITI'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={!!deleteTarget}
        title="Confirm ITI Deletion"
        message={`Are you sure you want to delete "${deleteTarget?.name}"? This action cannot be undone and will remove it from all departmental lists.`}
        confirmText="Yes, Delete ITI"
        cancelText="Cancel"
        isDanger={true}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};
