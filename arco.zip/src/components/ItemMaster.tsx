import React, { useState, useEffect } from 'react';
import {
  Package,
  Plus,
  Save,
  Trash2,
  Search,
  RotateCcw,
  AlertTriangle,
  CheckCircle2,
  Tag,
  Boxes,
  ArrowUpDown,
  Filter,
  Lock,
  Unlock,
  Calendar,
} from 'lucide-react';
import { Item, PRODUCT_CATEGORIES } from '../types';
import { dbService } from '../services/storage';
import { rbacService } from '../services/rbacService';
import { formatCurrency, roundTo2 } from '../services/gstCalculations';
import { SuccessPopup } from './SuccessPopup';
import { ConfirmModal } from './ConfirmModal';

const getTodayDateString = () => {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const ItemMasterComponent: React.FC = () => {
  const [items, setItems] = useState<Item[]>([]);
  const canViewPurchasePrice = rbacService.can('canViewPurchasePrice');
  const canManageInventory = rbacService.can('canManageInventory');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [itemToDelete, setItemToDelete] = useState<{ id: string; label: string } | null>(null);
  const [showClearAllModal, setShowClearAllModal] = useState<boolean>(false);

  // Form Fields
  const [itemCode, setItemCode] = useState<string>('');
  const [barcode, setBarcode] = useState<string>('');
  const [itemName, setItemName] = useState<string>('');
  const [category, setCategory] = useState<string>('General Footwear');
  const [unit, setUnit] = useState<string>('Pairs');
  const [hsnCode, setHsnCode] = useState<string>('6403');
  const [purchaseRate, setPurchaseRate] = useState<number | ''>('');
  const [sellingRate, setSellingRate] = useState<number | ''>('');
  const [mrp, setMrp] = useState<number | ''>('');
  const [gstRate, setGstRate] = useState<number>(5);
  const [createdDate, setCreatedDate] = useState<string>(getTodayDateString);
  const [minStockLevel, setMinStockLevel] = useState<number>(0);
  const [openingStock, setOpeningStock] = useState<number>(0);
  const [openingStockValue, setOpeningStockValue] = useState<number>(0);
  const [currentStock, setCurrentStock] = useState<number>(0);
  const [locationRack, setLocationRack] = useState<string>('Rack A-1');
  const [isActive, setIsActive] = useState<boolean>(true);
  const [isCodeLocked, setIsCodeLocked] = useState<boolean>(true);

  // Filtering & Search
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [filterDate, setFilterDate] = useState<string>(getTodayDateString);
  const [filterType, setFilterType] = useState<'all' | 'purchased' | 'unused'>('all');
  const [showLowStockOnly, setShowLowStockOnly] = useState<boolean>(false);

  // Feedback
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; title?: string; text: string } | null>(null);

  const loadItems = () => {
    const list = dbService.getItems();
    setItems(list);
  };

  const generateNextArticleCode = (existingItems: Item[]): string => {
    const codes = existingItems
      .map((i) => i.itemCode)
      .filter((code) => /^SH-ART-\d{3}$/.test(code));

    if (codes.length === 0) {
      return 'SH-ART-050';
    }

    const numbers = codes.map((code) => parseInt(code.split('-')[2], 10));
    const max = Math.max(...numbers);

    let nextNum = max + 1;
    let nextCode = `SH-ART-${String(nextNum).padStart(3, '0')}`;

    // Duplicate check
    while (existingItems.some((i) => i.itemCode === nextCode)) {
      nextNum++;
      nextCode = `SH-ART-${String(nextNum).padStart(3, '0')}`;
    }

    return nextCode;
  };

  useEffect(() => {
    loadItems();
    return dbService.subscribe(() => {
      loadItems();
    });
  }, []);

  const resetForm = () => {
    setSelectedId(null);
    const nextCode = generateNextArticleCode(dbService.getItems());
    setItemCode(nextCode);
    setBarcode(`890100100${nextCode.split('-')[2]}`);
    setItemName('');
    setCategory('General Footwear');
    setUnit('Pairs');
    setHsnCode('6403');
    setPurchaseRate('');
    setSellingRate('');
    setMrp('');
    setGstRate(5);
    setCreatedDate(getTodayDateString());
    setMinStockLevel(0);
    setOpeningStock(0);
    setOpeningStockValue(0);
    setCurrentStock(0);
    setLocationRack('Rack A-1');
    setIsActive(true);
    setIsCodeLocked(true);
    setFeedback(null);
  };

  useEffect(() => {
    if (!selectedId && items.length > 0) {
        resetForm();
    }
  }, []);


  const handleSelectItem = (it: Item) => {
    setSelectedId(it.id);
    setItemCode(it.itemCode);
    setBarcode(it.barcode || '');
    setItemName(it.itemName);
    setCategory(it.category);
    setUnit(it.unit);
    setHsnCode(it.hsnCode);
    setPurchaseRate(it.purchaseRate || '');
    setSellingRate(it.sellingRate || '');
    setMrp(it.mrp || it.sellingRate || '');
    setGstRate(it.gstRate);
    setCreatedDate(
      it.createdAt ? (it.createdAt.includes('T') ? it.createdAt.split('T')[0] : it.createdAt) : getTodayDateString()
    );
    setMinStockLevel(it.minStockLevel !== undefined ? it.minStockLevel : 0);
    setOpeningStock(it.openingStock || 0);
    setOpeningStockValue(it.openingStockValue || 0);
    setCurrentStock(it.currentStock);
    setLocationRack(it.locationRack || '');
    setIsActive(it.isActive);
    setIsCodeLocked(true);
    setFeedback(null);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemCode.trim()) {
      setFeedback({ type: 'error', title: 'Validation Required', text: 'Article Code is required.' });
      return;
    }
    if (!itemName.trim()) {
      setFeedback({ type: 'error', title: 'Validation Required', text: 'Item / Product Name is required.' });
      return;
    }

    const isUpdate = Boolean(selectedId);
    
    // Check for duplicate article code before saving if new item
    let finalItemCode = itemCode.trim().toUpperCase();
    if (!isUpdate) {
        const existingItems = dbService.getItems();
        if (existingItems.some(i => i.itemCode === finalItemCode)) {
            const newCode = generateNextArticleCode(existingItems);
            setItemCode(newCode);
            setFeedback({ 
                type: 'error', 
                title: 'Article Code Conflict', 
                text: `The article code "${finalItemCode}" was just taken by another user. It has been automatically updated to "${newCode}". Please review and save again.` 
            });
            return;
        }
    }

    const item: Item = {
      id: selectedId || `ITM-${Date.now()}`,
      itemCode: finalItemCode,
      barcode: barcode.trim(),
      itemName: itemName.trim(),
      category,
      unit,
      hsnCode: hsnCode.trim(),
      purchaseRate: Number(purchaseRate) || 0,
      sellingRate: Number(sellingRate) || 0,
      mrp: Number(mrp) || Number(sellingRate) || 0,
      gstRate: Number(gstRate) || 0,
      taxType: dbService.getCompanyInfo().defaultTaxCalculation || 'Inclusive',
      openingStock: Number(openingStock) || 0,
      openingStockValue: Number(openingStockValue) || Number(openingStock) * Number(purchaseRate),
      currentStock: selectedId ? Number(currentStock) : Number(openingStock) || 0,
      minStockLevel: Number(minStockLevel) || 0,
      locationRack: locationRack.trim(),
      isActive,
      createdAt: createdDate || (selectedId ? items.find((i) => i.id === selectedId)?.createdAt || getTodayDateString() : getTodayDateString()),
      updatedAt: getTodayDateString(),
    };

    dbService.saveItem(item);
    loadItems();
    setFeedback({
      type: 'success',
      title: isUpdate ? 'Item Updated Successfully' : 'Item Saved Successfully',
      text: isUpdate
        ? `Item "${item.itemName}" (${item.itemCode}) has been updated successfully in the catalog!`
        : `Item "${item.itemName}" (${item.itemCode}) has been saved successfully to the catalog!`,
    });
    if (!selectedId) {
      resetForm();
    }
  };

  const handleDelete = (targetId?: string | React.MouseEvent) => {
    const id = (typeof targetId === 'string' && targetId) ? targetId : selectedId;
    if (!id) return;
    const itemObj = items.find((i) => i.id === id);
    if (dbService.isItemPurchased(id)) {
      setFeedback({
        type: 'error',
        title: 'Cannot Delete Purchased Item',
        text: `Product "${itemObj ? itemObj.itemName : 'item'}" (${itemObj ? itemObj.itemCode : id}) has been purchased under Stock Purchase and cannot be deleted from the Product Catalog.`,
      });
      return;
    }
    const label = itemObj ? `"${itemObj.itemName}" (${itemObj.itemCode})` : 'this item';
    setItemToDelete({ id, label });
  };

  const confirmDelete = () => {
    if (!itemToDelete) return;
    const { id, label } = itemToDelete;
    const res = dbService.deleteItem(id, true);
    setItemToDelete(null);
    if (res.success) {
      setFeedback({
        type: 'success',
        title: 'Item Deleted Successfully',
        text: `Item ${label} has been deleted from the catalog successfully!`,
      });
      loadItems();
      if (selectedId === id) {
        resetForm();
      }
    } else {
      setFeedback({ type: 'error', title: 'Delete Operation Failed', text: res.message });
    }
  };

  const confirmClearAll = () => {
    setShowClearAllModal(false);
    const res = dbService.clearAllCatalogItems();
    if (res.success) {
      setFeedback({
        type: 'success',
        title: 'Catalog List Deleted',
        text: 'All items/products in the catalog list have been deleted successfully. (Purchased items in Stock Register remain secure).',
      });
      loadItems();
      resetForm();
    } else {
      setFeedback({ type: 'error', title: 'Delete Failed', text: res.message });
    }
  };

  const filteredItems = items.filter((it) => {
    const matchQuery =
      it.itemName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      it.itemCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (it.barcode && it.barcode.includes(searchQuery)) ||
      (it.hsnCode && it.hsnCode.includes(searchQuery));
    const matchCategory = filterCategory === 'ALL' || it.category === filterCategory;
    const matchLowStock = !showLowStockOnly || it.currentStock <= (it.minStockLevel !== undefined ? it.minStockLevel : 10);
    
    // Date filter
    let matchDate = true;
    if (filterDate) {
      const itemCreated = it.createdAt ? (it.createdAt.includes('T') ? it.createdAt.split('T')[0] : it.createdAt) : '';
      matchDate = itemCreated === filterDate;
    }

    // Usage filter (Purchased vs UnUsed)
    const isPurchased = dbService.isItemPurchased(it.id);
    if (filterType === 'purchased' && !isPurchased) return false;
    if (filterType === 'unused' && isPurchased) return false;

    return matchQuery && matchCategory && matchLowStock && matchDate;
  });

  // Category list containing all categories from New Product form, plus any other distinct categories from catalog items
  const categories = Array.from(
    new Set([
      ...PRODUCT_CATEGORIES,
      ...items.map((i) => i.category).filter((c): c is string => Boolean(c)),
    ])
  );

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none">
      {/* Confirmation Modal for Single Item */}
      {itemToDelete && (
        <ConfirmModal
          title="Delete Catalog Item"
          message={`Are you sure you want to permanently delete ${itemToDelete.label} from the catalog?`}
          confirmLabel="Delete Item"
          onConfirm={confirmDelete}
          onCancel={() => setItemToDelete(null)}
        />
      )}

      {/* Confirmation Modal for Clearing All Items */}
      {showClearAllModal && (
        <ConfirmModal
          title="Delete All Products"
          message={`Are you sure you want to delete all ${items.length} products from the Product Catalog? This will remove all catalog products, but will not affect your Purchase Inward Bills or Stock Sheet.`}
          confirmLabel="Delete All Products"
          onConfirm={confirmClearAll}
          onCancel={() => setShowClearAllModal(false)}
        />
      )}

      {/* Modal Popup for all Messages (Success, Errors, Updates) */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          onClose={() => setFeedback(null)}
        />
      )}

      {/* Main Grid: Form on Left/Top, List on Right/Bottom */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Form Panel (frmItemMaster) */}
        <div className="lg:col-span-5 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-700/40 pb-3 mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-amber-600/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shadow-inner">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
                    <span>{selectedId ? 'Edit Product' : 'New Product'}</span>
                  </h2>
                  <p className="text-xs text-slate-400">Footwear article, HSN, pricing & stock tracking</p>
                </div>
              </div>

              <button
                id="btn-new-item"
                type="button"
                onClick={resetForm}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 text-xs font-medium border border-slate-700/50 backdrop-blur-sm transition"
              >
                <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                <span>New</span>
              </button>
            </div>

            <form id="form-item-master" onSubmit={handleSave} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-slate-400 font-medium flex items-center gap-1.5">
                      <span>Article Code *</span>
                      <span
                        className={`inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.2 rounded border ${
                          isCodeLocked
                            ? 'bg-amber-950/60 text-amber-300 border-amber-500/40'
                            : 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                        }`}
                      >
                        {isCodeLocked ? <Lock className="w-2.5 h-2.5" /> : <Unlock className="w-2.5 h-2.5" />}
                        {isCodeLocked ? 'Locked' : 'Unlocked'}
                      </span>
                    </label>
                    <button
                      type="button"
                      onClick={() => setIsCodeLocked(!isCodeLocked)}
                      className="text-[10px] text-slate-400 hover:text-amber-300 flex items-center gap-1 transition-colors cursor-pointer"
                      title={isCodeLocked ? 'Click to unlock Article Code' : 'Click to lock Article Code'}
                    >
                      {isCodeLocked ? (
                        <>
                          <Unlock className="w-3 h-3 text-slate-400" />
                          <span>Unlock</span>
                        </>
                      ) : (
                        <>
                          <Lock className="w-3 h-3 text-amber-400" />
                          <span className="text-amber-400 font-medium">Lock</span>
                        </>
                      )}
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      id="input-item-code"
                      type="text"
                      required
                      readOnly={isCodeLocked}
                      value={itemCode}
                      onChange={(e) => setItemCode(e.target.value)}
                      placeholder="e.g. SH-FOR-OX-01"
                      className={`w-full rounded-lg px-2.5 py-1.5 font-mono font-bold uppercase transition-all ${
                        isCodeLocked
                          ? 'bg-slate-900/85 border border-slate-700/60 text-slate-300 cursor-not-allowed select-all pr-8'
                          : 'bg-slate-950/70 border border-amber-500/80 text-slate-100 focus:border-amber-400 focus:outline-none'
                      }`}
                    />
                    {isCodeLocked && (
                      <div className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none">
                        <Lock className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    {isCodeLocked ? 'Item code is locked to prevent accidental alteration.' : 'Field unlocked for manual code assignment.'}
                  </p>
                </div>
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Barcode / EAN</label>
                  <input
                    type="text"
                    value={barcode}
                    onChange={(e) => setBarcode(e.target.value)}
                    placeholder="e.g. 890100100001"
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Item Description / Name *</label>
                <input
                  type="text"
                  required
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                  placeholder="e.g. Men's Oxford Leather Formal Shoes (Black)"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-medium focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 focus:border-amber-500 focus:outline-none text-xs"
                  >
                    {PRODUCT_CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Unit</label>
                  <select
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 focus:border-amber-500 focus:outline-none text-xs"
                  >
                    <option value="Pairs">Pairs (Prs)</option>
                    <option value="Pcs">Pieces (Pcs)</option>
                    <option value="Box">Box (Bx)</option>
                    <option value="Doz">Dozen (Doz)</option>
                    <option value="Set">Set</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">HSN / SAC Code</label>
                  <input
                    type="text"
                    value={hsnCode}
                    onChange={(e) => setHsnCode(e.target.value)}
                    placeholder="6403"
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 font-mono focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Pricing & GST */}
              <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-700/40 space-y-2 backdrop-blur-xs">
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block">
                  Pricing & GST Tax Details
                </span>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-slate-400 font-medium mb-0.5">
                      Purchase Rate (₹) {!canViewPurchasePrice && <span className="text-amber-400 text-[10px]">🔒 Locked</span>}
                    </label>
                    {canViewPurchasePrice ? (
                      <input
                        type="number"
                        step="any"
                        placeholder="0.00"
                        value={purchaseRate}
                        onChange={(e) => setPurchaseRate(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono focus:border-amber-500 focus:outline-none"
                      />
                    ) : (
                      <div className="w-full bg-slate-900/40 border border-slate-800 rounded px-2 py-1 text-slate-500 font-mono text-xs">
                        ••••••
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-slate-400 font-medium mb-0.5">Selling Rate (₹)</label>
                    <input
                      type="number"
                      step="any"
                      placeholder="0.00"
                      value={sellingRate}
                      onChange={(e) => {
                        const val = e.target.value === '' ? '' : Number(e.target.value);
                        setSellingRate(val);
                        setMrp(val);
                      }}
                      className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-emerald-400 font-bold font-mono focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 font-medium mb-0.5">MRP Print (₹)</label>
                    <input
                      type="number"
                      step="any"
                      placeholder="0.00"
                      value={mrp}
                      onChange={(e) => setMrp(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="pt-1">
                  <label className="block text-slate-400 font-medium mb-0.5">GST Rate %</label>
                  <select
                    value={gstRate}
                    onChange={(e) => setGstRate(Number(e.target.value))}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono focus:border-amber-500 focus:outline-none text-xs"
                  >
                    <option value={0}>0% (Exempted)</option>
                    <option value={3}>3% (Precious / Gold)</option>
                    <option value={5}>5% (Footwear &lt; ₹1000)</option>
                    <option value={12}>12% (Footwear &gt; ₹1000 / Accessories)</option>
                    <option value={18}>18% (Standard Footwear / Leather)</option>
                    <option value={28}>28% (Luxury items)</option>
                  </select>
                </div>
              </div>

              {/* Stock Parameters & Entry Date */}
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Date</label>
                  <input
                    type="date"
                    value={createdDate}
                    onChange={(e) => setCreatedDate(e.target.value)}
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 focus:border-amber-500 focus:outline-none text-xs cursor-pointer"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Min Reorder Level</label>
                  <input
                    type="number"
                    value={minStockLevel}
                    onChange={(e) => setMinStockLevel(Number(e.target.value))}
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 font-mono focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Rack / Shelf</label>
                  <input
                    type="text"
                    value={locationRack}
                    onChange={(e) => setLocationRack(e.target.value)}
                    placeholder="Rack A-1"
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-700/40">
                {selectedId ? (
                  !canManageInventory ? (
                    <span className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800/80 text-slate-400 border border-slate-700 text-xs font-semibold" title="Item deletion restricted for your role">
                      <Lock className="w-3.5 h-3.5 text-slate-500" />
                      <span>Delete Restricted</span>
                    </span>
                  ) : dbService.isItemPurchased(selectedId) ? (
                    <span className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800/80 text-amber-300 border border-slate-700 text-xs font-semibold" title="Product purchased under Stock Purchase cannot be deleted">
                      <Lock className="w-3.5 h-3.5 text-amber-400" />
                      <span>Purchased (Locked)</span>
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={handleDelete}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 text-xs font-semibold backdrop-blur-sm transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  )
                ) : (
                  <div />
                )}

                {canManageInventory ? (
                  <button
                    id="btn-save-item-master"
                    type="submit"
                    className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg shadow-lg shadow-amber-900/20 border border-amber-500/30 transition cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>{selectedId ? 'Update Product' : 'Save Product [F8]'}</span>
                  </button>
                ) : (
                  <span className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 text-slate-400 font-semibold rounded-lg border border-slate-700 text-xs" title="Catalog modifications restricted for your role">
                    <Lock className="w-3.5 h-3.5 text-amber-400" />
                    <span>Catalog View Only</span>
                  </span>
                )}
              </div>
            </form>
          </div>
        </div>

        {/* Right Items Grid Panel */}
        <div className="lg:col-span-7 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 flex flex-col">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-700/40 pb-3 mb-3">
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <span>Product Catalog</span>
                <span className="bg-slate-800/60 text-amber-400 font-mono text-xs px-2 py-0.5 rounded border border-slate-700/50">
                  {filteredItems.length} records
                </span>
              </h3>
              {items.length > 0 && (
                <button
                  type="button"
                  onClick={() => setShowClearAllModal(true)}
                  className="flex items-center gap-1 px-2 py-1 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 text-xs font-medium border border-rose-800/60 transition cursor-pointer"
                  title="Delete All Products from Product Catalog"
                >
                  <Trash2 className="w-3 h-3 text-rose-400" />
                  <span>Delete Product List</span>
                </button>
              )}
            </div>

            {/* Quick Filters */}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
                <input
                  type="text"
                  placeholder="Search code/name/HSN..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-slate-950/70 border border-slate-700/60 rounded-lg pl-8 pr-2.5 py-1 text-slate-200 focus:border-amber-500 focus:outline-none text-xs"
                />
              </div>

              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1 text-slate-300 focus:border-amber-500 focus:outline-none text-xs"
              >
                <option value="ALL">All Categories</option>
                {categories.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>

              {/* Date Filter */}
              <div className="flex items-center gap-1 bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-0.5 text-xs">
                <Calendar className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <input
                  type="date"
                  value={filterDate}
                  onChange={(e) => setFilterDate(e.target.value)}
                  className="bg-transparent border-0 text-slate-200 text-xs focus:ring-0 focus:outline-none p-0 cursor-pointer"
                  title="Filter by creation date"
                />
                {filterDate ? (
                  <button
                    type="button"
                    onClick={() => setFilterDate(filterDate === getTodayDateString() ? '' : getTodayDateString())}
                    className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-white font-medium"
                    title={filterDate === getTodayDateString() ? 'Show all dates' : 'Set to today'}
                  >
                    {filterDate === getTodayDateString() ? 'All' : 'Today'}
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setFilterDate(getTodayDateString())}
                    className="text-[10px] px-1.5 py-0.5 rounded bg-amber-900/60 text-amber-300 hover:bg-amber-800 font-medium"
                    title="Filter by today"
                  >
                    Today
                  </button>
                )}
              </div>

              {/* Purchased / UnUsed Filter */}
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value as any)}
                className="bg-slate-950/70 border border-slate-700/60 text-slate-200 text-xs rounded-lg px-2 py-1 focus:outline-none focus:border-amber-500 cursor-pointer"
              >
                <option value="all">All Items</option>
                <option value="purchased">✓ Purchased</option>
                <option value="unused">○ UnUsed</option>
              </select>

              <button
                type="button"
                onClick={() => setShowLowStockOnly(!showLowStockOnly)}
                className={`px-2.5 py-1 rounded-lg border text-xs font-medium flex items-center gap-1 transition ${
                  showLowStockOnly
                    ? 'bg-rose-900/60 text-rose-300 border-rose-700'
                    : 'bg-slate-800/60 text-slate-400 border-slate-700/50 hover:text-slate-200'
                }`}
              >
                <AlertTriangle className="w-3 h-3 text-rose-400" />
                <span>Low Stock</span>
              </button>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto flex-1 max-h-[520px] rounded-lg border border-slate-700/40 bg-slate-900/20 backdrop-blur-xs">
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md z-10">
                <tr>
                  <th className="py-2.5 px-2.5">Code</th>
                  <th className="py-2.5 px-2">Item Name</th>
                  <th className="py-2.5 px-2">Category</th>
                  <th className="py-2.5 px-2 text-center">HSN</th>
                  <th className="py-2.5 px-2 text-right">Cost</th>
                  <th className="py-2.5 px-2 text-right">Sale Price</th>
                  <th className="py-2.5 px-2 text-center">GST</th>
                  <th className="py-2.5 px-2 text-right">Stock</th>
                  <th className="py-2.5 px-2 text-center">Status</th>
                  <th className="py-2.5 px-2 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredItems.map((it) => {
                  const isLow = it.currentStock <= (it.minStockLevel !== undefined ? it.minStockLevel : 10);
                  const isSelected = selectedId === it.id;
                  const isPurchased = dbService.isItemPurchased(it.id);
                  return (
                    <tr
                      key={it.id}
                      onClick={() => handleSelectItem(it)}
                      className={`cursor-pointer transition ${
                        isSelected
                          ? 'bg-amber-950/40 border-l-4 border-amber-500 text-slate-100'
                          : 'hover:bg-slate-800/40 text-slate-300'
                      }`}
                    >
                      <td className="py-2.5 px-2.5 font-mono font-bold text-amber-400">{it.itemCode}</td>
                      <td className="py-2.5 px-2">
                        <div className="font-semibold text-slate-100">{it.itemName}</div>
                        {it.barcode && <div className="text-[10px] text-slate-500 font-mono">EAN: {it.barcode}</div>}
                      </td>
                      <td className="py-2.5 px-2 text-slate-400">{it.category}</td>
                      <td className="py-2.5 px-2 text-center font-mono text-slate-300">{it.hsnCode}</td>
                      <td className="py-2.5 px-2 text-right font-mono">
                        {canViewPurchasePrice ? `₹${it.purchaseRate.toFixed(2)}` : <span className="text-slate-500 font-mono">••••••</span>}
                      </td>
                      <td className="py-2.5 px-2 text-right font-mono font-bold text-emerald-400">
                        ₹{it.sellingRate.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-slate-300">{it.gstRate}%</td>
                      <td className="py-2.5 px-2 text-right font-mono">
                        <span
                          className={`font-bold px-1.5 py-0.5 rounded ${
                            isLow
                              ? 'bg-rose-950/80 text-rose-400 border border-rose-800/60'
                              : 'text-slate-200'
                          }`}
                        >
                          {it.currentStock} {it.unit}
                        </span>
                      </td>
                      <td className="py-2.5 px-2 text-center">
                        {isPurchased ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold">
                            Active
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700 text-[10px] font-bold">
                            Deactive
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-2 text-center" onClick={(e) => e.stopPropagation()}>
                        {isPurchased ? (
                          <span
                            title="Purchased under Stock Purchase (Cannot be deleted)"
                            className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700 text-[10px] font-medium"
                          >
                            <Lock className="w-3 h-3 text-amber-400" />
                            <span>Purchased</span>
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleDelete(it.id)}
                            title="Delete Item"
                            className="p-1.5 rounded-lg bg-rose-950/50 hover:bg-rose-900/80 text-rose-400 border border-rose-800/50 transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
