import React, { useState, useEffect } from 'react';
import {
  Boxes,
  Search,
  Filter,
  AlertTriangle,
  Printer,
  Download,
  PlusCircle,
  CheckCircle2,
  TrendingDown,
  TrendingUp,
  RotateCcw,
  FileText,
  ShoppingBag,
  Layers,
  Wallet,
  CreditCard,
  Banknote,
  Trash2,
} from 'lucide-react';
import { PurchasedStockItem, StockAdjustment, PRODUCT_CATEGORIES } from '../types';
import { dbService } from '../services/storage';
import { formatCurrency, roundTo2 } from '../services/gstCalculations';
import { SuccessPopup } from './SuccessPopup';
import { StockLedgerPrintModal } from './StockLedgerPrintModal';

export const StockLedgerComponent: React.FC = () => {
  const [items, setItems] = useState<PurchasedStockItem[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedSupplier, setSelectedSupplier] = useState<string>('ALL');
  const [showLowStockOnly, setShowLowStockOnly] = useState<boolean>(false);

  // Stock Print Modal State
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);

  // Stock Adjustment Dialog
  const [showAdjustModal, setShowAdjustModal] = useState<boolean>(false);
  const [adjustItemId, setAdjustItemId] = useState<string>('');
  const [adjustType, setAdjustType] = useState<'ADD' | 'SUBTRACT'>('ADD');
  const [adjustQty, setAdjustQty] = useState<number>(1);
  const [adjustReason, setAdjustReason] = useState<string>('Physical Stock Audit Difference');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; title?: string; text: string } | null>(null);

  const loadData = () => {
    const list = dbService.getPurchasedStockItems();
    setItems(list);
  };

  useEffect(() => {
    loadData();
    return dbService.subscribe(loadData);
  }, []);

  const handleStockAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustItemId) {
      setFeedback({ type: 'error', text: 'Select an item to adjust.' });
      return;
    }
    const itm = items.find((i) => i.id === adjustItemId || i.itemCode === adjustItemId);
    if (!itm) return;

    const prevStock = itm.currentStock;
    const newStock = adjustType === 'ADD' ? prevStock + Number(adjustQty) : Math.max(0, prevStock - Number(adjustQty));

    const adj: StockAdjustment = {
      id: `ADJ-${Date.now()}`,
      itemId: itm.id,
      itemCode: itm.itemCode,
      itemName: itm.itemName,
      adjustmentDate: new Date().toISOString().split('T')[0],
      previousStock: prevStock,
      adjustedStock: newStock,
      difference: adjustType === 'ADD' ? Number(adjustQty) : -Number(adjustQty),
      reason: adjustReason,
    };

    const res = dbService.adjustStock(adj);
    if (res.success) {
      setFeedback({ type: 'success', text: `Stock for ${itm.itemName} updated to ${newStock} ${itm.unit}` });
      loadData();
      setShowAdjustModal(false);
      setAdjustQty(1);
    } else {
      setFeedback({ type: 'error', text: res.message });
    }
  };

  const handlePurgeSoldEntries = (itemCode: string, itemName: string) => {
    if (window.confirm(`Are you sure you want to remove all sold entries for "${itemCode} - ${itemName}" from the database? This will restore on-hand inventory.`)) {
      const res = dbService.purgeSoldEntriesForItem(itemCode);
      if (res.success) {
        setFeedback({ type: 'success', text: res.message });
        loadData();
      } else {
        setFeedback({ type: 'error', text: res.message });
      }
    }
  };

  // All categories from New Product page, plus any other distinct categories from stock items
  const categories = Array.from(
    new Set([
      ...PRODUCT_CATEGORIES,
      ...items.map((i) => i.category).filter((c): c is string => Boolean(c)),
    ])
  );

  const suppliers = Array.from(
    new Set(items.map((i) => i.supplierName).filter((s): s is string => Boolean(s && s.trim() !== '')))
  ).sort();

  const filteredItems = items.filter((it) => {
    const query = searchQuery.toLowerCase().trim();
    const matchQ =
      !query ||
      it.itemName.toLowerCase().includes(query) ||
      it.itemCode.toLowerCase().includes(query) ||
      (it.hsnCode && it.hsnCode.includes(query)) ||
      (it.lastPurchaseBillNo && it.lastPurchaseBillNo.toLowerCase().includes(query)) ||
      (it.allPurchaseBillNos && it.allPurchaseBillNos.toLowerCase().includes(query)) ||
      (it.supplierName && it.supplierName.toLowerCase().includes(query));
    const itemCat = it.category || 'General Footwear';
    const matchCat =
      selectedCategory === 'ALL' ||
      itemCat === selectedCategory ||
      (selectedCategory === 'General Footwear' && it.category === 'Footwear');
    const matchLow = !showLowStockOnly || it.currentStock <= (it.minStockLevel !== undefined ? it.minStockLevel : 10);
    const matchSupplier = selectedSupplier === 'ALL' || it.supplierName === selectedSupplier;

    return matchQ && matchCat && matchLow && matchSupplier;
  });

  // Aggregated Stock Metrics
  const totalStockQty = items.reduce((acc, it) => acc + it.currentStock, 0);
  const totalInwardQty = items.reduce((acc, it) => acc + it.totalPurchasedQty, 0);
  const totalSoldQty = items.reduce((acc, it) => acc + it.totalSoldQty, 0);
  const totalCostValuation = roundTo2(items.reduce((acc, it) => acc + it.currentStock * it.purchaseRate, 0));
  const totalMrpValuation = roundTo2(items.reduce((acc, it) => acc + it.currentStock * (it.mrp || it.sellingRate), 0));
  const totalSellingValuation = roundTo2(items.reduce((acc, it) => acc + it.currentStock * it.sellingRate, 0));
  const lowStockCount = items.filter((it) => it.currentStock <= (it.minStockLevel !== undefined ? it.minStockLevel : 10)).length;

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none">
      {/* Modal Popup for all Messages */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          onClose={() => setFeedback(null)}
        />
      )}

      {/* Top Inventory Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 text-xs">
        <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md flex items-center justify-between">
          <div>
            <span className="text-slate-400 font-medium block">Total Stock on Hand</span>
            <span className="text-xl sm:text-2xl font-black text-slate-100 font-mono mt-1 block">
              {totalStockQty.toLocaleString()} <span className="text-xs font-normal text-slate-400">Pairs/Units</span>
            </span>
            <span className="text-[11px] text-slate-500 block mt-0.5">
              Inward: {totalInwardQty} | Sold: {totalSoldQty}
            </span>
          </div>
          <div className="w-10 h-10 bg-blue-600/20 text-blue-400 rounded-xl border border-blue-500/30 flex items-center justify-center shadow-inner">
            <Boxes className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md flex items-center justify-between">
          <div>
            <span className="text-slate-400 font-medium block">Low Stock Alert</span>
            <span className="text-xl sm:text-2xl font-black text-rose-400 font-mono mt-1 block">
              {lowStockCount} <span className="text-xs font-normal text-slate-400">Articles</span>
            </span>
            <span className="text-[11px] text-slate-500 block mt-0.5">
              Reorder level reached
            </span>
          </div>
          <div className="w-10 h-10 bg-rose-600/20 text-rose-400 rounded-xl border border-rose-500/30 flex items-center justify-center shadow-inner">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md flex items-center justify-between">
          <div>
            <span className="text-slate-400 font-medium block">Total Cost Valuation</span>
            <span className="text-xl sm:text-2xl font-black text-emerald-400 font-mono mt-1 block">
              {formatCurrency(totalCostValuation)}
            </span>
            <span className="text-[11px] text-slate-500 block mt-0.5">
              Purchase Rate Total
            </span>
          </div>
          <div className="w-10 h-10 bg-emerald-600/20 text-emerald-400 rounded-xl border border-emerald-500/30 flex items-center justify-center shadow-inner">
            <Wallet className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md flex items-center justify-between">
          <div>
            <span className="text-slate-400 font-medium block">Total Selling Valuation</span>
            <span className="text-xl sm:text-2xl font-black text-cyan-400 font-mono mt-1 block">
              {formatCurrency(totalSellingValuation)}
            </span>
            <span className="text-[11px] text-slate-500 block mt-0.5">
              Selling Rate Total
            </span>
          </div>
          <div className="w-10 h-10 bg-cyan-600/20 text-cyan-400 rounded-xl border border-cyan-500/30 flex items-center justify-center shadow-inner">
            <ShoppingBag className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Stock Table & Controls */}
      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-700/40 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center shadow-inner">
              <Boxes className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
                <span>Stock Sheet</span>
              </h2>
              <p className="text-xs text-slate-400">
                Displays inventory items with live stock, inward/outward tracking & valuation
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            <button
              id="btn-open-stock-adjust"
              onClick={() => setShowAdjustModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold shadow-lg shadow-emerald-900/20 border border-emerald-500/30 transition cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Stock Adjustment Voucher</span>
            </button>

            <button
              id="btn-open-stock-print-modal"
              onClick={() => setShowPrintModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold shadow-lg shadow-blue-900/20 border border-blue-500/30 transition cursor-pointer"
              title="Print Stock Sheet (70mm, 80mm & A4)"
            >
              <Printer className="w-4 h-4 text-white" />
              <span>Print Stock Sheet</span>
            </button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs pt-1">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
              <input
                type="text"
                placeholder="Search code, item name, bill no, HSN..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-950/70 border border-slate-700/60 rounded-lg pl-8 pr-2.5 py-1 text-slate-200 focus:border-blue-500 focus:outline-none w-52 sm:w-60"
              />
            </div>

            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1 text-slate-300 focus:border-blue-500 focus:outline-none"
            >
              <option value="ALL">All Categories</option>
              {categories.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>

            <select
              value={selectedSupplier}
              onChange={(e) => setSelectedSupplier(e.target.value)}
              className="bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1 text-slate-300 focus:border-blue-500 focus:outline-none"
            >
              <option value="ALL">All Suppliers</option>
              {suppliers.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>



            <button
              onClick={() => setShowLowStockOnly(!showLowStockOnly)}
              className={`px-2.5 py-1 rounded-lg border flex items-center gap-1 transition ${
                showLowStockOnly
                  ? 'bg-rose-900/60 text-rose-300 border-rose-700/70'
                  : 'bg-slate-800/60 text-slate-400 border-slate-700/50 hover:text-slate-200'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
              <span>Low Stock</span>
            </button>
          </div>

          <div className="text-slate-400 font-mono text-xs">
            Showing {filteredItems.length} of {items.length} purchased articles
          </div>
        </div>

        {/* Stock Ledger Grid */}
        <div className="overflow-x-auto max-h-[520px] rounded-lg border border-slate-700/40 bg-slate-900/20 backdrop-blur-xs">
          {filteredItems.length === 0 ? (
            <div className="py-12 text-center text-slate-400 space-y-3">
              <Boxes className="w-12 h-12 mx-auto text-slate-600 stroke-[1.5]" />
              <div className="text-sm font-semibold text-slate-300">
                {items.length === 0 ? 'No Purchased Items in Stock Register' : 'No items match your search or category filter'}
              </div>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                {items.length === 0
                  ? 'The stock register only displays items that have been purchased under purchase bills. Record a Purchase Inward Bill to see items here.'
                  : 'Try clearing your search query, selecting All Modes, or choosing a different category.'}
              </p>
            </div>
          ) : (
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md z-10">
                <tr>
                  <th className="py-2.5 px-3">Item Code</th>
                  <th className="py-2.5 px-3">ITEM NAME</th>
                  <th className="py-2.5 px-3">DISCRIPTION</th>
                  <th className="py-2.5 px-2">Category</th>
                  <th className="py-2.5 px-2">PURCHASE BILL NO.</th>
                  <th className="py-2.5 px-2">SUPPLIER BILL NO</th>
                  <th className="py-2.5 px-2 text-right">Total Inward</th>
                  <th className="py-2.5 px-2 text-right">Sold Qty</th>
                  <th className="py-2.5 px-2 text-right font-bold text-slate-200">Stock on Hand</th>
                  <th className="py-2.5 px-3 text-right">Cost Value (₹)</th>
                  <th className="py-2.5 px-2 text-right">SELLING VALUE</th>
                  <th className="py-2.5 px-3 text-right">TOTAL VALUE</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {filteredItems.map((it) => {
                  const isLow = it.currentStock <= (it.minStockLevel !== undefined ? it.minStockLevel : 10);
                  const costVal = it.currentStock * it.purchaseRate;
                  const saleVal = it.currentStock * it.sellingRate;

                  return (
                    <tr key={it.id || it.itemCode} className="hover:bg-slate-800/40 transition">
                      <td className="py-2.5 px-3 font-bold text-amber-400">{it.itemCode}</td>
                      <td className="py-2.5 px-3 font-sans font-semibold text-slate-100">{it.itemName}</td>
                      <td className="py-2.5 px-3 font-sans text-slate-300">
                        <div className="text-[10px] text-slate-400 font-mono">
                          HSN: {it.hsnCode} | GST: {it.gstRate}% | Min Reorder: {it.minStockLevel !== undefined ? it.minStockLevel : 0}
                          {it.locationRack ? ` | Rack: ${it.locationRack}` : ''}
                          {it.notes ? ` | ${it.notes}` : ''}
                        </div>
                      </td>
                      <td className="py-2.5 px-2 text-slate-400 font-sans">{it.category || 'Footwear'}</td>
                      <td className="py-2.5 px-2 font-mono text-[11px] text-slate-300">
                        <div>{it.lastPurchaseBillNo || '—'}</div>
                        {it.lastPurchaseDate && <div className="text-[10px] text-slate-500">{it.lastPurchaseDate}</div>}
                      </td>
                      <td className="py-2.5 px-2 font-mono text-[11px] text-slate-300">
                        <div>{it.lastSupplierBillNo || '—'}</div>
                      </td>
                      <td className="py-2.5 px-2 text-right text-blue-400 font-bold">
                        {it.totalPurchasedQty} {it.unit}
                      </td>
                      <td className="py-2.5 px-2 text-right text-rose-300 font-bold">
                        <div className="inline-flex items-center gap-1.5 justify-end">
                          <span>{it.totalSoldQty} {it.unit}</span>
                          {it.totalSoldQty > 0 && (
                            <button
                              type="button"
                              onClick={() => handlePurgeSoldEntries(it.itemCode, it.itemName)}
                              title="Remove sold entries of this item from database and restore stock"
                              className="p-0.5 rounded text-rose-400/70 hover:text-rose-200 hover:bg-rose-950/60 transition"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </td>
                      <td className="py-2.5 px-2 text-right">
                        <span
                          className={`px-2 py-0.5 rounded font-bold text-xs ${
                            isLow
                              ? 'bg-rose-950/80 text-rose-400 border border-rose-800/80 animate-pulse'
                              : 'text-slate-100 bg-slate-800/60 border border-slate-700/50'
                          }`}
                        >
                          {it.currentStock} {it.unit}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-200">
                        ₹{costVal.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-2 text-right text-emerald-400 font-bold">₹{it.sellingRate.toFixed(2)}</td>
                      <td className="py-2.5 px-3 text-right font-bold text-cyan-300">
                        ₹{saleVal.toFixed(2)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="bg-slate-950/80 font-mono font-bold text-slate-100 border-t border-slate-700/50 backdrop-blur-md">
                  <td colSpan={4} className="py-2.5 px-3 text-right font-sans uppercase text-[11px] text-slate-400">
                    Total Inventory Valuation:
                  </td>
                  <td></td>
                  <td></td>
                  <td className="py-2.5 px-2 text-right text-blue-400 text-xs">
                    {filteredItems.reduce((acc, it) => acc + it.totalPurchasedQty, 0)}
                  </td>
                  <td className="py-2.5 px-2 text-right text-rose-400 text-xs">
                    {filteredItems.reduce((acc, it) => acc + it.totalSoldQty, 0)}
                  </td>
                  <td className="py-2.5 px-2 text-right text-emerald-400 text-sm">
                    {filteredItems.reduce((acc, it) => acc + it.currentStock, 0)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300 text-sm">
                    ₹{roundTo2(filteredItems.reduce((acc, it) => acc + (it.currentStock * it.purchaseRate), 0)).toFixed(2)}
                  </td>
                  <td className="py-2.5 px-2 text-right text-emerald-400 text-sm">
                    ₹{roundTo2(filteredItems.reduce((acc, it) => acc + it.sellingRate, 0)).toFixed(2)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-cyan-400 text-sm">
                    ₹{roundTo2(filteredItems.reduce((acc, it) => acc + (it.currentStock * it.sellingRate), 0)).toFixed(2)}
                  </td>
                </tr>
              </tfoot>
            </table>
          )}
        </div>
      </div>

      {/* Stock Adjustment Voucher Dialog */}
      {showAdjustModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="bg-slate-900/90 border border-slate-700/60 rounded-2xl shadow-2xl w-full max-w-lg p-5 text-slate-100 space-y-4 backdrop-blur-xl">
            <div className="flex items-center justify-between border-b border-slate-700/50 pb-2.5">
              <h3 className="font-bold text-base flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-emerald-400" />
                <span>Physical Stock Adjustment Voucher</span>
              </h3>
              <button
                onClick={() => setShowAdjustModal(false)}
                className="text-slate-400 hover:text-white text-xs px-2 py-0.5 rounded-lg bg-slate-800/60 border border-slate-700/50"
              >
                Close
              </button>
            </div>

            <form onSubmit={handleStockAdjustment} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Select Purchased Footwear Item *</label>
                <select
                  required
                  value={adjustItemId}
                  onChange={(e) => setAdjustItemId(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg p-2 text-slate-100 focus:border-emerald-500 focus:outline-none"
                >
                  <option value="">-- Choose Item to Adjust --</option>
                  {items.map((i) => (
                    <option key={i.id || i.itemCode} value={i.id || i.itemCode}>
                      {i.itemCode} - {i.itemName} (Stock on Hand: {i.currentStock} {i.unit})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Adjustment Action</label>
                  <select
                    value={adjustType}
                    onChange={(e) => setAdjustType(e.target.value as any)}
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg p-2 text-slate-100 focus:border-emerald-500 focus:outline-none"
                  >
                    <option value="ADD">Add Stock (+) Surplus Found</option>
                    <option value="SUBTRACT">Reduce Stock (-) Breakage / Loss</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Adjustment Qty</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={adjustQty}
                    onChange={(e) => setAdjustQty(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg p-2 text-slate-100 font-mono font-bold focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Reason for Audit Adjustment</label>
                <input
                  type="text"
                  required
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  placeholder="e.g. Annual physical count variance, damaged display pair"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg p-2 text-slate-100 focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-700/50 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAdjustModal(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-300 font-medium border border-slate-700/50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-lg shadow-emerald-900/20 border border-emerald-500/30"
                >
                  Apply Stock Adjustment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Stock Sheet Multi-Format Print Modal (70mm, 80mm & Standard A4) */}
      {showPrintModal && (
        <StockLedgerPrintModal
          isOpen={showPrintModal}
          onClose={() => setShowPrintModal(false)}
          company={dbService.getCompany()}
          items={filteredItems}
          selectedCategory={selectedCategory}
          selectedSupplier={selectedSupplier}
          searchQuery={searchQuery}
          showLowStockOnly={showLowStockOnly}
          totalStockQty={totalStockQty}
          totalInwardQty={totalInwardQty}
          totalSoldQty={totalSoldQty}
          totalCostValuation={totalCostValuation}
          totalSellingValuation={totalSellingValuation}
          totalMrpValuation={totalMrpValuation}
          lowStockCount={lowStockCount}
        />
      )}
    </div>
  );
};
