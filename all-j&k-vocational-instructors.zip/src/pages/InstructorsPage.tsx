import React, { useState, useMemo } from 'react';
import { Instructor, TrainingCenter, Division, DEFAULT_EMPLOYEE_TYPES } from '../types';
import { registerInstructor } from '../services/db';
import { formatDate } from '../utils/format';
import {
  Search,
  Users,
  Phone,
  Calendar,
  Briefcase,
  ChevronLeft,
  ChevronRight,
  Check,
  CheckCircle2,
  UserCheck,
  Plus,
  X,
  Building2,
  Clock,
  ShieldCheck,
  Info,
  AlertCircle,
  AlertTriangle,
} from 'lucide-react';

interface InstructorsPageProps {
  instructors: Instructor[];
  trainingCenters: TrainingCenter[];
  employeeTypes?: string[];
  onNotify?: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const InstructorsPage: React.FC<InstructorsPageProps> = ({
  instructors,
  trainingCenters,
  employeeTypes = DEFAULT_EMPLOYEE_TYPES,
  onNotify,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [divisionFilter, setDivisionFilter] = useState<'All' | Division>('All');
  const [itiFilter, setItiFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [tradeFilter, setTradeFilter] = useState<string>('All');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  // Modal registration states
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
  const [isIncompleteModalOpen, setIsIncompleteModalOpen] = useState(false);
  const [incompleteErrors, setIncompleteErrors] = useState<
    { field: string; message: string; elementId: string }[]
  >([]);
  const [name, setName] = useState('');
  const [selectedItiId, setSelectedItiId] = useState(trainingCenters[0]?.id || 'iti-1');
  const [trade, setTrade] = useState('');
  const [employeeType, setEmployeeType] = useState<string>(
    employeeTypes && employeeTypes.length > 0 ? employeeTypes[0] : 'Vocational Instructor'
  );
  const [contact, setContact] = useState('');
  const [joiningDate, setJoiningDate] = useState(new Date().toISOString().split('T')[0]);
  const [remarks, setRemarks] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successDetails, setSuccessDetails] = useState<{
    id: string;
    name: string;
    itiName: string;
    division: string;
    trade: string;
    employeeType: string;
    contact: string;
    joiningDate: string;
    refNo: string;
    submittedAt: string;
  } | null>(null);

  // Track Registration Modal State
  const [isTrackModalOpen, setIsTrackModalOpen] = useState(false);
  const [trackQuery, setTrackQuery] = useState('');
  const [trackedInstructor, setTrackedInstructor] = useState<Instructor | null>(null);
  const [trackSearched, setTrackSearched] = useState(false);

  // Derive selected ITI object to get division & name
  const currentSelectedIti = useMemo(
    () => trainingCenters.find((tc) => tc.id === selectedItiId) || trainingCenters[0],
    [trainingCenters, selectedItiId]
  );

  // Approved instructors count
  const approvedInstructors = useMemo(() => {
    return instructors.filter((i) => i.approvalStatus === 'Approved' || !i.approvalStatus);
  }, [instructors]);

  const handleResetFilters = () => {
    setSearchTerm('');
    setDivisionFilter('All');
    setItiFilter('All');
    setStatusFilter('All');
    setTradeFilter('All');
    setCurrentPage(1);
  };

  const handleSearchTrack = (explicitQuery?: string) => {
    const q = (explicitQuery !== undefined ? explicitQuery : trackQuery).trim().toLowerCase();
    if (!q) return;
    setTrackSearched(true);
    const found = instructors.find((inst) => {
      const reg = (inst.registrationNo || '').toLowerCase();
      const id = (inst.id || '').toLowerCase();
      const instName = (inst.name || '').toLowerCase();
      const contact = (inst.contact || '').toLowerCase();
      return (
        reg === q ||
        reg.includes(q) ||
        id === q ||
        id.includes(q) ||
        instName.includes(q) ||
        contact.includes(q)
      );
    });
    setTrackedInstructor(found || null);
  };

  // Derive available trades for the filter dropdown
  const uniqueTrades = useMemo(() => {
    const set = new Set<string>();
    approvedInstructors.forEach((i) => {
      if (i.trade && i.trade.trim() !== '') set.add(i.trade.trim());
    });
    return Array.from(set).sort();
  }, [approvedInstructors]);

  const filteredInstructors = useMemo(() => {
    return approvedInstructors.filter((inst) => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch =
        inst.name.toLowerCase().includes(searchLower) ||
        inst.trade.toLowerCase().includes(searchLower) ||
        inst.itiName.toLowerCase().includes(searchLower) ||
        (inst.contact && inst.contact.includes(searchTerm)) ||
        (inst.registrationNo && inst.registrationNo.toLowerCase().includes(searchLower)) ||
        (inst.id && inst.id.toLowerCase().includes(searchLower));

      const matchesDivision = divisionFilter === 'All' || inst.division === divisionFilter;
      const matchesIti = itiFilter === 'All' || inst.itiId === itiFilter;
      const matchesStatus = statusFilter === 'All' || inst.status === statusFilter;
      const matchesTrade = tradeFilter === 'All' || inst.trade === tradeFilter;

      return matchesSearch && matchesDivision && matchesIti && matchesStatus && matchesTrade;
    });
  }, [approvedInstructors, searchTerm, divisionFilter, itiFilter, statusFilter, tradeFilter]);

  const totalPages = Math.ceil(filteredInstructors.length / pageSize) || 1;
  const paginatedInstructors = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredInstructors.slice(start, start + pageSize);
  }, [filteredInstructors, currentPage, pageSize]);

  const handleOpenRegisterModal = () => {
    setName('');
    const defaultIti = trainingCenters[0]?.id || 'iti-1';
    setSelectedItiId(defaultIti);
    setTrade('');
    setContact('');
    setJoiningDate(new Date().toISOString().split('T')[0]);
    setRemarks('');
    setIncompleteErrors([]);
    setIsIncompleteModalOpen(false);
    setIsRegisterModalOpen(true);
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Check for incomplete / missing fields
    const missing: { field: string; message: string; elementId: string }[] = [];
    if (!name.trim()) {
      missing.push({
        field: 'Employee Full Name',
        message: 'Full name of the skill development employee is required.',
        elementId: 'reg-input-name',
      });
    }
    if (!selectedItiId) {
      missing.push({
        field: 'Assigned ITI',
        message: 'Please select an assigned Government ITI from the list.',
        elementId: 'reg-input-iti',
      });
    }
    if (!trade.trim()) {
      missing.push({
        field: 'Trade / Subject',
        message: 'Vocational trade or subject designation is required (e.g. Electrician, COPA, Fitter).',
        elementId: 'reg-input-trade',
      });
    }
    if (!employeeType.trim()) {
      missing.push({
        field: 'Employee Type',
        message: 'Please select an employee type designation.',
        elementId: 'reg-input-employee-type',
      });
    }
    if (!contact.trim()) {
      missing.push({
        field: 'Mobile / Contact Number',
        message: 'Active mobile contact number is required for official verification.',
        elementId: 'reg-input-contact',
      });
    } else if (!/^[0-9+\s\-]{8,15}$/.test(contact.trim())) {
      missing.push({
        field: 'Mobile / Contact Number',
        message: 'Please enter a valid telephone/mobile number (at least 8–10 digits).',
        elementId: 'reg-input-contact',
      });
    }
    if (!joiningDate) {
      missing.push({
        field: 'Joining Date',
        message: 'Date of joining or appointment is required.',
        elementId: 'reg-input-date',
      });
    }

    if (missing.length > 0) {
      setIncompleteErrors(missing);
      setIsIncompleteModalOpen(true);
      return;
    }

    const itiObj = trainingCenters.find((tc) => tc.id === selectedItiId) || trainingCenters[0];
    const itiName = itiObj ? itiObj.name : 'Government ITI';
    const division: Division = itiObj ? itiObj.division : 'Kashmir Division';

    setIsSubmitting(true);
    try {
      const refNo = `JK-ITI-REG-${Math.floor(100000 + Math.random() * 900000)}`;
      const saved = await registerInstructor({
        name: name.trim(),
        itiId: selectedItiId,
        itiName,
        division,
        trade: trade.trim(),
        employeeType: employeeType.trim() || 'Vocational Instructor',
        contact: contact.trim(),
        joiningDate,
        status: 'Active',
        remarks: remarks.trim(),
        registrationNo: refNo,
      });
      const nowFormatted = new Date().toLocaleString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });

      setSuccessDetails({
        id: saved.id,
        name: name.trim(),
        itiName,
        division,
        trade: trade.trim(),
        employeeType: employeeType.trim() || 'Vocational Instructor',
        contact: contact.trim() || 'Not Provided',
        joiningDate,
        refNo,
        submittedAt: nowFormatted,
      });

      // Close input form modal and show the dedicated success message box modal dialog
      setIsRegisterModalOpen(false);
      setIsSuccessModalOpen(true);

      onNotify?.(
        'success',
        `Registration for "${name.trim()}" submitted successfully. Queued in CPANEL for approval.`
      );
    } catch (err: any) {
      onNotify?.('error', err.message || 'Failed to submit registration. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-700"></span>
              <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
                Industrial Training Institutes • Jammu &amp; Kashmir
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-[#0F2942] uppercase tracking-tight">
              SKILL DEVELOPMENT EMPLOYEEE
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Statewide roster of verified Skill Development Employees teaching across 50 Government ITIs
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-indigo-50 border border-indigo-200 px-4 py-2.5 rounded-lg text-center">
              <span className="block text-xl font-black text-indigo-900">
                {approvedInstructors.length}
              </span>
              <span className="text-[10px] uppercase font-bold text-indigo-700 tracking-wider">
                Verified Employees
              </span>
            </div>

            <button
              type="button"
              id="btn-track-registration-public"
              onClick={() => {
                setIsTrackModalOpen(true);
                setTrackQuery('');
                setTrackedInstructor(null);
                setTrackSearched(false);
              }}
              className="px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-colors shadow-xs cursor-pointer active:scale-95"
            >
              <Search className="w-4 h-4" />
              <span>TRACK REGISTRATION</span>
            </button>

            <button
              type="button"
              id="btn-add-vocational-instructor-public"
              onClick={handleOpenRegisterModal}
              className="px-4 py-2.5 rounded-lg bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-colors shadow-xs cursor-pointer active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>ADD SKILL DEVELOPMENT EMPLOYEEE</span>
            </button>
          </div>
        </div>

        {/* Filter Toolbar */}
        <div className="mt-6 pt-6 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 text-xs">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="inst-search-input"
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search name, trade, reg. no (e.g. JK-ITI-REG-100001)..."
              className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            />
          </div>

          {/* Division Filter */}
          <div>
            <select
              id="inst-div-select"
              value={divisionFilter}
              onChange={(e) => {
                setDivisionFilter(e.target.value as any);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 bg-white border border-slate-300 rounded-lg text-xs text-slate-700 focus:outline-hidden"
            >
              <option value="All">All Divisions</option>
              <option value="Kashmir Division">Kashmir Division</option>
              <option value="Jammu Division">Jammu Division</option>
            </select>
          </div>

          {/* ITI Filter */}
          <div>
            <select
              id="inst-iti-select"
              value={itiFilter}
              onChange={(e) => {
                setItiFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 bg-white border border-slate-300 rounded-lg text-xs text-slate-700 focus:outline-hidden"
            >
              <option value="All">All ITIs (50)</option>
              {trainingCenters.map((iti) => (
                <option key={iti.id} value={iti.id}>
                  {iti.sNo}. {iti.name}
                </option>
              ))}
            </select>
          </div>

          {/* Trade Filter */}
          <div>
            <select
              id="inst-trade-select"
              value={tradeFilter}
              onChange={(e) => {
                setTradeFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 bg-white border border-slate-300 rounded-lg text-xs text-slate-700 focus:outline-hidden"
            >
              <option value="All">All Trades</option>
              {uniqueTrades.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              id="inst-status-select"
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 bg-white border border-slate-300 rounded-lg text-xs text-slate-700 focus:outline-hidden"
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active</option>
              <option value="On Leave">On Leave</option>
              <option value="Transferred">Transferred</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
        </div>
      </div>

      {/* Instructors Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#0F2942] text-slate-200 uppercase font-bold text-[11px] tracking-wider border-b border-slate-800">
                <th className="py-3 px-3.5 text-center w-14">S.No</th>
                <th className="py-3 px-4 min-w-[180px]">Instructor Name</th>
                <th className="py-3 px-4 min-w-[180px]">ITI &amp; Division</th>
                <th className="py-3 px-4 min-w-[170px]">Trade / Subject</th>
                <th className="py-3 px-4">Contact</th>
                <th className="py-3 px-4 text-center">Joining Date</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 min-w-[140px]">Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {paginatedInstructors.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-xs text-slate-500">
                    <p className="font-semibold text-slate-700">No Skill Development Employees found matching the selected filters.</p>
                    <div className="flex items-center justify-center gap-2 mt-3">
                      <button
                        type="button"
                        onClick={handleResetFilters}
                        className="px-3 py-1.5 rounded-lg bg-slate-200 text-slate-700 hover:bg-slate-300 font-bold text-xs transition-colors cursor-pointer"
                      >
                        Reset Filters
                      </button>
                      <button
                        type="button"
                        onClick={handleOpenRegisterModal}
                        className="px-3 py-1.5 rounded-lg bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs transition-colors cursor-pointer inline-flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>ADD SKILL DEVELOPMENT EMPLOYEEE</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                paginatedInstructors.map((inst, idx) => {
                  const sNo = (currentPage - 1) * pageSize + idx + 1;
                  const isKashmir = inst.division === 'Kashmir Division';
                  return (
                    <tr
                      key={inst.id}
                      className={`hover:bg-indigo-50/40 transition-colors ${
                        idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/40'
                      }`}
                    >
                      <td className="py-3 px-3.5 text-center font-bold text-slate-500">
                        {sNo}
                      </td>
                      <td className="py-3 px-4 font-bold text-slate-900">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-indigo-100 text-indigo-900 flex items-center justify-center font-bold text-xs shrink-0">
                            {inst.name.charAt(0)}
                          </div>
                          <div className="flex flex-col">
                            <span>{inst.name}</span>
                            {inst.registrationNo && (
                              <span className="text-[10px] font-mono text-indigo-700 font-semibold">
                                {inst.registrationNo}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex flex-col">
                          <span className="font-semibold text-slate-900">{inst.itiName}</span>
                          <span
                            className={`inline-block w-max mt-0.5 px-1.5 py-0.2 rounded text-[10px] font-bold ${
                              isKashmir
                                ? 'text-blue-800 bg-blue-50'
                                : 'text-emerald-800 bg-emerald-50'
                            }`}
                          >
                            {inst.division}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex flex-col">
                          <div className="flex items-center gap-1.5 text-slate-800 font-medium">
                            <Briefcase className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span>{inst.trade}</span>
                          </div>
                          <span className="text-[10px] text-indigo-700 font-medium bg-indigo-50 px-1.5 py-0.5 rounded w-fit border border-indigo-100 mt-1">
                            {inst.employeeType || 'Vocational Instructor'}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-600">
                        <div className="flex items-center gap-1.5">
                          <Phone className="w-3 h-3 text-slate-400" />
                          <span>{inst.contact || '—'}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center font-mono text-slate-600">
                        {formatDate(inst.joiningDate)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            inst.status === 'Active'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              : inst.status === 'On Leave'
                              ? 'bg-amber-100 text-amber-800 border border-amber-200'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {inst.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-500 text-[11px] truncate max-w-xs">
                        {inst.remarks || '—'}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
          <div>
            Showing {filteredInstructors.length > 0 ? (currentPage - 1) * pageSize + 1 : 0} to{' '}
            {Math.min(currentPage * pageSize, filteredInstructors.length)} of{' '}
            {filteredInstructors.length} Instructors
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              id="inst-prev-btn"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              className="p-1.5 rounded border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              aria-label="Previous Page"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-3 py-1 font-semibold text-slate-700">
              Page {currentPage} of {totalPages}
            </span>
            <button
              type="button"
              id="inst-next-btn"
              disabled={currentPage === totalPages || totalPages === 0}
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              className="p-1.5 rounded border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              aria-label="Next Page"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Public Add Skill Development Employee Modal */}
      {isRegisterModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden animate-scaleUp">
            {/* Modal Header */}
            <div className="bg-[#0F2942] text-white p-5 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest block">
                  J&amp;K ITI EMPLOYEE&#39;S UNITED FRONT
                </span>
                <h3 className="text-base font-bold uppercase tracking-wide">
                  ADD SKILL DEVELOPMENT EMPLOYEEE
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsRegisterModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white rounded-md transition-colors cursor-pointer"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRegisterSubmit} noValidate className="p-6 space-y-4 text-xs">
              {/* Approval Notice */}
              <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg flex items-start gap-2.5 text-blue-900">
                <Info className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                <p className="text-[11px] leading-relaxed text-blue-950">
                  <strong>Self-Registration:</strong> Instructors can register here without logging in. Your registration will be reviewed and approved by the administrator inside CPANEL before appearing in the verified statewide roster.
                </p>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Instructor Full Name *
                </label>
                <input
                  id="reg-input-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Ghulam Mohammad"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Assigned ITI *
                  </label>
                  <select
                    id="reg-input-iti"
                    required
                    value={selectedItiId}
                    onChange={(e) => setSelectedItiId(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden"
                  >
                    {trainingCenters.map((tc) => (
                      <option key={tc.id} value={tc.id}>
                        {tc.sNo}. {tc.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Division (Auto-set)
                  </label>
                  <input
                    type="text"
                    disabled
                    value={currentSelectedIti?.division || 'Kashmir Division'}
                    className="w-full p-2 bg-slate-100 border border-slate-300 rounded-lg text-slate-600 font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Trade / Subject *
                  </label>
                  <input
                    id="reg-input-trade"
                    type="text"
                    required
                    value={trade}
                    onChange={(e) => setTrade(e.target.value)}
                    placeholder="e.g. Electrician, COPA, Fitter"
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Employee Type *
                  </label>
                  <select
                    id="reg-input-employee-type"
                    required
                    value={employeeType}
                    onChange={(e) => setEmployeeType(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden font-medium"
                  >
                    {employeeTypes.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Mobile / Contact Number *
                  </label>
                  <input
                    id="reg-input-contact"
                    type="text"
                    required
                    value={contact}
                    onChange={(e) => setContact(e.target.value)}
                    placeholder="e.g. 9419012345"
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Joining Date / Date of Appointment *
                  </label>
                  <input
                    id="reg-input-date"
                    type="date"
                    required
                    value={joiningDate}
                    onChange={(e) => setJoiningDate(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsRegisterModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-lg bg-indigo-700 hover:bg-indigo-800 text-white font-bold disabled:opacity-50 transition-colors shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Submitting...</span>
                    </>
                  ) : (
                    <span>Submit for Admin Approval</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Dialog Message Box for Incomplete Fields */}
      {isIncompleteModalOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border border-rose-200 max-w-md w-full overflow-hidden animate-scaleUp">
            {/* Modal Dialog Header */}
            <div className="bg-rose-700 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-white/20 border border-white/30 flex items-center justify-center text-white shrink-0">
                  <AlertCircle className="w-5 h-5 text-amber-200" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-amber-200 uppercase tracking-widest block">
                    Form Validation Alert
                  </span>
                  <h3 className="text-base font-black tracking-tight uppercase">
                    INCOMPLETE FIELDS
                  </h3>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsIncompleteModalOpen(false)}
                className="p-1 text-white/80 hover:text-white rounded-md transition-colors cursor-pointer"
                title="Close dialog"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Dialog Content */}
            <div className="p-6 space-y-4">
              <div className="flex items-start gap-2 text-xs text-slate-700">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <p>
                  Please fill in the following <strong>{incompleteErrors.length} mandatory field{incompleteErrors.length > 1 ? 's' : ''}</strong> before submitting your instructor registration:
                </p>
              </div>

              {/* Incomplete Fields List */}
              <div className="bg-rose-50/80 border border-rose-200 rounded-xl p-3.5 space-y-2.5">
                {incompleteErrors.map((err, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs">
                    <span className="w-2 h-2 rounded-full bg-rose-600 mt-1.5 shrink-0"></span>
                    <div>
                      <span className="font-bold text-rose-950 uppercase tracking-wide">
                        {err.field}:{' '}
                      </span>
                      <span className="text-rose-800">{err.message}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg text-[11px] text-slate-600 leading-relaxed">
                <strong>CPANEL Verification Notice:</strong> Complete and accurate records are required by Directorate administrators to review and approve instructor profiles for the verified statewide roster.
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsIncompleteModalOpen(false);
                    const first = incompleteErrors[0];
                    if (first?.elementId) {
                      setTimeout(() => {
                        const el = document.getElementById(first.elementId);
                        el?.focus();
                      }, 100);
                    }
                  }}
                  className="w-full py-2.5 px-4 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-xs cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>Complete Required Fields</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Dialog Message Box for Successful Registration */}
      {isSuccessModalOpen && successDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden animate-scaleUp">
            {/* Dialog Header */}
            <div className="bg-[#0F2942] text-white p-5 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest block">
                    J&amp;K Skill Development Department
                  </span>
                  <h3 className="text-base font-black tracking-tight">
                    REGISTRATION SUCCESSFUL
                  </h3>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsSuccessModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white rounded-md transition-colors cursor-pointer"
                title="Close dialog"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Dialog Content */}
            <div className="p-6 space-y-4">
              {/* Success Badge Banner */}
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-xs text-emerald-950 space-y-0.5">
                  <p className="font-bold text-emerald-900 text-sm">
                    Instructor Enrollment Application Submitted!
                  </p>
                  <p className="text-emerald-800 text-[11px] leading-relaxed">
                    Your details have been registered in the system and forwarded for administrative review.
                  </p>
                </div>
              </div>

              {/* Reference Card */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">
                      Application Reference
                    </span>
                    <span className="font-mono text-sm font-black text-indigo-700">
                      {successDetails.refNo}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">
                      Approval Status
                    </span>
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                      <Clock className="w-3 h-3 text-amber-700" />
                      Pending Review (Awaiting Approval)
                    </span>
                  </div>
                </div>

                {/* Candidate Details Grid */}
                <div className="grid grid-cols-2 gap-2.5 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 font-semibold block uppercase">Instructor Name</span>
                    <span className="font-bold text-slate-800">{successDetails.name}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-semibold block uppercase">Trade / Subject</span>
                    <span className="font-bold text-slate-800">{successDetails.trade}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-semibold block uppercase">Employee Type</span>
                    <span className="font-bold text-indigo-800 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100 inline-block text-xs">
                      {successDetails.employeeType}
                    </span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-[10px] text-slate-400 font-semibold block uppercase">Assigned Institute</span>
                    <span className="font-bold text-slate-800 flex items-center gap-1">
                      <Building2 className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      {successDetails.itiName} ({successDetails.division})
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-semibold block uppercase">Mobile Contact</span>
                    <span className="font-medium text-slate-700">{successDetails.contact}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-semibold block uppercase">Submission Date</span>
                    <span className="font-medium text-slate-700">{successDetails.submittedAt}</span>
                  </div>
                </div>
              </div>

              {/* CPANEL Approval Workflow Notice */}
              <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-3.5 flex items-start gap-2.5 text-xs text-indigo-950">
                <ShieldCheck className="w-5 h-5 text-indigo-700 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-bold text-indigo-900">
                    Approval Status: Pending Review (Awaiting Approval)
                  </p>
                  <p className="text-[11px] text-indigo-900/80 leading-relaxed">
                    This registration has been registered with Approval Status <strong>Pending Review (Awaiting Approval)</strong> and is immediately reflected in CPANEL under <strong>MANAGE SKILL DEVELOPMENT EMPLOYEES</strong>. Authorized officers can review your application and use the <strong>Approve</strong> or <strong>Reject</strong> action buttons. Once approved, your profile will appear on the public verified roster.
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsSuccessModalOpen(false)}
                  className="w-full py-2.5 px-4 rounded-lg bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-xs"
                >
                  Close &amp; Return to Roster
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TRACK REGISTRATION MODAL */}
      {isTrackModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="bg-[#0F2942] text-white p-5 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
                  <Search className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-sm uppercase tracking-wide">
                    Track Vocational Registration
                  </h3>
                  <p className="text-[11px] text-slate-300">
                    Industrial Training Institutes • Jammu &amp; Kashmir
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsTrackModalOpen(false)}
                className="w-8 h-8 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-5 overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Enter Registration ID or Mobile Number
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      id="track-reg-input"
                      value={trackQuery}
                      onChange={(e) => setTrackQuery(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleSearchTrack();
                        }
                      }}
                      placeholder="e.g. JK-ITI-REG-100001"
                      className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    />
                  </div>
                  <button
                    type="button"
                    id="btn-track-submit"
                    onClick={() => handleSearchTrack()}
                    className="px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-xs"
                  >
                    Check Status
                  </button>
                </div>
              </div>

              {trackSearched && trackedInstructor && (
                <div className="rounded-xl border border-emerald-200 bg-emerald-50/40 p-4 space-y-4">
                  <div className="flex items-center justify-between gap-2 border-b border-emerald-200/70 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                        <Check className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">
                          Registration Found
                        </span>
                        <h4 className="text-sm font-black text-slate-900">
                          {trackedInstructor.name}
                        </h4>
                      </div>
                    </div>
                    <span
                      className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                        trackedInstructor.approvalStatus === 'Approved' || !trackedInstructor.approvalStatus
                          ? 'bg-emerald-600 text-white'
                          : trackedInstructor.approvalStatus === 'Pending'
                          ? 'bg-amber-500 text-slate-950'
                          : 'bg-rose-600 text-white'
                      }`}
                    >
                      {trackedInstructor.approvalStatus || 'Approved'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="bg-white rounded-lg p-2.5 border border-emerald-100">
                      <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                        Reference Number
                      </span>
                      <span className="font-mono font-bold text-indigo-900 text-xs">
                        {trackedInstructor.registrationNo || trackedInstructor.id}
                      </span>
                    </div>

                    <div className="bg-white rounded-lg p-2.5 border border-emerald-100">
                      <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                        Trade / Subject
                      </span>
                      <span className="font-semibold text-slate-800">
                        {trackedInstructor.trade}
                      </span>
                    </div>

                    <div className="bg-white rounded-lg p-2.5 border border-emerald-100">
                      <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                        Assigned Institute
                      </span>
                      <span className="font-semibold text-slate-800">
                        {trackedInstructor.itiName}
                      </span>
                      <span className="block text-[10px] text-slate-500">
                        {trackedInstructor.division}
                      </span>
                    </div>

                    <div className="bg-white rounded-lg p-2.5 border border-emerald-100">
                      <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                        Appointment / Joining
                      </span>
                      <span className="font-mono text-slate-800">
                        {formatDate(trackedInstructor.joiningDate)}
                      </span>
                    </div>

                    <div className="bg-white rounded-lg p-2.5 border border-emerald-100 sm:col-span-2">
                      <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                        Contact Number
                      </span>
                      <span className="font-mono text-slate-800">
                        {trackedInstructor.contact || 'Not Provided'}
                      </span>
                    </div>
                  </div>

                  <div className="pt-2 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsTrackModalOpen(false);
                        setSearchTerm(trackedInstructor.registrationNo || trackedInstructor.name);
                        setCurrentPage(1);
                      }}
                      className="w-full py-2 px-3 rounded-lg bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-xs text-center"
                    >
                      Show in Public Roster Table
                    </button>
                  </div>
                </div>
              )}

              {trackSearched && !trackedInstructor && (
                <div className="rounded-xl border border-rose-200 bg-rose-50/50 p-4 text-center space-y-2">
                  <p className="font-bold text-rose-900 text-xs">
                    No Registration Found for &quot;{trackQuery}&quot;
                  </p>
                  <p className="text-[11px] text-rose-700">
                    Please verify the reference code format (e.g. <code>JK-ITI-REG-100001</code>) or search with the candidate full name.
                  </p>
                </div>
              )}
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setIsTrackModalOpen(false)}
                className="px-4 py-2 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

