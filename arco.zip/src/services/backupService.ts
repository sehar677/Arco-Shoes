import { CloudBackupRecord, AutoBackupScheduleConfig } from '../types';
import { dbService } from './storage';
import { auditService } from './auditService';
import { db } from '../firebase';
import { doc, setDoc, onSnapshot, collection, query, orderBy, limit } from 'firebase/firestore';

const BACKUP_SCHEDULE_STORAGE_KEY = 'arco_backup_schedule_config_v2';
const CLOUD_BACKUPS_STORAGE_KEY = 'arco_cloud_backups_v2';

const DEFAULT_SCHEDULE_CONFIG: AutoBackupScheduleConfig = {
  enabled: true,
  frequency: 'DAILY',
  dailyTime: '23:00',
  retentionCount: 14,
  autoArchiveToExcel: false,
};

class BackupService {
  private backups: CloudBackupRecord[] = [];
  private scheduleConfig: AutoBackupScheduleConfig;
  private listeners: Array<(backups: CloudBackupRecord[]) => void> = [];
  private checkIntervalTimer: any = null;

  constructor() {
    this.scheduleConfig = this.loadScheduleConfig();
    this.backups = this.loadLocalBackups();
    if (typeof window !== 'undefined') {
      this.initFirestoreListener();
      this.startScheduler();
    }
  }

  private loadScheduleConfig(): AutoBackupScheduleConfig {
    try {
      const data = localStorage.getItem(BACKUP_SCHEDULE_STORAGE_KEY);
      if (data) {
        return { ...DEFAULT_SCHEDULE_CONFIG, ...JSON.parse(data) };
      }
    } catch (e) {
      console.warn('Failed to parse backup schedule config:', e);
    }
    return DEFAULT_SCHEDULE_CONFIG;
  }

  saveScheduleConfig(config: AutoBackupScheduleConfig): void {
    this.scheduleConfig = config;
    try {
      localStorage.setItem(BACKUP_SCHEDULE_STORAGE_KEY, JSON.stringify(config));
    } catch (e) {
      console.warn('Failed to save backup schedule config:', e);
    }
  }

  getScheduleConfig(): AutoBackupScheduleConfig {
    return { ...this.scheduleConfig };
  }

  private loadLocalBackups(): CloudBackupRecord[] {
    try {
      const data = localStorage.getItem(CLOUD_BACKUPS_STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Failed to parse local backups:', e);
    }
    return [];
  }

  private saveLocalBackups(): void {
    try {
      localStorage.setItem(CLOUD_BACKUPS_STORAGE_KEY, JSON.stringify(this.backups));
    } catch (e) {
      console.warn('Failed to save local backups:', e);
    }
  }

  private initFirestoreListener(): void {
    try {
      const q = query(collection(db, 'cloud_backups'), orderBy('timestamp', 'desc'), limit(50));
      onSnapshot(q, (snapshot) => {
        let changed = false;
        snapshot.docChanges().forEach((change) => {
          if (change.type === 'added' || change.type === 'modified') {
            const data = change.doc.data() as CloudBackupRecord;
            if (data && data.id) {
              const existingIdx = this.backups.findIndex((b) => b.id === data.id);
              if (existingIdx === -1) {
                this.backups.unshift(data);
                changed = true;
              } else {
                this.backups[existingIdx] = data;
                changed = true;
              }
            }
          }
        });
        if (changed) {
          this.backups.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
          this.saveLocalBackups();
          this.notify();
        }
      }, (err) => {
        console.warn('Firestore cloud_backups listener error:', err.message);
      });
    } catch (e) {
      console.warn('Error setting up cloud_backups listener:', e);
    }
  }

  subscribe(callback: (backups: CloudBackupRecord[]) => void): () => void {
    this.listeners.push(callback);
    callback(this.backups);
    return () => {
      this.listeners = this.listeners.filter((cb) => cb !== callback);
    };
  }

  private notify(): void {
    this.listeners.forEach((cb) => {
      try {
        cb(this.backups);
      } catch (err) {
        console.error('Backup listener error:', err);
      }
    });
  }

  /**
   * Background schedule runner
   */
  private startScheduler(): void {
    if (this.checkIntervalTimer) {
      clearInterval(this.checkIntervalTimer);
    }
    // Check every 10 minutes whether an automated backup is due
    this.checkIntervalTimer = setInterval(() => {
      this.checkAndRunScheduledBackup();
    }, 10 * 60 * 1000);

    // Initial check 5 seconds after load
    setTimeout(() => {
      this.checkAndRunScheduledBackup();
    }, 5000);
  }

  private checkAndRunScheduledBackup(): void {
    if (!this.scheduleConfig.enabled) return;

    const now = new Date();
    const lastBackupTime = this.scheduleConfig.lastBackupAt
      ? new Date(this.scheduleConfig.lastBackupAt).getTime()
      : 0;

    let isDue = false;
    const hoursSinceLast = (now.getTime() - lastBackupTime) / (1000 * 60 * 60);

    switch (this.scheduleConfig.frequency) {
      case 'HOURLY':
        if (hoursSinceLast >= 1) isDue = true;
        break;
      case 'EVERY_6_HOURS':
        if (hoursSinceLast >= 6) isDue = true;
        break;
      case 'EVERY_12_HOURS':
        if (hoursSinceLast >= 12) isDue = true;
        break;
      case 'DAILY':
      default:
        // Check if more than 20 hours have passed since last backup
        if (hoursSinceLast >= 20) {
          const [targetHour, targetMin] = (this.scheduleConfig.dailyTime || '23:00')
            .split(':')
            .map(Number);
          if (now.getHours() >= (targetHour || 23)) {
            isDue = true;
          }
        }
        break;
    }

    if (isDue) {
      console.log('Automated Cloud Backup is due. Executing snapshot...');
      this.createCloudSnapshot('AUTOMATED', 'System scheduled automatic database snapshot');
    }
  }

  /**
   * Create a cloud database snapshot
   */
  async createCloudSnapshot(type: 'AUTOMATED' | 'MANUAL' = 'MANUAL', notes?: string): Promise<CloudBackupRecord> {
    const rawDump = dbService.exportFullDatabase();
    const parsedData = JSON.parse(rawDump);

    const items = parsedData.items || [];
    const customers = parsedData.customers || [];
    const suppliers = parsedData.suppliers || [];
    const sales = parsedData.sales || [];
    const purchases = parsedData.purchases || [];
    const adjustments = parsedData.adjustments || [];
    const ledgers = parsedData.ledgers || [];
    const auditLogs = auditService.getLogs();

    const totalRecords =
      items.length +
      customers.length +
      suppliers.length +
      sales.length +
      purchases.length +
      adjustments.length +
      ledgers.length;

    const timestamp = new Date().toISOString();
    const recordId = `backup-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const sizeBytes = new Blob([rawDump]).size;

    const record: CloudBackupRecord = {
      id: recordId,
      timestamp,
      type,
      version: parsedData.version || 'FIREBASE_ARCO_GST_V2.0',
      totalRecords,
      counts: {
        items: items.length,
        customers: customers.length,
        suppliers: suppliers.length,
        sales: sales.length,
        purchases: purchases.length,
        adjustments: adjustments.length,
        ledgers: ledgers.length,
        auditLogs: auditLogs.length,
      },
      sizeBytes,
      status: 'ACTIVE',
      storageLocation: 'BOTH',
      notes: notes || (type === 'AUTOMATED' ? 'Automated Cloud Snapshot' : 'Manual Admin Snapshot'),
      dataSnapshot: rawDump,
    };

    // Update local list
    this.backups.unshift(record);

    // Enforce retention policy
    const retentionLimit = this.scheduleConfig.retentionCount || 14;
    if (this.backups.length > retentionLimit) {
      // Mark or prune old snapshots
      this.backups = this.backups.slice(0, retentionLimit);
    }

    this.saveLocalBackups();
    this.notify();

    // Update last backup timestamp
    this.scheduleConfig.lastBackupAt = timestamp;
    this.saveScheduleConfig(this.scheduleConfig);

    // Sync to Firestore
    try {
      // We store metadata in Firestore (with trimmed dataSnapshot to prevent oversized single doc if needed, or full data)
      const firestoreDoc = { ...record };
      await setDoc(doc(db, 'cloud_backups', record.id), firestoreDoc);
    } catch (err) {
      console.warn('Could not sync backup record to Firestore:', err);
    }

    // Log to Audit Trail
    auditService.log({
      action: 'BACKUP',
      entityType: 'BACKUP',
      entityId: record.id,
      entityName: `Snapshot (${record.type})`,
      summary: `Created ${record.type} cloud database backup: ${totalRecords} records (${(sizeBytes / 1024).toFixed(1)} KB)`,
      details: {
        totalRecords,
        counts: record.counts,
        sizeBytes,
      },
    });

    return record;
  }

  /**
   * Restore database from snapshot
   */
  restoreFromSnapshot(backupId: string): { success: boolean; message: string; summary?: any } {
    const backup = this.backups.find((b) => b.id === backupId);
    if (!backup || !backup.dataSnapshot) {
      return { success: false, message: 'Backup payload not found or corrupted.' };
    }

    const res = dbService.importDatabase(backup.dataSnapshot);

    auditService.log({
      action: 'RESTORE',
      entityType: 'BACKUP',
      entityId: backupId,
      entityName: `Snapshot ${backup.timestamp}`,
      summary: `Restored database from snapshot ${new Date(backup.timestamp).toLocaleString()} (${backup.totalRecords} records)`,
      details: {
        backupId,
        timestamp: backup.timestamp,
        status: res.status,
      },
    });

    return {
      success: res.status === 'SUCCESS',
      message: res.status === 'SUCCESS' ? 'Database restored successfully from snapshot!' : 'Restore completed with warnings.',
      summary: res,
    };
  }

  /**
   * Delete snapshot
   */
  deleteSnapshot(backupId: string): void {
    this.backups = this.backups.filter((b) => b.id !== backupId);
    this.saveLocalBackups();
    this.notify();

    auditService.log({
      action: 'DELETE',
      entityType: 'BACKUP',
      entityId: backupId,
      entityName: 'Cloud Snapshot',
      summary: `Deleted cloud database snapshot ${backupId}`,
    });
  }

  getBackups(): CloudBackupRecord[] {
    return [...this.backups];
  }

  /**
   * One-Click Offline JSON Archive Export
   */
  downloadOfflineJsonArchive(): void {
    const jsonDump = dbService.exportFullDatabase();
    const dateStr = new Date().toISOString().slice(0, 10);
    const timeStr = new Date().toTimeString().slice(0, 8).replace(/:/g, '-');
    const filename = `ARCO_GST_Archive_Full_${dateStr}_${timeStr}.json`;

    const blob = new Blob([jsonDump], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    auditService.log({
      action: 'EXPORT',
      entityType: 'BACKUP',
      entityId: filename,
      entityName: 'Offline JSON Archive',
      summary: `Exported complete offline JSON archive file: ${filename}`,
    });
  }

  /**
   * One-Click Offline Multi-Sheet Excel (.xls XML format) Archive Export
   * Natively compatible with Excel, Google Sheets, LibreOffice, and Numbers!
   */
  downloadOfflineExcelArchive(): void {
    const rawDump = dbService.exportFullDatabase();
    const data = JSON.parse(rawDump);

    const items = data.items || [];
    const sales = data.sales || [];
    const customers = data.customers || [];
    const suppliers = data.suppliers || [];
    const adjustments = data.adjustments || [];
    const purchases = data.purchases || [];
    const auditLogs = auditService.getLogs();

    // Helper to sanitize XML text
    const esc = (val: any) => {
      if (val === null || val === undefined) return '';
      return String(val)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
    };

    // Helper to build an Excel XML sheet
    const buildSheet = (sheetName: string, headers: string[], rows: (string | number)[][]) => {
      let sheetXml = `<Worksheet ss:Name="${esc(sheetName)}"><Table>`;
      // Headers
      sheetXml += '<Row ss:StyleID="HeaderStyle">';
      headers.forEach((h) => {
        sheetXml += `<Cell><Data ss:Type="String">${esc(h)}</Data></Cell>`;
      });
      sheetXml += '</Row>';

      // Data Rows
      rows.forEach((r) => {
        sheetXml += '<Row>';
        r.forEach((val) => {
          const isNum = typeof val === 'number';
          const type = isNum ? 'Number' : 'String';
          sheetXml += `<Cell><Data ss:Type="${type}">${esc(val)}</Data></Cell>`;
        });
        sheetXml += '</Row>';
      });

      sheetXml += '</Table></Worksheet>';
      return sheetXml;
    };

    // Build Sheets
    // 1. Sales Invoices
    const salesHeaders = [
      'Invoice No',
      'Date',
      'Customer Name',
      'Phone',
      'Payment Mode',
      'Items Count',
      'Taxable Amt',
      'CGST',
      'SGST',
      'Discount',
      'Total Amount',
      'Payment Status',
    ];
    const salesRows = sales.map((s: any) => [
      s.invoiceNumber || s.id,
      s.date || '',
      s.customer?.name || s.customerName || 'Cash Sale',
      s.customer?.phone || '',
      s.paymentMode || 'CASH',
      (s.items || []).length,
      s.subTotal || s.taxableAmount || 0,
      s.cgstAmount || 0,
      s.sgstAmount || 0,
      s.discountAmount || 0,
      s.grandTotal || s.totalAmount || 0,
      s.status || 'PAID',
    ]);

    // 2. Inventory Items
    const itemsHeaders = [
      'Item Code',
      'Item Name',
      'Category',
      'Brand',
      'Size',
      'HSN Code',
      'Purchase Rate',
      'Selling Rate',
      'GST %',
      'Current Stock',
      'Min Stock Alert',
    ];
    const itemsRows = items.map((it: any) => [
      it.code || it.itemCode || '',
      it.name || it.itemName || '',
      it.category || '',
      it.brand || '',
      it.size || '',
      it.hsn || '',
      it.purchaseRate || it.costPrice || 0,
      it.rate || it.saleRate || 0,
      it.gstPercent || it.taxRate || 18,
      it.stock || it.currentStock || 0,
      it.minStock || 5,
    ]);

    // 3. Customers
    const customersHeaders = ['Customer Name', 'Mobile', 'GSTIN', 'Address', 'City', 'State', 'Khata Balance'];
    const customersRows = customers.map((c: any) => [
      c.name || '',
      c.mobile || c.phone || '',
      c.gstin || '',
      c.address || '',
      c.city || '',
      c.state || '',
      c.balance || c.currentBalance || 0,
    ]);

    // 4. Suppliers
    const suppliersHeaders = ['Supplier Name', 'Mobile', 'GSTIN', 'Address', 'City', 'Payable Balance'];
    const suppliersRows = suppliers.map((sup: any) => [
      sup.name || '',
      sup.mobile || sup.phone || '',
      sup.gstin || '',
      sup.address || '',
      sup.city || '',
      sup.balance || sup.currentBalance || 0,
    ]);

    // 5. Stock Adjustments
    const adjustmentsHeaders = [
      'Date',
      'Item Code',
      'Item Name',
      'Physical Stock',
      'System Stock',
      'Difference',
      'Reason',
    ];
    const adjustmentsRows = adjustments.map((adj: any) => [
      adj.date || '',
      adj.itemCode || '',
      adj.itemName || '',
      adj.physicalStock || 0,
      adj.systemStock || 0,
      adj.difference || 0,
      adj.reason || '',
    ]);

    // 6. Purchases
    const purchasesHeaders = [
      'Bill No',
      'Date',
      'Supplier Name',
      'Payment Mode',
      'Total Amount',
      'GST Amount',
    ];
    const purchasesRows = purchases.map((p: any) => [
      p.billNumber || p.invoiceNumber || p.id,
      p.date || '',
      p.supplierName || '',
      p.paymentMode || 'CREDIT',
      p.grandTotal || p.totalAmount || 0,
      p.totalGst || 0,
    ]);

    // 7. Audit Trail
    const auditHeaders = ['Timestamp', 'Action', 'Entity', 'Entity ID', 'User', 'Role', 'Summary'];
    const auditRows = auditLogs.slice(0, 500).map((l: any) => [
      new Date(l.timestamp).toLocaleString(),
      l.action,
      l.entityType,
      l.entityId,
      l.userName,
      l.userRole,
      l.summary,
    ]);

    // Complete XML Excel template
    const excelXml = `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
 <Styles>
  <Style ss:ID="Default" ss:Name="Normal">
   <Alignment ss:Vertical="Center"/>
   <Font ss:FontName="Segoe UI" ss:Size="10" ss:Color="#1E293B"/>
  </Style>
  <Style ss:ID="HeaderStyle">
   <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#475569"/>
   </Borders>
   <Font ss:FontName="Segoe UI" ss:Bold="1" ss:Size="11" ss:Color="#FFFFFF"/>
   <Interior ss:Color="#1E293B" ss:Pattern="Solid"/>
  </Style>
 </Styles>
 ${buildSheet('Sales Invoices', salesHeaders, salesRows)}
 ${buildSheet('Inventory Master', itemsHeaders, itemsRows)}
 ${buildSheet('Customers', customersHeaders, customersRows)}
 ${buildSheet('Suppliers', suppliersHeaders, suppliersRows)}
 ${buildSheet('Purchase Bills', purchasesHeaders, purchasesRows)}
 ${buildSheet('Stock Adjustments', adjustmentsHeaders, adjustmentsRows)}
 ${buildSheet('Audit Logs', auditHeaders, auditRows)}
</Workbook>`;

    const dateStr = new Date().toISOString().slice(0, 10);
    const filename = `ARCO_GST_MultiSheet_Workbook_${dateStr}.xls`;

    const blob = new Blob([excelXml], { type: 'application/vnd.ms-excel' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    auditService.log({
      action: 'EXPORT',
      entityType: 'BACKUP',
      entityId: filename,
      entityName: 'Offline Excel Workbook',
      summary: `Exported offline multi-sheet Excel archive (.xls): ${sales.length} sales, ${items.length} items, ${customers.length} customers`,
    });
  }
}

export const backupService = new BackupService();
