import React, { createContext, useContext, useEffect, useState, useRef, useCallback } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut,
} from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import {
  registerAdminSession,
  subscribeAdminSession,
  pingAdminSession,
  clearAdminSession,
} from '../services/db';

const SESSION_TIMEOUT_SECONDS = 120; // 2 minutes inactivity timeout
const SESSION_STORAGE_KEY = 'cpanel_active_admin_session_id';

interface AuthContextType {
  currentUser: User | null;
  isAdmin: boolean;
  loading: boolean;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (email: string, pass: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  authError: string | null;
  clearAuthError: () => void;
  sessionRemainingSeconds: number;
  extendSession: () => void;
  currentSessionId: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [sessionRemainingSeconds, setSessionRemainingSeconds] = useState<number>(SESSION_TIMEOUT_SECONDS);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(() => {
    return sessionStorage.getItem(SESSION_STORAGE_KEY);
  });

  const lastActivityRef = useRef<number>(Date.now());
  const lastPingRef = useRef<number>(0);
  const isLoggingOutRef = useRef<boolean>(false);

  // Helper to generate a new unique session identifier
  const generateNewSessionId = useCallback(() => {
    const newId = 'sess_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);
    sessionStorage.setItem(SESSION_STORAGE_KEY, newId);
    setCurrentSessionId(newId);
    return newId;
  }, []);

  // Helper to extend session on user activity
  const extendSession = useCallback(() => {
    lastActivityRef.current = Date.now();
    setSessionRemainingSeconds(SESSION_TIMEOUT_SECONDS);
  }, []);

  // Logout handler
  const logout = useCallback(async (reason?: string) => {
    if (isLoggingOutRef.current) return;
    isLoggingOutRef.current = true;

    try {
      const user = auth.currentUser;
      const sid = sessionStorage.getItem(SESSION_STORAGE_KEY);
      
      // 1. Immediately reset session storage and local state
      sessionStorage.removeItem(SESSION_STORAGE_KEY);
      setCurrentSessionId(null);
      setCurrentUser(null);

      // 2. Clear remote session in background without blocking logout
      if (user) {
        clearAdminSession(user.uid, sid || undefined).catch((err) => {
          console.warn('Background clear admin session notice:', err);
        });
      }

      // 3. Sign out of Firebase Auth
      await signOut(auth);
      if (reason) {
        setAuthError(reason);
      }
    } catch (err) {
      console.warn('Logout error:', err);
    } finally {
      isLoggingOutRef.current = false;
    }
  }, []);

  // 1. Firebase Auth State Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      setLoading(false);

      if (user) {
        // When user logs in or session is restored, ensure single active session registration
        let sid = sessionStorage.getItem(SESSION_STORAGE_KEY);
        if (!sid) {
          sid = generateNewSessionId();
        }
        lastActivityRef.current = Date.now();
        setSessionRemainingSeconds(SESSION_TIMEOUT_SECONDS);
        await registerAdminSession(user.uid, user.email || '', sid);
      } else {
        sessionStorage.removeItem(SESSION_STORAGE_KEY);
        setCurrentSessionId(null);
      }
    });

    return () => unsubscribe();
  }, [generateNewSessionId]);

  // 2. Real-time Single Concurrent Session Enforcement
  // Listens to the user's active session document in Firestore
  useEffect(() => {
    if (!currentUser || !currentSessionId) return;

    const unsubscribeSession = subscribeAdminSession(currentUser.uid, (remoteSession) => {
      if (!remoteSession) return;

      // If another browser/tab logged in with the same credentials, remote sessionId will differ
      if (remoteSession.sessionId && remoteSession.sessionId !== currentSessionId) {
        console.warn('[AUTH] Mismatched session detected! Another login occurred with the same credentials.');
        logout('Session Terminated: Another administrator logged in with these credentials from another window/device. Only one active admin session is permitted at a time.');
      }
    });

    // Also listen to storage events across tabs within the same browser
    const handleStorage = (e: StorageEvent) => {
      if (e.key === SESSION_STORAGE_KEY && e.newValue && e.newValue !== currentSessionId) {
        logout('Session Terminated: Another admin window was opened with this account. Only one active admin session is permitted at a time.');
      }
    };
    window.addEventListener('storage', handleStorage);

    return () => {
      unsubscribeSession();
      window.removeEventListener('storage', handleStorage);
    };
  }, [currentUser, currentSessionId, logout]);

  // 3. Inactivity Tracker (1-Minute Session Timeout)
  useEffect(() => {
    if (!currentUser) return;

    // Reset activity timer on any user interaction
    const handleUserInteraction = () => {
      const now = Date.now();
      lastActivityRef.current = now;

      // Throttled background ping (every 15s) to keep Firestore and Server in sync
      if (now - lastPingRef.current > 15000 && currentSessionId) {
        lastPingRef.current = now;
        pingAdminSession(currentUser.uid, currentSessionId);
      }
    };

    const events = ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart', 'click'];
    events.forEach((evt) => {
      window.addEventListener(evt, handleUserInteraction, { passive: true });
    });

    // 1-second interval ticker for exact 1-minute countdown
    const timerInterval = setInterval(() => {
      const now = Date.now();
      const elapsedSeconds = Math.floor((now - lastActivityRef.current) / 1000);
      const remaining = Math.max(0, SESSION_TIMEOUT_SECONDS - elapsedSeconds);

      setSessionRemainingSeconds(remaining);

      if (remaining <= 0) {
        console.warn('[AUTH] Admin session timed out after 2 minutes of inactivity.');
        logout('Session Expired: You were automatically logged out after 2 minutes of inactivity.');
      }
    }, 1000);

    return () => {
      events.forEach((evt) => {
        window.removeEventListener(evt, handleUserInteraction);
      });
      clearInterval(timerInterval);
    };
  }, [currentUser, currentSessionId, logout]);

  const isAdmin = !!currentUser;
  const clearAuthError = () => setAuthError(null);

  const loginWithEmail = async (email: string, pass: string) => {
    setAuthError(null);
    try {
      const sid = generateNewSessionId();
      lastActivityRef.current = Date.now();
      setSessionRemainingSeconds(SESSION_TIMEOUT_SECONDS);

      const userCredential = await signInWithEmailAndPassword(auth, email, pass);
      await registerAdminSession(userCredential.user.uid, userCredential.user.email || email, sid);
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'Authentication failed';
      if (errorMsg.includes('user-not-found') || errorMsg.includes('invalid-credential')) {
        setAuthError('Invalid credentials. If this is your first admin login, you can create the admin account below or sign in with Google.');
      } else if (errorMsg.includes('wrong-password')) {
        setAuthError('Incorrect password. Please verify your credentials.');
      } else {
        setAuthError(errorMsg);
      }
      throw err;
    }
  };

  const registerWithEmail = async (email: string, pass: string) => {
    setAuthError(null);
    try {
      const sid = generateNewSessionId();
      lastActivityRef.current = Date.now();
      setSessionRemainingSeconds(SESSION_TIMEOUT_SECONDS);

      const userCredential = await createUserWithEmailAndPassword(auth, email, pass);
      await registerAdminSession(userCredential.user.uid, userCredential.user.email || email, sid);
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'Registration failed';
      setAuthError(errorMsg);
      throw err;
    }
  };

  const loginWithGoogle = async () => {
    setAuthError(null);
    try {
      const sid = generateNewSessionId();
      lastActivityRef.current = Date.now();
      setSessionRemainingSeconds(SESSION_TIMEOUT_SECONDS);

      const userCredential = await signInWithPopup(auth, googleProvider);
      await registerAdminSession(userCredential.user.uid, userCredential.user.email || '', sid);
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'Google sign-in failed';
      setAuthError(errorMsg);
      throw err;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAdmin,
        loading,
        loginWithEmail,
        registerWithEmail,
        loginWithGoogle,
        logout: () => logout(),
        authError,
        clearAuthError,
        sessionRemainingSeconds,
        extendSession,
        currentSessionId,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

