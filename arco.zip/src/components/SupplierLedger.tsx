import React, { useState, useEffect } from 'react';
import {
  Building2,
  Search,
  Calendar,
  Printer,
  Download,
  Receipt,
  ArrowDownLeft,
  ArrowUpRight,
  Filter,
  FileSpreadsheet,
  Building,
  Phone,
  MapPin,
  CreditCard,
  Lock,
} from 'lucide-react';
import { CompanyInfo, Supplier, LedgerEntry } from '../types';
import { dbService } from '../services/storage';
import { formatCurrency, roundTo2 } from '../services/gstCalculations';
import { SupplierLedgerPrintModal } from './SupplierLedgerPrintModal';

interface SupplierLedgerProps {
  company: CompanyInfo;
  onNavigateToPayment?: (supplierId?: string) => void;
}

export const SupplierLedgerComponent: React.FC<SupplierLedgerProps> = ({
  company,
  onNavigateToPayment,
}) => {
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => dbService.getSuppliers());
  const [allLedgers, setAllLedgers] = useState<LedgerEntry[]>(() => dbService.getLedgers());

  // Listen to dbService changes so any added/edited/deleted payment or purchase is instantly reflected
  useEffect(() => {
    const unsub = dbService.subscribe(() => {
      setSuppliers([...dbService.getSuppliers()]);
      setAllLedgers([...dbService.getLedgers()]);
    });
    return () => unsub();
  }, []);

  const [selectedSupplierId, setSelectedSupplierId] = useState<string>('');
  const [supplierSearch, setSupplierSearch] = useState<string>('');

  // Financial Year 2026-27 or dynamic based on current date
  const now = new Date();
  const currentYear = now.getFullYear();
  const fyStartYear = now.getMonth() >= 3 ? currentYear : currentYear - 1;
  const fyEndYear = fyStartYear + 1;
  const defaultFyStart = `${fyStartYear}-04-01`;
  const defaultFyEnd = `${fyEndYear}-03-31`;
  const todayStr = now.toISOString().split('T')[0];

  // Default to full financial year so post-dated payments are always naturally included
  const [fromDate, setFromDate] = useState<string>(defaultFyStart);
  const [toDate, setToDate] = useState<string>(defaultFyEnd);
  const [includePostDated, setIncludePostDated] = useState<boolean>(true);
  const [voucherFilter, setVoucherFilter] = useState<string>('ALL');
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);

  const selectedSupplier = suppliers.find((s) => s.id === selectedSupplierId) || null;

  // Filtered supplier list for selector
  const filteredSuppliers = suppliers.filter(
    (s) =>
      s.supplierName.toLowerCase().includes(supplierSearch.toLowerCase()) ||
      (s.supplierCode && s.supplierCode.toLowerCase().includes(supplierSearch.toLowerCase())) ||
      (s.mobile && s.mobile.includes(supplierSearch)) ||
      (s.city && s.city.toLowerCase().includes(supplierSearch.toLowerCase())) ||
      (s.gstin && s.gstin.toLowerCase().includes(supplierSearch.toLowerCase()))
  );

  // Combine ledgers + guarantee any payments from PAYMENTS table are included
  const allPayments = dbService.getPayments();
  const existingLedgerVoucherNos = new Set(
    allLedgers.map((l) => (l.voucherNo || '').trim().toUpperCase())
  );

  // Synthesize any missing payment ledger entries if present in payments
  const missingPaymentLedgers: LedgerEntry[] = !selectedSupplier
    ? []
    : allPayments
        .filter((p) => {
          if (!p.voucherNo) return false;
          const vNo = p.voucherNo.trim().toUpperCase();
          if (existingLedgerVoucherNos.has(vNo)) return false;
          const isForSupplier =
            p.supplierId === selectedSupplierId ||
            (selectedSupplier && (
              p.supplierId === selectedSupplier.id ||
              p.supplierId === selectedSupplier.supplierCode ||
              (p.supplierName && p.supplierName.trim().toLowerCase() === selectedSupplier.supplierName.trim().toLowerCase())
            ));
          return isForSupplier;
        })
        .map((p) => ({
          id: `LED-SP-${p.id}`,
          date: p.voucherDate,
          partyType: 'Supplier' as const,
          partyId: p.supplierId,
          partyName: p.supplierName,
          voucherType: 'Payment',
          voucherNo: p.voucherNo,
          debit: (p.amountPaid || 0) + (p.discountReceived || 0),
          credit: 0,
          runningBalance: p.newBalance || 0,
          narration: `Payment issued to Supplier (${p.paymentMode || 'Cash'}) Ref: ${p.referenceNo || 'Direct'}${p.discountReceived ? ` Disc: ${p.discountReceived}` : ''}${p.remarks ? ` - ${p.remarks}` : ''}`,
        }));

  const combinedLedgers = [...allLedgers, ...missingPaymentLedgers];

  // Raw ledgers for this supplier (matching by ID, Code, or Name)
  const supplierLedgers = !selectedSupplier
    ? []
    : combinedLedgers.filter((l) => {
        if (l.partyType !== 'Supplier') return false;
        if (l.partyId === selectedSupplierId) return true;
        if (selectedSupplier) {
          if (selectedSupplier.id && l.partyId === selectedSupplier.id) return true;
          if (selectedSupplier.supplierCode && l.partyId === selectedSupplier.supplierCode) return true;
          if (l.partyName && selectedSupplier.supplierName && l.partyName.trim().toLowerCase() === selectedSupplier.supplierName.trim().toLowerCase()) return true;
        }
        return false;
      });

  // Calculate Opening Balance prior to fromDate
  // For suppliers: Credit = Inward purchases, Debit = Outward payments
  const preDateEntries = supplierLedgers.filter((l) => l.date < fromDate);
  const preDebit = preDateEntries.reduce((sum, l) => sum + (l.debit || 0), 0);
  const preCredit = preDateEntries.reduce((sum, l) => sum + (l.credit || 0), 0);
  const openingBalance = selectedSupplier
    ? roundTo2((selectedSupplier.openingBalance || 0) + preCredit - preDebit)
    : 0;

  // Period entries
  const periodEntries = supplierLedgers
    .filter((l) => {
      if (l.date < fromDate) return false;
      if (l.date > toDate) return false;
      if (voucherFilter !== 'ALL' && l.voucherType !== voucherFilter) return false;
      return true;
    })
    .sort((a, b) => {
      const cmp = a.date.localeCompare(b.date);
      if (cmp !== 0) return cmp;
      return (a.voucherNo || '').localeCompare(b.voucherNo || '');
    });

  // Compute running balance for each row
  let running = openingBalance;
  const rowsWithBalance = periodEntries.map((entry) => {
    running = roundTo2(running + (entry.credit || 0) - (entry.debit || 0));
    return {
      ...entry,
      calculatedBalance: running,
      isPostDated: entry.date > todayStr,
    };
  });

  const periodTotalDebit = roundTo2(periodEntries.reduce((sum, l) => sum + (l.debit || 0), 0));
  const periodTotalCredit = roundTo2(periodEntries.reduce((sum, l) => sum + (l.credit || 0), 0));
  const closingBalance = rowsWithBalance.length > 0
    ? rowsWithBalance[rowsWithBalance.length - 1].calculatedBalance
    : openingBalance;
  const postDatedEntries = rowsWithBalance.filter((r) => r.isPostDated);

  // Export CSV
  const handleExportCSV = () => {
    if (!selectedSupplier) return;
    const headers = ['Date', 'Voucher Type', 'Voucher No', 'Particulars', 'Debit (Rs)', 'Credit (Rs)', 'Balance (Rs)'];
    const rows = [
      [`Opening Balance as on ${fromDate}`, '', '', '', '', '', `${openingBalance.toFixed(2)} ${openingBalance >= 0 ? 'Cr' : 'Dr'}`],
      ...rowsWithBalance.map((r) => [
        r.date,
        r.voucherType,
        r.voucherNo,
        `"${(r.narration || '').replace(/"/g, '""')}"`,
        r.debit > 0 ? r.debit.toFixed(2) : '',
        r.credit > 0 ? r.credit.toFixed(2) : '',
        `${Math.abs(r.calculatedBalance).toFixed(2)} ${r.calculatedBalance >= 0 ? 'Cr' : 'Dr'}`,
      ]),
      ['TOTALS', '', '', '', periodTotalDebit.toFixed(2), periodTotalCredit.toFixed(2), `${Math.abs(closingBalance).toFixed(2)} ${closingBalance >= 0 ? 'Cr' : 'Dr'}`],
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Supplier_Ledger_${selectedSupplier.supplierName.replace(/\s+/g, '_')}_${fromDate}_to_${toDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none text-slate-100">
      {/* Top Header Card */}
      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shadow-inner">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-base sm:text-lg text-slate-100">Supplier Account Ledger</h2>
              <span className="text-xs font-mono bg-indigo-950 text-indigo-300 px-2 py-0.5 rounded border border-indigo-800/60">
                Vendor Khata
              </span>
            </div>
            <p className="text-xs text-slate-400">Statement of Purchases, Stock Inward Bills, Payments & Vendor Balance</p>
          </div>
        </div>

        {/* Global Controls & Actions */}
        <div className="flex flex-wrap items-center gap-2">
          {onNavigateToPayment && (
            <button
              onClick={() => selectedSupplierId && onNavigateToPayment(selectedSupplierId)}
              disabled={!selectedSupplierId}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-lg shadow-sm border border-rose-500/30 text-xs transition cursor-pointer"
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>Record Payment</span>
            </button>
          )}

          <button
            onClick={() => setShowPrintModal(true)}
            disabled={!selectedSupplier}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/80 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed text-slate-200 border border-slate-700/60 rounded-lg text-xs font-semibold backdrop-blur-sm transition cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-indigo-400" />
            <span>Print Statement</span>
          </button>

          <button
            onClick={handleExportCSV}
            disabled={!selectedSupplier}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/80 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed text-slate-200 border border-slate-700/60 rounded-lg text-xs font-semibold backdrop-blur-sm transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Filter & Selection Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Supplier Select / Search Card */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-3.5 shadow-sm space-y-2.5">
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-end">
            <div className="sm:col-span-8">
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                SELECT SUPPLIER
              </label>
              <select
                value={selectedSupplierId}
                onChange={(e) => setSelectedSupplierId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-slate-900 font-semibold focus:border-indigo-500 focus:outline-none text-xs"
              >
                <option value="">--Select Supplier--</option>
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.supplierName}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-4">
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1 flex items-center justify-between">
                <span>Supplier Code</span>
                <span className="text-[10px] text-indigo-600 font-semibold flex items-center gap-0.5">
                  <Lock className="w-2.5 h-2.5" /> Locked
                </span>
              </label>
              <input
                type="text"
                readOnly
                value={selectedSupplier ? (selectedSupplier.supplierCode || selectedSupplier.id) : ''}
                placeholder="Code"
                className="w-full bg-slate-100 border border-slate-300 text-indigo-700 font-mono font-bold rounded-lg px-2.5 py-2 text-xs cursor-not-allowed select-all uppercase focus:outline-none"
              />
            </div>
          </div>

          {/* Search filter for fast locating */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search by supplier name, code, phone or GSTIN..."
              value={supplierSearch}
              onChange={(e) => setSupplierSearch(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg pl-8 pr-2.5 py-1.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
            />
          </div>

          {supplierSearch.trim() && (
            <div className="max-h-36 overflow-y-auto space-y-1 pr-1">
              {filteredSuppliers.map((s) => (
                <button
                  key={s.id}
                  onClick={() => {
                    setSelectedSupplierId(s.id);
                    setSupplierSearch('');
                  }}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition-colors duration-200 ${
                    selectedSupplierId === s.id
                      ? 'bg-indigo-50 text-indigo-800 border border-indigo-200'
                      : 'bg-slate-50 text-slate-700 hover:bg-indigo-100 border border-slate-200 hover:border-indigo-300'
                  }`}
                >
                  <div className="flex items-center gap-1.5 truncate">
                    {s.supplierCode && (
                      <span className="font-mono text-[10px] bg-slate-200 text-slate-700 px-1 py-0.5 rounded border border-slate-300">
                        {s.supplierCode}
                      </span>
                    )}
                    <span className="font-semibold truncate">{s.supplierName}</span>
                  </div>
                  <span className="font-mono text-[11px] text-amber-700">₹{s.currentBalance.toFixed(2)}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Date Filter & Voucher Type Filter */}
        <div className="lg:col-span-7 bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md flex flex-col justify-between gap-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Date & Voucher Filter
            </span>
            <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
              <button
                onClick={() => {
                  const now = new Date();
                  const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
                  const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0];
                  setFromDate(firstDay);
                  setToDate(lastDay);
                }}
                className="px-2 py-0.5 rounded bg-slate-800/60 hover:bg-slate-700 text-slate-300 border border-slate-700/50 transition"
              >
                This Month
              </button>
              <button
                onClick={() => {
                  setFromDate(defaultFyStart);
                  setToDate(defaultFyEnd);
                }}
                className="px-2 py-0.5 rounded bg-indigo-900/50 hover:bg-indigo-800/60 text-indigo-200 border border-indigo-700/60 transition font-semibold"
              >
                FY {fyStartYear.toString().slice(-2)}-{fyEndYear.toString().slice(-2)} (Full Year)
              </button>
              <button
                onClick={() => {
                  setFromDate(defaultFyStart);
                  setToDate(todayStr);
                }}
                className="px-2 py-0.5 rounded bg-slate-800/60 hover:bg-slate-700 text-slate-300 border border-slate-700/50 transition"
              >
                Up to Today
              </button>
              <button
                onClick={() => {
                  setFromDate('2020-01-01');
                  setToDate('2030-12-31');
                }}
                className="px-2 py-0.5 rounded bg-slate-800/60 hover:bg-slate-700 text-slate-300 border border-slate-700/50 transition"
              >
                All Time / Lifetime
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
            <div className="flex items-center gap-1.5 bg-slate-950/70 px-2.5 py-1.5 rounded-lg border border-slate-700/60">
              <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="text-slate-400">From:</span>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="w-full bg-transparent text-slate-200 font-mono focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5 bg-slate-950/70 px-2.5 py-1.5 rounded-lg border border-slate-700/60">
              <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="text-slate-400">To:</span>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="w-full bg-transparent text-slate-200 font-mono focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5 bg-slate-950/70 px-2 py-1 rounded-lg border border-slate-700/60">
              <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <select
                value={voucherFilter}
                onChange={(e) => setVoucherFilter(e.target.value)}
                className="w-full bg-transparent text-slate-200 focus:outline-none text-xs font-semibold"
              >
                <option value="ALL">All Vouchers</option>
                <option value="Purchase">Purchases Only</option>
                <option value="Payment">Payments Only</option>
                <option value="Purchase Return">Returns Only</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Supplier Info Card & Metric Summary */}
      {selectedSupplier && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Party Snapshot */}
          <div className="md:col-span-4 bg-white border border-slate-200 rounded-xl p-3.5 shadow-sm space-y-1.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-sm text-slate-800">{selectedSupplier.supplierName}</span>
              <span className="font-mono text-[11px] text-slate-600 bg-slate-100 px-1.5 py-0.2 rounded border border-slate-200">
                {selectedSupplier.id}
              </span>
            </div>
            <p className="text-slate-600 flex items-center gap-1.5">
              <Phone className="w-3 h-3 text-slate-400" />
              <span>Phone: <strong className="text-slate-800 font-mono">{selectedSupplier.mobile || selectedSupplier.phone || 'N/A'}</strong></span>
            </p>
            <p className="text-slate-600 flex items-center gap-1.5">
              <MapPin className="w-3 h-3 text-slate-400" />
              <span>Address: <strong className="text-slate-800">{selectedSupplier.address || ''} {selectedSupplier.city || ''}</strong></span>
            </p>
            <p className="text-slate-600 flex items-center gap-1.5">
              <Building className="w-3 h-3 text-slate-400" />
              <span>GSTIN: <strong className="text-slate-800 font-mono">{selectedSupplier.gstin || 'Unregistered'}</strong></span>
            </p>
            {selectedSupplier.openingDate && (
              <p className="text-slate-600 flex items-center gap-1.5">
                <Calendar className="w-3 h-3 text-slate-400" />
                <span>A/C Opened: <strong className="text-slate-800 font-mono">{selectedSupplier.openingDate}</strong></span>
              </p>
            )}
          </div>

          {/* Metric KPI cards */}
          <div className="md:col-span-8 grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono">
            <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-sm">
              <span className="text-slate-500 block text-[10px] uppercase tracking-wider">Opening Balance</span>
              <span className="text-base font-bold text-slate-800 mt-1 block">
                ₹{Math.abs(openingBalance).toFixed(2)}
                <span className="text-[10px] ml-1 text-slate-500">{openingBalance >= 0 ? 'Cr' : 'Dr'}</span>
              </span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-sm">
              <span className="text-slate-500 block text-[10px] uppercase tracking-wider flex items-center gap-1">
                <ArrowDownLeft className="w-3 h-3 text-blue-600" />
                <span className="text-blue-600">Period Credits</span>
              </span>
              <span className="text-base font-bold text-blue-700 mt-1 block">
                ₹{periodTotalCredit.toFixed(2)}
              </span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 text-[10px] uppercase tracking-wider">
                <span className="flex items-center gap-1 text-red-600">
                  <ArrowUpRight className="w-3 h-3" />
                  <span>Period Debits</span>
                </span>
                {postDatedEntries.length > 0 && (
                  <span className="text-[9px] font-semibold bg-orange-100 text-orange-800 border border-orange-200 px-1.5 py-0.2 rounded font-sans">
                    {postDatedEntries.length} Post-Dated
                  </span>
                )}
              </div>
              <span className="text-base font-bold text-red-700 mt-1 block">
                ₹{periodTotalDebit.toFixed(2)}
              </span>
            </div>

            <div className={`border rounded-xl p-3 shadow-sm ${
              closingBalance > 0
                ? 'bg-orange-50 border-orange-200'
                : 'bg-green-50 border-green-200'
            }`}>
              <span className="block text-[10px] uppercase tracking-wider font-bold text-orange-800">
                Closing Payable
              </span>
              <span className={`text-lg font-black mt-1 block ${
                closingBalance > 0 ? 'text-orange-900' : 'text-green-800'
              }`}>
                ₹{Math.abs(closingBalance).toFixed(2)}
                <span className="text-xs ml-1 font-bold">{closingBalance >= 0 ? 'Cr' : 'Dr'}</span>
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Ledger Statement Table */}
      <div className="bg-slate-900/30 border border-slate-700/50 rounded-xl shadow-xl backdrop-blur-md overflow-hidden">
        <div className="p-3 bg-slate-800/40 border-b border-slate-700/50 flex items-center justify-between text-xs backdrop-blur-sm">
          <span className="font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <span>Supplier Transaction Ledger Entries</span>
            <span className="text-slate-400 font-mono font-normal">({rowsWithBalance.length} records)</span>
          </span>
          <span className="text-[11px] text-slate-400 font-mono">
            Period: {fromDate} to {toDate}
          </span>
        </div>

        <div className="overflow-x-auto bg-white rounded-xl shadow-sm border border-slate-200">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px] tracking-wider">
                <th className="p-3">Date</th>
                <th className="p-3">Voucher Type</th>
                <th className="p-3">Vch No / Bill Ref</th>
                <th className="p-3">Particulars / Narration</th>
                <th className="p-3 text-right">Debit / Paid (₹)</th>
                <th className="p-3 text-right">Credit / Purchase (₹)</th>
                <th className="p-3 text-right">Balance (₹)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {!selectedSupplier ? (
                <tr>
                  <td colSpan={7} className="p-12 text-center text-slate-500">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <Building2 className="w-8 h-8 text-slate-300" />
                      <p className="font-semibold text-slate-600 text-sm">No Supplier Selected</p>
                      <p className="text-xs text-slate-500 max-w-sm">
                        Please choose a supplier to view their ledger.
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                <>
                  {/* Opening Balance Row */}
                  <tr className="bg-slate-50/50 font-semibold text-slate-700">
                    <td className="p-3 font-mono text-slate-500">{fromDate}</td>
                    <td className="p-3">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-mono uppercase bg-slate-200 text-slate-700 border border-slate-300">
                        B/F
                      </span>
                    </td>
                    <td className="p-3 font-mono text-slate-500">-</td>
                    <td className="p-3 text-slate-600">Opening Balance Brought Forward</td>
                    <td className="p-3 text-right font-mono">-</td>
                    <td className="p-3 text-right font-mono">-</td>
                    <td className="p-3 text-right font-mono font-bold text-amber-700">
                      ₹{Math.abs(openingBalance).toFixed(2)} {openingBalance >= 0 ? 'Cr' : 'Dr'}
                    </td>
                  </tr>

                  {rowsWithBalance.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-slate-500">
                        No transactions recorded for this supplier in the selected date range.
                      </td>
                    </tr>
                  ) : (
                    rowsWithBalance.map((row) => (
                      <tr key={row.id} className="hover:bg-slate-50 transition">
                        <td className="p-3 font-mono text-slate-500 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <span>{row.date}</span>
                            {row.isPostDated && (
                              <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase tracking-wider bg-amber-100 text-amber-800 border border-amber-200 shadow-sm">
                                Post-Dated
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="p-3 whitespace-nowrap">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold uppercase tracking-wider border ${
                              row.voucherType === 'Purchase'
                                ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                                : row.voucherType === 'Payment'
                                ? 'bg-rose-50 text-rose-700 border-rose-200'
                                : row.voucherType === 'Purchase Return'
                                ? 'bg-purple-50 text-purple-700 border-purple-200'
                                : 'bg-slate-100 text-slate-600 border-slate-200'
                            }`}
                          >
                            {row.voucherType}
                          </span>
                        </td>
                        <td className="p-3 font-mono font-semibold text-slate-800 whitespace-nowrap">{row.voucherNo}</td>
                        <td className="p-3 text-slate-600 max-w-xs sm:max-w-md truncate">{row.narration || '-'}</td>
                        <td className="p-3 text-right font-mono font-semibold text-rose-700 whitespace-nowrap">
                          {row.debit > 0 ? `₹${row.debit.toFixed(2)}` : '-'}
                        </td>
                        <td className="p-3 text-right font-mono font-semibold text-indigo-700 whitespace-nowrap">
                          {row.credit > 0 ? `₹${row.credit.toFixed(2)}` : '-'}
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-amber-800 whitespace-nowrap">
                          ₹{Math.abs(row.calculatedBalance).toFixed(2)} {row.calculatedBalance >= 0 ? 'Cr' : 'Dr'}
                        </td>
                      </tr>
                    ))
                  )}
                </>
              )}
            </tbody>
            {selectedSupplier && (
              <tfoot>
                <tr className="bg-slate-100 font-bold border-t border-slate-200 text-slate-800">
                  <td colSpan={4} className="p-3 text-right uppercase tracking-wider text-[11px] text-slate-500">
                    Total for Period:
                  </td>
                  <td className="p-3 text-right font-mono text-rose-800">₹{periodTotalDebit.toFixed(2)}</td>
                  <td className="p-3 text-right font-mono text-indigo-800">₹{periodTotalCredit.toFixed(2)}</td>
                  <td className="p-3 text-right font-mono text-amber-900">
                    ₹{Math.abs(closingBalance).toFixed(2)} {closingBalance >= 0 ? 'Cr' : 'Dr'}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
      {/* Supplier Ledger Print Modal */}
      {showPrintModal && selectedSupplier && (
        <SupplierLedgerPrintModal
          company={company}
          supplier={selectedSupplier}
          fromDate={fromDate}
          toDate={toDate}
          openingBalance={openingBalance}
          rows={rowsWithBalance}
          periodTotalDebit={periodTotalDebit}
          periodTotalCredit={periodTotalCredit}
          closingBalance={closingBalance}
          onClose={() => setShowPrintModal(false)}
        />
      )}
    </div>
  );
};
