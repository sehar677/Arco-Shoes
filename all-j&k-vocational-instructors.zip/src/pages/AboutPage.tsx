import React from 'react';
import {
  GraduationCap,
  ShieldCheck,
  Target,
  Building2,
  CheckCircle2,
  Users,
  Layers,
  Banknote,
  Award,
  BookOpen,
} from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="space-y-8 pb-12">
      {/* Header Banner */}
      <div className="bg-[#0F2942] text-white rounded-2xl p-6 sm:p-10 shadow-lg border border-blue-900/80">
        <div className="max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-bold uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>Official Administrative Overview</span>
          </div>

          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight uppercase leading-tight">
            J&amp;K ITI EMPLOYEE&#39;S UNITED FRONT
          </h2>
          <p className="text-amber-400 text-sm sm:text-base font-semibold tracking-wide">
            Industrial Training Institutes • Jammu &amp; Kashmir
          </p>
        </div>
      </div>

      {/* Section 1: J&K ITI Employee's United Front */}
      <section className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-900 flex items-center justify-center font-bold">
            <BookOpen className="w-4 h-4" />
          </div>
          <h3 className="text-lg font-black text-[#0F2942] uppercase tracking-wide">
            J&amp;K ITI EMPLOYEE&#39;S UNITED FRONT
          </h3>
        </div>

        <div className="text-xs sm:text-sm text-slate-700 leading-relaxed space-y-3">
          <p>
            The J&amp;K ITI Employee&#39;s United Front is a collective platform dedicated to safeguarding the rights, dignity, and legitimate interests of Skill Development Employees working in Industrial Training Institutes (ITIs) across Jammu &amp; Kashmir. Our primary objective is to stand united against injustice, discrimination, and any violation of the rights of employees, while ensuring that all matters concerning our members are addressed fairly and transparently in accordance with Government rules, regulations, policies, and applicable service norms.
          </p>
          <p>
            We believe that every employee deserves respect, equal treatment, job security, and a fair working environment. The United Front works through unity, lawful representation, dialogue, and democratic means to raise genuine concerns before the appropriate authorities and seek timely and just solutions. We are committed to promoting the professional welfare of Skill Development Employees, protecting their legitimate rights, and contributing positively to the improvement of the vocational training system in Jammu &amp; Kashmir.
          </p>
          <p className="font-semibold text-slate-900 pt-1">
            Our strength is unity, our approach is lawful, and our goal is justice and dignity for every Skill Development Employee.
          </p>
        </div>
      </section>

      {/* Section 2: Our Objective */}
      <section className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex items-center gap-2.5 mb-6">
          <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-900 flex items-center justify-center font-bold">
            <Target className="w-4 h-4" />
          </div>
          <h3 className="text-lg font-black text-[#0F2942] uppercase tracking-wide">
            2. OUR KEY OBJECTIVES
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                Centralized Employee Database
              </h4>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Maintain an up-to-date registry of all Skill Development Employees, their assigned trades, contact details, and institutional postings across J&amp;K.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                Transparent Fund &amp; Contribution Tracking
              </h4>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Real-time recording, receipt allocation, and audit of financial contributions received from all 50 ITIs with non-negative validation.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                Transparent Scheme Execution Monitoring
              </h4>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Clear allocation of financial targets per scheme, collection tracking, balance monitoring, and achievement percentage indicators.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                Streamlined Noticeboard Communication
              </h4>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Direct broadcasting of circulars, meetings, priority notifications, and academic calendars directly from the state directorate to every institute.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 flex items-start gap-3 md:col-span-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                Accurate Statistical Reporting for Administrative Decisions
              </h4>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Real-time executive summaries, institutional balance metrics, and printable compliance audits to assist high-level government policymakers.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Section 3: Coverage */}
      <section className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex items-center gap-2.5 mb-6">
          <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-900 flex items-center justify-center font-bold">
            <Building2 className="w-4 h-4" />
          </div>
          <h3 className="text-lg font-black text-[#0F2942] uppercase tracking-wide">
            3. INSTITUTIONAL COVERAGE
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 rounded-xl bg-blue-50/70 border border-blue-200 space-y-2">
            <span className="text-xs font-bold text-blue-800 uppercase tracking-wider block">
              Division 1
            </span>
            <h4 className="text-lg font-black text-blue-950">Kashmir Division</h4>
            <div className="text-3xl font-black text-blue-700">24 ITIs</div>
            <p className="text-xs text-slate-600">
              Covering Srinagar, Anantnag, Baramulla, Budgam, Ganderbal, Kulgam, Kupwara, Pulwama, Shopian, Bandipora, Pattan, Uri, Gurez, and allied tehsils.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-emerald-50/70 border border-emerald-200 space-y-2">
            <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider block">
              Division 2
            </span>
            <h4 className="text-lg font-black text-emerald-950">Jammu Division</h4>
            <div className="text-3xl font-black text-emerald-700">26 ITIs</div>
            <p className="text-xs text-slate-600">
              Covering Jammu, Kathua, Samba, Udhampur, Reasi, Rajouri, Poonch, Doda, Ramban, Kishtwar, R.S. Pura, Hiranagar, Mendhar, and adjoining frontiers.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-amber-50/70 border border-amber-200 space-y-2">
            <span className="text-xs font-bold text-amber-800 uppercase tracking-wider block">
              Consolidated Total
            </span>
            <h4 className="text-lg font-black text-amber-950">Total Institutes</h4>
            <div className="text-3xl font-black text-amber-700">50 ITIs</div>
            <p className="text-xs text-slate-600">
              100% of all Government Industrial Training Institutes in the Union Territory with live database synchronization.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};
