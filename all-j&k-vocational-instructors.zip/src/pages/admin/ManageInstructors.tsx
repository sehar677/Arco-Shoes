import React, { useState, useMemo, useEffect } from 'react';
import { Instructor, TrainingCenter, Division, DEFAULT_EMPLOYEE_TYPES } from '../../types';
import {
  addInstructor,
  updateInstructor,
  deleteInstructor,
  approveInstructor,
  rejectInstructor,
  syncPendingInstructorsToFirestore,
} from '../../services/db';
import { ConfirmModal } from '../../components/ConfirmModal';
import { formatDate } from '../../utils/format';
import {
  Search,
  Plus,
  Edit2,
  Trash2,
  Users,
  Briefcase,
  Phone,
  Calendar,
  X,
  Check,
  CheckCircle2,
  Clock,
  ShieldCheck,
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  Copy,
  Save,
  GraduationCap,
} from 'lucide-react';

interface ManageInstructorsProps {
  instructors: Instructor[];
  trainingCenters: TrainingCenter[];
  employeeTypes?: string[];
  initialTab?: 'All' | 'Pending' | 'Approved' | 'Rejected';
  initialOpenAddModal?: boolean;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const isPendingApproval = (inst: { approvalStatus?: string }): boolean => {
  if (!inst.approvalStatus) return false;
  const s = inst.approvalStatus.trim().toLowerCase();
  return (
    s.includes('pending') ||
    s.includes('awaiting') ||
    (s.includes('review') && !s.includes('approved'))
  );
};

export const ManageInstructors: React.FC<ManageInstructorsProps> = ({
  instructors,
  trainingCenters,
  employeeTypes = DEFAULT_EMPLOYEE_TYPES,
  initialTab,
  initialOpenAddModal,
  onNotify,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [itiFilter, setItiFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [typeFilter, setTypeFilter] = useState('All');
  const [approvalTab, setApprovalTab] = useState<'All' | 'Pending' | 'Approved' | 'Rejected'>(() => {
    if (initialTab) return initialTab;
    const hasPending = instructors.some(isPendingApproval);
    return hasPending ? 'Pending' : 'All';
  });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingInstructor, setEditingInstructor] = useState<Instructor | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [selectedItiId, setSelectedItiId] = useState('');
  const [trade, setTrade] = useState('');
  const [employeeType, setEmployeeType] = useState<string>(
    employeeTypes && employeeTypes.length > 0 ? employeeTypes[0] : 'Vocational Instructor'
  );
  const [contact, setContact] = useState('');
  const [joiningDate, setJoiningDate] = useState(new Date().toISOString().split('T')[0]);
  const [status, setStatus] = useState<'Active' | 'On Leave' | 'Transferred' | 'Inactive'>('Active');
  const [approvalStatus, setApprovalStatus] = useState<
    'Approved' | 'Pending' | 'Pending Review (Awaiting Approval)' | 'Rejected'
  >('Approved');
  const [remarks, setRemarks] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isIncompleteModalOpen, setIsIncompleteModalOpen] = useState(false);
  const [incompleteErrors, setIncompleteErrors] = useState<
    { field: string; message: string; elementId: string }[]
  >([]);

  // Delete / Reject modal state
  const [deleteTarget, setDeleteTarget] = useState<Instructor | null>(null);
  const [rejectTarget, setRejectTarget] = useState<Instructor | null>(null);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [justApprovedId, setJustApprovedId] = useState<string | null>(null);

  // Popup Window Dialog for Successful Save Changes
  const [saveSuccessModalData, setSaveSuccessModalData] = useState<{
    isEdit: boolean;
    instructor: Instructor;
    savedAt: string;
  } | null>(null);
  const [copiedRegNo, setCopiedRegNo] = useState(false);

  const handleCopyRegNo = (regNo?: string) => {
    if (!regNo) return;
    navigator.clipboard.writeText(regNo);
    setCopiedRegNo(true);
    setTimeout(() => setCopiedRegNo(false), 2500);
  };

  // Derive counts
  const pendingCount = useMemo(
    () => instructors.filter(isPendingApproval).length,
    [instructors]
  );
  const approvedCount = useMemo(
    () => instructors.filter((i) => i.approvalStatus === 'Approved' || !i.approvalStatus).length,
    [instructors]
  );
  const rejectedCount = useMemo(
    () => instructors.filter((i) => i.approvalStatus === 'Rejected').length,
    [instructors]
  );

  // Sync pending registrations to Firestore on mount
  useEffect(() => {
    syncPendingInstructorsToFirestore();
  }, []);

  // Update approvalTab when initialTab or pending status changes
  useEffect(() => {
    if (initialTab) {
      setApprovalTab(initialTab);
    }
  }, [initialTab]);

  useEffect(() => {
    if (initialOpenAddModal) {
      handleOpenAddModal();
    }
  }, [initialOpenAddModal]);

  // Derive selected ITI object to get division & name
  const currentIti = useMemo(
    () => trainingCenters.find((tc) => tc.id === selectedItiId),
    [trainingCenters, selectedItiId]
  );

  const filteredInstructors = useMemo(() => {
    const list = instructors.filter((inst) => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch =
        (inst.name && inst.name.toLowerCase().includes(searchLower)) ||
        (inst.trade && inst.trade.toLowerCase().includes(searchLower)) ||
        (inst.itiName && inst.itiName.toLowerCase().includes(searchLower)) ||
        (inst.contact && inst.contact.includes(searchTerm)) ||
        (inst.registrationNo && inst.registrationNo.toLowerCase().includes(searchLower)) ||
        (inst.id && inst.id.toLowerCase().includes(searchLower));
      const matchesIti = itiFilter === 'All' || inst.itiId === itiFilter;
      const matchesStatus = statusFilter === 'All' || inst.status === statusFilter;
      const matchesType =
        typeFilter === 'All' ||
        (inst.employeeType || 'Vocational Instructor').toLowerCase() === typeFilter.toLowerCase();

      const isPending = isPendingApproval(inst);
      const isApproved = inst.approvalStatus === 'Approved' || (!inst.approvalStatus && !isPending);
      const isRejected = inst.approvalStatus === 'Rejected';

      let matchesApproval = true;
      if (approvalTab === 'Pending') matchesApproval = isPending;
      if (approvalTab === 'Approved') matchesApproval = isApproved;
      if (approvalTab === 'Rejected') matchesApproval = isRejected;

      return matchesSearch && matchesIti && matchesStatus && matchesType && matchesApproval;
    });

    // In 'All Records', prioritize Pending registrations at the very top of the table
    return list.sort((a, b) => {
      const aPending = isPendingApproval(a) ? 1 : 0;
      const bPending = isPendingApproval(b) ? 1 : 0;
      if (aPending !== bPending) {
        return bPending - aPending; // Pending registrations first
      }
      return (a.name || '').localeCompare(b.name || '');
    });
  }, [instructors, searchTerm, itiFilter, statusFilter, approvalTab]);

  const handleOpenAddModal = () => {
    setEditingInstructor(null);
    setName('');
    const defaultIti = trainingCenters[0]?.id || '';
    setSelectedItiId(defaultIti);
    setTrade('Electrician');
    setEmployeeType(employeeTypes && employeeTypes.length > 0 ? employeeTypes[0] : 'Vocational Instructor');
    setContact('');
    setJoiningDate(new Date().toISOString().split('T')[0]);
    setStatus('Active');
    setApprovalStatus('Approved');
    setRemarks('');
    setIncompleteErrors([]);
    setIsIncompleteModalOpen(false);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (inst: Instructor) => {
    setEditingInstructor(inst);
    setName(inst.name);
    setSelectedItiId(inst.itiId);
    setTrade(inst.trade);
    setEmployeeType(
      inst.employeeType || (employeeTypes && employeeTypes.length > 0 ? employeeTypes[0] : 'Vocational Instructor')
    );
    setContact(inst.contact || '');
    setJoiningDate(inst.joiningDate || new Date().toISOString().split('T')[0]);
    setStatus(inst.status);
    setApprovalStatus(inst.approvalStatus || 'Approved');
    setRemarks(inst.remarks || '');
    setIncompleteErrors([]);
    setIsIncompleteModalOpen(false);
    setIsModalOpen(true);
  };

  const handleApproveQuick = async (inst: Instructor) => {
    setActionLoadingId(inst.id);
    try {
      await approveInstructor(inst.id);
      setJustApprovedId(inst.id);
      setTimeout(() => setJustApprovedId((prev) => (prev === inst.id ? null : prev)), 6000);
      onNotify(
        'success',
        `Approved registration for "${inst.name}" (${inst.trade}). Added to the Skill Development Employees roster.`
      );
      if (approvalTab === 'Pending') {
        setApprovalTab('Approved');
      }
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to approve instructor.');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleRejectQuick = async (inst: Instructor) => {
    setActionLoadingId(inst.id);
    try {
      await rejectInstructor(inst.id);
      onNotify('info', `Rejected registration for "${inst.name}" (${inst.trade}).`);
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to reject instructor.');
    } finally {
      setActionLoadingId(null);
      setRejectTarget(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const missing: { field: string; message: string; elementId: string }[] = [];
    if (!name.trim()) {
      missing.push({
        field: 'Instructor Full Name',
        message: 'Full name of the instructor is required.',
        elementId: 'admin-inst-name',
      });
    }
    if (!selectedItiId) {
      missing.push({
        field: 'Assigned ITI',
        message: 'Please select an assigned Government ITI institution.',
        elementId: 'admin-inst-iti',
      });
    }
    if (!trade.trim()) {
      missing.push({
        field: 'Trade / Subject',
        message: 'Vocational trade or subject designation is required.',
        elementId: 'admin-inst-trade',
      });
    }
    if (!employeeType.trim()) {
      missing.push({
        field: 'Employee Type',
        message: 'Please select an employee type classification.',
        elementId: 'admin-inst-employee-type',
      });
    }

    if (missing.length > 0) {
      setIncompleteErrors(missing);
      setIsIncompleteModalOpen(true);
      return;
    }

    const itiObj = trainingCenters.find((tc) => tc.id === selectedItiId);
    const itiName = itiObj ? itiObj.name : 'Unknown ITI';
    const division: Division = itiObj ? itiObj.division : 'Kashmir Division';

    setIsSubmitting(true);
    try {
      if (editingInstructor) {
        const updatedRecord: Instructor = {
          ...editingInstructor,
          name: name.trim(),
          itiId: selectedItiId,
          itiName,
          division,
          trade: trade.trim(),
          employeeType: employeeType.trim() || 'Vocational Instructor',
          contact: contact.trim(),
          joiningDate,
          status,
          approvalStatus,
          remarks: remarks.trim(),
          updatedAt: new Date().toISOString(),
        };

        await updateInstructor(editingInstructor.id, updatedRecord);
        if (approvalStatus === 'Approved') {
          setJustApprovedId(editingInstructor.id);
          setTimeout(() => setJustApprovedId((prev) => (prev === editingInstructor.id ? null : prev)), 6000);
          if (approvalTab === 'Pending') {
            setApprovalTab('Approved');
          }
        }
        onNotify('success', `Updated instructor "${name}" successfully.`);
        setIsModalOpen(false);

        // Display popup window dialog for successful save changes
        setSaveSuccessModalData({
          isEdit: true,
          instructor: updatedRecord,
          savedAt: new Date().toLocaleTimeString('en-IN', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true,
          }),
        });
      } else {
        const newId = await addInstructor({
          name: name.trim(),
          itiId: selectedItiId,
          itiName,
          division,
          trade: trade.trim(),
          employeeType: employeeType.trim() || 'Vocational Instructor',
          contact: contact.trim(),
          joiningDate,
          status,
          approvalStatus: approvalStatus || 'Approved',
          remarks: remarks.trim(),
        });

        const createdRecord: Instructor = {
          id: newId || `inst-${Date.now()}`,
          name: name.trim(),
          itiId: selectedItiId,
          itiName,
          division,
          trade: trade.trim(),
          employeeType: employeeType.trim() || 'Vocational Instructor',
          contact: contact.trim(),
          joiningDate,
          status,
          approvalStatus: approvalStatus || 'Approved',
          remarks: remarks.trim(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        if (approvalStatus === 'Pending' || approvalStatus === 'Pending Review (Awaiting Approval)') {
          setApprovalTab('Pending');
          onNotify('success', `Added new instructor "${name}" in Pending Approvals queue.`);
        } else {
          onNotify('success', `Added new instructor "${name}" to ${itiName}.`);
        }
        setIsModalOpen(false);

        // Display popup window dialog for successful save
        setSaveSuccessModalData({
          isEdit: false,
          instructor: createdRecord,
          savedAt: new Date().toLocaleTimeString('en-IN', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true,
          }),
        });
      }
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to save Instructor.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteInstructor(deleteTarget.id);
      onNotify('success', `Removed instructor record "${deleteTarget.name}".`);
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to delete instructor.');
    } finally {
      setDeleteTarget(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-black text-[#0F2942] uppercase tracking-wide flex items-center gap-2">
            <span>MANAGE SKILL DEVELOPMENT EMPLOYEES</span>
            {pendingCount > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 font-bold text-[10px] tracking-normal animate-pulse">
                {pendingCount} Pending Approval
              </span>
            )}
          </h2>
          <p className="text-xs text-slate-500">
            Review self-registrations, verify employee credentials, approve postings, and maintain records
          </p>
        </div>

        <button
          type="button"
          id="admin-add-instructor-btn"
          onClick={handleOpenAddModal}
          className="px-4 py-2 rounded-lg bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>ADD SKILL DEVELOPMENT EMPLOYEEE</span>
        </button>
      </div>

      {/* Pending Registrations Attention Banner */}
      {pendingCount > 0 && approvalTab !== 'Pending' && (
        <div className="bg-amber-500/15 border-2 border-amber-500 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-bold shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                {pendingCount} New Skill Development Employee Registration(s) Awaiting Review &amp; Approval
              </h3>
              <p className="text-xs text-slate-600">
                Registrations submitted via the vocational portal require verification before appearing on the public roster.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setApprovalTab('Pending')}
            className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
          >
            <span>Review Pending Approvals ({pendingCount})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Tabs / Filter Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3 text-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg">
            <button
              type="button"
              onClick={() => setApprovalTab('All')}
              className={`px-3 py-1.5 rounded-md font-bold text-xs transition-colors cursor-pointer ${
                approvalTab === 'All'
                  ? 'bg-white text-[#0F2942] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Records ({instructors.length})
            </button>
            <button
              type="button"
              onClick={() => setApprovalTab('Pending')}
              className={`px-3 py-1.5 rounded-md font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer ${
                approvalTab === 'Pending'
                  ? 'bg-amber-500 text-slate-950 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Pending Approvals ({pendingCount})</span>
            </button>
            <button
              type="button"
              onClick={() => setApprovalTab('Approved')}
              className={`px-3 py-1.5 rounded-md font-bold text-xs transition-colors cursor-pointer ${
                approvalTab === 'Approved'
                  ? 'bg-white text-[#0F2942] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Approved Roster ({approvedCount})
            </button>
            <button
              type="button"
              onClick={() => setApprovalTab('Rejected')}
              className={`px-3 py-1.5 rounded-md font-bold text-xs transition-colors cursor-pointer ${
                approvalTab === 'Rejected'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Rejected ({rejectedCount})
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              id="admin-inst-iti-filter"
              value={itiFilter}
              onChange={(e) => setItiFilter(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-700 focus:outline-hidden max-w-[200px]"
            >
              <option value="All">All ITIs (50)</option>
              {trainingCenters.map((tc) => (
                <option key={tc.id} value={tc.id}>
                  {tc.sNo}. {tc.name}
                </option>
              ))}
            </select>

            <select
              id="admin-inst-status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-700 focus:outline-hidden"
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active</option>
              <option value="On Leave">On Leave</option>
              <option value="Transferred">Transferred</option>
              <option value="Inactive">Inactive</option>
            </select>

            <select
              id="admin-inst-type-filter"
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-700 focus:outline-hidden"
            >
              <option value="All">All Employee Types</option>
              {employeeTypes.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="relative w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            id="admin-inst-search"
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by instructor name, trade, reg. no (e.g. JK-ITI-REG-100001), mobile contact..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs focus:bg-white focus:outline-hidden text-slate-800"
          />
        </div>
      </div>

      {/* Pending Approvals Alert Banner */}
      {pendingCount > 0 && (
        <div className="bg-amber-50 border border-amber-300 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-200/80 text-amber-900 flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5 text-amber-800" />
            </div>
            <div>
              <h4 className="font-bold text-amber-950 text-xs sm:text-sm flex items-center gap-2">
                <span>{pendingCount} Instructor Registration(s) Awaiting Approval</span>
                <span className="px-2 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black text-[10px]">
                  ACTION REQUIRED
                </span>
              </h4>
              <p className="text-[11px] text-amber-800 mt-0.5">
                New skill development employees have registered through the public portal. Use the <strong>Approve</strong> or <strong>Reject</strong> action buttons below to verify credentials.
              </p>
            </div>
          </div>
          {approvalTab !== 'Pending' && (
            <button
              type="button"
              onClick={() => setApprovalTab('Pending')}
              className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs uppercase tracking-wider transition-colors shrink-0 shadow-xs cursor-pointer"
            >
              Review Pending ({pendingCount})
            </button>
          )}
        </div>
      )}

      {/* Instructors Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                <th className="py-3 px-3.5 text-center w-12">S.No</th>
                <th className="py-3 px-4 min-w-[170px]">Instructor Name</th>
                <th className="py-3 px-4 min-w-[180px]">Assigned ITI</th>
                <th className="py-3 px-4 min-w-[140px]">Employee Type</th>
                <th className="py-3 px-4">Trade / Subject</th>
                <th className="py-3 px-4">Contact</th>
                <th className="py-3 px-4 text-center">Approval Status</th>
                <th className="py-3 px-4 text-center">Duty Status</th>
                <th className="py-3 px-4 text-right min-w-[130px]">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredInstructors.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-10 text-center text-slate-500">
                    No instructors found matching criteria.
                  </td>
                </tr>
              ) : (
                filteredInstructors.map((inst, idx) => {
                  const isPending = isPendingApproval(inst);
                  const isJustApproved = justApprovedId === inst.id;
                  return (
                    <tr
                      key={inst.id}
                      className={`transition-all duration-300 ${
                        isJustApproved
                          ? 'bg-emerald-50 ring-2 ring-emerald-500 shadow-xs'
                          : isPending
                          ? 'bg-amber-50/70 hover:bg-amber-100/60'
                          : idx % 2 === 0
                          ? 'bg-white hover:bg-slate-50'
                          : 'bg-slate-50/40 hover:bg-slate-50'
                      }`}
                    >
                      <td className="py-2.5 px-3.5 text-center font-bold text-slate-600">
                        {idx + 1}
                      </td>
                      <td className="py-2.5 px-4 font-bold text-slate-900">
                        <div className="flex flex-col">
                          <div className="flex items-center gap-2">
                            <span>{inst.name}</span>
                            {isPending && (
                              <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-200 text-amber-900">
                                NEW REGISTRATION
                              </span>
                            )}
                            {isJustApproved && (
                              <span className="px-2 py-0.5 rounded-full bg-emerald-600 text-white font-black text-[9px] tracking-wider animate-pulse flex items-center gap-1">
                                <Check className="w-2.5 h-2.5" />
                                JUST APPROVED &amp; ADDED
                              </span>
                            )}
                          </div>
                          {inst.registrationNo && (
                            <span className="text-[10px] font-mono text-indigo-700 font-semibold mt-0.5">
                              {inst.registrationNo}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-2.5 px-4">
                        <div className="flex flex-col">
                          <span className="font-semibold text-slate-900">{inst.itiName}</span>
                          <span className="text-[10px] text-slate-600">{inst.division}</span>
                        </div>
                      </td>
                      <td className="py-2.5 px-4">
                        <span className="inline-flex items-center px-2.5 py-1 rounded-md text-[11px] font-bold bg-indigo-50 text-indigo-800 border border-indigo-200/80 shadow-2xs">
                          {inst.employeeType || 'Vocational Instructor'}
                        </span>
                      </td>
                      <td className="py-2.5 px-4">
                        <span className="text-slate-900 font-semibold">{inst.trade}</span>
                      </td>
                      <td className="py-2.5 px-4 font-mono text-slate-600">{inst.contact || '—'}</td>
                      <td className="py-2.5 px-4 text-center">
                        {isPending ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                            <Clock className="w-3 h-3 text-amber-600" />
                            Pending Review (Awaiting Approval)
                          </span>
                        ) : inst.approvalStatus === 'Rejected' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                            Rejected
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            <Check className="w-3 h-3 text-emerald-600" />
                            Approved
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            inst.status === 'Active'
                              ? 'bg-emerald-100 text-emerald-800'
                              : inst.status === 'On Leave'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {inst.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {isPending && (
                            <>
                              <button
                                type="button"
                                id={`approve-inst-${inst.id}`}
                                disabled={actionLoadingId === inst.id}
                                onClick={() => handleApproveQuick(inst)}
                                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md font-bold text-[11px] flex items-center gap-1 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                                title="Approve registration and publish to public roster"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Approve</span>
                              </button>
                              <button
                                type="button"
                                id={`reject-inst-${inst.id}`}
                                disabled={actionLoadingId === inst.id}
                                onClick={() => setRejectTarget(inst)}
                                className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-md font-bold text-[11px] flex items-center gap-1 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                                title="Reject instructor registration"
                              >
                                <X className="w-3.5 h-3.5" />
                                <span>Reject</span>
                              </button>
                            </>
                          )}
                          {inst.approvalStatus === 'Rejected' && (
                            <button
                              type="button"
                              id={`reapprove-inst-${inst.id}`}
                              disabled={actionLoadingId === inst.id}
                              onClick={() => handleApproveQuick(inst)}
                              className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded font-bold text-[10px] flex items-center gap-1 transition-colors cursor-pointer disabled:opacity-50"
                              title="Re-Approve and publish to public roster"
                            >
                              <Check className="w-3 h-3 text-emerald-700" />
                              <span>Re-Approve</span>
                            </button>
                          )}
                          <button
                            type="button"
                            id={`edit-inst-${inst.id}`}
                            onClick={() => handleOpenEditModal(inst)}
                            className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 hover:border-blue-300 rounded font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer shadow-2xs"
                            title="Edit / Review Instructor Record"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                            <span>Edit</span>
                          </button>
                          <button
                            type="button"
                            id={`delete-inst-${inst.id}`}
                            onClick={() => setDeleteTarget(inst)}
                            className="p-1.5 text-rose-700 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                            title={isPending ? 'Delete Application Record' : 'Delete Instructor'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden animate-scaleUp">
            <div className="bg-[#0F2942] text-white p-5 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest block">
                  CPANEL Administration
                </span>
                <h3 className="text-base font-bold uppercase tracking-wide flex items-center gap-2">
                  <GraduationCap className="w-5 h-5 text-amber-400" />
                  <span>{editingInstructor ? 'EDIT SKILL DEVELOPMENT EMPLOYEEE' : 'ADD SKILL DEVELOPMENT EMPLOYEEE'}</span>
                </h3>
                {editingInstructor && (
                  <div className="mt-1 flex items-center gap-2 text-xs text-slate-300">
                    <span>Editing: <strong className="text-white">{editingInstructor.name}</strong></span>
                    {editingInstructor.registrationNo && (
                      <span className="bg-slate-800 border border-slate-700 font-mono text-[10px] px-1.5 py-0.5 rounded text-amber-300">
                        {editingInstructor.registrationNo}
                      </span>
                    )}
                  </div>
                )}
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} noValidate className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Instructor Full Name *
                </label>
                <input
                  id="admin-inst-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Ghulam Mohammad"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Assigned ITI *
                  </label>
                  <select
                    id="admin-inst-iti"
                    required
                    value={selectedItiId}
                    onChange={(e) => setSelectedItiId(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden"
                  >
                    {trainingCenters.map((tc) => (
                      <option key={tc.id} value={tc.id}>
                        {tc.sNo}. {tc.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Division (Auto-set)
                  </label>
                  <input
                    type="text"
                    disabled
                    value={currentIti?.division || 'Kashmir Division'}
                    className="w-full p-2 bg-slate-100 border border-slate-300 rounded-lg text-slate-600 font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Trade / Subject *
                  </label>
                  <input
                    id="admin-inst-trade"
                    type="text"
                    required
                    value={trade}
                    onChange={(e) => setTrade(e.target.value)}
                    placeholder="e.g. Electrician, Fitter, COPA"
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Employee Type *
                  </label>
                  <select
                    id="admin-inst-employee-type"
                    required
                    value={employeeType}
                    onChange={(e) => setEmployeeType(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden font-medium"
                  >
                    {employeeTypes.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Mobile / Contact
                  </label>
                  <input
                    id="admin-inst-contact"
                    type="text"
                    value={contact}
                    onChange={(e) => setContact(e.target.value)}
                    placeholder="e.g. 9419012345"
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Joining Date
                  </label>
                  <input
                    id="admin-inst-date"
                    type="date"
                    value={joiningDate}
                    onChange={(e) => setJoiningDate(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Duty Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden"
                  >
                    <option value="Active">Active</option>
                    <option value="On Leave">On Leave</option>
                    <option value="Transferred">Transferred</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Approval Status
                </label>
                <select
                  id="admin-inst-approval-status"
                  value={approvalStatus}
                  onChange={(e) => setApprovalStatus(e.target.value as any)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden font-bold"
                >
                  <option value="Approved">Approved (Publicly Listed on Roster)</option>
                  <option value="Pending Review (Awaiting Approval)">Pending Review (Awaiting Approval)</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Remarks
                </label>
                <input
                  id="admin-inst-remarks"
                  type="text"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="Optional service notes or remarks"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                <div>
                  {editingInstructor && isPendingApproval(editingInstructor) && (
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setIsModalOpen(false);
                          handleApproveQuick(editingInstructor);
                        }}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Approve Now</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setIsModalOpen(false);
                          setRejectTarget(editingInstructor);
                        }}
                        className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold text-xs flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Reject</span>
                      </button>
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    id="save-instructor-submit-btn"
                    disabled={isSubmitting}
                    className="px-5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold disabled:opacity-50 cursor-pointer shadow-xs flex items-center gap-1.5 transition-colors"
                  >
                    {isSubmitting ? (
                      <>
                        <Clock className="w-4 h-4 animate-spin" />
                        <span>Saving Changes...</span>
                      </>
                    ) : editingInstructor ? (
                      <>
                        <Save className="w-4 h-4" />
                        <span>Save Changes</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4" />
                        <span>Save Instructor</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Successful Save Changes Popup Window Dialog */}
      {saveSuccessModalData && (
        <div
          id="save-success-popup-dialog"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200"
        >
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden animate-scaleUp">
            {/* Header with Emerald Theme */}
            <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-emerald-900 text-white p-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl pointer-events-none" />
              <button
                type="button"
                onClick={() => setSaveSuccessModalData(null)}
                className="absolute top-4 right-4 text-emerald-200 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
                title="Close Window"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-3 mb-2">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center shadow-inner">
                  <CheckCircle2 className="w-7 h-7 text-emerald-300" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-300 block">
                    CPANEL &bull; SKILL DEVELOPMENT EMPLOYEES
                  </span>
                  <h3 className="text-xl font-extrabold tracking-tight text-white">
                    {saveSuccessModalData.isEdit ? 'Changes Saved Successfully!' : 'Employee Added Successfully!'}
                  </h3>
                </div>
              </div>
              <p className="text-xs text-emerald-100/90 pl-15">
                {saveSuccessModalData.isEdit
                  ? 'The instructor record has been updated and synchronized with the master database.'
                  : 'The new instructor record has been saved and registered into the system.'}
              </p>
            </div>

            {/* Body */}
            <div className="p-6 space-y-4 text-xs bg-slate-50/50">
              {/* Highlighted Profile Card */}
              <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3">
                <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-3">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      Instructor Name
                    </span>
                    <span className="text-base font-bold text-slate-900">
                      {saveSuccessModalData.instructor.name}
                    </span>
                  </div>
                  {saveSuccessModalData.instructor.registrationNo && (
                    <div className="text-right">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                        Registration No.
                      </span>
                      <div className="flex items-center gap-1.5 mt-0.5 justify-end">
                        <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
                          {saveSuccessModalData.instructor.registrationNo}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleCopyRegNo(saveSuccessModalData.instructor.registrationNo)}
                          className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors"
                          title="Copy Registration Number"
                        >
                          {copiedRegNo ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-2 gap-3 text-slate-700">
                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                      Assigned ITI
                    </span>
                    <span className="font-semibold text-slate-900 block truncate" title={saveSuccessModalData.instructor.itiName}>
                      {saveSuccessModalData.instructor.itiName}
                    </span>
                    <span className="text-[10px] text-slate-500">{saveSuccessModalData.instructor.division}</span>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                      Trade / Subject
                    </span>
                    <span className="font-semibold text-slate-900 block truncate" title={saveSuccessModalData.instructor.trade}>
                      {saveSuccessModalData.instructor.trade}
                    </span>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                      Employee Type
                    </span>
                    <span className="font-semibold text-slate-900 block truncate" title={saveSuccessModalData.instructor.employeeType || 'Vocational Instructor'}>
                      {saveSuccessModalData.instructor.employeeType || 'Vocational Instructor'}
                    </span>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                      Approval Status
                    </span>
                    {isPendingApproval(saveSuccessModalData.instructor) ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                        <Clock className="w-3 h-3 text-amber-600" />
                        Pending Review
                      </span>
                    ) : saveSuccessModalData.instructor.approvalStatus === 'Rejected' ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                        Rejected
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                        <Check className="w-3 h-3 text-emerald-600" />
                        Approved
                      </span>
                    )}
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                      Service Status
                    </span>
                    <span className="inline-block font-semibold text-slate-900">
                      {saveSuccessModalData.instructor.status}
                    </span>
                  </div>

                  {saveSuccessModalData.instructor.contact && (
                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                        Contact Number
                      </span>
                      <span className="font-mono text-slate-800 font-medium">
                        {saveSuccessModalData.instructor.contact}
                      </span>
                    </div>
                  )}

                  {saveSuccessModalData.instructor.joiningDate && (
                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                        Date of Joining
                      </span>
                      <span className="text-slate-800 font-medium">
                        {formatDate(saveSuccessModalData.instructor.joiningDate)}
                      </span>
                    </div>
                  )}
                </div>

                {saveSuccessModalData.instructor.remarks && (
                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                      Service Remarks / Notes
                    </span>
                    <p className="text-slate-700 italic text-[11px]">
                      &ldquo;{saveSuccessModalData.instructor.remarks}&rdquo;
                    </p>
                  </div>
                )}
              </div>

              {/* Sync confirmation box */}
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center justify-between text-emerald-900">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="text-[11px] font-medium">
                    Verified and saved to database at <strong className="font-mono">{saveSuccessModalData.savedAt}</strong>
                  </span>
                </div>
                <span className="text-[10px] bg-emerald-200/70 text-emerald-800 px-2 py-0.5 rounded font-bold">
                  Synced
                </span>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-end gap-2">
              <button
                type="button"
                id="btn-close-save-success-dial"
                onClick={() => setSaveSuccessModalData(null)}
                className="w-full sm:w-auto px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-sm hover:shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>OK &bull; Continue</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Modal Dialog Message Box for Incomplete Fields */}
      {isIncompleteModalOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border border-rose-200 max-w-md w-full overflow-hidden animate-scaleUp">
            {/* Modal Dialog Header */}
            <div className="bg-rose-700 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-white/20 border border-white/30 flex items-center justify-center text-white shrink-0">
                  <AlertCircle className="w-5 h-5 text-amber-200" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-amber-200 uppercase tracking-widest block">
                    Validation Required
                  </span>
                  <h3 className="text-base font-black tracking-tight uppercase">
                    INCOMPLETE FIELDS
                  </h3>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsIncompleteModalOpen(false)}
                className="p-1 text-white/80 hover:text-white rounded-md transition-colors cursor-pointer"
                title="Close dialog"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Dialog Content */}
            <div className="p-6 space-y-4">
              <div className="flex items-start gap-2 text-xs text-slate-700">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <p>
                  Please fill in the following <strong>{incompleteErrors.length} mandatory field{incompleteErrors.length > 1 ? 's' : ''}</strong> before saving the instructor record:
                </p>
              </div>

              {/* Incomplete Fields List */}
              <div className="bg-rose-50/80 border border-rose-200 rounded-xl p-3.5 space-y-2.5">
                {incompleteErrors.map((err, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs">
                    <span className="w-2 h-2 rounded-full bg-rose-600 mt-1.5 shrink-0"></span>
                    <div>
                      <span className="font-bold text-rose-950 uppercase tracking-wide">
                        {err.field}:{' '}
                      </span>
                      <span className="text-rose-800">{err.message}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsIncompleteModalOpen(false);
                    const first = incompleteErrors[0];
                    if (first?.elementId) {
                      setTimeout(() => {
                        const el = document.getElementById(first.elementId);
                        el?.focus();
                      }, 100);
                    }
                  }}
                  className="w-full py-2.5 px-4 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-xs cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>Complete Required Fields</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={!!deleteTarget}
        title="Confirm Instructor Removal"
        message={`Are you sure you want to remove "${deleteTarget?.name}" from ${deleteTarget?.itiName}?`}
        confirmText="Yes, Remove"
        cancelText="Cancel"
        isDanger={true}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      {/* Reject Application Confirmation Modal */}
      <ConfirmModal
        isOpen={!!rejectTarget}
        title="Reject Instructor Application"
        message={`Are you sure you want to reject the registration application for "${rejectTarget?.name}" (${rejectTarget?.trade} at ${rejectTarget?.itiName})? It will be marked as Rejected and hidden from the public roster.`}
        confirmText="Yes, Reject Application"
        cancelText="Cancel"
        isDanger={true}
        onConfirm={() => rejectTarget && handleRejectQuick(rejectTarget)}
        onCancel={() => setRejectTarget(null)}
      />
    </div>
  );
};

