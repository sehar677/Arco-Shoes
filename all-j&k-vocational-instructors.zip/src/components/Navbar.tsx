import React, { useState } from 'react';
import { Shield, Menu, X, Lock, ExternalLink, GraduationCap, Building2, Users, IndianRupee, Bell, Info, Home, LogOut, Layers } from 'lucide-react';
import { ActivePage } from '../types';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  activePage: ActivePage;
  onNavigate: (page: ActivePage) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activePage, onNavigate }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { currentUser, isAdmin, logout } = useAuth();

  const navItems: { id: ActivePage; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'HOME', icon: <Home className="w-4 h-4" /> },
    { id: 'training-centers', label: 'TRAINING CENTERS', icon: <Building2 className="w-4 h-4" /> },
    { id: 'instructors', label: 'SKILL DEVELOPMENT EMPLOYEE', icon: <Users className="w-4 h-4" /> },
    { id: 'noticeboard', label: 'NOTICEBOARD', icon: <Bell className="w-4 h-4" /> },
    { id: 'contributions', label: 'EVENTS', icon: <Layers className="w-4 h-4" /> },
    { id: 'about', label: 'ABOUT', icon: <Info className="w-4 h-4" /> },
  ];

  const handleNavClick = (page: ActivePage) => {
    onNavigate(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="w-full bg-white border-b border-slate-200 shadow-xs sticky top-0 z-40">
      {/* Top Administrative Bar */}
      <div className="bg-[#0b2038] text-slate-200 text-xs py-1.5 px-4 sm:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 font-medium">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Government of Jammu &amp; Kashmir • Directorate of Skill Development (ITIs)</span>
          </div>
          <div className="hidden md:flex items-center gap-4 text-[11px] text-slate-300">
            <span>Official Portal for 50 ITIs</span>
            <span className="text-slate-500">|</span>
            <span>Kashmir &amp; Jammu Divisions</span>
          </div>
        </div>
      </div>

      {/* Main Branding Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-3.5 flex items-center justify-between">
        <button
          type="button"
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 text-left group transition-transform"
          id="brand-header-link"
        >
          {/* Official Seal Emblem */}
          <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#0F2942] to-[#1E3A8A] border border-blue-800 flex items-center justify-center text-amber-400 shadow-md shadow-slate-200 shrink-0">
            <GraduationCap className="w-7 h-7" />
          </div>
          <div>
            <h1 className="text-lg sm:text-xl md:text-2xl font-black tracking-tight text-[#0F2942] group-hover:text-blue-900 transition-colors uppercase leading-none">
              J&amp;K ITI EMPLOYEE&#39;S UNITED FRONT
            </h1>
            <p className="text-xs sm:text-sm font-semibold text-amber-700 tracking-wide mt-1">
              Industrial Training Institutes • Jammu &amp; Kashmir
            </p>
          </div>
        </button>

        {/* Desktop Navigation & CPANEL Button */}
        <div className="hidden lg:flex items-center gap-2">
          <nav className="flex items-center gap-1 mr-1" aria-label="Main Navigation">
            {navItems.map((item) => {
              const isActive = activePage === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  type="button"
                  onClick={() => handleNavClick(item.id)}
                  className={`px-3.5 py-2 rounded-md text-xs font-bold tracking-wider transition-all flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-blue-50 text-blue-900 border border-blue-200 shadow-xs'
                      : 'text-slate-700 hover:text-blue-900 hover:bg-slate-100'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Dedicated CPANEL Button with Developer Tag */}
          <div className="flex items-center gap-2">
            <div className="flex flex-col items-center">
              <button
                type="button"
                id="cpanel-header-btn"
                onClick={() => handleNavClick(isAdmin ? 'admin' : 'login')}
                className={`px-3.5 py-1.5 rounded-md text-xs font-extrabold tracking-wider transition-all shadow-xs flex items-center gap-2 border ${
                  isAdmin || activePage === 'admin'
                    ? 'bg-amber-600 hover:bg-amber-700 text-white border-amber-700 ring-2 ring-amber-300'
                    : 'bg-[#0F2942] hover:bg-[#1A3E63] text-white border-[#0F2942]'
                }`}
              >
                <Lock className="w-3.5 h-3.5" />
                <span>CPANEL</span>
                {isAdmin && <span className="w-2 h-2 rounded-full bg-emerald-400"></span>}
              </button>
              <span className="text-[9px] font-bold text-slate-500 tracking-tight mt-0.5 whitespace-nowrap select-none">
                Developed by: NAJEEB UL REHMAN
              </span>
            </div>

            {isAdmin && (
              <button
                type="button"
                id="navbar-logout-btn"
                onClick={async () => {
                  await logout();
                  handleNavClick('home');
                }}
                className="px-2.5 py-1.5 rounded-md bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition-all flex items-center gap-1 shadow-xs"
                title="Logout of CPANEL"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Logout</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Hamburger Toggle */}
        <div className="flex items-center gap-2 lg:hidden">
          <div className="flex flex-col items-center">
            <button
              type="button"
              id="mobile-cpanel-btn"
              onClick={() => handleNavClick(isAdmin ? 'admin' : 'login')}
              className="px-3 py-1.5 rounded-md text-xs font-bold tracking-wider bg-[#0F2942] text-white flex items-center gap-1.5"
            >
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <span>CPANEL</span>
              {isAdmin && <span className="w-2 h-2 rounded-full bg-emerald-400"></span>}
            </button>
            <span className="text-[8px] font-bold text-slate-500 tracking-tight mt-0.5 whitespace-nowrap select-none">
              Developed by: NAJEEB UL REHMAN
            </span>
          </div>
          <button
            type="button"
            id="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-md text-slate-700 hover:text-slate-900 hover:bg-slate-100 border border-slate-200"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-slate-50 px-4 py-3 shadow-inner">
          <nav className="flex flex-col gap-1">
            {navItems.map((item) => {
              const isActive = activePage === item.id;
              return (
                <button
                  key={item.id}
                  id={`mobile-nav-${item.id}`}
                  type="button"
                  onClick={() => handleNavClick(item.id)}
                  className={`px-4 py-2.5 rounded-md text-sm font-bold text-left flex items-center gap-3 transition-colors ${
                    isActive
                      ? 'bg-blue-900 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-slate-200 hover:text-slate-900'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              );
            })}

            <div className="pt-2 border-t border-slate-200 mt-2 space-y-2">
              <button
                type="button"
                id="mobile-cpanel-drawer-btn"
                onClick={() => handleNavClick(isAdmin ? 'admin' : 'login')}
                className="w-full px-4 py-2.5 rounded-md text-sm font-extrabold bg-[#0F2942] text-amber-400 flex items-center justify-center gap-2 shadow-sm"
              >
                <Lock className="w-4 h-4" />
                <span>ADMIN CPANEL {isAdmin ? '(OPEN DASHBOARD)' : 'LOGIN'}</span>
              </button>

              {isAdmin && (
                <button
                  type="button"
                  id="mobile-logout-drawer-btn"
                  onClick={async () => {
                    await logout();
                    handleNavClick('home');
                  }}
                  className="w-full px-4 py-2 rounded-md text-xs font-bold bg-rose-100 text-rose-800 flex items-center justify-center gap-2 border border-rose-200"
                >
                  <LogOut className="w-4 h-4" />
                  <span>LOGOUT FROM CPANEL</span>
                </button>
              )}

              <p className="text-[10px] text-center font-bold text-slate-500 mt-1.5 select-none">
                Developed by: NAJEEB UL REHMAN
              </p>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
