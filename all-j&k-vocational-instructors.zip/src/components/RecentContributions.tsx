import React, { useMemo } from 'react';
import { Contribution, Scheme, ActivePage } from '../types';
import { formatCurrency, formatDate } from '../utils/format';
import { ReceiptText } from 'lucide-react';

interface RecentContributionsProps {
  contributions: Contribution[];
  schemes?: Scheme[];
  onNavigate?: (page: ActivePage) => void;
}

export const RecentContributions: React.FC<RecentContributionsProps> = ({
  contributions,
  schemes = [],
}) => {
  // Show the last three (3) contributions sorted by date (newest first)
  const latestItems = useMemo(() => {
    return [...contributions]
      .sort((a, b) => {
        const dateA = new Date(a.contributionDate || 0).getTime();
        const dateB = new Date(b.contributionDate || 0).getTime();
        return dateB - dateA;
      })
      .slice(0, 3);
  }, [contributions]);

  // Helper to resolve scheme name reliably
  const getSchemeName = (c: Contribution) => {
    if (c.schemeName && c.schemeName.trim() !== '') {
      return c.schemeName;
    }
    const matched = schemes.find((s) => s.id === c.schemeId);
    if (matched && matched.name) {
      return matched.name;
    }
    return c.schemeId || 'General Contribution';
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
      <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
            <ReceiptText className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-extrabold text-[#0F2942] uppercase tracking-wide">
              RECENT CONTRIBUTIONS
            </h3>
            <p className="text-xs text-slate-500">
              Last 3 scheme remittances recorded across J&amp;K Industrial Training Institutes
            </p>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
              <th className="py-2.5 px-4">ITI Name</th>
              <th className="py-2.5 px-4">Scheme</th>
              <th className="py-2.5 px-4 text-right">Amount (₹)</th>
              <th className="py-2.5 px-4 text-center">Date</th>
              <th className="py-2.5 px-4">Receipt / Mode</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {latestItems.length === 0 ? (
              <tr>
                <td colSpan={5} className="py-6 text-center text-slate-500">
                  No contribution records found. Admin can add contributions via CPANEL.
                </td>
              </tr>
            ) : (
              latestItems.map((c, i) => (
                <tr
                  key={c.id}
                  className={`hover:bg-slate-50 transition-colors ${
                    i % 2 === 0 ? 'bg-white' : 'bg-slate-50/40'
                  }`}
                >
                  <td className="py-2.5 px-4 font-bold text-slate-900">
                    <div className="flex flex-col">
                      <span>{c.itiName}</span>
                      <span className="text-[10px] text-slate-600 font-normal">{c.division}</span>
                    </div>
                  </td>
                  <td className="py-2.5 px-4 text-slate-800 font-medium max-w-xs">
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-sky-50 text-sky-900 border border-sky-200">
                      {getSchemeName(c)}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono font-bold text-emerald-700">
                    {formatCurrency(c.amount)}
                  </td>
                  <td className="py-2.5 px-4 text-center font-mono text-slate-600">
                    {formatDate(c.contributionDate)}
                  </td>
                  <td className="py-2.5 px-4 text-slate-600 text-[11px]">
                    <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded text-slate-700">
                      {c.receiptNumber || 'N/A'}
                    </span>
                    <span className="ml-2 text-[10px] text-slate-600">({c.mode})</span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
