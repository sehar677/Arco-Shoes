import React from 'react';
import { Building2, Users, Layers } from 'lucide-react';
import { formatNumber } from '../utils/format';

interface DashboardCardsProps {
  totalItis: number;
  totalInstructors: number;
  totalSchemes: number;
}

export const DashboardCards: React.FC<DashboardCardsProps> = ({
  totalItis,
  totalInstructors,
  totalSchemes,
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
      {/* Card 1: No. of ITIs */}
      <div
        id="dashboard-card-itis"
        className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden flex flex-col justify-between"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
            No. of ITIs
          </span>
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-800 flex items-center justify-center shadow-2xs">
            <Building2 className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4">
          <div className="text-3xl font-black text-[#0F2942] tracking-tight">
            {formatNumber(totalItis)}
          </div>
          <p className="text-xs font-medium text-slate-500 mt-1">
            {totalItis > 0 ? `${totalItis} Registered Institutes across J&K` : 'No Institutes Registered'}
          </p>
        </div>
        <div className="h-1.5 w-full bg-blue-600 rounded-full mt-4"></div>
      </div>

      {/* Card 2: No. of Skill Development Employees */}
      <div
        id="dashboard-card-instructors"
        className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden flex flex-col justify-between"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Skill Development Employees
          </span>
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-800 flex items-center justify-center shadow-2xs">
            <Users className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4">
          <div className="text-3xl font-black text-[#0F2942] tracking-tight">
            {formatNumber(totalInstructors)}
          </div>
          <p className="text-xs font-medium text-emerald-600 font-semibold mt-1">
            Active Verified Employees in Roster
          </p>
        </div>
        <div className="h-1.5 w-full bg-indigo-600 rounded-full mt-4"></div>
      </div>

      {/* Card 3: No. of Schemes */}
      <div
        id="dashboard-card-schemes"
        className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden flex flex-col justify-between"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
            No. of Schemes
          </span>
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center shadow-2xs">
            <Layers className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4">
          <div className="text-3xl font-black text-[#0F2942] tracking-tight">
            {formatNumber(totalSchemes)}
          </div>
          <p className="text-xs font-medium text-slate-500 mt-1">
            Active Welfare &amp; Union Schemes
          </p>
        </div>
        <div className="h-1.5 w-full bg-amber-600 rounded-full mt-4"></div>
      </div>
    </div>
  );
};

