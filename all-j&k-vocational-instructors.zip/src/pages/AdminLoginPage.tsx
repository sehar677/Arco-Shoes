import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { ActivePage } from '../types';
import { Lock, Mail, KeyRound, ArrowLeft, ShieldAlert, Shield, Info } from 'lucide-react';

interface AdminLoginPageProps {
  onNavigate: (page: ActivePage) => void;
  onLoginSuccess: () => void;
}

export const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ onNavigate, onLoginSuccess }) => {
  const { loginWithEmail, authError, clearAuthError, currentUser, isAdmin } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [localMessage, setLocalMessage] = useState<string | null>(null);

  // If already authenticated as admin, proceed immediately to the CPANEL dashboard
  useEffect(() => {
    if (currentUser && isAdmin) {
      onLoginSuccess();
    }
  }, [currentUser, isAdmin, onLoginSuccess]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setLocalMessage('Please provide both email and password.');
      return;
    }
    setLocalMessage(null);
    clearAuthError();
    setIsSubmitting(true);

    try {
      await loginWithEmail(email, password);
      onLoginSuccess();
    } catch (err: any) {
      // Handled by AuthContext or error state
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-[75vh] flex items-center justify-center py-10 px-4">
      <div className="max-w-md w-full bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden animate-scaleUp">
        {/* Header Badge */}
        <div className="bg-[#0F2942] text-white p-6 text-center relative">
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-400 flex items-center justify-center mx-auto mb-3 shadow-inner">
            <Lock className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-black uppercase tracking-wider text-white">
            ADMINISTRATIVE CPANEL
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            Directorate of Skill Development • J&amp;K Government
          </p>
          <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-900/60 border border-blue-700/50 text-[11px] text-amber-300 font-mono">
            <Shield className="w-3 h-3 text-amber-400" />
            <span>Secure Firebase Authentication</span>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Error alerts */}
          {(authError || localMessage) && (
            <div className="p-3.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5">
              <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <p className="leading-snug">{authError || localMessage}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Official Admin Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="admin-email-input"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@jk.gov.in"
                  className="w-full pl-9 pr-3 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden text-slate-900"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Password
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="admin-password-input"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-9 pr-3 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden text-slate-900"
                />
              </div>
            </div>

            <div className="pt-2 flex flex-col gap-2.5">
              <button
                type="submit"
                id="admin-login-submit-btn"
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 rounded-lg bg-[#0F2942] hover:bg-[#153a5c] text-amber-400 font-extrabold text-xs uppercase tracking-wider shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{isSubmitting ? 'Authenticating...' : 'LOGIN'}</span>
              </button>

              <button
                type="button"
                id="back-to-home-btn"
                onClick={() => onNavigate('home')}
                className="w-full py-2 px-4 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs tracking-wider transition-colors flex items-center justify-center gap-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>BACK TO HOME</span>
              </button>
            </div>
          </form>

          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-[11px] text-slate-600 space-y-1.5">
            <div className="flex items-start gap-2">
              <Shield className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
              <p>
                <strong>Single Active Session:</strong> Only one administrator session is permitted per credential at a time.
              </p>
            </div>
            <div className="flex items-start gap-2">
              <Info className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
              <p>
                <strong>2-Minute Session Timeout:</strong> For portal security, your session will automatically log out after 2 minutes of inactivity.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
