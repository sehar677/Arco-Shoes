import React, { useState, useEffect, useMemo } from 'react';
import {
  Receipt,
  ArrowDownLeft,
  ArrowUpRight,
  Save,
  RotateCcw,
  AlertCircle,
  Search,
  Filter,
  Trash2,
  Edit2,
  Printer,
  X,
  DollarSign,
  PlusCircle,
  Layers,
  Clock,
  FileText,
} from 'lucide-react';
import {
  Customer,
  Supplier,
  SupplierPayment,
  CompanyInfo,
  CustomerReceipt,
} from '../types';
import { dbService } from '../services/storage';
import { formatCurrency, roundTo2, numberToWords } from '../services/gstCalculations';
import { SuccessPopup } from './SuccessPopup';

// Helper to get local YYYY-MM-DD
const getLocalTodayDate = (): string => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

interface VoucherEntryProps {
  type: 'RECEIPT' | 'PAYMENT';
}

export const VoucherEntryComponent: React.FC<VoucherEntryProps> = ({ type }) => {
  const isReceipt = type === 'RECEIPT';

  // Navigation tab: 'NEW' (New Voucher/Receipt) vs 'MANAGE' (Manage Payments/Receipts)
  const [activeTab, setActiveTab] = useState<'NEW' | 'MANAGE'>('NEW');

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [payments, setPayments] = useState<SupplierPayment[]>([]);
  const [receipts, setReceipts] = useState<CustomerReceipt[]>([]);
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo | null>(null);

  // Form State (New Voucher / Receipt)
  const [partyId, setPartyId] = useState<string>('');
  const [voucherNo, setVoucherNo] = useState<string>('');
  const [date, setDate] = useState<string>(getLocalTodayDate());
  const [amount, setAmount] = useState<number>(0);
  const [discountReceived, setDiscountReceived] = useState<number>(0);
  const [paymentMode, setPaymentMode] = useState<'Cash' | 'Bank / Cheque' | 'UPI / QR' | 'NEFT / RTGS'>('Cash');
  const [refNumber, setRefNumber] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');

  // Manage Filters - default date filter to today
  const [filterPartyId, setFilterPartyId] = useState<string>('');
  const [filterDate, setFilterDate] = useState<string>(getLocalTodayDate());
  const [filterDateFrom, setFilterDateFrom] = useState<string>('');
  const [filterDateTo, setFilterDateTo] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals state for Supplier Payments
  const [editingPayment, setEditingPayment] = useState<SupplierPayment | null>(null);
  const [deletingPayment, setDeletingPayment] = useState<SupplierPayment | null>(null);
  const [printingPayment, setPrintingPayment] = useState<SupplierPayment | null>(null);

  // Modals state for Customer Receipts
  const [editingReceipt, setEditingReceipt] = useState<CustomerReceipt | null>(null);
  const [deletingReceipt, setDeletingReceipt] = useState<CustomerReceipt | null>(null);
  const [printingReceipt, setPrintingReceipt] = useState<CustomerReceipt | null>(null);

  // Edit Payment Form State
  const [editVoucherDate, setEditVoucherDate] = useState<string>('');
  const [editSupplierId, setEditSupplierId] = useState<string>('');
  const [editPaymentMode, setEditPaymentMode] = useState<'Cash' | 'Cheque' | 'Bank/NEFT' | 'UPI'>('Cash');
  const [editRefNumber, setEditRefNumber] = useState<string>('');
  const [editAmountPaid, setEditAmountPaid] = useState<number>(0);
  const [editDiscountReceived, setEditDiscountReceived] = useState<number>(0);
  const [editRemarks, setEditRemarks] = useState<string>('');

  // Edit Receipt Form State
  const [editReceiptDate, setEditReceiptDate] = useState<string>('');
  const [editCustomerId, setEditCustomerId] = useState<string>('');
  const [editReceiptPaymentMode, setEditReceiptPaymentMode] = useState<'Cash' | 'Cheque' | 'Bank/UPI' | 'Card'>('Cash');
  const [editReceiptRefNumber, setEditReceiptRefNumber] = useState<string>('');
  const [editAmountReceived, setEditAmountReceived] = useState<number>(0);
  const [editDiscountAllowed, setEditDiscountAllowed] = useState<number>(0);
  const [editReceiptRemarks, setEditReceiptRemarks] = useState<string>('');

  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; title?: string; text: string } | null>(null);

  const loadData = () => {
    const custs = dbService.getCustomers();
    const sups = dbService.getSuppliers();
    const pmts = dbService.getPayments();
    const recs = dbService.getReceipts();
    const comp = dbService.getCompanyInfo();

    setCustomers([...custs]);
    setSuppliers([...sups]);
    setPayments([...pmts]);
    setReceipts([...recs]);
    setCompanyInfo(comp);

    if (isReceipt) {
      setVoucherNo(dbService.getNextReceiptNo());
    } else {
      setVoucherNo(dbService.getNextPaymentVoucherNo());
    }
  };

  useEffect(() => {
    loadData();
    const unsub = dbService.subscribe(() => {
      const freshPayments = dbService.getPayments();
      const freshReceipts = dbService.getReceipts();
      const freshSuppliers = dbService.getSuppliers();
      const freshCustomers = dbService.getCustomers();
      setPayments([...freshPayments]);
      setReceipts([...freshReceipts]);
      setSuppliers([...freshSuppliers]);
      setCustomers([...freshCustomers]);
    });
    return () => unsub();
  }, [type]);

  const selectedCustomer = customers.find((c) => c.id === partyId);
  const selectedSupplier = suppliers.find((s) => s.id === partyId);

  const currentPartyBalance = isReceipt
    ? selectedCustomer?.currentBalance || 0
    : selectedSupplier?.currentBalance || 0;

  const newBalance = isReceipt
    ? Math.max(0, roundTo2(currentPartyBalance - amount))
    : Math.max(0, roundTo2(currentPartyBalance - (amount + discountReceived)));

  // Handle Save New Voucher / Receipt
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partyId) {
      setFeedback({ type: 'error', text: isReceipt ? 'Please select a customer account.' : 'Please select a supplier.' });
      return;
    }
    if (amount <= 0) {
      setFeedback({ type: 'error', text: 'Amount must be greater than 0.' });
      return;
    }

    if (isReceipt) {
      const cust = customers.find((c) => c.id === partyId);
      if (!cust) return;
      const prevBal = cust.currentBalance;
      const totalReduction = Number(amount) + Number(discountReceived || 0);
      const updatedBal = roundTo2(prevBal - totalReduction);

      let mappedMode: 'Cash' | 'Cheque' | 'Bank/UPI' | 'Card' = 'Cash';
      if (paymentMode === 'Bank / Cheque') mappedMode = 'Cheque';
      else if (paymentMode === 'UPI / QR' || paymentMode === 'NEFT / RTGS') mappedMode = 'Bank/UPI';

      const recRecord: CustomerReceipt = {
        id: `CR-${Date.now()}`,
        receiptNo: voucherNo,
        receiptDate: date,
        customerId: cust.id,
        customerName: cust.customerName,
        paymentMode: mappedMode,
        referenceNo: refNumber.trim() || undefined,
        previousBalance: prevBal,
        amountReceived: Number(amount),
        discountAllowed: Number(discountReceived) || 0,
        newBalance: updatedBal,
        remarks: remarks.trim() || undefined,
        createdAt: new Date().toISOString(),
      };

      const res = dbService.saveCustomerReceipt(recRecord);
      const savedReceiptNo = res.receiptNo || recRecord.receiptNo;
      if (res.success) {
        setReceipts((prev) => [{ ...recRecord, receiptNo: savedReceiptNo }, ...prev.filter((r) => r.id !== recRecord.id)]);
        setFeedback({
          type: 'success',
          title: 'Customer Receipt Saved',
          text: `Receipt ${savedReceiptNo} of ${formatCurrency(amount)} recorded for ${cust.customerName}.`,
        });
      } else {
        setFeedback({ type: 'error', text: res.message });
        return;
      }
    } else {
      const sup = suppliers.find((s) => s.id === partyId);
      if (!sup) return;
      const prevBal = sup.currentBalance;
      const totalReduction = Number(amount) + Number(discountReceived || 0);
      const updatedBal = roundTo2(prevBal - totalReduction);

      let mappedMode: 'Cash' | 'Cheque' | 'Bank/NEFT' | 'UPI' = 'Cash';
      if (paymentMode === 'Bank / Cheque') mappedMode = 'Cheque';
      else if (paymentMode === 'UPI / QR') mappedMode = 'UPI';
      else if (paymentMode === 'NEFT / RTGS') mappedMode = 'Bank/NEFT';

      const paymentRecord: SupplierPayment = {
        id: `SP-${Date.now()}`,
        voucherNo,
        voucherDate: date,
        supplierId: sup.id,
        supplierName: sup.supplierName,
        paymentMode: mappedMode,
        referenceNo: refNumber.trim() || undefined,
        previousBalance: prevBal,
        amountPaid: Number(amount),
        discountReceived: Number(discountReceived) || 0,
        newBalance: updatedBal,
        remarks: remarks.trim() || undefined,
        createdAt: new Date().toISOString(),
      };

      const res = dbService.saveSupplierPayment(paymentRecord);
      if (res.success) {
        setPayments((prev) => [{ ...paymentRecord }, ...prev.filter((p) => p.id !== paymentRecord.id)]);
        setFeedback({
          type: 'success',
          title: 'Payment Voucher Saved',
          text: `Payment voucher ${voucherNo} of ${formatCurrency(amount)} recorded to ${sup.supplierName}.`,
        });
      } else {
        setFeedback({ type: 'error', text: res.message });
        return;
      }
    }

    loadData();
    setPartyId('');
    setAmount(0);
    setDiscountReceived(0);
    setRefNumber('');
    setRemarks('');
  };

  // Open Edit Payment Modal
  const handleOpenEditPayment = (p: SupplierPayment) => {
    setEditingPayment(p);
    setEditVoucherDate(p.voucherDate || new Date().toISOString().split('T')[0]);
    setEditSupplierId(p.supplierId);
    setEditPaymentMode(p.paymentMode || 'Cash');
    setEditRefNumber(p.referenceNo || '');
    setEditAmountPaid(p.amountPaid || 0);
    setEditDiscountReceived(p.discountReceived || 0);
    setEditRemarks(p.remarks || '');
  };

  // Submit Edit Payment
  const handleUpdatePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPayment) return;
    if (!editSupplierId) {
      setFeedback({ type: 'error', text: 'Select a supplier.' });
      return;
    }
    if (editAmountPaid <= 0) {
      setFeedback({ type: 'error', text: 'Amount paid must be greater than 0.' });
      return;
    }

    const sup = suppliers.find((s) => s.id === editSupplierId);
    const updatedPay: SupplierPayment = {
      ...editingPayment,
      voucherDate: editVoucherDate,
      supplierId: editSupplierId,
      supplierName: sup?.supplierName || editingPayment.supplierName,
      paymentMode: editPaymentMode,
      referenceNo: editRefNumber.trim() || undefined,
      amountPaid: Number(editAmountPaid),
      discountReceived: Number(editDiscountReceived) || 0,
      remarks: editRemarks.trim() || undefined,
    };

    const res = dbService.updateSupplierPayment(updatedPay);
    if (res.success) {
      setPayments((prev) => prev.map((p) => (p.id === updatedPay.id ? { ...updatedPay } : p)));
      setFeedback({
        type: 'success',
        title: 'Voucher Updated',
        text: `Payment voucher ${updatedPay.voucherNo} updated successfully.`,
      });
      setEditingPayment(null);
      loadData();
    } else {
      setFeedback({ type: 'error', text: res.message });
    }
  };

  // Confirm Delete Payment
  const handleConfirmDeletePayment = () => {
    if (!deletingPayment) return;
    const deletedId = deletingPayment.id;
    const res = dbService.deleteSupplierPayment(deletedId);
    if (res.success) {
      setPayments((prev) => prev.filter((p) => p.id !== deletedId));
      setFeedback({
        type: 'success',
        title: 'Voucher Deleted',
        text: res.message,
      });
      setDeletingPayment(null);
      loadData();
    } else {
      setFeedback({ type: 'error', text: res.message });
    }
  };

  // Open Edit Receipt Modal
  const handleOpenEditReceipt = (r: CustomerReceipt) => {
    setEditingReceipt(r);
    setEditReceiptDate(r.receiptDate || new Date().toISOString().split('T')[0]);
    setEditCustomerId(r.customerId);
    setEditReceiptPaymentMode(r.paymentMode || 'Cash');
    setEditReceiptRefNumber(r.referenceNo || '');
    setEditAmountReceived(r.amountReceived || 0);
    setEditDiscountAllowed(r.discountAllowed || 0);
    setEditReceiptRemarks(r.remarks || '');
  };

  // Submit Edit Receipt
  const handleUpdateReceipt = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingReceipt) return;
    if (!editCustomerId) {
      setFeedback({ type: 'error', text: 'Select a customer.' });
      return;
    }
    if (editAmountReceived <= 0) {
      setFeedback({ type: 'error', text: 'Amount received must be greater than 0.' });
      return;
    }

    const cust = customers.find((c) => c.id === editCustomerId);
    const updatedRec: CustomerReceipt = {
      ...editingReceipt,
      receiptDate: editReceiptDate,
      customerId: editCustomerId,
      customerName: cust?.customerName || editingReceipt.customerName,
      paymentMode: editReceiptPaymentMode,
      referenceNo: editReceiptRefNumber.trim() || undefined,
      amountReceived: Number(editAmountReceived),
      discountAllowed: Number(editDiscountAllowed) || 0,
      remarks: editReceiptRemarks.trim() || undefined,
    };

    const res = dbService.updateCustomerReceipt(updatedRec);
    if (res.success) {
      setReceipts((prev) => prev.map((r) => (r.id === updatedRec.id ? { ...updatedRec } : r)));
      setFeedback({
        type: 'success',
        title: 'Receipt Updated',
        text: `Receipt ${updatedRec.receiptNo} updated successfully.`,
      });
      setEditingReceipt(null);
      loadData();
    } else {
      setFeedback({ type: 'error', text: res.message });
    }
  };

  // Confirm Delete Receipt
  const handleConfirmDeleteReceipt = () => {
    if (!deletingReceipt) return;
    const deletedId = deletingReceipt.id;
    const res = dbService.deleteCustomerReceipt(deletedId);
    if (res.success) {
      setReceipts((prev) => prev.filter((r) => r.id !== deletedId));
      setFeedback({
        type: 'success',
        title: 'Receipt Deleted',
        text: res.message,
      });
      setDeletingReceipt(null);
      loadData();
    } else {
      setFeedback({ type: 'error', text: res.message });
    }
  };

  // Filtered Payments for Manage Payments tab
  const filteredPayments = useMemo(() => {
    return payments
      .filter((p) => {
        if (filterPartyId && filterPartyId !== 'ALL' && p.supplierId !== filterPartyId) {
          return false;
        }
        if (filterDate && p.voucherDate !== filterDate) {
          return false;
        }
        if (filterDateFrom && p.voucherDate < filterDateFrom) return false;
        if (filterDateTo && p.voucherDate > filterDateTo) return false;

        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchVoucher = p.voucherNo?.toLowerCase().includes(q);
          const matchSupplier = p.supplierName?.toLowerCase().includes(q);
          const matchRef = p.referenceNo?.toLowerCase().includes(q);
          const matchRemarks = p.remarks?.toLowerCase().includes(q);
          if (!matchVoucher && !matchSupplier && !matchRef && !matchRemarks) {
            return false;
          }
        }
        return true;
      })
      .sort((a, b) => {
        const dateCompare = (b.voucherDate || '').localeCompare(a.voucherDate || '');
        if (dateCompare !== 0) return dateCompare;
        return (b.voucherNo || '').localeCompare(a.voucherNo || '');
      });
  }, [payments, filterPartyId, filterDate, filterDateFrom, filterDateTo, searchQuery]);

  const totalFilteredAmount = useMemo(() => {
    return filteredPayments.reduce((acc, p) => acc + (p.amountPaid || 0), 0);
  }, [filteredPayments]);

  const totalFilteredDiscount = useMemo(() => {
    return filteredPayments.reduce((acc, p) => acc + (p.discountReceived || 0), 0);
  }, [filteredPayments]);

  // Filtered Receipts for Manage Receipts tab
  const filteredReceipts = useMemo(() => {
    return receipts
      .filter((r) => {
        if (filterPartyId && filterPartyId !== 'ALL' && r.customerId !== filterPartyId) {
          return false;
        }
        if (filterDate && r.receiptDate !== filterDate) {
          return false;
        }
        if (filterDateFrom && r.receiptDate < filterDateFrom) return false;
        if (filterDateTo && r.receiptDate > filterDateTo) return false;

        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchNo = r.receiptNo?.toLowerCase().includes(q);
          const matchCust = r.customerName?.toLowerCase().includes(q);
          const matchRef = r.referenceNo?.toLowerCase().includes(q);
          const matchRemarks = r.remarks?.toLowerCase().includes(q);
          if (!matchNo && !matchCust && !matchRef && !matchRemarks) {
            return false;
          }
        }
        return true;
      })
      .sort((a, b) => {
        const dateCompare = (b.receiptDate || '').localeCompare(a.receiptDate || '');
        if (dateCompare !== 0) return dateCompare;
        return (b.receiptNo || '').localeCompare(a.receiptNo || '');
      });
  }, [receipts, filterPartyId, filterDate, filterDateFrom, filterDateTo, searchQuery]);

  const totalFilteredReceiptAmount = useMemo(() => {
    return filteredReceipts.reduce((acc, r) => acc + (r.amountReceived || 0), 0);
  }, [filteredReceipts]);

  const totalFilteredReceiptDiscount = useMemo(() => {
    return filteredReceipts.reduce((acc, r) => acc + (r.discountAllowed || 0), 0);
  }, [filteredReceipts]);

  // Date Handlers
  const handleSingleDateChange = (val: string) => {
    setFilterDate(val);
    if (val) {
      setFilterDateFrom('');
      setFilterDateTo('');
    }
  };

  const handleDateFromChange = (val: string) => {
    setFilterDateFrom(val);
    if (val) {
      setFilterDate('');
    }
  };

  const handleDateToChange = (val: string) => {
    setFilterDateTo(val);
    if (val) {
      setFilterDate('');
    }
  };

  const handleSetToday = () => {
    const today = getLocalTodayDate();
    setFilterDate(today);
    setFilterDateFrom('');
    setFilterDateTo('');
  };

  const handleSetYesterday = () => {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    const yest = d.toISOString().split('T')[0];
    setFilterDate(yest);
    setFilterDateFrom('');
    setFilterDateTo('');
  };

  const handleSetThisMonth = () => {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
    const today = now.toISOString().split('T')[0];
    setFilterDate('');
    setFilterDateFrom(firstDay);
    setFilterDateTo(today);
  };

  const handleClearDateFilters = () => {
    setFilterDate('');
    setFilterDateFrom('');
    setFilterDateTo('');
  };

  const handleClearAllFilters = () => {
    setFilterPartyId('');
    setFilterDate('');
    setFilterDateFrom('');
    setFilterDateTo('');
    setSearchQuery('');
  };

  return (
    <div className="p-3 sm:p-5 max-w-6xl mx-auto space-y-4 font-sans select-none">
      {/* Modal Popup for Notifications */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          onClose={() => setFeedback(null)}
        />
      )}

      {/* Main Container Card */}
      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 sm:p-5 shadow-xl backdrop-blur-md text-slate-100 space-y-4">
        {/* Header with Title and Mode Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-700/40 pb-3">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-9 h-9 rounded-lg flex items-center justify-center shadow-inner ${
                isReceipt
                  ? 'bg-teal-600/20 text-teal-400 border border-teal-500/30'
                  : 'bg-rose-600/20 text-rose-400 border border-rose-500/30'
              }`}
            >
              {isReceipt ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
                <span>{isReceipt ? 'Customer Payment Receipt' : 'Supplier Payment Voucher'}</span>
              </h2>
              <p className="text-xs text-slate-400">
                {isReceipt
                  ? 'Credit cash/bank inflow into customer account and manage receipt entries'
                  : 'Manage, create, and audit payments issued to suppliers'}
              </p>
            </div>
          </div>

          {/* Tab navigation for BOTH Receipts and Supplier Payments */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 p-1 rounded-lg border border-slate-800 self-start sm:self-center">
            <button
              type="button"
              onClick={() => setActiveTab('NEW')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'NEW'
                  ? isReceipt
                    ? 'bg-teal-600 text-white shadow'
                    : 'bg-rose-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>{isReceipt ? 'New Receipt' : 'New Voucher'}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('MANAGE');
                loadData();
              }}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'MANAGE'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{isReceipt ? 'Manage Receipts' : 'Manage Payments'}</span>
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-slate-900/90 text-indigo-200 border border-indigo-500/40">
                {isReceipt ? receipts.length : payments.length}
              </span>
            </button>
          </div>
        </div>

        {/* TAB 1: NEW VOUCHER / RECEIPT FORM */}
        {activeTab === 'NEW' && (
          <form onSubmit={handleSave} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-400 font-medium mb-1">{isReceipt ? 'Receipt Number' : 'Voucher Number'}</label>
                <input
                  type="text"
                  readOnly
                  value={voucherNo}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Transaction Date</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Payment Mode</label>
                <select
                  value={paymentMode}
                  onChange={(e) => setPaymentMode(e.target.value as any)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-rose-500 focus:outline-none"
                >
                  <option value="Cash">Cash In Hand</option>
                  <option value="Bank / Cheque">Bank Cheque</option>
                  <option value="UPI / QR">UPI / QR Transfer</option>
                  <option value="NEFT / RTGS">NEFT / RTGS / Online</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  {isReceipt ? 'Select Customer (Debtor)' : 'SELECT SUPPLIER (Creditor)'}
                </label>
                <select
                  required
                  value={partyId}
                  onChange={(e) => setPartyId(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-semibold focus:border-rose-500 focus:outline-none"
                >
                  {isReceipt ? (
                    <>
                      <option value="">--Select Customer--</option>
                      {customers.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.customerName}
                        </option>
                      ))}
                    </>
                  ) : (
                    <>
                      <option value="">--Select Supplier--</option>
                      {suppliers.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.supplierName}
                        </option>
                      ))}
                    </>
                  )}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Cheque / UTR / Transaction Ref #</label>
                <input
                  type="text"
                  value={refNumber}
                  onChange={(e) => setRefNumber(e.target.value)}
                  placeholder="Optional transaction reference"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-rose-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  {isReceipt ? 'Amount Received (₹)' : 'Amount Paid (₹)'}
                </label>
                <input
                  type="number"
                  step="any"
                  required
                  min="1"
                  value={amount || ''}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  placeholder="0.00"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono font-bold text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  {isReceipt ? 'Discount Allowed (₹)' : 'Discount Received (₹)'}
                </label>
                <input
                  type="number"
                  step="any"
                  min="0"
                  value={discountReceived || ''}
                  onChange={(e) => setDiscountReceived(Number(e.target.value))}
                  placeholder="0.00"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-rose-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Remarks / Particulars</label>
              <textarea
                rows={2}
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                placeholder="Remarks or payment particulars..."
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-rose-500 focus:outline-none"
              />
            </div>

            {/* Current Balance Summary */}
            {partyId && (
              <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-400 block">Current Balance:</span>
                  <strong className="text-slate-200 font-mono">{formatCurrency(currentPartyBalance)}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block">{isReceipt ? 'Receipt Total:' : 'Payment Total:'}</span>
                  <strong className="text-emerald-400 font-mono">{formatCurrency(amount + discountReceived)}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block">New Balance After:</span>
                  <strong className="text-indigo-300 font-mono">{formatCurrency(newBalance)}</strong>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setAmount(0);
                  setDiscountReceived(0);
                  setRefNumber('');
                  setRemarks('');
                }}
                className="px-4 py-2 rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-300 font-medium flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
              <button
                type="submit"
                className={`px-5 py-2 rounded-lg font-bold text-white shadow-lg flex items-center gap-2 ${
                  isReceipt
                    ? 'bg-teal-600 hover:bg-teal-500'
                    : 'bg-rose-600 hover:bg-rose-500'
                }`}
              >
                <Save className="w-4 h-4" />
                <span>{isReceipt ? 'Save Customer Receipt' : 'Save Payment Voucher'}</span>
              </button>
            </div>
          </form>
        )}

        {/* TAB 2: MANAGE RECEIPTS TAB (When isReceipt === true) */}
        {isReceipt && activeTab === 'MANAGE' && (
          <div className="space-y-4">
            {/* Filters Bar */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-indigo-400" />
                  <span className="text-xs font-bold text-slate-200 uppercase tracking-wide">Filter Customer Receipts</span>
                </div>
                {/* Date Presets */}
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  <button
                    type="button"
                    onClick={handleClearDateFilters}
                    className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition ${
                      !filterDate && !filterDateFrom && !filterDateTo
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-xs'
                        : 'bg-slate-900 text-slate-400 border-slate-700/60 hover:text-slate-200'
                    }`}
                  >
                    All Dates
                  </button>
                  <button
                    type="button"
                    onClick={handleSetToday}
                    className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition ${
                      filterDate === getLocalTodayDate()
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-xs'
                        : 'bg-slate-900 text-slate-400 border-slate-700/60 hover:text-slate-200'
                    }`}
                  >
                    Today
                  </button>
                  <button
                    type="button"
                    onClick={handleSetYesterday}
                    className="px-2.5 py-1 rounded text-[11px] font-semibold border transition bg-slate-900 text-slate-400 border-slate-700/60 hover:text-slate-200"
                  >
                    Yesterday
                  </button>
                  <button
                    type="button"
                    onClick={handleSetThisMonth}
                    className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition ${
                      filterDateFrom && filterDateTo && !filterDate
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-xs'
                        : 'bg-slate-900 text-slate-400 border-slate-700/60 hover:text-slate-200'
                    }`}
                  >
                    This Month
                  </button>
                  {(filterPartyId || filterDate || filterDateFrom || filterDateTo || searchQuery) && (
                    <button
                      type="button"
                      onClick={handleClearAllFilters}
                      className="px-2.5 py-1 rounded text-[11px] font-semibold border transition bg-rose-950/40 text-rose-300 border-rose-800/60 hover:bg-rose-900/60 flex items-center gap-1 cursor-pointer"
                      title="Reset all filters"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Reset All</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Filter Controls Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2.5 text-xs items-end">
                {/* 1. Customer Filter */}
                <div className="lg:col-span-3">
                  <label className="block text-[11px] font-medium text-slate-400 mb-1 flex items-center justify-between">
                    <span>Customer</span>
                    {filterPartyId && filterPartyId !== 'ALL' && (
                      <button
                        type="button"
                        onClick={() => setFilterPartyId('')}
                        className="text-[10px] text-indigo-400 hover:text-indigo-300 font-normal cursor-pointer"
                      >
                        Reset
                      </button>
                    )}
                  </label>
                  <select
                    value={filterPartyId}
                    onChange={(e) => setFilterPartyId(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700/70 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-indigo-500 focus:outline-none cursor-pointer"
                  >
                    <option value="">--Select Customer--</option>
                    <option value="ALL">All Customers ({customers.length})</option>
                    {customers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.customerName}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 2. Date Filter */}
                <div className="lg:col-span-2">
                  <label className="block text-[11px] font-medium text-slate-400 mb-1 flex items-center justify-between">
                    <span>Date Filter</span>
                    {filterDate && (
                      <button
                        type="button"
                        onClick={() => setFilterDate('')}
                        className="text-[10px] text-rose-400 hover:text-rose-300 font-normal cursor-pointer"
                      >
                        Clear
                      </button>
                    )}
                  </label>
                  <input
                    type="date"
                    value={filterDate}
                    onChange={(e) => handleSingleDateChange(e.target.value)}
                    className={`w-full bg-slate-900 border rounded-lg px-2 py-1.5 text-slate-100 font-mono text-xs focus:outline-none ${
                      filterDate ? 'border-indigo-500 ring-1 ring-indigo-500/30' : 'border-slate-700/70 focus:border-indigo-500'
                    }`}
                  />
                </div>

                {/* 3. Date Range Filter */}
                <div className="lg:col-span-4">
                  <label className="block text-[11px] font-medium text-slate-400 mb-1 flex items-center justify-between">
                    <span>Date Range Filter</span>
                    {(filterDateFrom || filterDateTo) && (
                      <button
                        type="button"
                        onClick={() => {
                          setFilterDateFrom('');
                          setFilterDateTo('');
                        }}
                        className="text-[10px] text-rose-400 hover:text-rose-300 font-normal cursor-pointer"
                      >
                        Clear Range
                      </button>
                    )}
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    <div>
                      <input
                        type="date"
                        value={filterDateFrom}
                        onChange={(e) => handleDateFromChange(e.target.value)}
                        className={`w-full bg-slate-900 border rounded-lg px-2 py-1.5 text-slate-100 font-mono text-xs focus:outline-none ${
                          filterDateFrom ? 'border-indigo-500 ring-1 ring-indigo-500/30' : 'border-slate-700/70 focus:border-indigo-500'
                        }`}
                      />
                    </div>
                    <div>
                      <input
                        type="date"
                        value={filterDateTo}
                        onChange={(e) => handleDateToChange(e.target.value)}
                        className={`w-full bg-slate-900 border rounded-lg px-2 py-1.5 text-slate-100 font-mono text-xs focus:outline-none ${
                          filterDateTo ? 'border-indigo-500 ring-1 ring-indigo-500/30' : 'border-slate-700/70 focus:border-indigo-500'
                        }`}
                      />
                    </div>
                  </div>
                </div>

                {/* 4. Search Filter */}
                <div className="lg:col-span-3">
                  <label className="block text-[11px] font-medium text-slate-400 mb-1">
                    Search Receipt / Ref / Remarks
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Search receipt #, ref, customer..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700/70 rounded-lg pl-8 pr-2.5 py-1.5 text-slate-100 text-xs focus:border-indigo-500 focus:outline-none"
                    />
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    {searchQuery && (
                      <button
                        type="button"
                        onClick={() => setSearchQuery('')}
                        className="absolute right-2 top-2 text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Active Filter Summary Badges */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1.5 border-t border-slate-800/80 text-[11px] text-slate-400">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="font-semibold text-slate-300">Active Filters:</span>
                  <span className="bg-slate-900 border border-slate-700 px-2 py-0.5 rounded text-indigo-300 font-medium">
                    Customer: {filterPartyId && filterPartyId !== 'ALL' ? (customers.find(c => c.id === filterPartyId)?.customerName || filterPartyId) : 'All Customers'}
                  </span>
                  <span className="bg-slate-900 border border-slate-700 px-2 py-0.5 rounded text-amber-300 font-medium">
                    {filterDate
                      ? `Date: ${filterDate}`
                      : filterDateFrom || filterDateTo
                      ? `Range: ${filterDateFrom || 'Start'} to ${filterDateTo || 'End'}`
                      : 'All Dates'}
                  </span>
                  {searchQuery && (
                    <span className="bg-slate-900 border border-slate-700 px-2 py-0.5 rounded text-sky-300 font-mono">
                      "{searchQuery}"
                    </span>
                  )}
                </div>
                <div className="text-slate-400">
                  Showing <strong className="text-slate-200 font-mono">{filteredReceipts.length}</strong> matching receipts
                </div>
              </div>
            </div>

            {/* Metrics Overview Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Filtered Receipts</span>
                  <span className="text-xl font-black font-mono text-slate-100">{filteredReceipts.length}</span>
                  <span className="text-[11px] text-slate-500 ml-1">of {receipts.length} total</span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-teal-500/10 border border-teal-500/30 flex items-center justify-center text-teal-400">
                  <FileText className="w-4 h-4" />
                </div>
              </div>

              <div className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Total Amount Received</span>
                  <span className="text-xl font-black font-mono text-emerald-400">{formatCurrency(totalFilteredReceiptAmount)}</span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <DollarSign className="w-4 h-4" />
                </div>
              </div>

              <div className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Total Discount Allowed</span>
                  <span className="text-xl font-black font-mono text-sky-400">{formatCurrency(totalFilteredReceiptDiscount)}</span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
                  <Clock className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Receipts Table */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-xl overflow-hidden shadow-inner">
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-900/90 text-slate-300 font-semibold border-b border-slate-800">
                      <th className="p-3 w-12 text-center">#</th>
                      <th className="p-3">Receipt Details</th>
                      <th className="p-3">Customer Name</th>
                      <th className="p-3">Payment Mode & Ref</th>
                      <th className="p-3 text-right">Amount Received</th>
                      <th className="p-3 text-right">Discount</th>
                      <th className="p-3">Remarks</th>
                      <th className="p-3 text-center w-28">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 font-normal">
                    {filteredReceipts.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="p-8 text-center text-slate-400 space-y-2">
                          <Receipt className="w-8 h-8 text-slate-600 mx-auto" />
                          <p className="font-semibold text-sm">No customer receipts found</p>
                          <p className="text-xs text-slate-500">Try adjusting your filters, date range, or search criteria.</p>
                        </td>
                      </tr>
                    ) : (
                      filteredReceipts.map((r, idx) => (
                        <tr key={r.id} className="hover:bg-slate-900/40 transition">
                          <td className="p-3 text-center text-slate-500 font-mono">{idx + 1}</td>
                          <td className="p-3">
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono font-bold text-teal-300 bg-teal-950/40 border border-teal-800/50 px-1.5 py-0.5 rounded text-[11px]">
                                {r.receiptNo}
                              </span>
                            </div>
                            <span className="text-[11px] text-slate-400 block mt-0.5 font-mono">{r.receiptDate}</span>
                          </td>
                          <td className="p-3">
                            <div className="font-semibold text-slate-100">{r.customerName}</div>
                            <span className="text-[10px] text-slate-400">ID: {r.customerId}</span>
                          </td>
                          <td className="p-3">
                            <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                              {r.paymentMode}
                            </span>
                            {r.referenceNo && (
                              <div className="text-[11px] text-slate-400 font-mono mt-0.5">Ref: {r.referenceNo}</div>
                            )}
                          </td>
                          <td className="p-3 text-right">
                            <span className="font-mono font-bold text-emerald-400 text-sm">
                              {formatCurrency(r.amountReceived)}
                            </span>
                          </td>
                          <td className="p-3 text-right">
                            {r.discountAllowed && r.discountAllowed > 0 ? (
                              <span className="font-mono text-sky-400 text-xs">
                                {formatCurrency(r.discountAllowed)}
                              </span>
                            ) : (
                              <span className="text-slate-600 font-mono">-</span>
                            )}
                          </td>
                          <td className="p-3 max-w-[200px] truncate text-slate-300">
                            {r.remarks || <span className="text-slate-600 italic">None</span>}
                          </td>
                          <td className="p-3 text-center">
                            <div className="flex items-center justify-center gap-1">
                              <button
                                type="button"
                                onClick={() => setPrintingReceipt(r)}
                                className="p-1.5 rounded-md text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700/60 transition"
                                title="Print Receipt"
                              >
                                <Printer className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleOpenEditReceipt(r)}
                                className="p-1.5 rounded-md text-indigo-400 hover:text-indigo-200 hover:bg-indigo-950/50 border border-indigo-800/50 transition"
                                title="Edit Receipt"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeletingReceipt(r)}
                                className="p-1.5 rounded-md text-rose-400 hover:text-rose-200 hover:bg-rose-950/50 border border-rose-800/50 transition"
                                title="Delete Receipt"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: MANAGE PAYMENTS TAB (When isReceipt === false) */}
        {!isReceipt && activeTab === 'MANAGE' && (
          <div className="space-y-4">
            {/* Filters Bar */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-indigo-400" />
                  <span className="text-xs font-bold text-slate-200 uppercase tracking-wide">Filter Payments</span>
                </div>
                {/* Date Presets */}
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  <button
                    type="button"
                    onClick={handleClearDateFilters}
                    className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition ${
                      !filterDate && !filterDateFrom && !filterDateTo
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-xs'
                        : 'bg-slate-900 text-slate-400 border-slate-700/60 hover:text-slate-200'
                    }`}
                  >
                    All Dates
                  </button>
                  <button
                    type="button"
                    onClick={handleSetToday}
                    className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition ${
                      filterDate === getLocalTodayDate()
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-xs'
                        : 'bg-slate-900 text-slate-400 border-slate-700/60 hover:text-slate-200'
                    }`}
                  >
                    Today
                  </button>
                  <button
                    type="button"
                    onClick={handleSetYesterday}
                    className="px-2.5 py-1 rounded text-[11px] font-semibold border transition bg-slate-900 text-slate-400 border-slate-700/60 hover:text-slate-200"
                  >
                    Yesterday
                  </button>
                  <button
                    type="button"
                    onClick={handleSetThisMonth}
                    className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition ${
                      filterDateFrom && filterDateTo && !filterDate
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-xs'
                        : 'bg-slate-900 text-slate-400 border-slate-700/60 hover:text-slate-200'
                    }`}
                  >
                    This Month
                  </button>
                  {(filterPartyId || filterDate || filterDateFrom || filterDateTo || searchQuery) && (
                    <button
                      type="button"
                      onClick={handleClearAllFilters}
                      className="px-2.5 py-1 rounded text-[11px] font-semibold border transition bg-rose-950/40 text-rose-300 border-rose-800/60 hover:bg-rose-900/60 flex items-center gap-1 cursor-pointer"
                      title="Reset all filters"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Reset All</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Filter Controls Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2.5 text-xs items-end">
                {/* 1. Supplier Filter */}
                <div className="lg:col-span-3">
                  <label className="block text-[11px] font-medium text-slate-400 mb-1 flex items-center justify-between">
                    <span>Supplier</span>
                    {filterPartyId && filterPartyId !== 'ALL' && (
                      <button
                        type="button"
                        onClick={() => setFilterPartyId('')}
                        className="text-[10px] text-indigo-400 hover:text-indigo-300 font-normal cursor-pointer"
                      >
                        Reset
                      </button>
                    )}
                  </label>
                  <select
                    value={filterPartyId}
                    onChange={(e) => setFilterPartyId(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700/70 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-indigo-500 focus:outline-none cursor-pointer"
                  >
                    <option value="">--Select Supplier--</option>
                    <option value="ALL">All Suppliers ({suppliers.length})</option>
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.supplierName}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 2. Date Filter */}
                <div className="lg:col-span-2">
                  <label className="block text-[11px] font-medium text-slate-400 mb-1 flex items-center justify-between">
                    <span>Date Filter</span>
                    {filterDate && (
                      <button
                        type="button"
                        onClick={() => setFilterDate('')}
                        className="text-[10px] text-rose-400 hover:text-rose-300 font-normal cursor-pointer"
                      >
                        Clear
                      </button>
                    )}
                  </label>
                  <input
                    type="date"
                    value={filterDate}
                    onChange={(e) => handleSingleDateChange(e.target.value)}
                    className={`w-full bg-slate-900 border rounded-lg px-2 py-1.5 text-slate-100 font-mono text-xs focus:outline-none ${
                      filterDate ? 'border-indigo-500 ring-1 ring-indigo-500/30' : 'border-slate-700/70 focus:border-indigo-500'
                    }`}
                  />
                </div>

                {/* 3. Date Range Filter */}
                <div className="lg:col-span-4">
                  <label className="block text-[11px] font-medium text-slate-400 mb-1 flex items-center justify-between">
                    <span>Date Range Filter</span>
                    {(filterDateFrom || filterDateTo) && (
                      <button
                        type="button"
                        onClick={() => {
                          setFilterDateFrom('');
                          setFilterDateTo('');
                        }}
                        className="text-[10px] text-rose-400 hover:text-rose-300 font-normal cursor-pointer"
                      >
                        Clear Range
                      </button>
                    )}
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    <div>
                      <input
                        type="date"
                        value={filterDateFrom}
                        onChange={(e) => handleDateFromChange(e.target.value)}
                        className={`w-full bg-slate-900 border rounded-lg px-2 py-1.5 text-slate-100 font-mono text-xs focus:outline-none ${
                          filterDateFrom ? 'border-indigo-500 ring-1 ring-indigo-500/30' : 'border-slate-700/70 focus:border-indigo-500'
                        }`}
                      />
                    </div>
                    <div>
                      <input
                        type="date"
                        value={filterDateTo}
                        onChange={(e) => handleDateToChange(e.target.value)}
                        className={`w-full bg-slate-900 border rounded-lg px-2 py-1.5 text-slate-100 font-mono text-xs focus:outline-none ${
                          filterDateTo ? 'border-indigo-500 ring-1 ring-indigo-500/30' : 'border-slate-700/70 focus:border-indigo-500'
                        }`}
                      />
                    </div>
                  </div>
                </div>

                {/* 4. Search Filter */}
                <div className="lg:col-span-3">
                  <label className="block text-[11px] font-medium text-slate-400 mb-1">
                    Search Voucher / Ref / Remarks
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Search voucher #, ref, UTR..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700/70 rounded-lg pl-8 pr-2.5 py-1.5 text-slate-100 text-xs focus:border-indigo-500 focus:outline-none"
                    />
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    {searchQuery && (
                      <button
                        type="button"
                        onClick={() => setSearchQuery('')}
                        className="absolute right-2 top-2 text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Active Filter Summary Badges */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1.5 border-t border-slate-800/80 text-[11px] text-slate-400">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="font-semibold text-slate-300">Active Filters:</span>
                  <span className="bg-slate-900 border border-slate-700 px-2 py-0.5 rounded text-indigo-300 font-medium">
                    Supplier: {filterPartyId && filterPartyId !== 'ALL' ? (suppliers.find(s => s.id === filterPartyId)?.supplierName || filterPartyId) : 'All Suppliers'}
                  </span>
                  <span className="bg-slate-900 border border-slate-700 px-2 py-0.5 rounded text-amber-300 font-medium">
                    {filterDate
                      ? `Date: ${filterDate}`
                      : filterDateFrom || filterDateTo
                      ? `Range: ${filterDateFrom || 'Start'} to ${filterDateTo || 'End'}`
                      : 'All Dates'}
                  </span>
                  {searchQuery && (
                    <span className="bg-slate-900 border border-slate-700 px-2 py-0.5 rounded text-sky-300 font-mono">
                      "{searchQuery}"
                    </span>
                  )}
                </div>
                <div className="text-slate-400">
                  Showing <strong className="text-slate-200 font-mono">{filteredPayments.length}</strong> matching payments
                </div>
              </div>
            </div>

            {/* Metrics Overview Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Filtered Vouchers</span>
                  <span className="text-xl font-black font-mono text-slate-100">{filteredPayments.length}</span>
                  <span className="text-[11px] text-slate-500 ml-1">of {payments.length} total</span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                  <FileText className="w-4 h-4" />
                </div>
              </div>

              <div className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Total Amount Paid</span>
                  <span className="text-xl font-black font-mono text-emerald-400">{formatCurrency(totalFilteredAmount)}</span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <DollarSign className="w-4 h-4" />
                </div>
              </div>

              <div className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Total Discount Received</span>
                  <span className="text-xl font-black font-mono text-sky-400">{formatCurrency(totalFilteredDiscount)}</span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
                  <Clock className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Payments Table */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-xl overflow-hidden shadow-inner">
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-900/90 text-slate-300 font-semibold border-b border-slate-800">
                      <th className="p-3 w-12 text-center">#</th>
                      <th className="p-3">Voucher Details</th>
                      <th className="p-3">Supplier Name</th>
                      <th className="p-3">Payment Mode & Ref</th>
                      <th className="p-3 text-right">Amount Paid</th>
                      <th className="p-3 text-right">Discount</th>
                      <th className="p-3">Particulars</th>
                      <th className="p-3 text-center w-28">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 font-normal">
                    {filteredPayments.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="p-8 text-center text-slate-400 space-y-2">
                          <Receipt className="w-8 h-8 text-slate-600 mx-auto" />
                          <p className="font-semibold text-sm">No payment vouchers found</p>
                          <p className="text-xs text-slate-500">Try adjusting your filters, date range, or search criteria.</p>
                        </td>
                      </tr>
                    ) : (
                      filteredPayments.map((p, idx) => (
                        <tr key={p.id} className="hover:bg-slate-900/40 transition">
                          <td className="p-3 text-center text-slate-500 font-mono">{idx + 1}</td>
                          <td className="p-3">
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono font-bold text-rose-300 bg-rose-950/40 border border-rose-800/50 px-1.5 py-0.5 rounded text-[11px]">
                                {p.voucherNo}
                              </span>
                            </div>
                            <span className="text-[11px] text-slate-400 block mt-0.5 font-mono">{p.voucherDate}</span>
                          </td>
                          <td className="p-3">
                            <div className="font-semibold text-slate-100">{p.supplierName}</div>
                            <span className="text-[10px] text-slate-400">ID: {p.supplierId}</span>
                          </td>
                          <td className="p-3">
                            <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                              {p.paymentMode}
                            </span>
                            {p.referenceNo && (
                              <div className="text-[11px] text-slate-400 font-mono mt-0.5">Ref: {p.referenceNo}</div>
                            )}
                          </td>
                          <td className="p-3 text-right">
                            <span className="font-mono font-bold text-emerald-400 text-sm">
                              {formatCurrency(p.amountPaid)}
                            </span>
                          </td>
                          <td className="p-3 text-right">
                            {p.discountReceived && p.discountReceived > 0 ? (
                              <span className="font-mono text-sky-400 text-xs">
                                {formatCurrency(p.discountReceived)}
                              </span>
                            ) : (
                              <span className="text-slate-600 font-mono">-</span>
                            )}
                          </td>
                          <td className="p-3 max-w-[200px] truncate text-slate-300">
                            {p.remarks || <span className="text-slate-600 italic">None</span>}
                          </td>
                          <td className="p-3 text-center">
                            <div className="flex items-center justify-center gap-1">
                              <button
                                type="button"
                                onClick={() => setPrintingPayment(p)}
                                className="p-1.5 rounded-md text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700/60 transition"
                                title="Print Voucher"
                              >
                                <Printer className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleOpenEditPayment(p)}
                                className="p-1.5 rounded-md text-indigo-400 hover:text-indigo-200 hover:bg-indigo-950/50 border border-indigo-800/50 transition"
                                title="Edit Voucher"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeletingPayment(p)}
                                className="p-1.5 rounded-md text-rose-400 hover:text-rose-200 hover:bg-rose-950/50 border border-rose-800/50 transition"
                                title="Delete Voucher"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* EDIT RECEIPT MODAL */}
      {editingReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-xl w-full p-5 shadow-2xl space-y-4 text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Edit2 className="w-4 h-4 text-teal-400" />
                <h3 className="font-bold text-sm text-slate-100">
                  Edit Customer Receipt: <span className="font-mono text-teal-300">{editingReceipt.receiptNo}</span>
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingReceipt(null)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleUpdateReceipt} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Receipt Number</label>
                  <input
                    type="text"
                    readOnly
                    value={editingReceipt.receiptNo}
                    className="w-full bg-slate-950/80 border border-slate-800 rounded-lg px-2.5 py-1.5 text-teal-300 font-mono font-bold cursor-not-allowed"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Receipt Date</label>
                  <input
                    type="date"
                    required
                    value={editReceiptDate}
                    onChange={(e) => setEditReceiptDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Customer</label>
                  <select
                    value={editCustomerId}
                    onChange={(e) => setEditCustomerId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 font-semibold focus:border-teal-500 focus:outline-none"
                  >
                    {customers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.customerName}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Payment Mode</label>
                  <select
                    value={editReceiptPaymentMode}
                    onChange={(e) => setEditReceiptPaymentMode(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-teal-500 focus:outline-none"
                  >
                    <option value="Cash">Cash In Hand</option>
                    <option value="Cheque">Bank Cheque</option>
                    <option value="Bank/UPI">Bank / UPI / Online</option>
                    <option value="Card">Card</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Amount Received (₹) *</label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={editAmountReceived}
                    onChange={(e) => setEditAmountReceived(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-emerald-400 font-mono font-bold focus:border-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Discount Allowed (₹)</label>
                  <input
                    type="number"
                    step="any"
                    value={editDiscountAllowed}
                    onChange={(e) => setEditDiscountAllowed(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-sky-400 font-mono font-bold focus:border-sky-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Ref / Txn #</label>
                  <input
                    type="text"
                    value={editReceiptRefNumber}
                    onChange={(e) => setEditReceiptRefNumber(e.target.value)}
                    placeholder="Ref or Txn No"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Remarks / Particulars</label>
                <input
                  type="text"
                  value={editReceiptRemarks}
                  onChange={(e) => setEditReceiptRemarks(e.target.value)}
                  placeholder="Optional remarks"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-teal-500 focus:outline-none"
                />
              </div>

              <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 text-[11px] text-slate-400 space-y-1">
                <p>
                  <span className="text-slate-300 font-semibold">Note:</span> Updating this receipt will automatically recalculate the customer's balance and sync the corresponding ledger credit entry.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingReceipt(null)}
                  className="px-4 py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-bold flex items-center gap-1.5 shadow"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Update Receipt</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE RECEIPT CONFIRMATION MODAL */}
      {deletingReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-rose-700/50 rounded-xl max-w-md w-full p-5 shadow-2xl space-y-4 text-slate-100">
            <div className="flex items-center gap-3 text-rose-400 border-b border-slate-800 pb-3">
              <div className="w-9 h-9 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center">
                <AlertCircle className="w-5 h-5 text-rose-400" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-100">Delete Customer Receipt</h3>
                <span className="text-xs text-slate-400">Receipt: {deletingReceipt.receiptNo}</span>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-300">
              <p>Are you sure you want to delete this customer receipt?</p>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1 font-mono text-xs">
                <div><span className="text-slate-400">Customer:</span> <strong className="text-slate-200">{deletingReceipt.customerName}</strong></div>
                <div><span className="text-slate-400">Date:</span> {deletingReceipt.receiptDate}</div>
                <div><span className="text-slate-400">Amount Received:</span> <strong className="text-emerald-400">{formatCurrency(deletingReceipt.amountReceived)}</strong></div>
                {deletingReceipt.discountAllowed && deletingReceipt.discountAllowed > 0 ? (
                  <div><span className="text-slate-400">Discount:</span> <strong className="text-sky-400">{formatCurrency(deletingReceipt.discountAllowed)}</strong></div>
                ) : null}
              </div>
              <p className="text-[11px] text-amber-400">
                ⚠️ Deleting this receipt will restore {formatCurrency((deletingReceipt.amountReceived || 0) + (deletingReceipt.discountAllowed || 0))} back to the customer's balance and delete the corresponding ledger credit entry.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setDeletingReceipt(null)}
                className="px-4 py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteReceipt}
                className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center gap-1.5 shadow"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirm Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PRINT RECEIPT MODAL */}
      {printingReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white text-slate-900 rounded-xl max-w-2xl w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b pb-3 print:hidden">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Customer Receipt Preview</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shadow"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Receipt</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPrintingReceipt(null)}
                  className="p-1.5 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Printable Receipt Slip Area */}
            <div className="border border-slate-900 p-6 space-y-4 font-sans text-xs">
              {/* Header */}
              <div className="text-center border-b border-slate-900 pb-3 space-y-1">
                <h1 className="text-lg font-black tracking-wide uppercase">{companyInfo?.companyName || 'ARCO ENTERPRISE'}</h1>
                <p className="text-slate-600 text-[11px]">
                  {companyInfo?.addressLine1 || ''}{companyInfo?.city ? `, ${companyInfo.city}` : ''}{companyInfo?.pincode ? ` - ${companyInfo.pincode}` : ''}
                </p>
                <p className="text-slate-600 text-[11px]">
                  GSTIN: <strong>{companyInfo?.gstin || '08ABCDE1234F1Z5'}</strong> • Phone: {companyInfo?.phone || companyInfo?.mobile || 'N/A'}
                </p>
                <div className="inline-block mt-2 px-3 py-1 bg-teal-800 text-white font-bold uppercase tracking-wider rounded text-xs">
                  Customer Payment Receipt
                </div>
              </div>

              {/* Receipt Meta */}
              <div className="grid grid-cols-2 gap-4 border-b border-slate-900 pb-3">
                <div className="space-y-1">
                  <div><strong>Received From:</strong> {printingReceipt.customerName}</div>
                  <div><strong>Customer ID:</strong> {printingReceipt.customerId}</div>
                  <div><strong>Payment Mode:</strong> {printingReceipt.paymentMode}</div>
                  {printingReceipt.referenceNo && (
                    <div><strong>Txn / Cheque #:</strong> {printingReceipt.referenceNo}</div>
                  )}
                </div>
                <div className="space-y-1 text-right font-mono">
                  <div><strong>Receipt No:</strong> {printingReceipt.receiptNo}</div>
                  <div><strong>Date:</strong> {printingReceipt.receiptDate}</div>
                </div>
              </div>

              {/* Amount Breakdown */}
              <div className="border border-slate-900 rounded overflow-hidden">
                <table className="w-full text-xs">
                  <thead className="bg-slate-100 border-b border-slate-900">
                    <tr>
                      <th className="p-2 text-left">Description</th>
                      <th className="p-2 text-right">Amount (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    <tr>
                      <td className="p-2">
                        Payment received towards bill settlement / account credit
                        {printingReceipt.remarks && (
                          <div className="text-[11px] text-slate-600 italic">Remarks: {printingReceipt.remarks}</div>
                        )}
                      </td>
                      <td className="p-2 text-right font-mono font-bold">{formatCurrency(printingReceipt.amountReceived)}</td>
                    </tr>
                    {printingReceipt.discountAllowed && printingReceipt.discountAllowed > 0 ? (
                      <tr>
                        <td className="p-2 text-slate-600">Discount Allowed</td>
                        <td className="p-2 text-right font-mono text-slate-600">{formatCurrency(printingReceipt.discountAllowed)}</td>
                      </tr>
                    ) : null}
                    <tr className="bg-slate-100 font-bold border-t border-slate-900">
                      <td className="p-2">Total Credit Applied</td>
                      <td className="p-2 text-right font-mono text-sm">
                        {formatCurrency((printingReceipt.amountReceived || 0) + (printingReceipt.discountAllowed || 0))}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Amount in words */}
              <div className="bg-slate-50 p-2.5 rounded border border-slate-300">
                <span className="font-bold">Amount in Words: </span>
                <span className="italic">{numberToWords(printingReceipt.amountReceived)}</span>
              </div>

              {/* Signature Blocks */}
              <div className="grid grid-cols-2 pt-10 text-center gap-8">
                <div>
                  <div className="border-t border-slate-900 pt-1 font-semibold">Customer's Signature</div>
                  <div className="text-[10px] text-slate-500">(Payer)</div>
                </div>
                <div>
                  <div className="border-t border-slate-900 pt-1 font-semibold">Authorized Signatory</div>
                  <div className="text-[10px] text-slate-500">For {companyInfo?.companyName || 'ARCO ENTERPRISE'}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* EDIT PAYMENT MODAL */}
      {editingPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-xl w-full p-5 shadow-2xl space-y-4 text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Edit2 className="w-4 h-4 text-indigo-400" />
                <h3 className="font-bold text-sm text-slate-100">
                  Edit Payment Voucher: <span className="font-mono text-rose-400">{editingPayment.voucherNo}</span>
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingPayment(null)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleUpdatePayment} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Voucher Number</label>
                  <input
                    type="text"
                    readOnly
                    value={editingPayment.voucherNo}
                    className="w-full bg-slate-950/80 border border-slate-800 rounded-lg px-2.5 py-1.5 text-rose-300 font-mono font-bold cursor-not-allowed"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Transaction Date</label>
                  <input
                    type="date"
                    required
                    value={editVoucherDate}
                    onChange={(e) => setEditVoucherDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Supplier</label>
                  <select
                    value={editSupplierId}
                    onChange={(e) => setEditSupplierId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 font-semibold focus:border-indigo-500 focus:outline-none"
                  >
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.supplierName}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Payment Mode</label>
                  <select
                    value={editPaymentMode}
                    onChange={(e) => setEditPaymentMode(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-indigo-500 focus:outline-none"
                  >
                    <option value="Cash">Cash In Hand</option>
                    <option value="Cheque">Bank Cheque</option>
                    <option value="Bank/NEFT">Bank / NEFT / RTGS</option>
                    <option value="UPI">UPI / QR Transfer</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Amount Paid (₹) *</label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={editAmountPaid}
                    onChange={(e) => setEditAmountPaid(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-emerald-400 font-mono font-bold focus:border-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Discount Received (₹)</label>
                  <input
                    type="number"
                    step="any"
                    value={editDiscountReceived}
                    onChange={(e) => setEditDiscountReceived(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-sky-400 font-mono font-bold focus:border-sky-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Ref / Cheque #</label>
                  <input
                    type="text"
                    value={editRefNumber}
                    onChange={(e) => setEditRefNumber(e.target.value)}
                    placeholder="Ref or Cheque No"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Narration / Remarks</label>
                <input
                  type="text"
                  value={editRemarks}
                  onChange={(e) => setEditRemarks(e.target.value)}
                  placeholder="Optional remarks"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 text-[11px] text-slate-400 space-y-1">
                <p>
                  <span className="text-slate-300 font-semibold">Note:</span> Updating this voucher will automatically recalculate the supplier's balance and sync the corresponding ledger debit entry.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingPayment(null)}
                  className="px-4 py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold flex items-center gap-1.5 shadow"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Update Voucher</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE PAYMENT CONFIRMATION MODAL */}
      {deletingPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-rose-700/50 rounded-xl max-w-md w-full p-5 shadow-2xl space-y-4 text-slate-100">
            <div className="flex items-center gap-3 text-rose-400 border-b border-slate-800 pb-3">
              <div className="w-9 h-9 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center">
                <AlertCircle className="w-5 h-5 text-rose-400" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-100">Delete Payment Voucher</h3>
                <span className="text-xs text-slate-400">Voucher: {deletingPayment.voucherNo}</span>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-300">
              <p>Are you sure you want to delete this payment voucher?</p>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1 font-mono text-xs">
                <div><span className="text-slate-400">Supplier:</span> <strong className="text-slate-200">{deletingPayment.supplierName}</strong></div>
                <div><span className="text-slate-400">Date:</span> {deletingPayment.voucherDate}</div>
                <div><span className="text-slate-400">Amount Paid:</span> <strong className="text-emerald-400">{formatCurrency(deletingPayment.amountPaid)}</strong></div>
                {deletingPayment.discountReceived && deletingPayment.discountReceived > 0 ? (
                  <div><span className="text-slate-400">Discount:</span> <strong className="text-sky-400">{formatCurrency(deletingPayment.discountReceived)}</strong></div>
                ) : null}
              </div>
              <p className="text-[11px] text-amber-400">
                ⚠️ Deleting this payment will revert {formatCurrency((deletingPayment.amountPaid || 0) + (deletingPayment.discountReceived || 0))} back to the supplier's payable balance and delete the corresponding ledger debit entry.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setDeletingPayment(null)}
                className="px-4 py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeletePayment}
                className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center gap-1.5 shadow"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirm Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PRINT PAYMENT VOUCHER MODAL */}
      {printingPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white text-slate-900 rounded-xl max-w-2xl w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b pb-3 print:hidden">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Payment Voucher Preview</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Voucher</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPrintingPayment(null)}
                  className="p-1.5 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Printable Slip Area */}
            <div className="border border-slate-900 p-6 space-y-4 font-sans text-xs">
              {/* Header */}
              <div className="text-center border-b border-slate-900 pb-3 space-y-1">
                <h1 className="text-lg font-black tracking-wide uppercase">{companyInfo?.companyName || 'ARCO ENTERPRISE'}</h1>
                <p className="text-slate-600 text-[11px]">
                  {companyInfo?.addressLine1 || ''}{companyInfo?.city ? `, ${companyInfo.city}` : ''}{companyInfo?.pincode ? ` - ${companyInfo.pincode}` : ''}
                </p>
                <p className="text-slate-600 text-[11px]">
                  GSTIN: <strong>{companyInfo?.gstin || '08ABCDE1234F1Z5'}</strong> • Phone: {companyInfo?.phone || companyInfo?.mobile || 'N/A'}
                </p>
                <div className="inline-block mt-2 px-3 py-1 bg-slate-900 text-white font-bold uppercase tracking-wider rounded text-xs">
                  Supplier Payment Voucher
                </div>
              </div>

              {/* Voucher Meta */}
              <div className="grid grid-cols-2 gap-4 border-b border-slate-900 pb-3">
                <div className="space-y-1">
                  <div><strong>Paid To:</strong> {printingPayment.supplierName}</div>
                  <div><strong>Supplier ID:</strong> {printingPayment.supplierId}</div>
                  <div><strong>Payment Mode:</strong> {printingPayment.paymentMode}</div>
                  {printingPayment.referenceNo && (
                    <div><strong>Cheque / Ref #:</strong> {printingPayment.referenceNo}</div>
                  )}
                </div>
                <div className="space-y-1 text-right font-mono">
                  <div><strong>Voucher No:</strong> {printingPayment.voucherNo}</div>
                  <div><strong>Date:</strong> {printingPayment.voucherDate}</div>
                </div>
              </div>

              {/* Amount Breakdown */}
              <div className="border border-slate-900 rounded overflow-hidden">
                <table className="w-full text-xs">
                  <thead className="bg-slate-100 border-b border-slate-900">
                    <tr>
                      <th className="p-2 text-left">Description</th>
                      <th className="p-2 text-right">Amount (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    <tr>
                      <td className="p-2">
                        Amount Paid towards bill clearance / account credit
                        {printingPayment.remarks && (
                          <div className="text-[11px] text-slate-600 italic">Narration: {printingPayment.remarks}</div>
                        )}
                      </td>
                      <td className="p-2 text-right font-mono font-bold">{formatCurrency(printingPayment.amountPaid)}</td>
                    </tr>
                    {printingPayment.discountReceived && printingPayment.discountReceived > 0 ? (
                      <tr>
                        <td className="p-2 text-slate-600">Discount Received</td>
                        <td className="p-2 text-right font-mono text-slate-600">{formatCurrency(printingPayment.discountReceived)}</td>
                      </tr>
                    ) : null}
                    <tr className="bg-slate-100 font-bold border-t border-slate-900">
                      <td className="p-2">Total Net Benefit Applied</td>
                      <td className="p-2 text-right font-mono text-sm">
                        {formatCurrency((printingPayment.amountPaid || 0) + (printingPayment.discountReceived || 0))}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Amount in words */}
              <div className="bg-slate-50 p-2.5 rounded border border-slate-300">
                <span className="font-bold">Amount in Words: </span>
                <span className="italic">{numberToWords(printingPayment.amountPaid)}</span>
              </div>

              {/* Signature Blocks */}
              <div className="grid grid-cols-2 pt-10 text-center gap-8">
                <div>
                  <div className="border-t border-slate-900 pt-1 font-semibold">Receiver's Signature</div>
                  <div className="text-[10px] text-slate-500">(Supplier / Representative)</div>
                </div>
                <div>
                  <div className="border-t border-slate-900 pt-1 font-semibold">Authorized Signatory</div>
                  <div className="text-[10px] text-slate-500">For {companyInfo?.companyName || 'ARCO ENTERPRISE'}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
