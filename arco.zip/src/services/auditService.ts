import { AuditLog, AuditAction, AuditEntityType } from '../types';
import { authService } from './authService';
import { db } from '../firebase';
import { doc, setDoc, deleteDoc, onSnapshot, collection, query, orderBy, limit, writeBatch } from 'firebase/firestore';

const STORAGE_KEY = 'arco_audit_logs_v2';
const MAX_LOCAL_LOGS = 1000;

class AuditService {
  private logs: AuditLog[] = [];
  private listeners: Array<(logs: AuditLog[]) => void> = [];

  constructor() {
    this.logs = this.loadLocalLogs();
    if (typeof window !== 'undefined') {
      this.initFirestoreListener();
    }
  }

  private loadLocalLogs(): AuditLog[] {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (err) {
      console.warn('Failed to load local audit logs:', err);
    }
    return [];
  }

  private saveLocalLogs(): void {
    try {
      // Keep most recent MAX_LOCAL_LOGS
      const trimmed = this.logs.slice(0, MAX_LOCAL_LOGS);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
    } catch (err) {
      console.warn('Failed to save audit logs to localStorage:', err);
    }
  }

  private initFirestoreListener(): void {
    try {
      const q = query(collection(db, 'audit_logs'), orderBy('timestamp', 'desc'), limit(150));
      onSnapshot(q, (snapshot) => {
        let changed = false;
        snapshot.docChanges().forEach((change) => {
          if (change.type === 'added' || change.type === 'modified') {
            const data = change.doc.data() as AuditLog;
            if (data && data.id) {
              const existingIdx = this.logs.findIndex((l) => l.id === data.id);
              if (existingIdx === -1) {
                this.logs.unshift(data);
                changed = true;
              } else {
                this.logs[existingIdx] = data;
                changed = true;
              }
            }
          } else if (change.type === 'removed') {
            const docId = change.doc.id;
            const beforeLen = this.logs.length;
            this.logs = this.logs.filter((l) => l.id !== docId);
            if (this.logs.length !== beforeLen) {
              changed = true;
            }
          }
        });
        if (changed) {
          // Sort descending by timestamp
          this.logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
          this.saveLocalLogs();
          this.notify();
        }
      }, (err) => {
        console.warn('Firestore audit_logs realtime listener error:', err.message);
      });
    } catch (err) {
      console.warn('Error setting up audit_logs Firestore listener:', err);
    }
  }

  subscribe(callback: (logs: AuditLog[]) => void): () => void {
    this.listeners.push(callback);
    callback(this.logs);
    return () => {
      this.listeners = this.listeners.filter((cb) => cb !== callback);
    };
  }

  private notify(): void {
    this.listeners.forEach((cb) => {
      try {
        cb(this.logs);
      } catch (err) {
        console.error('Audit listener error:', err);
      }
    });
  }

  /**
   * Record a new audit log entry
   */
  log(params: {
    action: AuditAction;
    entityType: AuditEntityType;
    entityId: string;
    entityName?: string;
    summary: string;
    details?: Record<string, any>;
  }): AuditLog {
    const activeAdmin = authService.getActiveAdmin();
    const newLog: AuditLog = {
      id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
      userId: activeAdmin?.id || 'admin-primary',
      userEmail: activeAdmin?.email || 'arcoshoesco@gmail.com',
      userName: activeAdmin?.name || 'Administrator',
      userRole: activeAdmin?.role || 'Super Admin',
      action: params.action,
      entityType: params.entityType,
      entityId: params.entityId,
      entityName: params.entityName,
      summary: params.summary,
      details: params.details,
    };

    // Prepend to local memory & persist
    this.logs.unshift(newLog);
    this.saveLocalLogs();
    this.notify();

    // Asynchronously write to Firestore
    try {
      setDoc(doc(db, 'audit_logs', newLog.id), newLog).catch((err) => {
        console.warn('Could not sync audit log to Firestore:', err);
      });
    } catch (err) {
      console.warn('Failed to initiate audit log Firestore write:', err);
    }

    return newLog;
  }

  /**
   * Get all logs with optional filtering
   */
  getLogs(filter?: {
    action?: string;
    entityType?: string;
    userId?: string;
    query?: string;
    dateFrom?: string;
    dateTo?: string;
  }): AuditLog[] {
    let result = [...this.logs];

    if (!filter) return result;

    if (filter.action && filter.action !== 'ALL') {
      result = result.filter((l) => l.action === filter.action);
    }

    if (filter.entityType && filter.entityType !== 'ALL') {
      result = result.filter((l) => l.entityType === filter.entityType);
    }

    if (filter.userId && filter.userId !== 'ALL') {
      result = result.filter((l) => l.userId === filter.userId || l.userEmail.toLowerCase() === filter.userId.toLowerCase());
    }

    if (filter.dateFrom) {
      const fromTime = new Date(filter.dateFrom).getTime();
      result = result.filter((l) => new Date(l.timestamp).getTime() >= fromTime);
    }

    if (filter.dateTo) {
      const toTime = new Date(`${filter.dateTo}T23:59:59.999Z`).getTime();
      result = result.filter((l) => new Date(l.timestamp).getTime() <= toTime);
    }

    if (filter.query && filter.query.trim()) {
      const q = filter.query.toLowerCase().trim();
      result = result.filter(
        (l) =>
          l.summary.toLowerCase().includes(q) ||
          l.entityId.toLowerCase().includes(q) ||
          (l.entityName && l.entityName.toLowerCase().includes(q)) ||
          l.userName.toLowerCase().includes(q) ||
          l.userEmail.toLowerCase().includes(q) ||
          l.action.toLowerCase().includes(q)
      );
    }

    return result;
  }

  /**
   * Export audit trail to CSV format
   */
  exportToCsv(filteredLogs?: AuditLog[]): string {
    const list = filteredLogs || this.logs;
    const headers = ['Timestamp', 'Action', 'Entity Type', 'Entity ID', 'Entity Name', 'Summary', 'User Name', 'User Email', 'Role'];
    const rows = list.map((l) => [
      `"${new Date(l.timestamp).toLocaleString()}"`,
      `"${l.action}"`,
      `"${l.entityType}"`,
      `"${l.entityId}"`,
      `"${(l.entityName || '').replace(/"/g, '""')}"`,
      `"${l.summary.replace(/"/g, '""')}"`,
      `"${l.userName.replace(/"/g, '""')}"`,
      `"${l.userEmail}"`,
      `"${l.userRole}"`,
    ]);
    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }

  /**
   * Export audit trail to JSON format
   */
  exportToJson(filteredLogs?: AuditLog[]): string {
    const list = filteredLogs || this.logs;
    return JSON.stringify(list, null, 2);
  }

  /**
   * Delete a single audit log entry
   */
  async deleteLog(logId: string): Promise<boolean> {
    const prevCount = this.logs.length;
    this.logs = this.logs.filter((l) => l.id !== logId);
    if (this.logs.length !== prevCount) {
      this.saveLocalLogs();
      this.notify();
    }

    // Delete from Firestore
    try {
      await deleteDoc(doc(db, 'audit_logs', logId));
      return true;
    } catch (err) {
      console.warn('Failed to delete audit log from Firestore:', err);
      return true;
    }
  }

  /**
   * Delete multiple audit log entries (e.g. all filtered/active logs)
   */
  async deleteLogs(logIds: string[]): Promise<number> {
    if (!logIds || logIds.length === 0) return 0;

    const idSet = new Set(logIds);
    const initialCount = this.logs.length;
    this.logs = this.logs.filter((l) => !idSet.has(l.id));
    const deletedCount = initialCount - this.logs.length;

    this.saveLocalLogs();
    this.notify();

    // Delete in batches from Firestore
    try {
      const chunks: string[][] = [];
      for (let i = 0; i < logIds.length; i += 400) {
        chunks.push(logIds.slice(i, i + 400));
      }

      for (const chunk of chunks) {
        const batch = writeBatch(db);
        chunk.forEach((id) => {
          batch.delete(doc(db, 'audit_logs', id));
        });
        await batch.commit().catch((err) => {
          console.warn('Batch deletion of audit logs partial error:', err);
        });
      }
    } catch (err) {
      console.warn('Failed to batch delete audit logs from Firestore:', err);
    }

    return deletedCount;
  }

  /**
   * Clear local audit log cache (Super Admin only)
   */
  clearLocalLogs(): void {
    this.logs = [];
    localStorage.removeItem(STORAGE_KEY);
    this.notify();
  }
}

export const auditService = new AuditService();
