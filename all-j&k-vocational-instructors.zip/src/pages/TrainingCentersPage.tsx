import React, { useState, useMemo } from 'react';
import { TrainingCenter, ItiAggregatedData, Division } from '../types';
import { formatCurrency, formatNumber } from '../utils/format';
import { Search, Building2, MapPin, Users, CheckCircle2, XCircle, ArrowUpDown, ChevronRight, X } from 'lucide-react';

interface TrainingCentersPageProps {
  aggregatedItis: ItiAggregatedData[];
}

export const TrainingCentersPage: React.FC<TrainingCentersPageProps> = ({ aggregatedItis }) => {
  const [divisionFilter, setDivisionFilter] = useState<'All' | Division>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Active' | 'Inactive'>('All');
  const [selectedIti, setSelectedIti] = useState<ItiAggregatedData | null>(null);

  const filteredItis = useMemo(() => {
    return aggregatedItis.filter((iti) => {
      const matchesSearch =
        iti.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        iti.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (iti.remarks && iti.remarks.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesDivision = divisionFilter === 'All' || iti.division === divisionFilter;
      const matchesStatus = statusFilter === 'All' || iti.status === statusFilter;

      return matchesSearch && matchesDivision && matchesStatus;
    });
  }, [aggregatedItis, searchTerm, divisionFilter, statusFilter]);

  const kashmirItis = useMemo(
    () => filteredItis.filter((iti) => iti.division === 'Kashmir Division'),
    [filteredItis]
  );
  const jammuItis = useMemo(
    () => filteredItis.filter((iti) => iti.division === 'Jammu Division'),
    [filteredItis]
  );

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-700"></span>
              <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
                Industrial Training Institutes • Jammu &amp; Kashmir
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-[#0F2942] uppercase tracking-tight">
              TRAINING CENTERS
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Government Industrial Training Institutes of Jammu &amp; Kashmir (Kashmir Division: ITIs 1–24 &bull; Jammu Division: ITIs 25–50)
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-blue-50 border border-blue-200 px-4 py-2 rounded-lg text-center">
              <span className="block text-xl font-black text-blue-900">{aggregatedItis.length}</span>
              <span className="text-[10px] uppercase font-bold text-blue-700">Total ITIs</span>
            </div>
            <div className="bg-emerald-50 border border-emerald-200 px-4 py-2 rounded-lg text-center">
              <span className="block text-xl font-black text-emerald-900">
                {aggregatedItis.reduce((sum, i) => sum + i.calculatedInstructorCount, 0)}
              </span>
              <span className="text-[10px] uppercase font-bold text-emerald-700">Instructors</span>
            </div>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="mt-6 pt-6 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
          {/* Division Switcher Tabs */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg text-xs font-bold">
            <button
              type="button"
              id="tc-tab-all"
              onClick={() => setDivisionFilter('All')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                divisionFilter === 'All'
                  ? 'bg-[#0F2942] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Divisions ({aggregatedItis.length})
            </button>
            <button
              type="button"
              id="tc-tab-kashmir"
              onClick={() => setDivisionFilter('Kashmir Division')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                divisionFilter === 'Kashmir Division'
                  ? 'bg-blue-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-blue-900'
              }`}
            >
              Kashmir Division (ITIs 1–24)
            </button>
            <button
              type="button"
              id="tc-tab-jammu"
              onClick={() => setDivisionFilter('Jammu Division')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                divisionFilter === 'Jammu Division'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-emerald-900'
              }`}
            >
              Jammu Division (ITIs 25–50)
            </button>
          </div>

          {/* Search and Status Filters */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative min-w-[240px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                id="tc-search-input"
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search ITI name or location..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-800"
              />
            </div>

            <select
              id="tc-status-select"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-700 focus:outline-hidden"
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active Only</option>
              <option value="Inactive">Inactive Only</option>
            </select>
          </div>
        </div>
      </div>

      {/* When "All" or "Kashmir Division" is selected */}
      {(divisionFilter === 'All' || divisionFilter === 'Kashmir Division') && (
        <section className="space-y-4">
          <div className="flex items-center justify-between border-b border-blue-200 pb-2">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-blue-700"></span>
              <h3 className="text-base sm:text-lg font-black text-blue-950 uppercase tracking-wide">
                KASHMIR DIVISION (ITIs 1–24)
              </h3>
            </div>
            <span className="text-xs font-bold text-blue-800 bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded-full">
              {kashmirItis.length} ITIs listed
            </span>
          </div>

          <ItiTableComponent itis={kashmirItis} onSelect={(iti) => setSelectedIti(iti)} />
        </section>
      )}

      {/* When "All" or "Jammu Division" is selected */}
      {(divisionFilter === 'All' || divisionFilter === 'Jammu Division') && (
        <section className="space-y-4 pt-4">
          <div className="flex items-center justify-between border-b border-emerald-200 pb-2">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-700"></span>
              <h3 className="text-base sm:text-lg font-black text-emerald-950 uppercase tracking-wide">
                JAMMU DIVISION (ITIs 25–50)
              </h3>
            </div>
            <span className="text-xs font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full">
              {jammuItis.length} ITIs listed
            </span>
          </div>

          <ItiTableComponent itis={jammuItis} onSelect={(iti) => setSelectedIti(iti)} />
        </section>
      )}

      {/* ITI Detail Modal */}
      {selectedIti && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden animate-scaleUp">
            <div className="bg-[#0F2942] text-white p-5 flex items-start justify-between">
              <div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500 text-slate-950 uppercase">
                  S.No #{selectedIti.sNo} &bull; {selectedIti.division}
                </span>
                <h3 className="text-lg font-extrabold text-white mt-1.5">
                  {selectedIti.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedIti(null)}
                className="p-1 rounded text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs sm:text-sm text-slate-700">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                  <span className="text-[11px] text-slate-500 uppercase font-bold block">Status</span>
                  <span
                    className={`inline-block mt-1 px-2 py-0.5 rounded text-xs font-bold ${
                      selectedIti.status === 'Active'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {selectedIti.status}
                  </span>
                </div>
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                  <span className="text-[11px] text-slate-500 uppercase font-bold block">
                    Skill Development Employees
                  </span>
                  <span className="text-base font-black text-[#0F2942] mt-1 block">
                    {selectedIti.calculatedInstructorCount} Employees
                  </span>
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
                <div>
                  <span className="font-bold text-slate-900">Location / Address:</span>
                  <p className="text-slate-600 mt-0.5">{selectedIti.location || 'Not Available'}</p>
                </div>
                <div>
                  <span className="font-bold text-slate-900">Total Contribution Recorded:</span>
                  <p className="text-emerald-700 font-bold font-mono text-sm mt-0.5">
                    {formatCurrency(selectedIti.totalContribution)}
                  </p>
                </div>
                <div>
                  <span className="font-bold text-slate-900">Remarks:</span>
                  <p className="text-slate-600 mt-0.5">{selectedIti.remarks || 'None provided'}</p>
                </div>
              </div>
            </div>

            <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedIti(null)}
                className="px-4 py-1.5 text-xs font-bold rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const ItiTableComponent: React.FC<{
  itis: ItiAggregatedData[];
  onSelect: (iti: ItiAggregatedData) => void;
}> = ({ itis, onSelect }) => {
  if (itis.length === 0) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-xs text-slate-500">
        No training centers found matching the current search parameters.
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-[#0F2942] text-slate-200 uppercase font-bold text-[11px] tracking-wider border-b border-slate-800">
              <th className="py-3 px-3.5 text-center w-16">S.No</th>
              <th className="py-3 px-4">Division</th>
              <th className="py-3 px-4 min-w-[220px]">ITI Name</th>
              <th className="py-3 px-4">Location</th>
              <th className="py-3 px-4 text-center w-36">No. of Instructors</th>
              <th className="py-3 px-4 text-center w-28">Status</th>
              <th className="py-3 px-4 text-right w-24">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {itis.map((iti, idx) => {
              const isKashmir = iti.division === 'Kashmir Division';
              return (
                <tr
                  key={iti.id}
                  className={`hover:bg-blue-50/50 transition-colors ${
                    idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/40'
                  }`}
                >
                  <td className="py-3 px-3.5 text-center font-bold text-slate-600">
                    {iti.sNo}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                        isKashmir
                          ? 'bg-blue-50 text-blue-800 border border-blue-200'
                          : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      }`}
                    >
                      {iti.division}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-900">
                    <span>{iti.name}</span>
                  </td>
                  <td className="py-3 px-4 text-slate-600">
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{iti.location || 'Not Available'}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-flex items-center justify-center px-2.5 py-1 rounded-full font-bold text-xs ${
                        iti.calculatedInstructorCount > 0
                          ? 'bg-indigo-100 text-indigo-900 border border-indigo-200'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {iti.calculatedInstructorCount}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        iti.status === 'Active'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {iti.status === 'Active' ? (
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      ) : (
                        <XCircle className="w-3 h-3 text-slate-400" />
                      )}
                      <span>{iti.status}</span>
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      type="button"
                      onClick={() => onSelect(iti)}
                      className="px-2.5 py-1 text-xs font-semibold text-blue-700 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 rounded transition-colors"
                    >
                      Details
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
