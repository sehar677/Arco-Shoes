import React, { useState, useEffect, useMemo } from 'react';
import {
  Wallet,
  Building2,
  Search,
  Filter,
  Calendar,
  Printer,
  Download,
  ArrowDownLeft,
  ArrowUpRight,
  Phone,
  MapPin,
  Building,
  Receipt,
  AlertCircle,
  FileText,
  PlusCircle,
  ShoppingBag,
} from 'lucide-react';
import { CompanyInfo, Supplier, LedgerEntry, PurchaseInvoice } from '../types';
import { dbService } from '../services/storage';
import { SupplierLedgerPrintModal, SupplierLedgerPrintRow } from './SupplierLedgerPrintModal';

interface CashLedgerProps {
  company: CompanyInfo;
  onNavigateToPayment?: (supplierId: string) => void;
  onNavigateToPurchase?: () => void;
}

interface UnregisteredSupplierSummary {
  id: string;
  supplierCode: string;
  supplierName: string;
  supplierType: 'UnRegistered';
  mobile?: string;
  city?: string;
  address?: string;
  gstin?: string;
  openingBalance: number;
  currentBalance: number;
  totalBills: number;
  totalPurchases: number;
  totalPaid: number;
  totalOutstanding: number;
  lastPurchaseDate?: string;
}

export const CashLedgerComponent: React.FC<CashLedgerProps> = ({
  company,
  onNavigateToPayment,
  onNavigateToPurchase,
}) => {
  // Financial Year Helpers
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;
  const fyStartYear = currentMonth >= 4 ? currentYear : currentYear - 1;
  const fyEndYear = fyStartYear + 1;
  const defaultFyStart = `${fyStartYear}-04-01`;
  const defaultFyEnd = `${fyEndYear}-03-31`;
  const todayStr = now.toISOString().split('T')[0];

  const [selectedSupplierId, setSelectedSupplierId] = useState<string>('');
  const [fromDate, setFromDate] = useState<string>(defaultFyStart);
  const [toDate, setToDate] = useState<string>(todayStr);
  const [voucherFilter, setVoucherFilter] = useState<string>('ALL');
  const [includePostDated, setIncludePostDated] = useState<boolean>(true);
  const [supplierSearch, setSupplierSearch] = useState<string>('');
  const [tableSearch, setTableSearch] = useState<string>('');
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);

  // Storage subscription trigger
  const [version, setVersion] = useState(0);
  useEffect(() => {
    const unsub = dbService.subscribe(() => setVersion((v) => v + 1));
    return () => unsub();
  }, []);

  // Fetch all purchases and ledgers
  const allPurchases = useMemo(() => dbService.getPurchases(), [version]);
  const allLedgers = useMemo(() => dbService.getLedgers(), [version]);
  const registeredSuppliers = useMemo(() => dbService.getSuppliers(), [version]);

  // Set of registered supplier IDs and exact names
  const registeredSupplierMap = useMemo(() => {
    const ids = new Set<string>();
    const names = new Set<string>();
    registeredSuppliers.forEach((s) => {
      if (s.id) ids.add(s.id);
      if (s.supplierName) names.add(s.supplierName.trim().toLowerCase());
    });
    return { ids, names };
  }, [registeredSuppliers]);

  // Filter purchases that belong to Unregistered suppliers
  const unregisteredPurchases = useMemo(() => {
    return allPurchases.filter((p) => {
      if (p.supplierType === 'UnRegistered') return true;
      if (p.supplierId === 'SUP-CASH' || p.supplierId === 'CASH_MANUAL' || p.supplierId?.startsWith('SUP-MANUAL')) return true;
      if (p.purchaseType === 'Cash') return true;
      // If supplierId does not match any registered supplier
      if (p.supplierId && !registeredSupplierMap.ids.has(p.supplierId) && !registeredSupplierMap.names.has((p.supplierName || '').trim().toLowerCase())) {
        return true;
      }
      return false;
    });
  }, [allPurchases, registeredSupplierMap]);

  // Extract distinct Unregistered Suppliers
  const unregisteredSuppliers = useMemo<UnregisteredSupplierSummary[]>(() => {
    const supplierGroup: { [nameKey: string]: { purchases: PurchaseInvoice[]; latest: PurchaseInvoice } } = {};

    unregisteredPurchases.forEach((p) => {
      const cleanName = (p.supplierName || 'Cash Supplier (Unregistered)').trim();
      const nameKey = cleanName.toLowerCase();
      if (!supplierGroup[nameKey]) {
        supplierGroup[nameKey] = { purchases: [], latest: p };
      }
      supplierGroup[nameKey].purchases.push(p);
      if (p.purchaseDate >= supplierGroup[nameKey].latest.purchaseDate) {
        supplierGroup[nameKey].latest = p;
      }
    });

    return Object.keys(supplierGroup).map((key, idx) => {
      const group = supplierGroup[key];
      const name = group.latest.supplierName?.trim() || 'Cash Supplier';
      const totalPurchases = group.purchases.reduce((sum, p) => sum + (Number(p.grandTotal) || 0), 0);
      const totalPaid = group.purchases.reduce((sum, p) => sum + (Number(p.amountPaid) || 0), 0);
      const totalOutstanding = group.purchases.reduce((sum, p) => sum + (Number(p.balanceDue) || 0), 0);

      // Check for custom manual payments in ledgers for this supplier
      const matchingLedgers = allLedgers.filter(
        (l) =>
          l.partyType === 'Supplier' &&
          (l.partyId === group.latest.supplierId || l.partyName?.trim().toLowerCase() === key)
      );

      const extraPayments = matchingLedgers
        .filter((l) => l.voucherType === 'Payment')
        .reduce((sum, l) => sum + (Number(l.debit) || 0), 0);

      const computedBalance = Math.max(0, totalPurchases - (totalPaid + extraPayments));

      const id = group.latest.supplierId && group.latest.supplierId !== 'SUP-CASH' && group.latest.supplierId !== 'CASH_MANUAL'
        ? group.latest.supplierId
        : `UNREG-${encodeURIComponent(key)}`;

      return {
        id,
        supplierCode: `UNREG-${(idx + 1).toString().padStart(3, '0')}`,
        supplierName: name,
        supplierType: 'UnRegistered',
        mobile: (group.latest as any).supplierPhone || (group.latest as any).mobile || '',
        city: (group.latest as any).supplierCity || (group.latest as any).city || '',
        address: (group.latest as any).supplierAddress || (group.latest as any).address || '',
        gstin: 'Unregistered',
        openingBalance: 0,
        currentBalance: computedBalance,
        totalBills: group.purchases.length,
        totalPurchases,
        totalPaid: totalPaid + extraPayments,
        totalOutstanding: computedBalance,
        lastPurchaseDate: group.latest.purchaseDate,
      };
    });
  }, [unregisteredPurchases, allLedgers]);

  // Filtered Unregistered Suppliers for dropdown and search
  const filteredSuppliers = useMemo(() => {
    if (!supplierSearch.trim()) return unregisteredSuppliers;
    const q = supplierSearch.toLowerCase();
    return unregisteredSuppliers.filter(
      (s) =>
        s.supplierName.toLowerCase().includes(q) ||
        (s.mobile && s.mobile.toLowerCase().includes(q)) ||
        (s.city && s.city.toLowerCase().includes(q))
    );
  }, [unregisteredSuppliers, supplierSearch]);

  // Determine active selected supplier object (supports specific or ALL)
  const isAllSelected = selectedSupplierId === 'ALL_UNREGISTERED';
  const selectedSupplierSummary = useMemo(() => {
    if (isAllSelected) {
      const totalPurchases = unregisteredSuppliers.reduce((sum, s) => sum + s.totalPurchases, 0);
      const totalPaid = unregisteredSuppliers.reduce((sum, s) => sum + s.totalPaid, 0);
      const totalOutstanding = unregisteredSuppliers.reduce((sum, s) => sum + s.totalOutstanding, 0);
      const totalBills = unregisteredSuppliers.reduce((sum, s) => sum + s.totalBills, 0);

      return {
        id: 'ALL_UNREGISTERED',
        supplierCode: 'UNREG-ALL',
        supplierName: 'All Unregistered Suppliers (Combined)',
        supplierType: 'UnRegistered' as const,
        mobile: 'Multiple',
        city: 'Showroom Consolidated',
        address: 'Cash Purchases Register',
        gstin: 'Unregistered',
        openingBalance: 0,
        currentBalance: totalOutstanding,
        totalBills,
        totalPurchases,
        totalPaid,
        totalOutstanding,
      };
    }
    return unregisteredSuppliers.find((s) => s.id === selectedSupplierId) || null;
  }, [unregisteredSuppliers, selectedSupplierId, isAllSelected]);

  // Convert summary to Supplier type for Print Modal
  const activeSupplierForModal: Supplier | null = useMemo(() => {
    if (!selectedSupplierSummary) return null;
    return {
      id: selectedSupplierSummary.id,
      supplierCode: selectedSupplierSummary.supplierCode,
      supplierName: selectedSupplierSummary.supplierName,
      supplierType: 'UnRegistered',
      mobile: selectedSupplierSummary.mobile || '',
      city: selectedSupplierSummary.city || '',
      address: selectedSupplierSummary.address || '',
      state: company.state || 'Maharashtra',
      stateCode: company.stateCode || '27',
      gstin: 'Unregistered',
      openingBalance: 0,
      currentBalance: selectedSupplierSummary.currentBalance,
      paymentTermsDays: 0,
      isActive: true,
      createdAt: defaultFyStart,
    };
  }, [selectedSupplierSummary, defaultFyStart, company.state, company.stateCode]);

  // Fetch all transactions for the selected unregistered supplier(s)
  const relevantTransactions = useMemo(() => {
    if (!selectedSupplierSummary) return [];

    let entries: Array<{
      id: string;
      date: string;
      voucherType: string;
      voucherNo: string;
      narration?: string;
      debit: number;
      credit: number;
      isPostDated?: boolean;
      supplierName: string;
      paymentMode?: string;
    }> = [];

    // Filter purchases
    const targetPurchases = isAllSelected
      ? unregisteredPurchases
      : unregisteredPurchases.filter((p) => {
          const cleanName = (p.supplierName || '').trim().toLowerCase();
          const targetName = selectedSupplierSummary.supplierName.trim().toLowerCase();
          return (
            cleanName === targetName ||
            p.supplierId === selectedSupplierSummary.id ||
            `UNREG-${encodeURIComponent(cleanName)}` === selectedSupplierSummary.id
          );
        });

    targetPurchases.forEach((p) => {
      const vNo = p.purchaseNo || p.purchaseInvoiceNo || p.supplierBillNo || 'PUR-CASH';
      const itemsCount = p.items?.length || 0;
      const desc =
        itemsCount > 0
          ? `Stock Inward Cash Bill #${vNo} (${p.totalQuantity || itemsCount} items)`
          : `Direct Cash Purchase Bill #${vNo}`;

      // Credit: Purchase Invoice Amount
      entries.push({
        id: `PUR-${p.id}`,
        date: p.purchaseDate,
        voucherType: 'Purchase',
        voucherNo: vNo,
        narration: desc,
        debit: 0,
        credit: Number(p.grandTotal) || 0,
        isPostDated: p.purchaseDate > todayStr,
        supplierName: p.supplierName || 'Unregistered Vendor',
        paymentMode: p.paymentMode || 'Cash',
      });

      // Debit: Immediate Cash/Bank Payment if paid > 0
      if (Number(p.amountPaid) > 0) {
        entries.push({
          id: `PAY-${p.id}`,
          date: p.purchaseDate,
          voucherType: 'Payment',
          voucherNo: `PMT-${vNo}`,
          narration: `Paid for Inward Bill #${vNo} (${p.paymentMode || 'Cash'})`,
          debit: Number(p.amountPaid) || 0,
          credit: 0,
          isPostDated: p.purchaseDate > todayStr,
          supplierName: p.supplierName || 'Unregistered Vendor',
          paymentMode: p.paymentMode || 'Cash',
        });
      }
    });

    // Also look for standalone payment vouchers in ledgers
    const matchingLedgers = allLedgers.filter((l) => {
      if (l.partyType !== 'Supplier') return false;
      if (l.voucherType !== 'Payment' && l.voucherType !== 'Purchase Return') return false;
      if (isAllSelected) {
        return unregisteredSuppliers.some(
          (s) => s.supplierName.trim().toLowerCase() === (l.partyName || '').trim().toLowerCase()
        );
      }
      return (
        (l.partyName || '').trim().toLowerCase() === selectedSupplierSummary.supplierName.trim().toLowerCase() ||
        l.partyId === selectedSupplierSummary.id
      );
    });

    matchingLedgers.forEach((l) => {
      // Avoid duplicate if already covered by purchase amountPaid
      const isAlreadyIncluded = entries.some((e) => e.voucherNo.includes(l.voucherNo) && e.debit === l.debit);
      if (!isAlreadyIncluded) {
        entries.push({
          id: l.id,
          date: l.date,
          voucherType: l.voucherType,
          voucherNo: l.voucherNo,
          narration: l.narration || `${l.voucherType} Outward Voucher`,
          debit: Number(l.debit) || 0,
          credit: Number(l.credit) || 0,
          isPostDated: l.date > todayStr,
          supplierName: l.partyName || 'Unregistered Vendor',
        });
      }
    });

    // Sort chronologically
    entries.sort((a, b) => {
      if (a.date !== b.date) return a.date.localeCompare(b.date);
      // Purchases come before payments on same day
      if (a.voucherType === 'Purchase' && b.voucherType !== 'Purchase') return -1;
      if (a.voucherType !== 'Purchase' && b.voucherType === 'Purchase') return 1;
      return a.id.localeCompare(b.id);
    });

    return entries;
  }, [
    selectedSupplierSummary,
    isAllSelected,
    unregisteredPurchases,
    allLedgers,
    unregisteredSuppliers,
    todayStr,
  ]);

  // Compute Opening Balance before fromDate
  const openingBalance = useMemo(() => {
    if (!selectedSupplierSummary) return 0;
    const priorEntries = relevantTransactions.filter((e) => e.date < fromDate);
    const priorCredits = priorEntries.reduce((sum, e) => sum + e.credit, 0);
    const priorDebits = priorEntries.reduce((sum, e) => sum + e.debit, 0);
    return priorCredits - priorDebits;
  }, [relevantTransactions, fromDate, selectedSupplierSummary]);

  // Period entries filtered by date and voucher type
  const periodEntries = useMemo(() => {
    return relevantTransactions.filter((e) => {
      if (e.date < fromDate || e.date > toDate) return false;
      if (voucherFilter !== 'ALL') {
        if (voucherFilter === 'Purchase' && e.voucherType !== 'Purchase') return false;
        if (voucherFilter === 'Payment' && e.voucherType !== 'Payment') return false;
        if (voucherFilter === 'Purchase Return' && e.voucherType !== 'Purchase Return') return false;
      }
      if (tableSearch.trim()) {
        const q = tableSearch.toLowerCase();
        const matches =
          e.voucherNo.toLowerCase().includes(q) ||
          (e.narration && e.narration.toLowerCase().includes(q)) ||
          e.supplierName.toLowerCase().includes(q) ||
          e.date.includes(q);
        if (!matches) return false;
      }
      return true;
    });
  }, [relevantTransactions, fromDate, toDate, includePostDated, voucherFilter, tableSearch]);

  // Calculate Running Balances
  const rowsWithBalance: SupplierLedgerPrintRow[] = useMemo(() => {
    let current = openingBalance;
    return periodEntries.map((e) => {
      // Credit increases payable (Vendor account is Credited on purchase), Debit decreases payable (Vendor debited on payment)
      current = current + e.credit - e.debit;
      return {
        id: e.id,
        date: e.date,
        voucherType: e.voucherType,
        voucherNo: e.voucherNo,
        narration: e.narration,
        debit: e.debit,
        credit: e.credit,
        calculatedBalance: current,
        isPostDated: e.isPostDated,
      } as any;
    });
  }, [periodEntries, openingBalance]);

  // Period Totals
  const periodTotalDebit = useMemo(
    () => periodEntries.reduce((sum, e) => sum + e.debit, 0),
    [periodEntries]
  );
  const periodTotalCredit = useMemo(
    () => periodEntries.reduce((sum, e) => sum + e.credit, 0),
    [periodEntries]
  );
  const closingBalance = openingBalance + periodTotalCredit - periodTotalDebit;

  const postDatedEntries = useMemo(() => {
    return periodEntries.filter((e) => e.isPostDated);
  }, [periodEntries]);

  // Export to CSV
  const handleExportCSV = () => {
    if (!selectedSupplierSummary) return;

    const headers = [
      'Date',
      'Voucher Type',
      'Voucher No / Bill Ref',
      'Unregistered Supplier',
      'Particulars / Narration',
      'Debit / Paid (INR)',
      'Credit / Inward (INR)',
      'Running Balance (INR)',
    ];

    const csvRows = [
      [`${company.companyName} - Cash Ledger Statement`],
      [`Unregistered Supplier: ${selectedSupplierSummary.supplierName}`],
      [`Period: ${fromDate} to ${toDate}`],
      [`Opening Balance: ${openingBalance.toFixed(2)}`],
      [],
      headers,
    ];

    rowsWithBalance.forEach((r: any) => {
      csvRows.push([
        r.date,
        r.voucherType,
        r.voucherNo,
        selectedSupplierSummary.supplierName,
        `"${(r.narration || '').replace(/"/g, '""')}"`,
        r.debit.toFixed(2),
        r.credit.toFixed(2),
        `${Math.abs(r.calculatedBalance).toFixed(2)} ${r.calculatedBalance >= 0 ? 'Cr' : 'Dr'}`,
      ]);
    });

    csvRows.push([]);
    csvRows.push([
      'Totals',
      '',
      '',
      '',
      '',
      periodTotalDebit.toFixed(2),
      periodTotalCredit.toFixed(2),
      `${Math.abs(closingBalance).toFixed(2)} ${closingBalance >= 0 ? 'Cr' : 'Dr'}`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + csvRows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `Cash_Ledger_${selectedSupplierSummary.supplierName.replace(/\s+/g, '_')}_${fromDate}_to_${toDate}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto pb-12 animate-fadeIn">
      {/* Top Header Card */}
      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shadow-inner">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-base sm:text-lg text-slate-100">Cash Ledger</h2>
              <span className="text-xs font-mono bg-amber-950 text-amber-300 px-2 py-0.5 rounded border border-amber-800/60">
                Unregistered Vendor Khata
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Statement of Cash Purchases, Unregistered Suppliers Stock Inward, Payments & Outstanding Balances
            </p>
          </div>
        </div>

        {/* Global Controls & Actions */}
        <div className="flex flex-wrap items-center gap-2">
          {onNavigateToPurchase && (
            <button
              onClick={onNavigateToPurchase}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg shadow-sm border border-emerald-500/30 text-xs transition cursor-pointer"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Stock Purchase</span>
            </button>
          )}

          {onNavigateToPayment && (
            <button
              onClick={() => selectedSupplierId && onNavigateToPayment(selectedSupplierId)}
              disabled={!selectedSupplierId || isAllSelected}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-lg shadow-sm border border-rose-500/30 text-xs transition cursor-pointer"
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>Record Payment</span>
            </button>
          )}

          <button
            onClick={() => setShowPrintModal(true)}
            disabled={!selectedSupplierSummary}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/80 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed text-slate-200 border border-slate-700/60 rounded-lg text-xs font-semibold backdrop-blur-sm transition cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-amber-400" />
            <span>Print Statement</span>
          </button>

          <button
            onClick={handleExportCSV}
            disabled={!selectedSupplierSummary}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/80 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed text-slate-200 border border-slate-700/60 rounded-lg text-xs font-semibold backdrop-blur-sm transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Filter & Selection Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Unregistered Supplier Select / Search Card */}
        <div className="lg:col-span-5 bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md space-y-2.5">
          <div className="flex items-center justify-between">
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              SELECT UNREGISTERED SUPPLIER
            </label>
            <span className="text-[10px] text-amber-400 font-mono">
              {unregisteredSuppliers.length} Unregistered Vendor{unregisteredSuppliers.length !== 1 ? 's' : ''}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedSupplierId}
              onChange={(e) => setSelectedSupplierId(e.target.value)}
              className="flex-1 bg-slate-950/80 border border-slate-700/60 rounded-lg px-2.5 py-2 text-slate-100 font-semibold focus:border-amber-500 focus:outline-none text-xs"
            >
              <option value="">--Select UnRegistered Suppliers--</option>
              {unregisteredSuppliers.length > 0 && (
                <option value="ALL_UNREGISTERED">⚡ All Unregistered Suppliers (Consolidated)</option>
              )}
              {unregisteredSuppliers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.supplierName}
                </option>
              ))}
            </select>
          </div>

          {/* Search filter for fast locating */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search unregistered supplier name or phone..."
              value={supplierSearch}
              onChange={(e) => setSupplierSearch(e.target.value)}
              className="w-full bg-slate-950/60 border border-slate-700/50 rounded-lg pl-8 pr-2.5 py-1.5 text-xs text-slate-200 focus:border-amber-500 focus:outline-none"
            />
          </div>

          {supplierSearch.trim() && (
            <div className="max-h-36 overflow-y-auto space-y-1 pr-1">
              {filteredSuppliers.map((s) => (
                <button
                  key={s.id}
                  onClick={() => {
                    setSelectedSupplierId(s.id);
                    setSupplierSearch('');
                  }}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition cursor-pointer ${
                    selectedSupplierId === s.id
                      ? 'bg-amber-600/30 text-amber-200 border border-amber-500/40'
                      : 'bg-slate-950/40 text-slate-300 hover:bg-slate-800/50'
                  }`}
                >
                  <span className="font-semibold truncate">{s.supplierName}</span>
                  <span className="font-mono text-[11px] text-amber-400">₹{s.currentBalance.toFixed(2)}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Date Filter & Voucher Type Filter */}
        <div className="lg:col-span-7 bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md flex flex-col justify-between gap-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Date & Voucher Filter
            </span>
            <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
              <button
                onClick={() => {
                  const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
                  const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0];
                  setFromDate(firstDay);
                  setToDate(lastDay);
                }}
                className="px-2 py-0.5 rounded bg-slate-800/60 hover:bg-slate-700 text-slate-300 border border-slate-700/50 transition cursor-pointer"
              >
                This Month
              </button>
              <button
                onClick={() => {
                  setFromDate(defaultFyStart);
                  setToDate(defaultFyEnd);
                }}
                className="px-2 py-0.5 rounded bg-amber-900/50 hover:bg-amber-800/60 text-amber-200 border border-amber-700/60 transition font-semibold cursor-pointer"
              >
                FY {fyStartYear.toString().slice(-2)}-{fyEndYear.toString().slice(-2)} (Full Year)
              </button>
              <button
                onClick={() => {
                  setFromDate(defaultFyStart);
                  setToDate(todayStr);
                }}
                className="px-2 py-0.5 rounded bg-slate-800/60 hover:bg-slate-700 text-slate-300 border border-slate-700/50 transition cursor-pointer"
              >
                Up to Today
              </button>
              <button
                onClick={() => {
                  setFromDate('2020-01-01');
                  setToDate('2030-12-31');
                }}
                className="px-2 py-0.5 rounded bg-slate-800/60 hover:bg-slate-700 text-slate-300 border border-slate-700/50 transition cursor-pointer"
              >
                All Time / Lifetime
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
            <div className="flex items-center gap-1.5 bg-slate-950/70 px-2.5 py-1.5 rounded-lg border border-slate-700/60">
              <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="text-slate-400">From:</span>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="w-full bg-transparent text-slate-200 font-mono focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5 bg-slate-950/70 px-2.5 py-1.5 rounded-lg border border-slate-700/60">
              <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="text-slate-400">To:</span>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="w-full bg-transparent text-slate-200 font-mono focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5 bg-slate-950/70 px-2 py-1 rounded-lg border border-slate-700/60">
              <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <select
                value={voucherFilter}
                onChange={(e) => setVoucherFilter(e.target.value)}
                className="w-full bg-transparent text-slate-200 focus:outline-none text-xs font-semibold"
              >
                <option value="ALL">All Vouchers</option>
                <option value="Purchase">Purchases Only</option>
                <option value="Payment">Payments Only</option>
                <option value="Purchase Return">Returns Only</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Unregistered Supplier Info Card & Metric Summary */}
      {selectedSupplierSummary && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Party Snapshot */}
          <div className="md:col-span-4 bg-slate-900/30 border border-slate-700/50 rounded-xl p-3.5 backdrop-blur-sm space-y-1.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-sm text-slate-100">{selectedSupplierSummary.supplierName}</span>
              <span className="font-mono text-[11px] text-amber-400 bg-amber-950/80 px-1.5 py-0.2 rounded border border-amber-800/50">
                {selectedSupplierSummary.supplierCode}
              </span>
            </div>
            <p className="text-slate-400 flex items-center gap-1.5">
              <Phone className="w-3 h-3 text-slate-500" />
              <span>Phone: <strong className="text-slate-200 font-mono">{selectedSupplierSummary.mobile || 'Cash Supplier'}</strong></span>
            </p>
            <p className="text-slate-400 flex items-center gap-1.5">
              <MapPin className="w-3 h-3 text-slate-500" />
              <span>Location: <strong className="text-slate-200">{selectedSupplierSummary.city || 'Local / Cash Purchase'}</strong></span>
            </p>
            <p className="text-slate-400 flex items-center gap-1.5">
              <Building className="w-3 h-3 text-slate-500" />
              <span>Type: <strong className="text-amber-300 font-mono">Unregistered Supplier</strong></span>
            </p>
            <p className="text-slate-400 flex items-center gap-1.5">
              <ShoppingBag className="w-3 h-3 text-slate-500" />
              <span>Total Inward Bills: <strong className="text-slate-200 font-mono">{selectedSupplierSummary.totalBills} Bills</strong></span>
            </p>
          </div>

          {/* Metric KPI cards */}
          <div className="md:col-span-8 grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono">
            <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3 shadow-xl backdrop-blur-md">
              <span className="text-slate-400 block text-[10px] uppercase tracking-wider">Opening Balance</span>
              <span className="text-base font-bold text-slate-200 mt-1 block">
                ₹{Math.abs(openingBalance).toFixed(2)}
                <span className="text-[10px] ml-1 text-slate-400">{openingBalance >= 0 ? 'Cr' : 'Dr'}</span>
              </span>
            </div>

            <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3 shadow-xl backdrop-blur-md">
              <span className="text-slate-400 block text-[10px] uppercase tracking-wider flex items-center gap-1 text-amber-400">
                <ArrowDownLeft className="w-3 h-3" />
                <span>Period Purchases</span>
              </span>
              <span className="text-base font-bold text-amber-400 mt-1 block">
                ₹{periodTotalCredit.toFixed(2)}
              </span>
            </div>

            <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3 shadow-xl backdrop-blur-md">
              <div className="flex items-center justify-between text-slate-400 text-[10px] uppercase tracking-wider">
                <span className="flex items-center gap-1 text-rose-400">
                  <ArrowUpRight className="w-3 h-3" />
                  <span>Period Debits (Paid)</span>
                </span>
                {postDatedEntries.length > 0 && (
                  <span className="text-[9px] font-semibold bg-amber-950 text-amber-300 border border-amber-800/80 px-1.5 py-0.2 rounded font-sans">
                    {postDatedEntries.length} Post-Dated
                  </span>
                )}
              </div>
              <span className="text-base font-bold text-rose-400 mt-1 block">
                ₹{periodTotalDebit.toFixed(2)}
              </span>
            </div>

            <div
              className={`border rounded-xl p-3 shadow-xl backdrop-blur-md ${
                closingBalance > 0
                  ? 'bg-rose-950/30 border-rose-800/50'
                  : 'bg-emerald-950/30 border-emerald-800/50'
              }`}
            >
              <span className="block text-[10px] uppercase tracking-wider font-bold text-amber-400">
                Closing Balance Due
              </span>
              <span
                className={`text-lg font-black mt-1 block ${
                  closingBalance > 0 ? 'text-rose-300' : 'text-emerald-300'
                }`}
              >
                ₹{Math.abs(closingBalance).toFixed(2)}
                <span className="text-xs ml-1 font-bold">
                  {closingBalance > 0 ? 'Cr (Payable Due)' : closingBalance < 0 ? 'Dr (Advance)' : 'Settled (₹0.00)'}
                </span>
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Ledger Statement Table */}
      <div className="bg-slate-900/30 border border-slate-700/50 rounded-xl shadow-xl backdrop-blur-md overflow-hidden">
        <div className="p-3 bg-slate-800/40 border-b border-slate-700/50 flex flex-wrap items-center justify-between gap-2 text-xs backdrop-blur-sm">
          <div className="flex items-center gap-2">
            <span className="font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <span>Cash Ledger & Unregistered Vendor Transactions</span>
              <span className="text-slate-400 font-mono font-normal">({rowsWithBalance.length} records)</span>
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="w-3 h-3 text-slate-400 absolute left-2 top-2" />
              <input
                type="text"
                placeholder="Filter by bill no / text..."
                value={tableSearch}
                onChange={(e) => setTableSearch(e.target.value)}
                className="bg-slate-950/70 border border-slate-700/50 rounded-md pl-7 pr-2 py-1 text-[11px] text-slate-200 focus:outline-none focus:border-amber-500 w-44"
              />
            </div>
            <span className="text-[11px] text-slate-400 font-mono">
              Period: {fromDate} to {toDate}
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/60 border-b border-slate-700/60 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                <th className="p-2.5">Date</th>
                <th className="p-2.5">Voucher Type</th>
                <th className="p-2.5">Vch No / Bill Ref</th>
                {isAllSelected && <th className="p-2.5">Supplier Name</th>}
                <th className="p-2.5">Particulars / Narration</th>
                <th className="p-2.5 text-right text-rose-400">Debit / Paid (₹)</th>
                <th className="p-2.5 text-right text-amber-400">Credit / Purchase (₹)</th>
                <th className="p-2.5 text-right text-amber-300">Balance (₹)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {!selectedSupplierSummary ? (
                <tr>
                  <td colSpan={isAllSelected ? 8 : 7} className="p-12 text-center text-slate-400">
                    <div className="flex flex-col items-center justify-center gap-2.5 max-w-md mx-auto">
                      <Wallet className="w-10 h-10 text-amber-500/70" />
                      <p className="font-semibold text-slate-200 text-sm">No Unregistered Supplier Selected</p>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        Please choose an unregistered vendor from the <strong className="text-amber-400">--select Unregister Supplier--</strong> dropdown above, or choose <em>All Unregistered Suppliers</em> to view all cash stock purchase entries.
                      </p>
                      {unregisteredSuppliers.length === 0 && (
                        <div className="mt-2 p-3 rounded-lg bg-amber-950/40 border border-amber-800/50 text-[11px] text-amber-200 text-left">
                          <p className="font-bold flex items-center gap-1.5">
                            <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                            No unregistered stock purchases recorded yet.
                          </p>
                          <p className="mt-1 text-slate-300">
                            When you record a stock purchase with <strong>Supplier Type = 'UnRegistered'</strong> on the Stock Purchase page, it will automatically populate this Cash Ledger!
                          </p>
                        </div>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                <>
                  {/* Opening Balance Row */}
                  <tr className="bg-slate-900/50 font-semibold text-slate-300">
                    <td className="p-2.5 font-mono text-slate-400">{fromDate}</td>
                    <td className="p-2.5">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-mono uppercase bg-slate-800 text-slate-300 border border-slate-700">
                        B/F
                      </span>
                    </td>
                    <td className="p-2.5 font-mono text-slate-500">-</td>
                    {isAllSelected && <td className="p-2.5 text-slate-400">-</td>}
                    <td className="p-2.5 text-slate-300">Opening Balance Brought Forward</td>
                    <td className="p-2.5 text-right font-mono">-</td>
                    <td className="p-2.5 text-right font-mono">-</td>
                    <td className="p-2.5 text-right font-mono font-bold text-amber-300">
                      ₹{Math.abs(openingBalance).toFixed(2)} {openingBalance >= 0 ? 'Cr' : 'Dr'}
                    </td>
                  </tr>

                  {rowsWithBalance.length === 0 ? (
                    <tr>
                      <td colSpan={isAllSelected ? 8 : 7} className="p-8 text-center text-slate-500">
                        No transactions recorded for this unregistered supplier in the selected date range.
                      </td>
                    </tr>
                  ) : (
                    rowsWithBalance.map((row: any) => (
                      <tr key={row.id} className="hover:bg-slate-800/40 transition">
                        <td className="p-2.5 font-mono text-slate-400 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <span>{row.date}</span>
                            {row.isPostDated && (
                              <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase tracking-wider bg-amber-950 text-amber-300 border border-amber-800/80 shadow-sm">
                                Post-Dated
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="p-2.5 whitespace-nowrap">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold uppercase tracking-wider border ${
                              row.voucherType === 'Purchase'
                                ? 'bg-amber-950/80 text-amber-300 border-amber-800/60'
                                : row.voucherType === 'Payment'
                                ? 'bg-rose-950/80 text-rose-300 border-rose-800/60'
                                : row.voucherType === 'Purchase Return'
                                ? 'bg-purple-950/80 text-purple-300 border-purple-800/60'
                                : 'bg-slate-800 text-slate-300 border-slate-700'
                            }`}
                          >
                            {row.voucherType}
                          </span>
                        </td>
                        <td className="p-2.5 font-mono font-semibold text-slate-200 whitespace-nowrap">{row.voucherNo}</td>
                        {isAllSelected && (
                          <td className="p-2.5 text-slate-300 font-medium whitespace-nowrap">
                            {relevantTransactions.find((t) => t.id === row.id)?.supplierName || '-'}
                          </td>
                        )}
                        <td className="p-2.5 text-slate-300 max-w-xs sm:max-w-md truncate">{row.narration || '-'}</td>
                        <td className="p-2.5 text-right font-mono font-semibold text-rose-400 whitespace-nowrap">
                          {row.debit > 0 ? `₹${row.debit.toFixed(2)}` : '-'}
                        </td>
                        <td className="p-2.5 text-right font-mono font-semibold text-amber-400 whitespace-nowrap">
                          {row.credit > 0 ? `₹${row.credit.toFixed(2)}` : '-'}
                        </td>
                        <td className="p-2.5 text-right font-mono font-bold text-amber-300 whitespace-nowrap">
                          ₹{Math.abs(row.calculatedBalance).toFixed(2)} {row.calculatedBalance >= 0 ? 'Cr' : 'Dr'}
                        </td>
                      </tr>
                    ))
                  )}
                </>
              )}
            </tbody>
            {selectedSupplierSummary && (
              <tfoot>
                <tr className="bg-slate-950/80 font-bold border-t-2 border-slate-700 text-slate-200">
                  <td colSpan={isAllSelected ? 5 : 4} className="p-3 text-right uppercase tracking-wider text-[11px] text-slate-400">
                    Total for Period:
                  </td>
                  <td className="p-3 text-right font-mono text-rose-400">₹{periodTotalDebit.toFixed(2)}</td>
                  <td className="p-3 text-right font-mono text-amber-400">₹{periodTotalCredit.toFixed(2)}</td>
                  <td className="p-3 text-right font-mono text-amber-300">
                    ₹{Math.abs(closingBalance).toFixed(2)} {closingBalance >= 0 ? 'Cr' : 'Dr'}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      {/* Supplier Ledger Print Modal */}
      {showPrintModal && activeSupplierForModal && (
        <SupplierLedgerPrintModal
          company={company}
          supplier={activeSupplierForModal}
          fromDate={fromDate}
          toDate={toDate}
          openingBalance={openingBalance}
          rows={rowsWithBalance}
          periodTotalDebit={periodTotalDebit}
          periodTotalCredit={periodTotalCredit}
          closingBalance={closingBalance}
          onClose={() => setShowPrintModal(false)}
        />
      )}
    </div>
  );
};
