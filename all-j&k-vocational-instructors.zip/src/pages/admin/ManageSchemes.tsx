import React, { useState, useMemo } from 'react';
import { Scheme, Contribution } from '../../types';
import { addScheme, updateScheme, deleteScheme } from '../../services/db';
import { ConfirmModal } from '../../components/ConfirmModal';
import { formatCurrency, formatDate } from '../../utils/format';
import {
  Plus,
  Edit2,
  Trash2,
  Layers,
  CheckCircle2,
  Power,
  X,
  TrendingUp,
  RefreshCw,
  Check,
  Clock,
  Sparkles,
  AlertCircle,
} from 'lucide-react';

interface ManageSchemesProps {
  schemes: Scheme[];
  contributions?: Contribution[];
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const ManageSchemes: React.FC<ManageSchemesProps> = ({
  schemes,
  contributions = [],
  onNotify,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingScheme, setEditingScheme] = useState<Scheme | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [targetAmount, setTargetAmount] = useState<number>(100000);
  const [startDate, setStartDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [endDate, setEndDate] = useState('');
  const [status, setStatus] = useState<
    'Active' | 'Completed' | 'Pending' | 'Upcoming' | 'Inactive'
  >('Active');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Delete modal state
  const [deleteTarget, setDeleteTarget] = useState<Scheme | null>(null);

  // Scheme contributions aggregate map
  const schemeAggregates = useMemo(() => {
    const map = new Map<string, { total: number; count: number }>();
    schemes.forEach((s) => map.set(s.id, { total: 0, count: 0 }));

    contributions.forEach((c) => {
      const existing = map.get(c.schemeId);
      if (existing) {
        existing.total += c.amount || 0;
        existing.count += 1;
      }
    });
    return map;
  }, [schemes, contributions]);

  const handleOpenAdd = () => {
    setEditingScheme(null);
    setName('');
    setDescription('');
    setTargetAmount(250000);
    setStartDate(new Date().toISOString().split('T')[0]);
    setEndDate('');
    setStatus('Active');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (s: Scheme) => {
    setEditingScheme(s);
    setName(s.name);
    setDescription(s.description || '');
    setTargetAmount(s.targetAmount || 0);
    setStartDate(s.startDate || new Date().toISOString().split('T')[0]);
    setEndDate(s.endDate || '');
    setStatus(s.status);
    setIsModalOpen(true);
  };

  const handleToggleStatus = async (s: Scheme) => {
    const nextStatus = s.status === 'Active' ? 'Pending' : 'Active';
    try {
      await updateScheme(s.id, { status: nextStatus });
      onNotify('info', `Event "${s.name}" is now ${nextStatus} in database.`);
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to update event status.');
    }
  };

  const handleDirectStatusChange = async (
    schemeId: string,
    newStatus: Scheme['status'],
    schemeName: string
  ) => {
    try {
      await updateScheme(schemeId, { status: newStatus });
      onNotify('success', `Event "${schemeName}" status updated to ${newStatus} in database.`);
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to update event status.');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      onNotify('error', 'Event name is required');
      return;
    }
    if (targetAmount < 0) {
      onNotify('error', 'Target amount cannot be negative');
      return;
    }

    setIsSubmitting(true);
    try {
      if (editingScheme) {
        await updateScheme(editingScheme.id, {
          name: name.trim(),
          description: description.trim(),
          targetAmount: Number(targetAmount),
          startDate,
          endDate: endDate || undefined,
          status,
        });
        onNotify('success', `Event "${name}" updated successfully.`);
      } else {
        await addScheme({
          name: name.trim(),
          description: description.trim(),
          targetAmount: Number(targetAmount),
          startDate,
          endDate: endDate || undefined,
          status,
        });
        onNotify('success', `New event "${name}" created.`);
      }
      setIsModalOpen(false);
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to save event.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteScheme(deleteTarget.id);
      onNotify('success', `Deleted event "${deleteTarget.name}" and all associated contributions.`);
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to delete event.');
    } finally {
      setDeleteTarget(null);
    }
  };

  const renderStatusBadge = (status: Scheme['status']) => {
    switch (status) {
      case 'Active':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
            <span>ACTIVE</span>
          </span>
        );
      case 'Completed':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-blue-100 text-blue-800 border border-blue-200">
            <Check className="w-3 h-3 text-blue-700" />
            <span>COMPLETED</span>
          </span>
        );
      case 'Pending':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-800 border border-amber-200">
            <Clock className="w-3 h-3 text-amber-700" />
            <span>PENDING</span>
          </span>
        );
      case 'Upcoming':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-purple-100 text-purple-800 border border-purple-200">
            <Sparkles className="w-3 h-3 text-purple-700" />
            <span>UPCOMING</span>
          </span>
        );
      case 'Inactive':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-700 border border-slate-300">
            <span>INACTIVE</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-black text-[#0F2942] uppercase tracking-wide">
            MANAGE EVENTS
          </h2>
          <p className="text-xs text-slate-500">
            Define events, allocate targets, set deadlines, and monitor real-time collection progress in database
          </p>
        </div>

        <button
          type="button"
          id="admin-add-scheme-btn"
          onClick={handleOpenAdd}
          className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>CREATE NEW EVENT</span>
        </button>
      </div>

      {/* Events Grid */}
      {schemes.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center shadow-xs">
          <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3 text-slate-400">
            <Layers className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-700">No events found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Get started by creating your first event to allocate fund collection targets and track remittances.
          </p>
          <button
            type="button"
            onClick={handleOpenAdd}
            className="mt-4 px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs uppercase tracking-wider inline-flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>CREATE FIRST EVENT</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {schemes.map((s) => {
            const isActive = s.status === 'Active';
            const agg = schemeAggregates.get(s.id);
            const collected = agg ? agg.total : 0;
            const count = agg ? agg.count : 0;
            const percent =
              s.targetAmount > 0
                ? Math.min(100, (collected / s.targetAmount) * 100)
                : 0;
            const isTargetAchieved = collected >= s.targetAmount && s.targetAmount > 0;

            return (
              <div
                key={s.id}
                className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between space-y-4 hover:border-amber-400 transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      {renderStatusBadge(s.status)}
                      {isTargetAchieved && s.status !== 'Completed' && (
                        <span className="text-[10px] font-black text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded">
                          Target Met
                        </span>
                      )}
                    </div>

                    <select
                      value={s.status}
                      onChange={(e) =>
                        handleDirectStatusChange(
                          s.id,
                          e.target.value as Scheme['status'],
                          s.name
                        )
                      }
                      className="text-[11px] bg-slate-50 border border-slate-300 rounded px-1.5 py-0.5 font-bold text-slate-700 hover:border-amber-500 focus:outline-hidden"
                      title="Change event status in database"
                    >
                      <option value="Active">Active</option>
                      <option value="Completed">Completed</option>
                      <option value="Pending">Pending</option>
                      <option value="Upcoming">Upcoming</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>

                  <h3 className="text-sm sm:text-base font-bold text-[#0F2942] mt-2">
                    {s.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                    {s.description || 'No description provided.'}
                  </p>

                  {/* Progress bar and metrics */}
                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Collected in DB:</span>
                      <span className="font-mono font-bold text-emerald-700">
                        {formatCurrency(collected)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Target Amount:</span>
                      <span className="font-mono font-bold text-slate-900">
                        {formatCurrency(s.targetAmount)}
                      </span>
                    </div>

                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          percent >= 100
                            ? 'bg-blue-600'
                            : percent >= 50
                            ? 'bg-emerald-600'
                            : 'bg-amber-500'
                        }`}
                        style={{ width: `${percent}%` }}
                      ></div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-500">
                      <span>{percent.toFixed(1)}% Realized</span>
                      <span>{count} Remittances</span>
                    </div>

                    <div className="flex items-center justify-between pt-1 text-[11px]">
                      <span className="text-slate-500">Period:</span>
                      <span className="font-mono text-slate-600">
                        {formatDate(s.startDate)} {s.endDate ? `to ${formatDate(s.endDate)}` : ''}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(s)}
                    className="px-3 py-1.5 rounded-md text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 transition-colors flex items-center gap-1"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Edit</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleteTarget(s)}
                    className="px-3 py-1.5 rounded-md text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 transition-colors flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden animate-scaleUp">
            <div className="bg-[#0F2942] text-white p-5 flex items-center justify-between">
              <h3 className="text-base font-bold uppercase">
                {editingScheme ? 'EDIT EVENT' : 'CREATE NEW EVENT'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Event Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Annual Skill Exhibition & Welfare Drive"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Details about event purpose and targets..."
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800"
                ></textarea>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Target Amount (₹) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    required
                    value={targetAmount}
                    onChange={(e) => setTargetAmount(Number(e.target.value))}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono font-bold text-emerald-800"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Status *
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 font-bold"
                  >
                    <option value="Active">Active</option>
                    <option value="Completed">Completed</option>
                    <option value="Pending">Pending</option>
                    <option value="Upcoming">Upcoming</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Start Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    End Date (Optional)
                  </label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving...' : editingScheme ? 'Update Event' : 'Create Event'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={!!deleteTarget}
        title="Confirm Event Deletion"
        message={`Are you sure you want to delete event "${deleteTarget?.name}"? All associated contribution records for this event will also be permanently deleted from the database.`}
        confirmText="Yes, Delete Event"
        cancelText="Cancel"
        isDanger={true}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};
