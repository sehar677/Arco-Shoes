import React, { useState } from 'react';
import {
  TrainingCenter,
  Instructor,
  Scheme,
  Contribution,
  ItiAggregatedData,
} from '../../types';
import { formatCurrency, formatNumber } from '../../utils/format';
import { FileDown, Printer, BarChart3, Building2, Layers, Users } from 'lucide-react';

interface AdminReportsProps {
  aggregatedItis: ItiAggregatedData[];
  schemes: Scheme[];
  contributions: Contribution[];
  instructors: Instructor[];
}

type ReportType = 'iti-contribution' | 'scheme-report' | 'instructor-distribution';

export const AdminReports: React.FC<AdminReportsProps> = ({
  aggregatedItis,
  schemes,
  contributions,
  instructors,
}) => {
  const [activeReport, setActiveReport] = useState<ReportType>('iti-contribution');

  // Calculate Scheme Report Metrics
  const schemeReportData = schemes.map((s) => {
    const schemeContribs = contributions.filter((c) => c.schemeId === s.id);
    const totalCollected = schemeContribs.reduce((sum, c) => sum + (c.amount || 0), 0);
    const balance = Math.max(0, (s.targetAmount || 0) - totalCollected);
    const progress =
      s.targetAmount > 0
        ? Math.min(100, (totalCollected / s.targetAmount) * 100).toFixed(1)
        : '0.0';
    return {
      ...s,
      totalCollected,
      balance,
      progress,
    };
  });

  // Calculate Instructor Distribution Metrics
  const instructorDistData = aggregatedItis.map((iti) => {
    const activeInstructors = instructors.filter(
      (inst) => inst.itiId === iti.id && inst.status === 'Active'
    );
    const totalInstructors = instructors.filter((inst) => inst.itiId === iti.id);
    return {
      sNo: iti.sNo,
      name: iti.name,
      division: iti.division,
      activeCount: activeInstructors.length,
      totalCount: totalInstructors.length,
    };
  });

  // Export CSV Helper
  const handleExportCsv = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';

    if (activeReport === 'iti-contribution') {
      csvContent += 'S.No,Division,ITI Name,Instructors,Total Contribution (INR),Last Contribution Date\n';
      aggregatedItis.forEach((i) => {
        csvContent += `${i.sNo},"${i.division}","${i.name}",${i.calculatedInstructorCount},${i.totalContribution},"${i.lastContributionDate || ''}"\n`;
      });
    } else if (activeReport === 'scheme-report') {
      csvContent += 'Scheme Name,Target Amount (INR),Total Collection (INR),Balance (INR),Progress (%)\n';
      schemeReportData.forEach((s) => {
        csvContent += `"${s.name}",${s.targetAmount},${s.totalCollected},${s.balance},${s.progress}%\n`;
      });
    } else if (activeReport === 'instructor-distribution') {
      csvContent += 'S.No,Division,ITI Name,Active Instructors,Total Instructors\n';
      instructorDistData.forEach((d) => {
        csvContent += `${d.sNo},"${d.division}","${d.name}",${d.activeCount},${d.totalCount}\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `JK_ITI_${activeReport}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden">
        <div>
          <h2 className="text-lg font-black text-[#0F2942] uppercase tracking-wide">
            STATISTICAL &amp; ADMINISTRATIVE REPORTS
          </h2>
          <p className="text-xs text-slate-500">
            Export official government summaries, scheme realization statements, and staffing rosters
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            id="export-csv-btn"
            onClick={handleExportCsv}
            className="px-3.5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <FileDown className="w-4 h-4" />
            <span>EXPORT CSV</span>
          </button>
          <button
            type="button"
            id="print-report-btn"
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Printer className="w-4 h-4" />
            <span>PRINT REPORT</span>
          </button>
        </div>
      </div>

      {/* Report Selector Tabs */}
      <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-xl text-xs font-bold print:hidden">
        <button
          type="button"
          id="report-tab-iti"
          onClick={() => setActiveReport('iti-contribution')}
          className={`px-4 py-2 rounded-lg transition-all flex items-center gap-2 ${
            activeReport === 'iti-contribution'
              ? 'bg-[#0F2942] text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>1. ITI Contribution Report</span>
        </button>
        <button
          type="button"
          id="report-tab-scheme"
          onClick={() => setActiveReport('scheme-report')}
          className={`px-4 py-2 rounded-lg transition-all flex items-center gap-2 ${
            activeReport === 'scheme-report'
              ? 'bg-[#0F2942] text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>2. Scheme Realization Report</span>
        </button>
        <button
          type="button"
          id="report-tab-instructors"
          onClick={() => setActiveReport('instructor-distribution')}
          className={`px-4 py-2 rounded-lg transition-all flex items-center gap-2 ${
            activeReport === 'instructor-distribution'
              ? 'bg-[#0F2942] text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>3. Skill Development Employee Distribution Report</span>
        </button>
      </div>

      {/* Report Body Printable Container */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 print:p-0 print:border-none">
        {/* Printable Header */}
        <div className="border-b-2 border-slate-900 pb-4 mb-6">
          <div className="text-center space-y-1">
            <h1 className="text-lg font-black uppercase text-slate-900">
              GOVERNMENT OF JAMMU &amp; KASHMIR
            </h1>
            <p className="text-xs font-bold text-slate-700 uppercase tracking-wide">
              Directorate of Skill Development • Technical Education
            </p>
            <h2 className="text-sm font-extrabold text-blue-900 uppercase underline decoration-2 underline-offset-4">
              {activeReport === 'iti-contribution' && 'ITI CONTRIBUTION & REMITTANCE AUDIT REPORT'}
              {activeReport === 'scheme-report' && 'SCHEME FUND COLLECTION & TARGET BALANCE REPORT'}
              {activeReport === 'instructor-distribution' && 'SKILL DEVELOPMENT EMPLOYEE INSTITUTIONAL DISTRIBUTION REPORT'}
            </h2>
            <p className="text-[11px] text-slate-500 font-mono">
              Generated on: {new Date().toLocaleDateString('en-IN', { dateStyle: 'full' })}
            </p>
          </div>
        </div>

        {/* 1. ITI Contribution Report */}
        {activeReport === 'iti-contribution' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-900 font-bold uppercase text-[10px] tracking-wider border-b border-slate-300">
                  <th className="py-2.5 px-3 text-center w-12 border border-slate-300">S.No</th>
                  <th className="py-2.5 px-3 border border-slate-300">Division</th>
                  <th className="py-2.5 px-3 border border-slate-300 min-w-[200px]">ITI Name</th>
                  <th className="py-2.5 px-3 text-center border border-slate-300">Instructors</th>
                  <th className="py-2.5 px-3 text-right border border-slate-300">Total Contribution (₹)</th>
                  <th className="py-2.5 px-3 text-center border border-slate-300">Last Contribution Date</th>
                </tr>
              </thead>
              <tbody>
                {aggregatedItis.map((iti) => (
                  <tr key={iti.id} className="hover:bg-slate-50 border-b border-slate-200">
                    <td className="py-2 px-3 text-center font-bold text-slate-600 border border-slate-200">
                      {iti.sNo}
                    </td>
                    <td className="py-2 px-3 border border-slate-200">{iti.division}</td>
                    <td className="py-2 px-3 font-semibold text-slate-900 border border-slate-200">
                      {iti.name}
                    </td>
                    <td className="py-2 px-3 text-center border border-slate-200 font-bold">
                      {iti.calculatedInstructorCount}
                    </td>
                    <td className="py-2 px-3 text-right font-mono font-bold text-slate-900 border border-slate-200">
                      {formatCurrency(iti.totalContribution)}
                    </td>
                    <td className="py-2 px-3 text-center font-mono border border-slate-200 text-slate-600">
                      {iti.lastContributionDate || '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-slate-100 font-black text-slate-900 border-t-2 border-slate-400">
                  <td colSpan={3} className="py-3 px-3 uppercase border border-slate-300">
                    Total (50 ITIs):
                  </td>
                  <td className="py-3 px-3 text-center border border-slate-300">
                    {aggregatedItis.reduce((s, i) => s + i.calculatedInstructorCount, 0)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono border border-slate-300 text-emerald-800 text-sm">
                    {formatCurrency(aggregatedItis.reduce((s, i) => s + i.totalContribution, 0))}
                  </td>
                  <td className="py-3 px-3 border border-slate-300"></td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}

        {/* 2. Scheme Report */}
        {activeReport === 'scheme-report' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-900 font-bold uppercase text-[10px] tracking-wider border-b border-slate-300">
                  <th className="py-2.5 px-3 min-w-[200px] border border-slate-300">Scheme Name</th>
                  <th className="py-2.5 px-3 text-right border border-slate-300">Target Amount (₹)</th>
                  <th className="py-2.5 px-3 text-right border border-slate-300">Total Realized (₹)</th>
                  <th className="py-2.5 px-3 text-right border border-slate-300">Balance Pending (₹)</th>
                  <th className="py-2.5 px-3 text-center border border-slate-300">Progress (%)</th>
                  <th className="py-2.5 px-3 text-center border border-slate-300">Status</th>
                </tr>
              </thead>
              <tbody>
                {schemeReportData.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50 border-b border-slate-200">
                    <td className="py-2.5 px-3 font-bold text-slate-900 border border-slate-200">
                      {s.name}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono border border-slate-200">
                      {formatCurrency(s.targetAmount)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-800 border border-slate-200">
                      {formatCurrency(s.totalCollected)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-amber-800 border border-slate-200">
                      {formatCurrency(s.balance)}
                    </td>
                    <td className="py-2.5 px-3 text-center font-bold border border-slate-200">
                      {s.progress}%
                    </td>
                    <td className="py-2.5 px-3 text-center border border-slate-200">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100">
                        {s.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-slate-100 font-black text-slate-900 border-t-2 border-slate-400">
                  <td className="py-3 px-3 uppercase border border-slate-300">Consolidated:</td>
                  <td className="py-3 px-3 text-right font-mono border border-slate-300">
                    {formatCurrency(schemeReportData.reduce((acc, s) => acc + (s.targetAmount || 0), 0))}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-emerald-800 border border-slate-300">
                    {formatCurrency(schemeReportData.reduce((acc, s) => acc + s.totalCollected, 0))}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-amber-800 border border-slate-300">
                    {formatCurrency(schemeReportData.reduce((acc, s) => acc + s.balance, 0))}
                  </td>
                  <td colSpan={2} className="py-3 px-3 border border-slate-300"></td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}

        {/* 3. Instructor Distribution Report */}
        {activeReport === 'instructor-distribution' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-900 font-bold uppercase text-[10px] tracking-wider border-b border-slate-300">
                  <th className="py-2.5 px-3 text-center w-12 border border-slate-300">S.No</th>
                  <th className="py-2.5 px-3 border border-slate-300">Division</th>
                  <th className="py-2.5 px-3 border border-slate-300 min-w-[200px]">ITI Name</th>
                  <th className="py-2.5 px-3 text-center border border-slate-300">Active Instructors</th>
                  <th className="py-2.5 px-3 text-center border border-slate-300">Total Enrolled</th>
                </tr>
              </thead>
              <tbody>
                {instructorDistData.map((d) => (
                  <tr key={d.sNo} className="hover:bg-slate-50 border-b border-slate-200">
                    <td className="py-2 px-3 text-center font-bold text-slate-600 border border-slate-200">
                      {d.sNo}
                    </td>
                    <td className="py-2 px-3 border border-slate-200">{d.division}</td>
                    <td className="py-2 px-3 font-semibold text-slate-900 border border-slate-200">
                      {d.name}
                    </td>
                    <td className="py-2 px-3 text-center font-bold text-indigo-900 border border-slate-200">
                      {d.activeCount}
                    </td>
                    <td className="py-2 px-3 text-center border border-slate-200">{d.totalCount}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-slate-100 font-black text-slate-900 border-t-2 border-slate-400">
                  <td colSpan={3} className="py-3 px-3 uppercase border border-slate-300">
                    Grand Total:
                  </td>
                  <td className="py-3 px-3 text-center font-black text-indigo-900 border border-slate-300">
                    {instructorDistData.reduce((sum, d) => sum + d.activeCount, 0)} Active
                  </td>
                  <td className="py-3 px-3 text-center font-black border border-slate-300">
                    {instructorDistData.reduce((sum, d) => sum + d.totalCount, 0)} Total
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
