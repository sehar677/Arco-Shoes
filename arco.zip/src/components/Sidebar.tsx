import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  ShoppingCart,
  FileText,
  Package,
  Users,
  Building2,
  Receipt,
  RotateCcw,
  BookOpen,
  ClipboardCheck,
  FileSpreadsheet,
  Settings,
  Printer,
  ChevronLeft,
  ChevronRight,
  Palette,
  Keyboard,
  LogOut,
  ShieldCheck,
  X,
  Sparkles,
  Wallet,
  Activity,
  Cloud,
  Lock,
} from 'lucide-react';
import { AppTheme, CompanyInfo, ModuleTab, AdminUser } from '../types';
import { authService } from '../services/authService';
import { rbacService } from '../services/rbacService';

interface SidebarProps {
  currentTab: ModuleTab;
  onSelectTab: (tab: ModuleTab) => void;
  company: CompanyInfo;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
  currentTheme: AppTheme;
  onOpenThemeSelector?: () => void;
  onOpenShortcuts?: () => void;
  onLogout?: () => void;
  hasPrintInvoice?: boolean;
}

interface NavItem {
  id: ModuleTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  shortcut?: string;
  badge?: string;
}

interface NavGroup {
  title: string;
  items: NavItem[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  company,
  isCollapsed,
  onToggleCollapse,
  isMobileOpen,
  onCloseMobile,
  currentTheme,
  onOpenThemeSelector,
  onOpenShortcuts,
  onLogout,
  hasPrintInvoice = false,
}) => {
  const [activeAdmin, setActiveAdmin] = useState<AdminUser>(() => authService.getActiveAdmin());

  useEffect(() => {
    const unsub = authService.onAuthChange(() => {
      setActiveAdmin(authService.getActiveAdmin());
    });
    return unsub;
  }, []);

  const roleInfo = rbacService.getActiveRoleInfo();

  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({
    'MAIN': true,
    'MASTERS': true,
    'TRANSACTIONS': true,
    'UPDATE & RETURN': true,
    'LEDGERS': true,
    'REPORTS': true,
    'SYSTEM': true,
  });

  const navGroups: NavGroup[] = [
    {
      title: 'MAIN',
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      ],
    },
    {
      title: 'MASTERS',
      items: [
        { id: 'item_master', label: 'Catalog', icon: Package, shortcut: 'F8' },
        { id: 'customer_master', label: 'Customer', icon: Users, shortcut: 'F9' },
        { id: 'supplier_master', label: 'Supplier', icon: Building2, shortcut: 'F10' },
      ],
    },
    {
      title: 'TRANSACTIONS',
      items: [
        { id: 'sales_invoice', label: 'Sales', icon: ShoppingCart, shortcut: 'F1' },
        { id: 'purchase_entry', label: 'Purchase', icon: FileText, shortcut: 'F4' },
        { id: 'customer_receipt', label: 'Receipts', icon: Receipt },
        { id: 'supplier_payment', label: 'Payments', icon: Receipt },
      ],
    },
    {
      title: 'UPDATE & RETURN',
      items: [
        { id: 'sales_return', label: 'Sales Register', icon: RotateCcw },
        { id: 'purchase_return', label: 'Purchase Register', icon: RotateCcw },
      ],
    },
    {
      title: 'LEDGERS',
      items: [
        { id: 'customer_ledger', label: 'Customer Ledger', icon: Users },
        { id: 'supplier_ledger', label: 'Supplier Ledger', icon: Building2 },
        { id: 'cash_ledger', label: 'Cash Ledger', icon: Wallet },
      ],
    },
    {
      title: 'REPORTS',
      items: [
        { id: 'day_book', label: 'Day Book', icon: BookOpen },
        { id: 'invoices', label: 'Customer Bill Reports', icon: FileText },
        { id: 'bills', label: 'Supplier Bill Reports', icon: FileText },
        { id: 'stock_adjustment', label: 'Stock Sheet', icon: ClipboardCheck },
        { id: 'gst_reports', label: 'GST Reports', icon: FileSpreadsheet },
      ],
    },
    {
      title: 'SYSTEM',
      items: [
        { id: 'audit_logs', label: 'Audit Trails', icon: Activity },
        { id: 'backup_center', label: 'Cloud Backups', icon: Cloud },
        { id: 'company_settings', label: 'Company Settings', icon: Settings },
        ...(currentTab === 'print_preview' || hasPrintInvoice
          ? [{ id: 'print_preview' as ModuleTab, label: 'Print Preview', icon: Printer, badge: 'Active' }]
          : []),
      ],
    },
  ];

  const handleItemClick = (tabId: ModuleTab) => {
    onSelectTab(tabId);
    onCloseMobile();
  };

  const getThemeBadge = () => {
    switch (currentTheme) {
      case 'default':
        return 'Default Theme';
      case 'clean_light':
        return 'Clean Light';
      case 'oxford':
        return 'Royal Oxford';
      case 'linen':
        return 'Green & Black';
      case 'cashmere':
        return 'Orange & Black';
      case 'institutional':
        return 'Violet';
      case 'black_gold':
        return 'Black & Gold';
      case 'orange_violet':
        return 'Orange & Violet';
      default:
        return 'Theme';
    }
  };

  // Determine active item styles based on theme
  const getActiveItemClasses = () => {
    if (currentTheme === 'orange_violet') {
      return 'bg-[#493C62] text-[#F8926A] font-bold shadow-md border-l-4 border-[#F8926A]';
    }
    if (currentTheme === 'default') {
      return 'bg-slate-900 text-white font-bold shadow-sm border-l-4 border-amber-500';
    }
    if (currentTheme === 'institutional') {
      return 'bg-[#8B3AEE] text-white font-bold shadow-md border-l-4 border-[#E9D5FF]';
    }
    if (currentTheme === 'black_gold') {
      return 'bg-[#21262D] text-white font-bold shadow-md border-l-4 border-[#E5A93B]';
    }
    if (currentTheme === 'clean_light') {
      return 'bg-blue-50 text-blue-700 border border-blue-200/80 font-bold shadow-sm';
    }
    if (currentTheme === 'dark' || currentTheme === 'oxford') {
      return 'bg-blue-600/30 text-blue-300 border border-blue-500/40 shadow-inner font-bold';
    }
    if (currentTheme === 'linen') {
      return 'bg-emerald-600 text-white shadow-md font-bold';
    }
    if (currentTheme === 'cashmere') {
      return 'bg-orange-600 text-white shadow-md font-bold';
    }
    return 'bg-amber-600 text-white shadow-md font-bold';
  };

  // Sidebar background and border container styles
  const getSidebarContainerClasses = () => {
    if (currentTheme === 'orange_violet') {
      return 'bg-[#081433]/96 text-white border-r border-[#493C62] shadow-2xl';
    }
    if (currentTheme === 'default') {
      return 'bg-white text-slate-800 border-r border-slate-200 shadow-sm';
    }
    if (currentTheme === 'institutional') {
      return 'bg-[#1E0A3C] text-white border-r border-[#581C87] shadow-2xl';
    }
    if (currentTheme === 'black_gold') {
      return 'bg-[#0D1117] text-[#F0F6FC] border-r border-[#30363D] shadow-2xl';
    }
    if (currentTheme === 'clean_light') {
      return 'bg-white text-slate-800 border-r border-slate-200 shadow-sm';
    }
    if (currentTheme === 'dark') {
      return 'bg-slate-900 text-slate-100 border-r border-slate-800 shadow-xl';
    }
    if (currentTheme === 'oxford') {
      return 'bg-[#0B132B] text-slate-100 border-r border-[#1C2541] shadow-xl';
    }
    if (currentTheme === 'linen') {
      return 'bg-[#F4F5F0] text-slate-900 border-r border-[#E0DDD4] shadow-sm';
    }
    if (currentTheme === 'cream') {
      return 'bg-[#F8F5EE] text-slate-900 border-r border-[#E6DED0] shadow-sm';
    }
    if (currentTheme === 'cashmere') {
      return 'bg-[#F5EFEB] text-slate-900 border-r border-[#E4D9CC] shadow-sm';
    }
    return 'bg-slate-900 text-white border-r border-slate-800 shadow-lg';
  };

  const SidebarContent = ({ isCollapsedMode }: { isCollapsedMode: boolean }) => (
    <div className="flex flex-col h-full select-none">
      {/* Sidebar Header / Branding */}
      <div className={`p-4 border-b flex items-center ${isCollapsedMode ? 'justify-center' : 'justify-between'} ${
        currentTheme === 'institutional'
          ? 'border-amber-900/15'
          : currentTheme === 'default' || currentTheme === 'clean_light'
          ? 'border-slate-200'
          : 'border-slate-700/30'
      }`}>
        <div className="flex items-center gap-3 overflow-hidden">
          <img
            src="/app-logo.jpg"
            alt="ARCO SHOES Logo"
            referrerPolicy="no-referrer"
            className="w-9 h-9 rounded-xl object-cover border border-amber-400/40 shadow-md flex-shrink-0"
          />
          {!isCollapsedMode && (
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <h1 className="font-bold text-sm tracking-tight truncate">
                  {company.companyName || 'ARCO SHOES'}
                </h1>
              </div>
              <p className="text-[10px] opacity-75 font-mono truncate">
                GSTIN: {company.gstin || '27AABCU9603R1ZM'}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Navigation Groups List */}
      <div className="flex-1 overflow-y-auto px-2.5 py-4 space-y-5 scrollbar-thin">
        {navGroups.map((group) => (
          <div key={group.title} className="space-y-1">
            {!isCollapsedMode && (
              <div className={`px-3 text-[10px] font-bold uppercase tracking-widest mb-1.5 flex items-center justify-between ${
                currentTheme === 'institutional'
                  ? 'text-amber-900/80 font-bold'
                  : currentTheme === 'default' || currentTheme === 'clean_light'
                  ? 'text-slate-500'
                  : 'opacity-60 text-slate-300'
              }`}>
                <span>{group.title}</span>
              </div>
            )}

            <div className="space-y-1">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                const isPermitted = rbacService.canAccessTab(item.id, activeAdmin);
                const req = rbacService.getRequiredPermissionForTab(item.id);

                return (
                  <button
                    key={item.id}
                    id={`sidebar-nav-${item.id}`}
                    onClick={() => handleItemClick(item.id)}
                    title={
                      isCollapsedMode
                        ? `${item.label} ${!isPermitted ? '(Restricted for ' + roleInfo.role + ')' : item.shortcut ? `(${item.shortcut})` : ''}`
                        : !isPermitted
                        ? `Restricted: Requires ${req?.label || 'permission'}`
                        : undefined
                    }
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs transition-all duration-150 cursor-pointer ${
                      isCollapsedMode ? 'justify-center py-2.5' : 'justify-between'
                    } ${
                      !isPermitted
                        ? 'opacity-40 hover:opacity-75 text-slate-500 hover:bg-slate-800/30'
                        : isActive
                        ? getActiveItemClasses()
                        : currentTheme === 'default'
                        ? 'text-slate-700 hover:bg-slate-100 hover:text-slate-900 font-medium'
                        : currentTheme === 'institutional'
                        ? 'text-black hover:bg-black/5 hover:text-black font-semibold'
                        : currentTheme === 'clean_light' || currentTheme === 'linen' || currentTheme === 'cream' || currentTheme === 'cashmere'
                        ? 'text-slate-700 hover:bg-slate-200/60 hover:text-slate-900'
                        : currentTheme === 'black_gold'
                        ? 'text-[#8B949E] hover:bg-[#161B22] hover:text-[#F0F6FC] font-medium'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <Icon className={`w-4 h-4 shrink-0 ${isActive && isPermitted ? 'scale-110 text-white' : 'opacity-80'}`} />
                      {!isCollapsedMode && (
                        <span className={`truncate font-medium ${isActive && isPermitted ? 'text-white' : ''}`}>
                          {item.label}
                        </span>
                      )}
                    </div>

                    {!isCollapsedMode && (
                      <div className="flex items-center gap-1 shrink-0">
                        {!isPermitted ? (
                          <span className="p-0.5 rounded bg-rose-950/40 text-rose-400 border border-rose-800/40" title="Restricted for current role">
                            <Lock className="w-3 h-3" />
                          </span>
                        ) : (
                          <>
                            {item.shortcut && (
                              <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded border ${
                                isActive
                                  ? 'bg-black/20 border-white/20 text-white font-bold'
                                  : 'bg-black/10 border-slate-700/30 opacity-70'
                              }`}>
                                {item.shortcut}
                              </span>
                            )}
                            {item.badge && (
                              <span className="text-[9px] font-bold bg-emerald-500 text-white px-1.5 py-0.5 rounded-full uppercase tracking-wider animate-pulse">
                                {item.badge}
                              </span>
                            )}
                          </>
                        )}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Sidebar Footer Controls */}
      <div className={`p-3 border-t shrink-0 space-y-2.5 ${
        currentTheme === 'institutional'
          ? 'border-amber-900/15'
          : currentTheme === 'default' || currentTheme === 'clean_light'
          ? 'border-slate-200'
          : 'border-slate-700/30'
      }`}>
        {/* User Role Card */}
        {!isCollapsedMode ? (
          <div className="p-2.5 rounded-xl bg-black/15 border border-slate-700/30 flex items-center justify-between gap-2">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0"></span>
                <p className="text-[11px] font-bold truncate">
                  {activeAdmin.name || 'Staff User'}
                </p>
              </div>
              <p className="text-[10px] opacity-60 font-mono truncate">
                {activeAdmin.email}
              </p>
            </div>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold border shrink-0 ${roleInfo.color}`}>
              {roleInfo.badge}
            </span>
          </div>
        ) : (
          <div className="flex justify-center" title={`${activeAdmin.name || 'Staff User'} (${roleInfo.role})`}>
            <span className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold text-xs flex items-center justify-center">
              {(activeAdmin.name || 'U').charAt(0).toUpperCase()}
            </span>
          </div>
        )}

        {/* Desktop Collapse / Expand Toggle Button */}
        <button
          onClick={onToggleCollapse}
          title={isCollapsedMode ? "Expand Sidebar" : "Collapse Sidebar"}
          className={`hidden lg:flex w-full items-center ${isCollapsedMode ? 'justify-center p-2.5' : 'justify-between px-3 py-2'} rounded-xl text-xs font-semibold border transition cursor-pointer ${
            currentTheme === 'default'
              ? 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
              : currentTheme === 'clean_light'
              ? 'bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100'
              : currentTheme === 'institutional'
              ? 'bg-amber-100/80 border-amber-300/80 text-black hover:bg-amber-200/90'
              : 'bg-slate-800/80 border-slate-700 text-slate-200 hover:bg-slate-700'
          }`}
        >
          {!isCollapsedMode && (
            <span className="flex items-center gap-2">
              <ChevronLeft className="w-4 h-4" />
              <span>Collapse Sidebar</span>
            </span>
          )}
          {isCollapsedMode && <ChevronRight className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Permanent / Collapsible Sidebar */}
      <aside
        className={`hidden lg:block sticky top-0 h-screen transition-all duration-300 ease-in-out z-40 shrink-0 ${
          isCollapsed ? 'w-[76px]' : 'w-64'
        } ${getSidebarContainerClasses()}`}
      >
        <SidebarContent isCollapsedMode={isCollapsed} />
      </aside>

      {/* Mobile Off-Canvas Drawer Navigation */}
      {isMobileOpen && (
        <div className="lg:hidden fixed inset-0 z-[150] flex">
          {/* Backdrop Overlay */}
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200"
            onClick={onCloseMobile}
          ></div>

          {/* Drawer Panel */}
          <div className={`relative w-72 max-w-[85vw] h-full shadow-2xl z-10 animate-in slide-in-from-left duration-200 ${getSidebarContainerClasses()}`}>
            <button
              onClick={onCloseMobile}
              className="absolute top-4 right-3 p-1.5 rounded-lg bg-black/20 text-slate-300 hover:text-white transition cursor-pointer"
              title="Close Menu"
            >
              <X className="w-5 h-5" />
            </button>
            <SidebarContent isCollapsedMode={false} />
          </div>
        </div>
      )}
    </>
  );
};
