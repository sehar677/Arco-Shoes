import React, { useState, useEffect } from 'react';
import { ConfirmModal } from './ConfirmModal';
import {
  Truck,
  Plus,
  Trash2,
  Save,
  RotateCcw,
  History,
  AlertCircle,
  CheckCircle,
  Search,
  ArrowDownLeft,
  FileText,
  Receipt,
  Building2,
  Calendar,
  CreditCard,
  FileCheck2,
  Lock,
} from 'lucide-react';
import { CompanyInfo, InvoiceItem, Item, PurchaseInvoice, Supplier } from '../types';
import { dbService } from '../services/storage';
import { calculateLineGST, formatCurrency, roundTo2 } from '../services/gstCalculations';
import { SuccessPopup } from './SuccessPopup';

interface PurchaseInvoiceProps {
  company: CompanyInfo;
}

// Helper to get local YYYY-MM-DD
const getLocalTodayDate = (): string => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const PurchaseInvoiceComponent: React.FC<PurchaseInvoiceProps> = ({ company }) => {
  const [itemsList, setItemsList] = useState<Item[]>([]);
  const [suppliersList, setSuppliersList] = useState<Supplier[]>([]);

  // Main Tab State
  const [activeTab, setActiveTab] = useState<'stock_inward' | 'purchase_voucher'>('stock_inward');

  // Standard Purchase Form State
  const [invoiceId, setInvoiceId] = useState<string>('');
  const [purchaseInvoiceNo, setPurchaseInvoiceNo] = useState<string>('');
  const [supplierBillNo, setSupplierBillNo] = useState<string>('');
  const [purchaseDate, setPurchaseDate] = useState<string>(getLocalTodayDate());
  const [supplierType, setSupplierType] = useState<'Registered' | 'UnRegistered'>('Registered');
  const [selectedSupplierId, setSelectedSupplierId] = useState<string>('');
  const [purchaseType, setPurchaseType] = useState<'Cash' | 'Credit Line'>('Credit Line');
  const [manualSupplierName, setManualSupplierName] = useState<string>('');
  const [supplierGstin, setSupplierGstin] = useState<string>('');
  const [supplierAddress, setSupplierAddress] = useState<string>('');
  const [supplierStateCode, setSupplierStateCode] = useState<string>('09');
  const [isInterState, setIsInterState] = useState<boolean>(false);
  const [paymentMode, setPaymentMode] = useState<'Credit' | 'Bank/NEFT' | 'Cash'>('Credit');
  const [remarks, setRemarks] = useState<string>('');
  const [amountPaid, setAmountPaid] = useState<number>(0);

  // Line items state
  const [lineItems, setLineItems] = useState<InvoiceItem[]>([]);

  // Row buffer
  const [activeItemId, setActiveItemId] = useState<string>('');
  const [isManualItemMode, setIsManualItemMode] = useState<boolean>(false);
  const [manualItemCode, setManualItemCode] = useState<string>('');
  const [manualItemName, setManualItemName] = useState<string>('');
  const [manualHsn, setManualHsn] = useState<string>('6403');
  const [manualGstRate, setManualGstRate] = useState<number>(5);
  const [manualUnit, setManualUnit] = useState<string>('Pairs');
  const [rowQty, setRowQty] = useState<number>(6);
  const [rowRate, setRowRate] = useState<number>(0);
  const [rowSellingRate, setRowSellingRate] = useState<number | ''>('');
  const [rowMrp, setRowMrp] = useState<number | ''>('');
  const [rowDisc, setRowDisc] = useState<number>(0);

  // Direct Purchase Voucher State (No Stock Entry)
  const [voucherBillNo, setVoucherBillNo] = useState<string>('');
  const [voucherBillDate, setVoucherBillDate] = useState<string>(getLocalTodayDate());
  const [voucherSupplierBillNo, setVoucherSupplierBillNo] = useState<string>('');
  const [voucherSupplierId, setVoucherSupplierId] = useState<string>('');
  const [voucherPurchaseType, setVoucherPurchaseType] = useState<'Credit Line' | 'Cash'>('Credit Line');
  const [voucherTotalAmount, setVoucherTotalAmount] = useState<number | ''>('');
  const [voucherRemarks, setVoucherRemarks] = useState<string>('');

  // History modal & notifications
  const [showHistoryModal, setShowHistoryModal] = useState<boolean>(false);
  const [purchaseToDelete, setPurchaseToDelete] = useState<{ id: string; no: string } | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; title?: string; text: string } | null>(null);

  const handleConfirmDelete = () => {
    if (!purchaseToDelete) return;
    const res = dbService.deletePurchaseInvoice(purchaseToDelete.id);
    if (res.success) {
      setFeedback({
        type: 'success',
        title: 'Purchase Bill Deleted / Voided',
        text: `Bill #${purchaseToDelete.no} has been deleted. Stock addition and vendor balance have been reversed safely.`,
      });
      setPurchaseToDelete(null);
      loadMasterData();
    } else {
      setFeedback({ type: 'error', text: res.message });
      setPurchaseToDelete(null);
    }
  };

  const activeTaxType = company.defaultTaxCalculation || 'Inclusive';

  const getNextBillNo = (purchases: PurchaseInvoice[]): string => {
    const validNumbers = purchases
      .map(p => p.purchaseInvoiceNo)
      .filter(no => /^PUR-BILL-(\d{3})$/.test(no))
      .map(no => parseInt(no.split('-')[2], 10));

    const maxNo = validNumbers.length > 0 ? Math.max(...validNumbers) : 0;
    return `PUR-BILL-${String(maxNo + 1).padStart(3, '0')}`;
  };

  const loadMasterData = () => {
    const itms = dbService.getItems();
    const sups = dbService.getSuppliers();
    setItemsList(itms);
    setSuppliersList(sups);
  };

  const resetForm = () => {
    loadMasterData();
    const purchases = dbService.getPurchases();
    const nextPurNo = getNextBillNo(purchases);
    
    setInvoiceId(`PUR-${Date.now()}`);
    setPurchaseInvoiceNo(nextPurNo);
    setSupplierBillNo('');
    setPurchaseDate(getLocalTodayDate());
    setSupplierType('Registered');
    setSelectedSupplierId('');
    setPurchaseType('Credit Line');
    setPaymentMode('Credit');
    setManualSupplierName('');
    setSupplierGstin('');
    setSupplierAddress('');
    setSupplierStateCode(company.stateCode || '09');
    setIsInterState(false);
    setVoucherSupplierId('');

    setRemarks('');
    setLineItems([]);
    setAmountPaid(0);
    setActiveItemId('');
    setRowQty(6);
    setRowRate(0);
    setRowSellingRate('');
    setRowMrp('');
    setRowDisc(0);

    // Reset direct purchase voucher form
    setVoucherBillNo(nextPurNo);
    setVoucherBillDate(getLocalTodayDate());
    setVoucherSupplierBillNo('');
    setVoucherPurchaseType('Credit Line');
    setVoucherTotalAmount('');
    setVoucherRemarks('');

    setFeedback(null);
  };

  useEffect(() => {
    resetForm();
    return dbService.subscribe(() => {
      setItemsList(dbService.getItems());
      setSuppliersList(dbService.getSuppliers());
    });
  }, []);

  const handleSupplierTypeChange = (type: 'Registered' | 'UnRegistered') => {
    setSupplierType(type);
    if (type === 'UnRegistered') {
      setSelectedSupplierId('');
      setSupplierGstin('');
      setPurchaseType('Cash');
      setPaymentMode('Cash');
    } else {
      setManualSupplierName('');
      setPurchaseType('Credit Line');
      setPaymentMode('Credit');
    }
  };

  const handleSupplierChange = (supId: string, currentSuppliers = suppliersList) => {
    setSelectedSupplierId(supId);
    if (!supId) {
      setSupplierGstin('');
      setSupplierAddress('');
      setSupplierStateCode(company.stateCode || '09');
      setIsInterState(false);
    } else {
      const sup = currentSuppliers.find((s) => s.id === supId);
      if (sup) {
        setSupplierGstin(sup.gstin || '');
        setSupplierAddress(sup.address || '');
        setSupplierStateCode(sup.stateCode || '09');
        const isInter = Boolean(sup.stateCode && sup.stateCode !== company.stateCode);
        setIsInterState(isInter);
        if (sup.gstin && sup.gstin.trim()) {
          setSupplierType('Registered');
        }
      }
    }
  };

  const handleSwitchToCashMode = () => {
    setPurchaseType('Cash');
    setPaymentMode('Cash');
  };

  const handleSwitchToCreditMode = () => {
    setPurchaseType('Credit Line');
    setPaymentMode('Credit');
  };

  const handleItemSelect = (itmId: string) => {
    setActiveItemId(itmId);
    const itm = itemsList.find((i) => i.id === itmId);
    if (itm) {
      setManualItemCode(itm.itemCode);
      setManualItemName(itm.itemName);
      setManualHsn(itm.hsnCode || '6403');
      setManualGstRate(itm.gstRate || 5);
      setManualUnit(itm.unit || 'Pairs');
      setRowRate(itm.purchaseRate || 0);
      setRowSellingRate(itm.sellingRate !== undefined && itm.sellingRate !== null ? itm.sellingRate : '');
      setRowMrp(itm.mrp !== undefined && itm.mrp !== null ? itm.mrp : (itm.sellingRate || ''));
      setRowQty(6);
      setRowDisc(0);
    } else {
      setRowRate(0);
      setRowSellingRate('');
      setRowMrp('');
      setRowQty(6);
      setRowDisc(0);
    }
  };

  const handleAddLineItem = () => {
    let finalCode = '';
    let finalName = '';
    let finalHsn = '6403';
    let finalUnit = 'Pairs';
    let finalGstRate = 5;
    let fallbackRate = 0;
    let fallbackSellingRate = 0;
    let fallbackMrp = 0;
    let itemIdToUse = `PUR-ITM-${Date.now()}`;

    if (!isManualItemMode && activeItemId) {
      const itm = itemsList.find((i) => i.id === activeItemId);
      if (itm) {
        finalCode = itm.itemCode;
        finalName = itm.itemName;
        finalHsn = itm.hsnCode || '6403';
        finalUnit = itm.unit || 'Pairs';
        finalGstRate = itm.gstRate || 5;
        fallbackRate = itm.purchaseRate || 0;
        fallbackSellingRate = itm.sellingRate || 0;
        fallbackMrp = itm.mrp || itm.sellingRate || 0;
        itemIdToUse = itm.id;
      }
    } else {
      finalCode = manualItemCode.trim() || `SH-${Date.now().toString().slice(-4)}`;
      finalName = manualItemName.trim();
      finalHsn = manualHsn.trim() || '6403';
      finalUnit = manualUnit || 'Pairs';
      finalGstRate = Number(manualGstRate) || 5;
    }

    if (!finalName) {
      setFeedback({ type: 'error', text: 'Select an item from catalog or enter item name.' });
      return;
    }

    if (rowQty <= 0) {
      setFeedback({ type: 'error', text: 'Purchase quantity must be greater than 0.' });
      return;
    }

    const rateToUse = Number(rowRate) > 0 ? Number(rowRate) : fallbackRate;
    const calc = calculateLineGST(
      Number(rowQty),
      rateToUse,
      rowDisc,
      finalGstRate,
      isInterState,
      activeTaxType
    );
    const newLine: InvoiceItem = {
      id: `PL-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      itemId: itemIdToUse,
      itemCode: finalCode,
      itemName: finalName,
      hsnCode: finalHsn,
      quantity: Number(rowQty),
      unit: finalUnit,
      rate: rateToUse,
      sellingRate: rowSellingRate !== '' ? Number(rowSellingRate) : fallbackSellingRate,
      mrp: rowMrp !== '' ? Number(rowMrp) : (fallbackMrp || fallbackSellingRate),
      gstRate: finalGstRate,
      ...calc,
    };

    setLineItems([...lineItems, newLine]);
    setActiveItemId('');
    setManualItemCode('');
    setManualItemName('');
    setRowQty(6);
    setRowRate(0);
    setRowSellingRate('');
    setRowMrp('');
    setRowDisc(0);
  };

  const handleRemoveLineItem = (index: number) => {
    setLineItems(lineItems.filter((_, idx) => idx !== index));
  };

  // Calculations
  const totalQuantity = lineItems.reduce((acc, it) => acc + it.quantity, 0);
  const grossSubtotal = roundTo2(lineItems.reduce((acc, it) => acc + it.grossAmount, 0));
  const totalDiscount = roundTo2(lineItems.reduce((acc, it) => acc + it.discountAmount, 0));
  const totalTaxable = roundTo2(lineItems.reduce((acc, it) => acc + it.taxableAmount, 0));
  const totalCgst = roundTo2(lineItems.reduce((acc, it) => acc + it.cgstAmount, 0));
  const totalSgst = roundTo2(lineItems.reduce((acc, it) => acc + it.sgstAmount, 0));
  const totalIgst = roundTo2(lineItems.reduce((acc, it) => acc + it.igstAmount, 0));
  const totalTax = roundTo2(totalCgst + totalSgst + totalIgst);

  const exactNet = totalTaxable + totalTax;
  const grandTotal = Math.round(exactNet);
  const roundOff = roundTo2(grandTotal - exactNet);

  const isCashPurchase = purchaseType === 'Cash';
  const selectedSupplier = suppliersList.find((s) => s.id === selectedSupplierId);
  const previousBalance = selectedSupplier ? (selectedSupplier.currentBalance || 0) : 0;
  const effectivePaid = isCashPurchase || paymentMode === 'Cash' || paymentMode === 'Bank/NEFT' ? grandTotal : amountPaid;
  const balanceDue = isCashPurchase ? 0 : Math.max(0, roundTo2(grandTotal - effectivePaid));
  const newBalance = isCashPurchase ? previousBalance : roundTo2(previousBalance + balanceDue);

  // Live calculation for currently buffered inward item
  const activeProduct = itemsList.find((i) => i.id === activeItemId);
  const currentCostRate = Number(rowRate) > 0 ? Number(rowRate) : (activeProduct?.purchaseRate || 0);
  const currentGstRate = !isManualItemMode ? (activeProduct?.gstRate || 5) : (Number(manualGstRate) || 5);
  const liveInwardItemCalc = calculateLineGST(
    Number(rowQty) || 0,
    currentCostRate,
    rowDisc,
    currentGstRate,
    isInterState,
    activeTaxType
  );

  const handleSavePurchase = () => {
    if (lineItems.length === 0) {
      setFeedback({ type: 'error', text: 'Please add at least 1 item to inward purchase.' });
      return;
    }
    if (!supplierBillNo.trim()) {
      setFeedback({ type: 'error', text: 'Supplier Bill / Invoice No. is required.' });
      return;
    }
    if (supplierType === 'Registered' && !selectedSupplierId) {
      setFeedback({ type: 'error', text: 'Please select a Supplier from the dropdown.' });
      return;
    }
    if (supplierType === 'UnRegistered' && !manualSupplierName.trim()) {
      setFeedback({ type: 'error', text: 'Please enter Supplier Name.' });
      return;
    }

    const currentSup = selectedSupplierId ? suppliersList.find((s) => s.id === selectedSupplierId) : null;
    const finalSupplierName = currentSup ? currentSup.supplierName : manualSupplierName.trim();
    const finalSupplierId = currentSup ? currentSup.id : (isCashPurchase ? 'SUP-CASH' : `SUP-MANUAL-${Date.now()}`);

    // Multi-device protection: recalculate to ensure uniqueness
    const latestPurchases = dbService.getPurchases();
    const finalPurchaseNo = getNextBillNo(latestPurchases);

    const invoice: PurchaseInvoice = {
      id: invoiceId,
      purchaseNo: finalPurchaseNo,
      purchaseInvoiceNo: finalPurchaseNo,
      supplierBillNo: supplierBillNo.trim(),
      purchaseDate,
      supplierId: finalSupplierId,
      supplierName: finalSupplierName,
      supplierGstin: currentSup?.gstin || supplierGstin || '',
      supplierAddress: currentSup?.address || supplierAddress || '',
      supplierStateCode: currentSup?.stateCode || supplierStateCode,
      isInterState,
      supplierType,
      purchaseType: isCashPurchase ? 'Cash' : 'Credit Line',
      paymentMode: isCashPurchase ? 'Cash' : paymentMode,
      items: lineItems,
      totalQuantity,
      grossSubtotal,
      totalDiscount,
      totalTaxable,
      totalCgst,
      totalSgst,
      totalIgst,
      totalTax,
      freightOtherCharges: 0,
      roundOff,
      grandTotal,
      amountPaid: isCashPurchase ? grandTotal : effectivePaid,
      balanceDue: isCashPurchase ? 0 : balanceDue,
      previousBalance,
      newBalance,
      remarks,
      createdAt: new Date().toISOString(),
    };

    const res = dbService.savePurchaseInvoice(invoice);
    if (res.success) {
      setFeedback({ type: 'success', text: res.message });
      setTimeout(() => resetForm(), 1200);
    } else {
      setFeedback({ type: 'error', text: res.message });
    }
  };

  const handleSaveDirectVoucher = () => {
    if (!voucherSupplierBillNo.trim()) {
      setFeedback({ type: 'error', text: 'Supplier Bill Number is required.' });
      return;
    }
    if (!voucherSupplierId) {
      setFeedback({ type: 'error', text: 'Please select a Supplier.' });
      return;
    }
    const amount = Number(voucherTotalAmount);
    if (!amount || amount <= 0) {
      setFeedback({ type: 'error', text: 'TOTAL INWARD BILL AMOUNT must be greater than 0.' });
      return;
    }

    const currentSup = suppliersList.find((s) => s.id === voucherSupplierId);
    if (!currentSup) {
      setFeedback({ type: 'error', text: 'Selected supplier not found.' });
      return;
    }

    // Multi-device protection: recalculate to ensure uniqueness
    const latestPurchases = dbService.getPurchases();
    const finalPurchaseNo = getNextBillNo(latestPurchases);

    const prevBal = currentSup.currentBalance || 0;
    const isCreditLine = voucherPurchaseType === 'Credit Line';
    const amountPaidVal = isCreditLine ? 0 : amount;
    const balanceDueVal = roundTo2(amount - amountPaidVal);
    const newBalVal = roundTo2(prevBal + balanceDueVal);

    const voucherInvoice: PurchaseInvoice = {
      id: `PUR-${Date.now()}`,
      purchaseNo: finalPurchaseNo,
      purchaseInvoiceNo: finalPurchaseNo,
      supplierBillNo: voucherSupplierBillNo.trim(),
      purchaseDate: voucherBillDate,
      supplierId: currentSup.id,
      supplierName: currentSup.supplierName,
      supplierGstin: currentSup.gstin || '',
      supplierAddress: currentSup.address || '',
      supplierStateCode: currentSup.stateCode || company.stateCode || '09',
      isInterState: currentSup.stateCode ? currentSup.stateCode !== company.stateCode : false,
      purchaseType: voucherPurchaseType,
      paymentMode: isCreditLine ? 'Credit' : 'Cash',
      items: [], // Empty items -> NO stock item addition!
      totalQuantity: 0,
      grossSubtotal: amount,
      totalDiscount: 0,
      totalTaxable: amount,
      totalCgst: 0,
      totalSgst: 0,
      totalIgst: 0,
      totalTax: 0,
      freightOtherCharges: 0,
      roundOff: 0,
      grandTotal: amount,
      amountPaid: amountPaidVal,
      balanceDue: balanceDueVal,
      previousBalance: prevBal,
      newBalance: newBalVal,
      remarks: voucherRemarks.trim() || 'Direct Purchase Voucher (Without Stock Entry)',
      createdAt: new Date().toISOString(),
    };

    const res = dbService.savePurchaseInvoice(voucherInvoice);
    if (res.success) {
      setFeedback({
        type: 'success',
        title: 'Purchase Voucher Posted',
        text: `Purchase Bill ${voucherInvoice.purchaseInvoiceNo} (Ref: ${voucherInvoice.supplierBillNo}) recorded! ${formatCurrency(amount)} added to ${currentSup.supplierName}'s account balance (No stock entered).`,
      });
      setTimeout(() => resetForm(), 1200);
    } else {
      setFeedback({ type: 'error', text: res.message });
    }
  };

  const pastPurchases = dbService.getPurchases();

  const selectedVoucherSupplier = suppliersList.find((s) => s.id === voucherSupplierId);
  const voucherPrevBal = selectedVoucherSupplier ? selectedVoucherSupplier.currentBalance : 0;
  const voucherAmountVal = Number(voucherTotalAmount) || 0;
  const voucherNewBal = roundTo2(voucherPrevBal + (voucherPurchaseType === 'Credit Line' ? voucherAmountVal : 0));

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none">
      {/* Modal Popup for all Messages */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          onClose={() => setFeedback(null)}
        />
      )}

      {/* Header Container & Tabs */}
      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-700/40 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-orange-600/20 text-orange-400 border border-orange-500/30 flex items-center justify-center shadow-inner">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
                <span>Stock Purchase</span>
                <span className="text-xs font-mono font-normal bg-slate-800/60 text-slate-400 px-2 py-0.5 rounded border border-slate-700/50">
                  frmPurchaseInvoice
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Record stock inward goods or post direct purchase bill vouchers to supplier accounts.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-view-past-purchases"
              onClick={() => setShowHistoryModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 border border-slate-700/50 backdrop-blur-sm text-xs font-medium transition-all cursor-pointer"
            >
              <History className="w-4 h-4 text-sky-400" />
              <span>Past Inward Bills ({pastPurchases.length})</span>
            </button>
            <button
              id="btn-new-purchase"
              onClick={resetForm}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 border border-slate-700/50 backdrop-blur-sm text-xs font-medium transition-all cursor-pointer"
            >
              <RotateCcw className="w-4 h-4 text-orange-400" />
              <span>Reset / New</span>
            </button>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-2 pt-1 border-b border-slate-800">
          <button
            id="tab-stock-inward"
            type="button"
            onClick={() => setActiveTab('stock_inward')}
            className={`flex items-center gap-2 px-4 py-2 rounded-t-lg font-bold text-xs transition-all cursor-pointer border-t border-x ${
              activeTab === 'stock_inward'
                ? 'bg-slate-800/90 text-orange-400 border-orange-500/50 shadow-md'
                : 'bg-slate-950/40 text-slate-400 border-transparent hover:text-slate-200 hover:bg-slate-900/50'
            }`}
          >
            <Truck className="w-4 h-4" />
            <span>Item Stock Inward</span>
          </button>

          <button
            id="tab-new-purchase-voucher"
            type="button"
            onClick={() => setActiveTab('purchase_voucher')}
            className={`flex items-center gap-2 px-4 py-2 rounded-t-lg font-bold text-xs transition-all cursor-pointer border-t border-x ${
              activeTab === 'purchase_voucher'
                ? 'bg-slate-800/90 text-emerald-400 border-emerald-500/50 shadow-md'
                : 'bg-slate-950/40 text-slate-400 border-transparent hover:text-slate-200 hover:bg-slate-900/50'
            }`}
          >
            <FileText className="w-4 h-4 text-emerald-400" />
            <span>New Purchase Voucher</span>
            <span className="bg-emerald-500/20 text-emerald-300 text-[10px] px-1.5 py-0.2 rounded font-mono">No Stock</span>
          </button>
        </div>

        {/* Header Form Body for Tab 1 (Stock Inward) */}
        {activeTab === 'stock_inward' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 text-xs pt-1">
            {/* 1. PURCHASE BILL NO */}
            <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">PURCHASE BILL NO</label>
              <input
                type="text"
                value={purchaseInvoiceNo}
                readOnly={true}
                placeholder="e.g. PUR-001"
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-500 font-mono font-bold focus:border-slate-700 focus:outline-none cursor-not-allowed"
              />
            </div>

            {/* 2. BILL DATE */}
            <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Bill Date</label>
              <input
                type="date"
                value={purchaseDate}
                onChange={(e) => setPurchaseDate(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-mono focus:border-orange-500 focus:outline-none"
              />
            </div>

            {/* 3. SUPPLIER BILL NUMBER */}
            <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
              <label className="block text-[10px] font-bold text-orange-400 uppercase tracking-wider mb-1">Supplier Bill Number *</label>
              <input
                type="text"
                required
                value={supplierBillNo}
                onChange={(e) => setSupplierBillNo(e.target.value)}
                placeholder="e.g. SUP-BILL-001"
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-mono font-bold focus:border-orange-500 focus:outline-none"
              />
            </div>

            {/* 4. SUPPLIER TYPE */}
            <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">SUPPLIER TYPE</label>
              <select
                id="select-supplier-type"
                value={supplierType}
                onChange={(e) => handleSupplierTypeChange(e.target.value as 'Registered' | 'UnRegistered')}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-semibold focus:border-orange-500 focus:outline-none text-xs cursor-pointer"
              >
                <option value="Registered">Registered</option>
                <option value="UnRegistered">UnRegistered</option>
              </select>
            </div>

            {/* 5. SUPPLIER NAME (Placed before Purchase Type) */}
            <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Supplier Name *
                </label>
                {supplierType === 'Registered' && selectedSupplier && (
                  <span className="text-[10px] text-purple-300 font-mono">
                    {formatCurrency(selectedSupplier.currentBalance)} Cr
                  </span>
                )}
              </div>
              {supplierType === 'Registered' ? (
                <select
                  id="select-purchase-supplier"
                  value={selectedSupplierId}
                  onChange={(e) => handleSupplierChange(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-semibold focus:border-orange-500 focus:outline-none text-xs cursor-pointer"
                >
                  <option value="">---Select Supplier--</option>
                  {suppliersList.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.supplierName}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  id="input-manual-supplier-name"
                  type="text"
                  required
                  value={manualSupplierName}
                  onChange={(e) => setManualSupplierName(e.target.value)}
                  placeholder="Enter Supplier Name *"
                  className="w-full bg-slate-950/90 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-semibold focus:border-orange-500 focus:outline-none text-xs placeholder:text-slate-500"
                />
              )}
            </div>

            {/* 6. PURCHASE TYPE */}
            <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm space-y-1">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                PURCHASE TYPE
              </label>
              <div className="flex items-center gap-1 bg-slate-950/80 p-0.5 rounded-md border border-slate-700/60">
                <button
                  type="button"
                  id="btn-purchase-type-credit"
                  onClick={handleSwitchToCreditMode}
                  className={`flex-1 py-1 rounded text-[10px] font-bold transition-all cursor-pointer text-center ${
                    !isCashPurchase
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Credit Line
                </button>
                <button
                  type="button"
                  id="btn-purchase-type-cash"
                  onClick={handleSwitchToCashMode}
                  className={`flex-1 py-1 rounded text-[10px] font-bold transition-all cursor-pointer text-center ${
                    isCashPurchase
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Cash Purchase
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Header Form Footer Callouts for Tab 1 */}
        {activeTab === 'stock_inward' && (
          <div className="mt-3 pt-2.5 border-t border-slate-700/40 flex items-center justify-between text-xs text-slate-400 flex-wrap gap-2">
            <div className="flex items-center gap-2 flex-wrap">
              {/* Supplier Type Badge */}
              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-bold ${
                supplierType === 'Registered'
                  ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                  : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
              }`}>
                Supplier Type: {supplierType}
              </span>
              <span>•</span>
              {/* Purchase Type Badge */}
              {isCashPurchase ? (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Purchase Type: Cash
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[10px] font-bold">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400"></span>
                  Purchase Type: Credit Line
                </span>
              )}
              <span>•</span>
              <span>Supplier GSTIN: <strong className="font-mono text-slate-200">{supplierGstin || (supplierType === 'UnRegistered' ? 'Unregistered' : 'None')}</strong></span>
              <span>•</span>
              <span>
                Tax Calculation Mode: <strong className="text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-700/40">{activeTaxType} GST</strong>
              </span>
            </div>
            <div>
              {isCashPurchase ? (
                <span className="text-emerald-400 font-medium">Cash Purchase: <strong className="font-mono text-emerald-300">₹0.00 Ledger Balance Added</strong></span>
              ) : (
                <span>Previous Payable Balance: <strong className="text-orange-400 font-mono">{formatCurrency(previousBalance)} Cr</strong></span>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Item Stock Inward Section */}
      {activeTab === 'stock_inward' && (
        <>
          {/* Item Quick Insertion */}
          <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-lg backdrop-blur-md space-y-2.5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-300">Add Stock Inward Item</span>
                <span className="text-[10px] text-slate-500">(Independent Purchase Inward - Stock Register tracks purchased bills)</span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-[minmax(170px,2.2fr)_minmax(100px,1.1fr)_minmax(65px,0.75fr)_minmax(95px,1.05fr)_minmax(95px,1.05fr)_minmax(95px,1.05fr)_minmax(105px,1.15fr)_auto] gap-2 text-xs items-end">
              <>
                  <div className="min-w-0">
                    <label className="block text-slate-400 font-medium mb-1 truncate">Select Product</label>
                    <select
                      value={activeItemId}
                      onChange={(e) => handleItemSelect(e.target.value)}
                      className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-orange-500 focus:outline-none text-xs cursor-pointer truncate"
                    >
                      <option value="">-- Select Product --</option>
                      {itemsList
                        .filter((i) => i.isActive && !dbService.isItemPurchased(i.id))
                        .map((i) => (
                        <option key={i.id} value={i.id}>
                          {i.itemName} (Cost: ₹{i.purchaseRate})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="min-w-0">
                    <label className="block text-slate-400 font-medium mb-1 flex items-center justify-between truncate">
                      <span className="truncate">Article Code</span>
                      <span className="text-[10px] text-amber-400 font-semibold flex items-center gap-0.5 shrink-0">
                        <Lock className="w-2.5 h-2.5" /> Locked
                      </span>
                    </label>
                    <input
                      type="text"
                      readOnly
                      value={manualItemCode}
                      placeholder="Article Code"
                      className="w-full bg-slate-900/90 border border-slate-700/70 text-slate-300 font-mono font-bold rounded-lg px-2.5 py-1.5 text-xs cursor-not-allowed select-all uppercase"
                    />
                  </div>
                </>

              <div className="min-w-0">
                <label className="block text-slate-400 font-medium mb-1 truncate">Inward Qty</label>
                <input
                  type="number"
                  min="1"
                  value={rowQty}
                  onChange={(e) => setRowQty(Math.max(1, Number(e.target.value)))}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-bold font-mono focus:border-orange-500 focus:outline-none text-xs"
                />
              </div>

              <div className="min-w-0">
                <label className="block text-slate-400 font-medium mb-1 truncate">Purchase Cost (₹)</label>
                <input
                  type="number"
                  value={rowRate}
                  onChange={(e) => setRowRate(Number(e.target.value))}
                  placeholder="0.00"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-orange-500 focus:outline-none text-xs"
                />
              </div>

              {/* Selling Rate box after Purchase Cost */}
              <div className="min-w-0">
                <label className="block text-emerald-400 font-medium mb-1 truncate">Selling Rate (₹)</label>
                <input
                  type="number"
                  value={rowSellingRate}
                  onChange={(e) => setRowSellingRate(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="Sale Price"
                  className="w-full bg-slate-950/70 border border-emerald-500/40 rounded-lg px-2.5 py-1.5 text-emerald-300 font-mono font-semibold focus:border-emerald-400 focus:outline-none text-xs"
                />
              </div>

              {/* MRP Print box after Selling Rate */}
              <div className="min-w-0">
                <label className="block text-sky-400 font-medium mb-1 truncate">MRP Print (₹)</label>
                <input
                  type="number"
                  value={rowMrp}
                  onChange={(e) => setRowMrp(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="Printed MRP"
                  className="w-full bg-slate-950/70 border border-sky-500/40 rounded-lg px-2.5 py-1.5 text-sky-300 font-mono font-semibold focus:border-sky-400 focus:outline-none text-xs"
                />
              </div>

              {/* Net Amount box after MRP Print (Same Row) */}
              <div className="min-w-0">
                <label className="block text-amber-400 font-medium mb-1 truncate" title="Calculated Net Amount including GST">
                  Net Amount (₹)
                </label>
                <input
                  type="text"
                  readOnly
                  value={liveInwardItemCalc.netAmount > 0 ? `₹${liveInwardItemCalc.netAmount.toFixed(2)}` : '₹0.00'}
                  title="Calculated Net Amount (Cost x Qty + GST)"
                  className="w-full bg-slate-950/80 border border-amber-500/40 rounded-lg px-2.5 py-1.5 text-amber-300 font-mono font-bold text-xs select-all cursor-default"
                />
              </div>

              <div className="min-w-0 shrink-0">
                <button
                  id="btn-add-purchase-line"
                  type="button"
                  onClick={handleAddLineItem}
                  className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-semibold rounded-lg shadow-lg shadow-orange-900/20 border border-orange-500/30 transition-all text-xs cursor-pointer whitespace-nowrap"
                >
                  <Plus className="w-4 h-4 shrink-0" />
                  <span>Inward</span>
                </button>
              </div>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="bg-slate-900/20 border border-slate-700/50 rounded-xl shadow-xl backdrop-blur-md overflow-hidden text-slate-200">
            <div className="overflow-x-auto max-h-72">
              <table className="w-full text-xs text-left border-collapse">
                <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md">
                  <tr>
                    <th className="py-2.5 px-2.5 w-8 text-center">#</th>
                    <th className="py-2.5 px-3">Item Details</th>
                    <th className="py-2.5 px-2 text-center w-16">HSN</th>
                    <th className="py-2.5 px-2 text-right w-16">Inward Qnty</th>
                    <th className="py-2.5 px-2 text-right w-20">Cost Rate</th>
                    <th className="py-2.5 px-2 text-right w-20">Selling Rate</th>
                    <th className="py-2.5 px-2 text-right w-20">MRP Print</th>
                    <th className="py-2.5 px-2 text-right w-20">Taxable</th>
                    <th className="py-2.5 px-2 text-center w-12">GST%</th>
                    <th className="py-2.5 px-2 text-right w-20">GST Tax</th>
                    <th className="py-2.5 px-3 text-right w-24">Net Amount</th>
                    <th className="py-2.5 px-2 text-center w-10">Act</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {lineItems.length === 0 ? (
                    <tr>
                      <td colSpan={12} className="py-8 text-center text-slate-500 font-sans">
                        No inward items added yet.
                      </td>
                    </tr>
                  ) : (
                    lineItems.map((line, idx) => (
                      <tr key={line.id} className="hover:bg-slate-800/40 transition">
                        <td className="py-2.5 px-2.5 text-center text-slate-400">{idx + 1}</td>
                        <td className="py-2.5 px-3 font-sans font-medium text-slate-100">{line.itemName}</td>
                        <td className="py-2.5 px-2 text-center text-slate-300">{line.hsnCode}</td>
                        <td className="py-2.5 px-2 text-right font-bold text-orange-400">{line.quantity} {line.unit}</td>
                        <td className="py-2.5 px-2 text-right">₹{line.rate.toFixed(2)}</td>
                        <td className="py-2.5 px-2 text-right text-emerald-400 font-semibold">
                          {line.sellingRate !== undefined && line.sellingRate !== null ? `₹${line.sellingRate.toFixed(2)}` : '-'}
                        </td>
                        <td className="py-2.5 px-2 text-right text-sky-400 font-semibold">
                          {line.mrp !== undefined && line.mrp !== null ? `₹${line.mrp.toFixed(2)}` : '-'}
                        </td>
                        <td className="py-2.5 px-2 text-right font-semibold">₹{line.taxableAmount.toFixed(2)}</td>
                        <td className="py-2.5 px-2 text-center">{line.gstRate}%</td>
                        <td className="py-2.5 px-2 text-right text-sky-400">
                          ₹{(line.cgstAmount + line.sgstAmount + line.igstAmount).toFixed(2)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-orange-300 text-sm">
                          ₹{line.netAmount.toFixed(2)}
                        </td>
                        <td className="py-2.5 px-2 text-center">
                          <button
                            onClick={() => handleRemoveLineItem(idx)}
                            className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-slate-800/60 transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Financial Summary & Save */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            <div className="lg:col-span-5 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-xs space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Remarks / Freight / Vehicle Info</label>
                <textarea
                  rows={2}
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="e.g. Received via VRL Logistics TR-9982"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg p-2 text-slate-100 focus:border-orange-500 focus:outline-none"
                />
              </div>
              <div>
                <span className="text-slate-400">Total Inward Units: </span>
                <strong className="text-orange-400 font-mono">{totalQuantity} Pairs</strong>
              </div>
            </div>

            <div className="lg:col-span-7 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-xs space-y-3 text-slate-300">
              <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-700/50 backdrop-blur-sm">
                <div className="grid grid-cols-3 gap-2 font-mono">
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Taxable Amount</span>
                    <span className="font-semibold text-slate-200">₹{totalTaxable.toFixed(2)}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Total GST (ITC)</span>
                    <span className="font-semibold text-sky-400">₹{totalTax.toFixed(2)}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Round Off</span>
                    <span>{roundOff.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Frosted Grand Total Callout */}
              <div className="bg-orange-600/20 p-4 sm:p-5 rounded-xl border border-orange-500/40 flex flex-col justify-center shadow-inner backdrop-blur-md">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs uppercase font-black text-orange-400 tracking-widest block">
                      Total Inward Bill Amount
                    </span>
                    <span className="text-[10px] text-orange-300 italic mt-0.5 block">
                      Stock automatically incremented in inventory
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-2xl sm:text-3xl font-mono text-white font-bold leading-tight">
                      ₹{grandTotal.toLocaleString('en-IN')}.00
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-700/40">
                <button
                  id="btn-save-purchase"
                  type="button"
                  onClick={handleSavePurchase}
                  className="flex items-center gap-1.5 px-5 py-2 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-lg shadow-lg shadow-orange-900/30 border border-orange-500/30 transition-all cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Inward Purchase Bill</span>
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Tab 2: New Purchase Voucher (No Stock Entry) */}
      {activeTab === 'purchase_voucher' && (
        <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-5 shadow-xl backdrop-blur-md text-slate-100 space-y-5">
          {/* Informational banner */}
          <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-lg p-3.5 text-xs text-emerald-200 flex items-start gap-3">
            <FileCheck2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-emerald-300">Direct Purchase Voucher Entry (No Stock Entry)</h4>
              <p className="text-[11px] text-emerald-200/80 mt-0.5">
                Record purchase bill details directly into the selected supplier's account payable balance without modifying inventory stock levels.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            {/* 1. PURCHASE BILL NUMBER */}
            <div className="bg-slate-900/70 border border-slate-700/60 p-3 rounded-xl space-y-1">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                1. Purchase Bill Number
              </label>
              <input
                type="text"
                value={purchaseInvoiceNo}
                readOnly={true}
                placeholder="e.g. PUR-001"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-500 font-mono font-bold text-sm focus:border-slate-700 focus:outline-none cursor-not-allowed"
              />
              <span className="text-[10px] text-slate-500">Auto-suggested (editable) purchase voucher ID</span>
            </div>

            {/* 2. BILL DATE */}
            <div className="bg-slate-900/70 border border-slate-700/60 p-3 rounded-xl space-y-1">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                2. Bill Date *
              </label>
              <input
                type="date"
                required
                value={voucherBillDate}
                onChange={(e) => setVoucherBillDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 font-mono text-xs focus:border-emerald-500 focus:outline-none"
              />
              <span className="text-[10px] text-slate-500">Date of purchase bill</span>
            </div>

            {/* 3. SUPPLIER BILL NUMBER */}
            <div className="bg-slate-900/70 border border-slate-700/60 p-3 rounded-xl space-y-1">
              <label className="block text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                3. Supplier Bill Number *
              </label>
              <input
                type="text"
                required
                value={voucherSupplierBillNo}
                onChange={(e) => setVoucherSupplierBillNo(e.target.value)}
                placeholder="e.g. SUP-BILL-9901"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 font-mono font-bold text-xs focus:border-emerald-500 focus:outline-none"
              />
              <span className="text-[10px] text-slate-500">Vendor's reference / tax invoice number</span>
            </div>

            {/* 4. SELECT SUPPLIER */}
            <div className="bg-slate-900/70 border border-slate-700/60 p-3 rounded-xl space-y-1 lg:col-span-2">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                4. Select Supplier *
              </label>
              <select
                value={voucherSupplierId}
                onChange={(e) => setVoucherSupplierId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 font-semibold focus:border-emerald-500 focus:outline-none text-xs"
              >
                <option value="">-- Choose Registered Supplier --</option>
                {suppliersList.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.supplierName}
                  </option>
                ))}
              </select>
              {selectedVoucherSupplier && (
                <div className="flex items-center gap-2 pt-1 text-[11px] text-slate-400">
                  <span>Code: <strong className="text-orange-400 font-mono">{selectedVoucherSupplier.supplierCode}</strong></span>
                  <span>•</span>
                  <span>GSTIN: <strong className="text-slate-200 font-mono">{selectedVoucherSupplier.gstin || 'None'}</strong></span>
                </div>
              )}
            </div>

            {/* 5. PURCHASE TYPE: CREDIT LINE */}
            <div className="bg-slate-900/70 border border-slate-700/60 p-3 rounded-xl space-y-1">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                5. Purchase Type
              </label>
              <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-lg border border-slate-800">
                <button
                  type="button"
                  onClick={() => setVoucherPurchaseType('Credit Line')}
                  className={`flex-1 py-1 px-2 rounded text-xs font-bold transition-all cursor-pointer ${
                    voucherPurchaseType === 'Credit Line'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Credit Line
                </button>
                <button
                  type="button"
                  onClick={() => setVoucherPurchaseType('Cash')}
                  className={`flex-1 py-1 px-2 rounded text-xs font-bold transition-all cursor-pointer ${
                    voucherPurchaseType === 'Cash'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Cash Purchase
                </button>
              </div>
              <span className="text-[10px] text-purple-300 block pt-0.5 font-medium">
                Default: Credit Line (Adds payable balance to supplier account)
              </span>
            </div>

            {/* 6. TOTAL INWARD BILL AMOUNT */}
            <div className="bg-emerald-950/30 border border-emerald-500/50 p-4 rounded-xl space-y-1 md:col-span-2 lg:col-span-3">
              <label className="block text-xs font-black text-emerald-400 uppercase tracking-wider">
                6. TOTAL INWARD BILL AMOUNT (₹) *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-emerald-400 font-bold text-lg font-mono">₹</span>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  required
                  value={voucherTotalAmount}
                  onChange={(e) => setVoucherTotalAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="0.00"
                  className="w-full bg-slate-950/90 border border-emerald-500/60 rounded-xl pl-8 pr-4 py-2.5 text-emerald-300 font-mono font-bold text-xl focus:border-emerald-400 focus:outline-none shadow-inner"
                />
              </div>
              <p className="text-[11px] text-slate-400 pt-1">
                Enter the total final bill amount of the inward invoice to be credited to the supplier's ledger.
              </p>
            </div>
          </div>

          {/* Additional details & Balance preview */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="bg-slate-900/70 border border-slate-700/60 p-3.5 rounded-xl space-y-2">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Remarks / Voucher Particulars
              </label>
              <textarea
                rows={3}
                value={voucherRemarks}
                onChange={(e) => setVoucherRemarks(e.target.value)}
                placeholder="e.g. Direct purchase bill entry without stock items for bulk raw materials / services..."
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-100 text-xs focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div className="bg-slate-900/70 border border-slate-700/60 p-3.5 rounded-xl flex flex-col justify-between space-y-3">
              <div className="space-y-2 text-xs">
                <h4 className="font-bold text-slate-300 border-b border-slate-800 pb-1.5 flex items-center justify-between">
                  <span>Supplier Account Balance Impact</span>
                  <span className="text-[10px] font-mono text-purple-400 font-normal">Ledger Update</span>
                </h4>
                <div className="flex items-center justify-between font-mono text-slate-400">
                  <span>Previous Balance:</span>
                  <span className="text-slate-200">{formatCurrency(voucherPrevBal)} Cr</span>
                </div>
                <div className="flex items-center justify-between font-mono text-emerald-400 font-bold">
                  <span>Voucher Inward Amount:</span>
                  <span>+ {formatCurrency(voucherAmountVal)}</span>
                </div>
                <div className="flex items-center justify-between font-mono text-slate-100 font-bold pt-1.5 border-t border-slate-800 text-sm">
                  <span>New Supplier Balance:</span>
                  <span className="text-orange-400">{formatCurrency(voucherNewBal)} Cr</span>
                </div>
              </div>

              <button
                id="btn-post-purchase-voucher"
                type="button"
                onClick={handleSaveDirectVoucher}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow-lg shadow-emerald-900/30 border border-emerald-500/30 transition-all cursor-pointer text-xs"
              >
                <Save className="w-4 h-4" />
                <span>Post Purchase Voucher (Save to Ledger)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Past Purchases History Modal */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4">
          <div className="bg-slate-900/90 border border-slate-700/60 rounded-xl shadow-2xl backdrop-blur-xl w-full max-w-4xl max-h-[85vh] flex flex-col text-slate-100">
            <div className="p-3.5 bg-slate-900/80 border-b border-slate-700/50 flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-100">Past Purchase Inward Records</h3>
              <button
                onClick={() => setShowHistoryModal(false)}
                className="text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/50 text-xs transition"
              >
                Close
              </button>
            </div>

            <div className="overflow-y-auto flex-1 p-3">
              <table className="w-full text-xs text-left border-collapse font-mono">
                <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md">
                  <tr>
                    <th className="p-2.5">Inward No</th>
                    <th className="p-2.5">Supplier Bill No</th>
                    <th className="p-2.5">Date</th>
                    <th className="p-2.5">Supplier</th>
                    <th className="p-2.5 text-center">Items</th>
                    <th className="p-2.5 text-right">Taxable</th>
                    <th className="p-2.5 text-right">GST (ITC)</th>
                    <th className="p-2.5 text-right">Grand Total</th>
                    <th className="p-2.5 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {pastPurchases.map((pur) => (
                    <tr key={pur.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-2.5 font-bold text-orange-400">{pur.purchaseInvoiceNo}</td>
                      <td className="p-2.5 text-slate-200">{pur.supplierBillNo}</td>
                      <td className="p-2.5 text-slate-300">{pur.purchaseDate}</td>
                      <td className="p-2.5 font-sans font-medium text-slate-100">{pur.supplierName}</td>
                      <td className="p-2.5 text-center">{pur.totalQuantity}</td>
                      <td className="p-2.5 text-right">₹{pur.totalTaxable.toFixed(2)}</td>
                      <td className="p-2.5 text-right text-sky-400">₹{pur.totalTax.toFixed(2)}</td>
                      <td className="p-2.5 text-right font-bold text-orange-300 text-sm">
                        ₹{pur.grandTotal.toFixed(2)}
                      </td>
                      <td className="p-2.5 text-center">
                        <button
                          onClick={() => setPurchaseToDelete({ id: pur.id, no: pur.purchaseInvoiceNo })}
                          className="px-2 py-1 bg-rose-950/60 hover:bg-rose-900 text-rose-300 rounded border border-rose-800/60 transition flex items-center gap-1 mx-auto text-[11px] font-medium cursor-pointer"
                          title="Delete / Void Purchase Bill"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                          <span>Delete</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {purchaseToDelete && (
        <ConfirmModal
          title="Delete / Return Purchase Bill?"
          message={`Are you sure you want to delete / void Purchase Bill #${purchaseToDelete.no}? This will automatically deduct the received quantities from current stock and reverse the supplier's balance in the ledger.`}
          confirmLabel="Yes, Delete Bill"
          cancelLabel="Cancel"
          isDestructive={true}
          onConfirm={handleConfirmDelete}
          onCancel={() => setPurchaseToDelete(null)}
        />
      )}
    </div>
  );
};
