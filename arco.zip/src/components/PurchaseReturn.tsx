import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  Calendar,
  Truck,
  RotateCcw,
  Trash2,
  Save,
  Printer,
  Plus,
  ArrowLeft,
  CheckCircle,
  AlertCircle,
  Clock,
  ChevronRight,
  FileText,
  DollarSign,
  Tag,
  Hash,
  X,
  Edit3,
  Package,
  Layers,
  Building2,
  Lock,
} from 'lucide-react';
import { CompanyInfo, InvoiceItem, Item, PurchaseInvoice, Supplier } from '../types';
import { dbService } from '../services/storage';
import { calculateLineGST, formatCurrency, roundTo2, numberToWords } from '../services/gstCalculations';
import { ConfirmModal } from './ConfirmModal';
import { SuccessPopup } from './SuccessPopup';

interface PurchaseReturnProps {
  company: CompanyInfo;
  onNavigateToPurchases?: () => void;
}

type DateFilterPreset = 'today' | 'yesterday' | 'last7' | 'thisMonth' | 'all' | 'custom';

export const PurchaseReturnComponent: React.FC<PurchaseReturnProps> = ({
  company,
  onNavigateToPurchases,
}) => {
  // Master Data
  const [allPurchases, setAllPurchases] = useState<PurchaseInvoice[]>([]);
  const [itemsList, setItemsList] = useState<Item[]>([]);
  const [suppliersList, setSuppliersList] = useState<Supplier[]>([]);

  // Filter States
  const todayStr = new Date().toISOString().split('T')[0];
  const [datePreset, setDatePreset] = useState<DateFilterPreset>('today');
  const [startDate, setStartDate] = useState<string>(todayStr);
  const [endDate, setEndDate] = useState<string>(todayStr);
  const [selectedSupplierIdFilter, setSelectedSupplierIdFilter] = useState<string>('ALL');
  const [purchaseTypeFilter, setPurchaseTypeFilter] = useState<'ALL' | 'Cash' | 'Credit Line'>('ALL');
  const [billNoFilter, setBillNoFilter] = useState<string>('');
  const [itemNameFilter, setItemNameFilter] = useState<string>('');

  // Selected Bill for Viewing / Editing / Returning
  const [selectedPurchase, setSelectedPurchase] = useState<PurchaseInvoice | null>(null);

  // Editable fields for the selected bill
  const [editPurchaseType, setEditPurchaseType] = useState<'Cash' | 'Credit Line'>('Credit Line');
  const [editManualSupplierName, setEditManualSupplierName] = useState<string>('');
  const [editPurchaseDate, setEditPurchaseDate] = useState<string>('');
  const [editSupplierBillNo, setEditSupplierBillNo] = useState<string>('');
  const [editSupplierId, setEditSupplierId] = useState<string>('');
  const [editSupplierName, setEditSupplierName] = useState<string>('');
  const [editSupplierGstin, setEditSupplierGstin] = useState<string>('');
  const [editSupplierAddress, setEditSupplierAddress] = useState<string>('');
  const [editSupplierStateCode, setEditSupplierStateCode] = useState<string>('09');
  const [editPaymentMode, setEditPaymentMode] = useState<'Credit' | 'Bank/NEFT' | 'Cash' | 'Bank'>('Credit');
  const [editRemarks, setEditRemarks] = useState<string>('');
  const [editLineItems, setEditLineItems] = useState<InvoiceItem[]>([]);
  const [editDirectVoucherAmount, setEditDirectVoucherAmount] = useState<number>(0);
  const [isInterState, setIsInterState] = useState<boolean>(true);

  // Quick Add Item buffer for selected bill
  const [showAddItem, setShowAddItem] = useState<boolean>(false);
  const [addSelectedItemId, setAddSelectedItemId] = useState<string>('');
  const [addManualName, setAddManualName] = useState<string>('');
  const [addQty, setAddQty] = useState<number>(6);
  const [addRate, setAddRate] = useState<number>(0);
  const [addSellingRate, setAddSellingRate] = useState<number | ''>('');
  const [addMrp, setAddMrp] = useState<number | ''>('');
  const [addDisc, setAddDisc] = useState<number>(0);

  // Modals & Feedback
  const [purchaseToDelete, setPurchaseToDelete] = useState<{ id: string; no: string } | null>(null);
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; title?: string; text: string } | null>(null);

  // Load Data
  const loadData = () => {
    setAllPurchases(dbService.getPurchases());
    setItemsList(dbService.getItems());
    setSuppliersList(dbService.getSuppliers());
  };

  useEffect(() => {
    loadData();
    return dbService.subscribe(loadData);
  }, []);

  // Handle Preset Date changes
  const handleDatePresetChange = (preset: DateFilterPreset) => {
    setDatePreset(preset);
    const now = new Date();
    const today = now.toISOString().split('T')[0];

    if (preset === 'today') {
      setStartDate(today);
      setEndDate(today);
    } else if (preset === 'yesterday') {
      const y = new Date();
      y.setDate(y.getDate() - 1);
      const yStr = y.toISOString().split('T')[0];
      setStartDate(yStr);
      setEndDate(yStr);
    } else if (preset === 'last7') {
      const d7 = new Date();
      d7.setDate(d7.getDate() - 7);
      setStartDate(d7.toISOString().split('T')[0]);
      setEndDate(today);
    } else if (preset === 'thisMonth') {
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
      setStartDate(firstDay);
      setEndDate(today);
    } else if (preset === 'all') {
      setStartDate('');
      setEndDate('');
    }
  };

  // Filter Purchases list
  const filteredPurchases = allPurchases.filter((pur) => {
    // Date filtering
    if (datePreset !== 'all') {
      const purDate = pur.purchaseDate || '';
      if (startDate && purDate < startDate) return false;
      if (endDate && purDate > endDate) return false;
    }

    // Purchase Type filter
    const isPurCash = pur.purchaseType === 'Cash' || pur.paymentMode === 'Cash' || pur.supplierId === 'SUP-CASH';
    if (purchaseTypeFilter === 'Cash' && !isPurCash) return false;
    if (purchaseTypeFilter === 'Credit Line' && isPurCash) return false;

    // Supplier filter
    if (selectedSupplierIdFilter !== 'ALL') {
      if (selectedSupplierIdFilter === 'CASH_PURCHASES') {
        if (!isPurCash) return false;
      } else if (pur.supplierId !== selectedSupplierIdFilter) {
        return false;
      }
    }

    // Bill No filter (checks supplierBillNo or purchaseNo / purchaseInvoiceNo)
    if (billNoFilter.trim()) {
      const q = billNoFilter.trim().toLowerCase();
      const supBill = (pur.supplierBillNo || '').toLowerCase();
      const purNo = (pur.purchaseNo || pur.purchaseInvoiceNo || '').toLowerCase();
      if (!supBill.includes(q) && !purNo.includes(q)) return false;
    }

    // Item Name filter
    if (itemNameFilter.trim()) {
      const q = itemNameFilter.trim().toLowerCase();
      const hasItem = pur.items.some(
        (it) =>
          it.itemName.toLowerCase().includes(q) ||
          (it.itemCode && it.itemCode.toLowerCase().includes(q))
      );
      if (!hasItem) return false;
    }

    return true;
  });

  // When user selects a bill from the Active List
  const handleSelectBill = (pur: PurchaseInvoice) => {
    setSelectedPurchase(pur);
    const isCash = pur.purchaseType === 'Cash' || pur.paymentMode === 'Cash' || pur.supplierId === 'SUP-CASH';
    setEditPurchaseType(isCash ? 'Cash' : 'Credit Line');
    setEditPurchaseDate(pur.purchaseDate || todayStr);
    setEditSupplierBillNo(pur.supplierBillNo || '');

    if (isCash) {
      setEditSupplierId('CASH_MANUAL');
      setEditManualSupplierName(pur.supplierName || 'Cash Vendor');
      setEditSupplierName(pur.supplierName || 'Cash Vendor');
      setEditSupplierGstin(pur.supplierGstin || '');
      setEditSupplierAddress(pur.supplierAddress || '');
      setEditSupplierStateCode(pur.supplierStateCode || company.stateCode || '09');
      setEditPaymentMode(pur.paymentMode === 'Bank/NEFT' ? 'Bank/NEFT' : 'Cash');
      setIsInterState(pur.isInterState ?? false);
    } else {
      setEditSupplierId(pur.supplierId || (suppliersList[0]?.id || ''));
      setEditManualSupplierName('');
      setEditSupplierName(pur.supplierName || 'Vendor');
      setEditSupplierGstin(pur.supplierGstin || '');
      setEditSupplierAddress(pur.supplierAddress || '');
      setEditSupplierStateCode(pur.supplierStateCode || '09');
      setEditPaymentMode(pur.paymentMode || 'Credit');
      setIsInterState(pur.isInterState ?? true);
    }

    setEditRemarks(pur.remarks || '');
    setEditLineItems((pur.items || []).map((line) => ({ ...line })));
    setEditDirectVoucherAmount(pur.grandTotal || 0);
    setShowAddItem(false);
    setFeedback(null);
  };

  // Deselect active bill
  const handleCloseSelectedBill = () => {
    setSelectedPurchase(null);
    setShowAddItem(false);
  };

  // Switch to Cash Purchase mode in edit form
  const handleSwitchToCashMode = () => {
    setEditPurchaseType('Cash');
    setEditSupplierId('CASH_MANUAL');
    setEditPaymentMode('Cash');
    setEditSupplierGstin('');
    setEditSupplierAddress('');
    setEditSupplierStateCode(company.stateCode || '09');
    setIsInterState(false);
  };

  // Switch to Credit Line mode in edit form
  const handleSwitchToCreditMode = () => {
    setEditPurchaseType('Credit Line');
    setEditPaymentMode('Credit');
    if (suppliersList.length > 0) {
      handleSupplierChange(suppliersList[0].id);
    } else {
      setEditSupplierId('');
    }
  };

  // Supplier change in edit form
  const handleSupplierChange = (supId: string) => {
    setEditSupplierId(supId);
    if (supId === 'CASH_MANUAL' || !supId) {
      setEditPurchaseType('Cash');
      setEditPaymentMode('Cash');
      setEditSupplierGstin('');
      setEditSupplierAddress('');
      setEditSupplierStateCode(company.stateCode || '09');
      setIsInterState(false);
    } else {
      setEditPurchaseType('Credit Line');
      setEditPaymentMode('Credit');
      const sup = suppliersList.find((s) => s.id === supId);
      if (sup) {
        setEditSupplierName(sup.supplierName);
        setEditSupplierGstin(sup.gstin || '');
        setEditSupplierAddress(sup.address || '');
        setEditSupplierStateCode(sup.stateCode || '09');
        const isInter = sup.stateCode && sup.stateCode !== company.stateCode;
        setIsInterState(Boolean(isInter));
      }
    }
  };

  // Line Item modifications
  const handleUpdateLineQty = (index: number, newQty: number) => {
    if (newQty < 0 || isNaN(newQty)) return;
    const activeTaxType = company.defaultTaxCalculation || 'Inclusive';
    const updated = [...editLineItems];
    const target = updated[index];

    const calc = calculateLineGST(
      newQty,
      target.rate,
      target.discountPercent,
      target.gstRate,
      isInterState,
      activeTaxType
    );

    updated[index] = {
      ...target,
      quantity: newQty,
      ...calc,
    };
    setEditLineItems(updated);
  };

  const handleUpdateLineRate = (index: number, newRate: number) => {
    if (newRate < 0 || isNaN(newRate)) return;
    const activeTaxType = company.defaultTaxCalculation || 'Inclusive';
    const updated = [...editLineItems];
    const target = updated[index];

    const calc = calculateLineGST(
      target.quantity,
      newRate,
      target.discountPercent,
      target.gstRate,
      isInterState,
      activeTaxType
    );

    updated[index] = {
      ...target,
      rate: newRate,
      ...calc,
    };
    setEditLineItems(updated);
  };

  const handleUpdateLineSellingRate = (index: number, newSellingRate: number) => {
    if (newSellingRate < 0 || isNaN(newSellingRate)) return;
    const updated = [...editLineItems];
    updated[index] = {
      ...updated[index],
      sellingRate: newSellingRate,
    };
    setEditLineItems(updated);
  };

  const handleUpdateLineMrp = (index: number, newMrp: number) => {
    if (newMrp < 0 || isNaN(newMrp)) return;
    const updated = [...editLineItems];
    updated[index] = {
      ...updated[index],
      mrp: newMrp,
    };
    setEditLineItems(updated);
  };

  const handleUpdateLineDiscount = (index: number, newDisc: number) => {
    if (newDisc < 0 || newDisc > 100 || isNaN(newDisc)) return;
    const activeTaxType = company.defaultTaxCalculation || 'Inclusive';
    const updated = [...editLineItems];
    const target = updated[index];

    const calc = calculateLineGST(
      target.quantity,
      target.rate,
      newDisc,
      target.gstRate,
      isInterState,
      activeTaxType
    );

    updated[index] = {
      ...target,
      discountPercent: newDisc,
      ...calc,
    };
    setEditLineItems(updated);
  };

  const handleRemoveLineItem = (index: number) => {
    if (editLineItems.length <= 1) {
      if (
        !window.confirm(
          'Removing the only item will leave this bill empty. You can delete the purchase bill instead if you want to void it. Continue removing?'
        )
      ) {
        return;
      }
    }
    const updated = editLineItems.filter((_, idx) => idx !== index);
    setEditLineItems(updated);
  };

  // Add Item to current selected bill
  const handleAddNewItemToBill = () => {
    const activeTaxType = company.defaultTaxCalculation || 'Inclusive';
    if (!addSelectedItemId && !addManualName.trim()) {
      setFeedback({
        type: 'error',
        text: 'Please select an item from master or enter custom item name.',
      });
      return;
    }
    if (addQty <= 0) {
      setFeedback({ type: 'error', text: 'Quantity must be at least 1.' });
      return;
    }
    if (addRate < 0) {
      setFeedback({ type: 'error', text: 'Rate cannot be negative.' });
      return;
    }

    let newItem: InvoiceItem;
    if (addSelectedItemId) {
      const itm = itemsList.find((i) => i.id === addSelectedItemId);
      if (!itm) return;
      const calc = calculateLineGST(
        addQty,
        addRate || itm.purchaseRate,
        addDisc,
        itm.gstRate,
        isInterState,
        activeTaxType
      );
      newItem = {
        id: `PL-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        itemId: itm.id,
        itemCode: itm.itemCode,
        itemName: itm.itemName,
        hsnCode: itm.hsnCode,
        quantity: addQty,
        unit: itm.unit,
        rate: addRate || itm.purchaseRate,
        sellingRate: addSellingRate !== '' ? Number(addSellingRate) : itm.sellingRate,
        mrp: addMrp !== '' ? Number(addMrp) : (itm.mrp || itm.sellingRate),
        gstRate: itm.gstRate,
        ...calc,
      };
    } else {
      const calc = calculateLineGST(addQty, addRate, addDisc, 5, isInterState, activeTaxType);
      newItem = {
        id: `PL-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        itemId: 'ITEM-MANUAL',
        itemCode: 'MANUAL',
        itemName: addManualName.trim(),
        hsnCode: '6403',
        quantity: addQty,
        unit: 'Pairs',
        rate: addRate,
        sellingRate: addSellingRate !== '' ? Number(addSellingRate) : undefined,
        mrp: addMrp !== '' ? Number(addMrp) : undefined,
        gstRate: 5,
        ...calc,
      };
    }

    setEditLineItems([...editLineItems, newItem]);
    setAddSelectedItemId('');
    setAddManualName('');
    setAddQty(6);
    setAddRate(0);
    setAddSellingRate('');
    setAddMrp('');
    setAddDisc(0);
    setShowAddItem(false);
  };

  // Check if original selected bill was a Direct Purchase Voucher (no item lines originally)
  const isOriginalDirectVoucher = Boolean(selectedPurchase && (!selectedPurchase.items || selectedPurchase.items.length === 0));
  const isDirectVoucherWithNoItems = editLineItems.length === 0;

  // Grand totals recalculations for selected bill
  const totalQuantity = isDirectVoucherWithNoItems ? 0 : editLineItems.reduce((acc, it) => acc + it.quantity, 0);
  const grossSubtotal = isDirectVoucherWithNoItems
    ? roundTo2(editDirectVoucherAmount)
    : roundTo2(editLineItems.reduce((acc, it) => acc + it.grossAmount, 0));
  const totalDiscount = isDirectVoucherWithNoItems
    ? 0
    : roundTo2(editLineItems.reduce((acc, it) => acc + it.discountAmount, 0));
  const totalTaxable = isDirectVoucherWithNoItems
    ? roundTo2(editDirectVoucherAmount)
    : roundTo2(editLineItems.reduce((acc, it) => acc + it.taxableAmount, 0));
  const totalCgst = isDirectVoucherWithNoItems
    ? 0
    : roundTo2(editLineItems.reduce((acc, it) => acc + it.cgstAmount, 0));
  const totalSgst = isDirectVoucherWithNoItems
    ? 0
    : roundTo2(editLineItems.reduce((acc, it) => acc + it.sgstAmount, 0));
  const totalIgst = isDirectVoucherWithNoItems
    ? 0
    : roundTo2(editLineItems.reduce((acc, it) => acc + it.igstAmount, 0));
  const totalTax = roundTo2(totalCgst + totalSgst + totalIgst);

  const exactNet = isDirectVoucherWithNoItems ? roundTo2(editDirectVoucherAmount) : (totalTaxable + totalTax);
  const roundedGrand = Math.round(exactNet);
  const roundOff = isDirectVoucherWithNoItems ? 0 : roundTo2(roundedGrand - exactNet);
  const grandTotal = isDirectVoucherWithNoItems ? roundTo2(editDirectVoucherAmount) : roundedGrand;

  // Selected supplier details & purchase mode calculation
  const isEditingCashPurchase = editPurchaseType === 'Cash' || editSupplierId === 'CASH_MANUAL';
  const currentSupplier = isEditingCashPurchase ? null : suppliersList.find((s) => s.id === editSupplierId);
  const previousBalance = currentSupplier ? currentSupplier.currentBalance : 0;
  const effectivePaid =
    isEditingCashPurchase || editPaymentMode === 'Cash' || editPaymentMode === 'Bank/NEFT'
      ? grandTotal
      : (editPaymentMode === 'Credit' ? 0 : grandTotal);
  const balanceDue = isEditingCashPurchase ? 0 : (editPaymentMode === 'Credit' ? grandTotal : 0);
  const newBalance = isEditingCashPurchase ? 0 : roundTo2(previousBalance + balanceDue);

  // Handle Save / Update Purchase Bill
  const handleSaveUpdatedBill = () => {
    if (!selectedPurchase) return;

    if (!isOriginalDirectVoucher && editLineItems.length === 0) {
      setFeedback({
        type: 'error',
        text: 'Cannot save an empty bill. Please add at least one line item or delete the bill.',
      });
      return;
    }

    if (isDirectVoucherWithNoItems && editDirectVoucherAmount <= 0) {
      setFeedback({
        type: 'error',
        text: 'Direct Purchase Voucher amount must be greater than 0.',
      });
      return;
    }

    if (!editSupplierBillNo.trim()) {
      setFeedback({
        type: 'error',
        text: 'Supplier Bill Number is required.',
      });
      return;
    }

    if (isEditingCashPurchase && !editManualSupplierName.trim() && !editSupplierName.trim()) {
      setFeedback({
        type: 'error',
        text: 'Please enter a Supplier / Vendor Name for this cash purchase bill.',
      });
      return;
    }

    const finalSupplierName = isEditingCashPurchase
      ? (editManualSupplierName.trim() || editSupplierName.trim() || 'Cash Vendor')
      : (currentSupplier ? currentSupplier.supplierName : (editSupplierName || 'Vendor'));

    const updatedPurchase: PurchaseInvoice = {
      ...selectedPurchase,
      purchaseDate: editPurchaseDate,
      supplierBillNo: editSupplierBillNo.trim(),
      supplierId: isEditingCashPurchase ? 'SUP-CASH' : (editSupplierId || 'SUP-UNREGISTERED'),
      supplierName: finalSupplierName,
      supplierGstin: isEditingCashPurchase ? (editSupplierGstin || '') : (currentSupplier?.gstin || editSupplierGstin || ''),
      supplierAddress: isEditingCashPurchase ? (editSupplierAddress || '') : (currentSupplier?.address || editSupplierAddress || ''),
      supplierStateCode: editSupplierStateCode,
      isInterState,
      purchaseType: isEditingCashPurchase ? 'Cash' : 'Credit Line',
      paymentMode: isEditingCashPurchase ? (editPaymentMode === 'Bank/NEFT' ? 'Bank/NEFT' : 'Cash') : editPaymentMode,
      remarks: editRemarks,
      items: editLineItems,
      totalQuantity,
      grossSubtotal,
      totalDiscount,
      totalTaxable,
      totalCgst,
      totalSgst,
      totalIgst,
      totalTax,
      roundOff,
      grandTotal,
      amountPaid: isEditingCashPurchase ? grandTotal : effectivePaid,
      balanceDue: isEditingCashPurchase ? 0 : balanceDue,
      previousBalance: isEditingCashPurchase ? 0 : previousBalance,
      newBalance: isEditingCashPurchase ? 0 : newBalance,
    };

    const res = dbService.savePurchaseInvoice(updatedPurchase);
    if (res.success) {
      setFeedback({
        type: 'success',
        title: 'Purchase Bill Updated Successfully',
        text: `Bill #${updatedPurchase.supplierBillNo || updatedPurchase.purchaseNo} has been updated. Stock, vendor balances, and ledger entries were recalculated.`,
      });
      setSelectedPurchase(updatedPurchase);
      loadData();
    } else {
      setFeedback({ type: 'error', text: res.message });
    }
  };

  // Handle Delete / Void Bill
  const handleConfirmDelete = () => {
    if (!purchaseToDelete) return;
    const res = dbService.deletePurchaseInvoice(purchaseToDelete.id);
    if (res.success) {
      setFeedback({
        type: 'success',
        title: 'Purchase Bill Deleted / Voided',
        text: `Bill #${purchaseToDelete.no} has been deleted. Stock addition and vendor balance have been reversed safely.`,
      });
      if (selectedPurchase && selectedPurchase.id === purchaseToDelete.id) {
        setSelectedPurchase(null);
      }
      setPurchaseToDelete(null);
      loadData();
    } else {
      setFeedback({ type: 'error', text: res.message });
      setPurchaseToDelete(null);
    }
  };

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none">
      {/* Modal Popup for Messages */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          onClose={() => setFeedback(null)}
        />
      )}

      {/* Delete Confirmation Modal */}
      {purchaseToDelete && (
        <ConfirmModal
          title="Delete / Return Purchase Bill?"
          message={`Are you sure you want to delete / void Purchase Bill #${purchaseToDelete.no}? This will automatically deduct the received quantities from current stock and reverse the supplier's balance in the ledger.`}
          confirmLabel="Yes, Delete Bill"
          cancelLabel="Cancel"
          isDestructive={true}
          onConfirm={handleConfirmDelete}
          onCancel={() => setPurchaseToDelete(null)}
        />
      )}

      {/* Header Banner */}
      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shadow-inner">
            <RotateCcw className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
              <span>Purchase Register</span>
            </h2>
            <p className="text-xs text-slate-400">
              Browse purchase bills, update inward items & rates, modify Cash vs Credit purchases, or void bills with automated stock and ledger reversal.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onNavigateToPurchases && (
            <button
              id="btn-goto-purchases"
              onClick={onNavigateToPurchases}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 border border-slate-700/50 backdrop-blur-sm text-xs font-medium transition-all"
            >
              <Truck className="w-4 h-4 text-orange-400" />
              <span>Create New Purchase</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Control Bar */}
      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-lg backdrop-blur-md text-slate-200 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-700/40 pb-2.5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
            <Filter className="w-4 h-4 text-indigo-400" />
            <span>Search & Filter Purchase Bills</span>
          </div>

          {/* Preset Buttons */}
          <div className="flex items-center gap-1 flex-wrap text-xs">
            <span className="text-[11px] text-slate-400 mr-1">Date:</span>
            {(
              [
                { id: 'today', label: 'Today (Default)' },
                { id: 'yesterday', label: 'Yesterday' },
                { id: 'last7', label: 'Last 7 Days' },
                { id: 'thisMonth', label: 'This Month' },
                { id: 'all', label: 'All Time' },
              ] as { id: DateFilterPreset; label: string }[]
            ).map((preset) => (
              <button
                key={preset.id}
                type="button"
                onClick={() => handleDatePresetChange(preset.id)}
                className={`px-2.5 py-1 rounded-md text-xs font-semibold transition ${
                  datePreset === preset.id
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-800/60 text-slate-300 hover:bg-slate-700/60 hover:text-white border border-slate-700/50'
                }`}
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>

        {/* Filter Inputs Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2.5 text-xs">
          {/* Start Date */}
          <div className="lg:col-span-2">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">From Date</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setDatePreset('custom');
              }}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-indigo-500 focus:outline-none"
            />
          </div>

          {/* End Date */}
          <div className="lg:col-span-2">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">To Date</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setDatePreset('custom');
              }}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-indigo-500 focus:outline-none"
            />
          </div>

          {/* Purchase Type Filter */}
          <div className="lg:col-span-2">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Purchase Type</label>
            <select
              value={purchaseTypeFilter}
              onChange={(e) => setPurchaseTypeFilter(e.target.value as any)}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-semibold focus:border-indigo-500 focus:outline-none"
            >
              <option value="ALL">All Purchase Types</option>
              <option value="Credit Line">Credit Line Bills</option>
              <option value="Cash">Cash Purchases</option>
            </select>
          </div>

          {/* Supplier Selector */}
          <div className="lg:col-span-3">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Filter by Supplier</label>
            <select
              value={selectedSupplierIdFilter}
              onChange={(e) => setSelectedSupplierIdFilter(e.target.value)}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-medium focus:border-indigo-500 focus:outline-none"
            >
              <option value="ALL">All Suppliers ({suppliersList.length})</option>
              <option value="CASH_PURCHASES">🟢 Cash Purchases (Non-registered / Cash)</option>
              {suppliersList.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.supplierName}
                </option>
              ))}
            </select>
          </div>

          {/* Bill Number Filter */}
          <div className="lg:col-span-1.5">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Bill / Voucher No.</label>
            <div className="relative">
              <input
                type="text"
                placeholder="e.g. 001"
                value={billNoFilter}
                onChange={(e) => setBillNoFilter(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg pl-7 pr-2 py-1.5 text-slate-100 font-mono focus:border-indigo-500 focus:outline-none"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2.5" />
            </div>
          </div>

          {/* Item Name Filter */}
          <div className="lg:col-span-1.5">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Item / Article</label>
            <div className="relative">
              <input
                type="text"
                placeholder="e.g. 6403"
                value={itemNameFilter}
                onChange={(e) => setItemNameFilter(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg pl-7 pr-2 py-1.5 text-slate-100 focus:border-indigo-500 focus:outline-none"
              />
              <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2.5" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Two-Column Layout: Active List & Bill Editor */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Left Column: Active List of Purchase Bills */}
        <div className={`space-y-3 ${selectedPurchase ? 'lg:col-span-4' : 'lg:col-span-12'}`}>
          <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-lg backdrop-blur-md">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-xs uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <span>Active Purchase Bills</span>
                <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-full text-[11px] font-mono font-bold">
                  {filteredPurchases.length} Found
                </span>
              </h3>
            </div>

            {/* Bills List Container */}
            <div className="space-y-2 max-h-[620px] overflow-y-auto pr-1">
              {filteredPurchases.length === 0 ? (
                <div className="p-8 text-center bg-slate-950/40 border border-dashed border-slate-800 rounded-lg text-slate-400">
                  <Package className="w-8 h-8 mx-auto mb-2 text-slate-500 opacity-60" />
                  <p className="text-xs font-semibold">No purchase bills found matching current filters.</p>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Try switching date preset to "All Time" or adjusting the supplier search.
                  </p>
                </div>
              ) : (
                filteredPurchases.map((pur) => {
                  const isSelected = selectedPurchase?.id === pur.id;
                  const billNoDisplay = pur.supplierBillNo || pur.purchaseNo || pur.purchaseInvoiceNo;
                  const isPurCash = pur.purchaseType === 'Cash' || pur.paymentMode === 'Cash' || pur.supplierId === 'SUP-CASH';
                  return (
                    <div
                      key={pur.id}
                      onClick={() => handleSelectBill(pur)}
                      className={`p-3 rounded-lg border transition cursor-pointer text-xs ${
                        isSelected
                          ? 'bg-indigo-950/50 border-indigo-500 text-white shadow-md'
                          : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-850 hover:border-slate-700 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1 mb-1.5">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold font-mono text-orange-400 bg-orange-950/50 border border-orange-700/40 px-1.5 py-0.5 rounded text-[11px]">
                            {billNoDisplay}
                          </span>
                          {pur.purchaseNo && pur.purchaseNo !== pur.supplierBillNo && (
                            <span className="text-[10px] font-mono text-slate-400">
                              ({pur.purchaseNo})
                            </span>
                          )}
                        </div>
                        <span className="font-mono text-slate-400 text-[11px]">{pur.purchaseDate}</span>
                      </div>

                      <div className="flex items-center justify-between text-xs font-semibold text-slate-100 mb-1">
                        <span className="truncate max-w-[180px]">{pur.supplierName}</span>
                        <span className="font-mono text-indigo-300 font-bold">
                          {formatCurrency(pur.grandTotal)}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/60">
                        <span>
                          {(!pur.items || pur.items.length === 0) ? (
                            <strong className="text-amber-400 font-bold">Direct Voucher (No Items)</strong>
                          ) : (
                            `${pur.items.length} Articles • ${pur.totalQuantity} Units`
                          )}
                        </span>
                        <div className="flex items-center gap-1">
                          {(!pur.items || pur.items.length === 0) && (
                            <span className="px-1.5 py-0.5 rounded font-bold text-[10px] bg-amber-950/70 text-amber-300 border border-amber-800/40">
                              Direct Voucher
                            </span>
                          )}
                          <span className={`px-1.5 py-0.5 rounded font-semibold text-[10px] ${
                            isPurCash
                              ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40'
                              : 'bg-purple-950/60 text-purple-300 border border-purple-800/40'
                          }`}>
                            {isPurCash ? 'Cash Purchase' : 'Credit Line'}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Selected Purchase Bill Editor & Detailed Form */}
        {selectedPurchase ? (
          <div className="lg:col-span-8 space-y-4 animate-in fade-in duration-150">
            {/* Bill Header Info Card */}
            <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 space-y-3">
              {isOriginalDirectVoucher && (
                <div className="bg-amber-950/40 border border-amber-500/40 rounded-lg p-3 text-amber-200 text-xs flex items-start gap-2.5 shadow-md">
                  <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-amber-300 flex items-center gap-1.5">
                      <span>Direct Purchase Voucher (No Stock Entry Originally)</span>
                    </span>
                    <p className="mt-0.5 text-[11.5px] text-amber-200/90 leading-relaxed">
                      This bill was originally recorded as a Direct Purchase Voucher without item stock entry (Original Voucher Amount: <strong className="font-mono text-white">{formatCurrency(selectedPurchase.grandTotal)}</strong>).
                      You can add new items to this bill below to populate inventory. The total bill value will automatically update based on the added items, and the existing supplier ledger record will be updated in-place without creating a duplicate second entry.
                    </p>
                  </div>
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-700/40 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-md bg-orange-600/20 text-orange-400 border border-orange-500/30 flex items-center justify-center">
                    <Edit3 className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2 flex-wrap">
                      <span>Editing Purchase Bill: {selectedPurchase.supplierBillNo || selectedPurchase.purchaseNo}</span>
                      <span className="text-[11px] font-mono text-orange-400 bg-orange-950/60 px-2 py-0.5 rounded border border-orange-700/40">
                        {selectedPurchase.purchaseNo}
                      </span>
                      <span className={`text-[11px] font-bold px-2 py-0.5 rounded border ${
                        isEditingCashPurchase
                          ? 'bg-emerald-950/70 text-emerald-300 border-emerald-700/50'
                          : 'bg-purple-950/70 text-purple-300 border-purple-700/50'
                      }`}>
                        {isEditingCashPurchase ? 'Cash Purchase' : 'Credit Line'}
                      </span>
                    </h3>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowPrintModal(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition"
                  >
                    <Printer className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Print Bill</span>
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setPurchaseToDelete({
                        id: selectedPurchase.id,
                        no: selectedPurchase.supplierBillNo || selectedPurchase.purchaseNo,
                      })
                    }
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/70 text-rose-300 border border-rose-800/50 text-xs font-semibold transition"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                    <span>Delete Bill</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleCloseSelectedBill}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                    title="Close"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Editable Bill Attributes */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                {/* Purchase Mode Switcher */}
                <div className="sm:col-span-3 bg-slate-900/60 border border-slate-700/60 p-2.5 rounded-lg flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Purchase Mode & Method</span>
                    <span className="text-xs font-medium text-slate-200">
                      {isEditingCashPurchase
                        ? '🟢 Cash Purchase (Supplier not in list / Direct Cash purchase)'
                        : '🟣 Credit Line (Linked to Supplier Ledger account)'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-slate-950/80 p-1 rounded-lg border border-slate-800">
                    <button
                      type="button"
                      onClick={handleSwitchToCreditMode}
                      className={`px-3 py-1 rounded text-xs font-bold transition flex items-center gap-1 ${
                        !isEditingCashPurchase
                          ? 'bg-purple-600 text-white shadow'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Building2 className="w-3.5 h-3.5" />
                      <span>Credit Line</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleSwitchToCashMode}
                      className={`px-3 py-1 rounded text-xs font-bold transition flex items-center gap-1 ${
                        isEditingCashPurchase
                          ? 'bg-emerald-600 text-white shadow'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <DollarSign className="w-3.5 h-3.5" />
                      <span>Cash Purchase</span>
                    </button>
                  </div>
                </div>

                <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
                  <label className="block text-[10px] font-bold text-orange-400 uppercase tracking-wider mb-1">Supplier Bill Number *</label>
                  <input
                    type="text"
                    required
                    value={editSupplierBillNo}
                    onChange={(e) => setEditSupplierBillNo(e.target.value)}
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-mono font-bold focus:border-orange-500 focus:outline-none"
                  />
                </div>

                <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Purchase Voucher Ref</label>
                  <input
                    type="text"
                    readOnly
                    value={selectedPurchase.purchaseNo || selectedPurchase.purchaseInvoiceNo}
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-orange-400 font-mono font-bold cursor-not-allowed"
                  />
                </div>

                <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Bill Date</label>
                  <input
                    type="date"
                    value={editPurchaseDate}
                    onChange={(e) => setEditPurchaseDate(e.target.value)}
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                {/* Direct Voucher Amount Field if no line items exist yet */}
                {isDirectVoucherWithNoItems && (
                  <div className="sm:col-span-3 bg-amber-950/40 border border-amber-600/50 p-2.5 rounded-lg backdrop-blur-sm">
                    <label className="block text-[10px] font-bold text-amber-400 uppercase tracking-wider mb-1">
                      Direct Purchase Bill Amount (₹) [Without Item Entry]
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="number"
                        min="1"
                        step="0.01"
                        value={editDirectVoucherAmount || ''}
                        onChange={(e) => setEditDirectVoucherAmount(Number(e.target.value) || 0)}
                        className="w-48 bg-slate-950/80 border border-amber-500/60 rounded-md px-2.5 py-1 text-amber-200 font-mono font-bold text-sm focus:border-amber-400 focus:outline-none"
                      />
                      <span className="text-[11px] text-amber-300/80">
                        (Note: Adding items below will calculate bill total automatically from item quantities & rates)
                      </span>
                    </div>
                  </div>
                )}
                {isEditingCashPurchase ? (
                  <>
                    <div className="sm:col-span-2 bg-slate-900/50 border border-emerald-700/40 p-2.5 rounded-lg backdrop-blur-sm">
                      <label className="block text-[10px] font-bold text-emerald-400 uppercase tracking-wider mb-1">
                        Supplier / Vendor Name (Manual) *
                      </label>
                      <input
                        type="text"
                        placeholder="Enter Supplier / Cash Vendor Name"
                        value={editManualSupplierName}
                        onChange={(e) => {
                          setEditManualSupplierName(e.target.value);
                          setEditSupplierName(e.target.value);
                        }}
                        className="w-full bg-slate-950/70 border border-emerald-600/50 rounded-md px-2 py-1 text-slate-100 font-semibold focus:border-emerald-400 focus:outline-none text-xs"
                      />
                    </div>

                    <div className="sm:col-span-1 bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Supplier GSTIN (Optional)
                      </label>
                      <input
                        type="text"
                        placeholder="GSTIN (if available)"
                        value={editSupplierGstin}
                        onChange={(e) => setEditSupplierGstin(e.target.value.toUpperCase())}
                        className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-mono text-xs focus:border-indigo-500 focus:outline-none"
                      />
                    </div>
                  </>
                ) : (
                  <div className="sm:col-span-3 bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                        SUPPLIER / MANUFACTURER
                      </label>
                      <span className="flex items-center gap-1 text-[10px] text-amber-400 font-semibold bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/50">
                        <Lock className="w-3 h-3" /> Locked
                      </span>
                    </div>
                    <div className="relative">
                      <input
                        type="text"
                        readOnly
                        disabled
                        value={
                          editSupplierName ||
                          (suppliersList.find((s) => s.id === editSupplierId)?.supplierName) ||
                          selectedPurchase.supplierName ||
                          ''
                        }
                        className="w-full bg-slate-950/80 border border-slate-700/60 rounded-md px-2.5 py-1 text-slate-200 font-semibold text-xs cursor-not-allowed select-none focus:outline-none"
                        title="Supplier / Manufacturer is locked for this recorded purchase bill"
                      />
                    </div>
                  </div>
                )}

                <div className="sm:col-span-3 bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Remarks / Note</label>
                  <input
                    type="text"
                    placeholder="Optional remarks"
                    value={editRemarks}
                    onChange={(e) => setEditRemarks(e.target.value)}
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 focus:border-indigo-500 focus:outline-none text-xs"
                  />
                </div>
              </div>

              {/* Status info bar */}
              <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400">Supplier GSTIN:</span>
                  <span className="font-mono font-semibold text-slate-200">
                    {editSupplierGstin || (isEditingCashPurchase ? 'Unregistered / Cash' : 'N/A')}
                  </span>
                </div>
                <div>
                  {isEditingCashPurchase ? (
                    <span className="text-emerald-400 font-medium">
                      Cash Purchase: Paid in full (₹0.00 Ledger Balance Added)
                    </span>
                  ) : (
                    <span className="text-slate-300">
                      Previous Balance:{' '}
                      <strong className="text-amber-400 font-mono">
                        {formatCurrency(previousBalance)} Cr
                      </strong>
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Add Item Bar */}
            <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-lg backdrop-blur-md">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-orange-400" />
                  <span>Add More Inward Items to This Bill</span>
                </span>
                {!showAddItem && (
                  <button
                    type="button"
                    onClick={() => setShowAddItem(true)}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-orange-600 hover:bg-orange-500 text-white font-semibold text-xs shadow transition"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Item</span>
                  </button>
                )}
              </div>

              {showAddItem && (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-12 gap-2 text-xs items-end bg-slate-950/60 p-3 rounded-lg border border-slate-800 animate-in fade-in duration-100">
                  <div className="sm:col-span-2 md:col-span-3">
                    <label className="block text-slate-400 font-medium mb-1">Select Item from Catalog</label>
                    <select
                      value={addSelectedItemId}
                      onChange={(e) => {
                        setAddSelectedItemId(e.target.value);
                        const itm = itemsList.find((i) => i.id === e.target.value);
                        if (itm) {
                          setAddRate(itm.purchaseRate || 0);
                          setAddSellingRate(itm.sellingRate !== undefined && itm.sellingRate !== null ? itm.sellingRate : '');
                          setAddMrp(itm.mrp !== undefined && itm.mrp !== null ? itm.mrp : (itm.sellingRate || ''));
                        } else {
                          setAddRate(0);
                          setAddSellingRate('');
                          setAddMrp('');
                        }
                      }}
                      className="w-full bg-slate-900 border border-slate-700 rounded-md px-2 py-1.5 text-slate-100 focus:border-orange-500 focus:outline-none text-xs"
                    >
                      <option value="">-- Choose Item --</option>
                      {itemsList.map((i) => (
                        <option key={i.id} value={i.id}>
                          {i.itemCode} - {i.itemName} (Stock: {i.currentStock} | Cost: ₹{i.purchaseRate})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="sm:col-span-1 md:col-span-1">
                    <label className="block text-slate-400 font-medium mb-1">Inward Qty</label>
                    <input
                      type="number"
                      min="1"
                      value={addQty}
                      onChange={(e) => setAddQty(Math.max(1, Number(e.target.value)))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-md px-2 py-1.5 text-slate-100 font-mono font-bold focus:border-orange-500 focus:outline-none text-xs"
                    />
                  </div>

                  {/* Cost box before Selling Rate */}
                  <div className="sm:col-span-1 md:col-span-2">
                    <label className="block text-slate-400 font-medium mb-1">Cost Rate (₹)</label>
                    <input
                      type="number"
                      value={addRate}
                      onChange={(e) => setAddRate(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-md px-2 py-1.5 text-slate-100 font-mono focus:border-orange-500 focus:outline-none text-xs"
                    />
                  </div>

                  {/* Selling Rate box after Cost */}
                  <div className="sm:col-span-1 md:col-span-2">
                    <label className="block text-emerald-400 font-medium mb-1">Selling Rate (₹)</label>
                    <input
                      type="number"
                      value={addSellingRate}
                      onChange={(e) => setAddSellingRate(e.target.value === '' ? '' : Number(e.target.value))}
                      placeholder="Sale Price"
                      className="w-full bg-slate-900 border border-emerald-500/40 rounded-md px-2 py-1.5 text-emerald-300 font-mono font-semibold focus:border-emerald-400 focus:outline-none text-xs"
                    />
                  </div>

                  {/* MRP Print box after Selling Rate */}
                  <div className="sm:col-span-1 md:col-span-2">
                    <label className="block text-sky-400 font-medium mb-1">MRP Print (₹)</label>
                    <input
                      type="number"
                      value={addMrp}
                      onChange={(e) => setAddMrp(e.target.value === '' ? '' : Number(e.target.value))}
                      placeholder="Printed MRP"
                      className="w-full bg-slate-900 border border-sky-500/40 rounded-md px-2 py-1.5 text-sky-300 font-mono font-semibold focus:border-sky-400 focus:outline-none text-xs"
                    />
                  </div>

                  <div className="sm:col-span-2 md:col-span-2 flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={handleAddNewItemToBill}
                      className="flex-1 px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-md transition shadow text-xs"
                    >
                      Add Line
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowAddItem(false);
                        setAddSellingRate('');
                        setAddMrp('');
                      }}
                      className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md transition text-xs"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Line Items Table */}
            <div className="bg-slate-900/20 border border-slate-700/50 rounded-xl shadow-xl backdrop-blur-md overflow-hidden text-slate-200">
              <div className="overflow-x-auto max-h-80">
                <table className="w-full text-xs text-left border-collapse">
                  <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md">
                    <tr>
                      <th className="py-2.5 px-2 w-8 text-center">#</th>
                      <th className="py-2.5 px-3">Item Details</th>
                      <th className="py-2.5 px-2 text-center w-16">HSN</th>
                      <th className="py-2.5 px-2 text-right w-20">Inward Qty</th>
                      <th className="py-2.5 px-2 text-right w-20">Cost (₹)</th>
                      <th className="py-2.5 px-2 text-right w-20">Selling Rate</th>
                      <th className="py-2.5 px-2 text-right w-20">MRP Print</th>
                      <th className="py-2.5 px-2 text-right w-20">Taxable</th>
                      <th className="py-2.5 px-2 text-center w-12">GST%</th>
                      <th className="py-2.5 px-2 text-right w-20">Tax (₹)</th>
                      <th className="py-2.5 px-3 text-right w-24">Net Amount</th>
                      <th className="py-2.5 px-2 text-center w-10">Act</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {editLineItems.length === 0 ? (
                      <tr>
                        <td colSpan={12} className="py-8 text-center text-slate-500 font-sans">
                          No items in this purchase bill.
                        </td>
                      </tr>
                    ) : (
                      editLineItems.map((line, idx) => (
                        <tr key={line.id || idx} className="hover:bg-slate-800/40 transition">
                          <td className="py-2.5 px-2 text-center text-slate-400">{idx + 1}</td>
                          <td className="py-2.5 px-3 font-sans font-medium text-slate-100">
                            <div>{line.itemName}</div>
                            {line.itemCode && (
                              <div className="text-[10px] text-slate-400 font-mono">{line.itemCode}</div>
                            )}
                          </td>
                          <td className="py-2.5 px-2 text-center text-slate-300">{line.hsnCode || '6403'}</td>
                          <td className="py-2.5 px-2 text-right">
                            <input
                              type="number"
                              min="1"
                              value={line.quantity}
                              onChange={(e) => handleUpdateLineQty(idx, Number(e.target.value))}
                              className="w-16 bg-slate-950/80 border border-slate-700/60 rounded px-1.5 py-0.5 text-right font-bold text-orange-400 font-mono focus:border-orange-500 focus:outline-none"
                            />
                          </td>
                          <td className="py-2.5 px-2 text-right">
                            <input
                              type="number"
                              value={line.rate}
                              onChange={(e) => handleUpdateLineRate(idx, Number(e.target.value))}
                              className="w-20 bg-slate-950/80 border border-slate-700/60 rounded px-1.5 py-0.5 text-right font-mono focus:border-orange-500 focus:outline-none"
                            />
                          </td>
                          <td className="py-2.5 px-2 text-right">
                            <input
                              type="number"
                              value={line.sellingRate !== undefined && line.sellingRate !== null ? line.sellingRate : ''}
                              onChange={(e) => handleUpdateLineSellingRate(idx, Number(e.target.value) || 0)}
                              placeholder="0.00"
                              className="w-16 bg-slate-950/80 border border-emerald-500/40 rounded px-1.5 py-0.5 text-right font-mono text-emerald-300 font-semibold focus:border-emerald-400 focus:outline-none"
                            />
                          </td>
                          <td className="py-2.5 px-2 text-right">
                            <input
                              type="number"
                              value={line.mrp !== undefined && line.mrp !== null ? line.mrp : ''}
                              onChange={(e) => handleUpdateLineMrp(idx, Number(e.target.value) || 0)}
                              placeholder="0.00"
                              className="w-16 bg-slate-950/80 border border-sky-500/40 rounded px-1.5 py-0.5 text-right font-mono text-sky-300 font-semibold focus:border-sky-400 focus:outline-none"
                            />
                          </td>
                          <td className="py-2.5 px-2 text-right font-semibold">₹{line.taxableAmount.toFixed(2)}</td>
                          <td className="py-2.5 px-2 text-center text-slate-300">{line.gstRate}%</td>
                          <td className="py-2.5 px-2 text-right text-slate-300">
                            ₹{(line.cgstAmount + line.sgstAmount + line.igstAmount).toFixed(2)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-bold text-emerald-400">
                            ₹{line.netAmount.toFixed(2)}
                          </td>
                          <td className="py-2.5 px-2 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveLineItem(idx)}
                              className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-950/50 transition"
                              title="Remove item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              {/* Financial Calculation Summary Bar */}
              <div className="bg-slate-950/80 p-3.5 border-t border-slate-700/50 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-3 text-slate-400 flex-wrap">
                  <span>Total Qty: <strong className="text-slate-100 font-mono">{totalQuantity}</strong></span>
                  <span>•</span>
                  <span>Taxable: <strong className="text-slate-100 font-mono">₹{totalTaxable.toFixed(2)}</strong></span>
                  <span>•</span>
                  <span>Total Tax: <strong className="text-slate-100 font-mono">₹{totalTax.toFixed(2)}</strong></span>
                  <span>•</span>
                  <span>Round Off: <strong className="text-slate-300 font-mono">{roundOff >= 0 ? `+${roundOff.toFixed(2)}` : roundOff.toFixed(2)}</strong></span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-slate-400 text-xs uppercase font-bold">Grand Total:</span>
                  <span className="text-xl font-bold font-mono text-orange-400 bg-orange-950/60 px-3 py-1 rounded-lg border border-orange-700/40">
                    {formatCurrency(grandTotal)}
                  </span>
                </div>
              </div>
            </div>

            {/* Bottom Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={handleCloseSelectedBill}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition"
              >
                Cancel / Close
              </button>

              <button
                id="btn-save-purchase-updates"
                type="button"
                onClick={handleSaveUpdatedBill}
                className="flex items-center gap-2 px-5 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold rounded-lg text-xs shadow-lg shadow-orange-900/30 border border-orange-400/30 transition"
              >
                <Save className="w-4 h-4" />
                <span>Save / Update Purchase Bill</span>
              </button>
            </div>
          </div>
        ) : (
          /* Empty selection placeholder when in multi-column view */
          <div className="hidden lg:block lg:col-span-8 bg-slate-900/30 border border-dashed border-slate-800 rounded-xl p-12 text-center text-slate-400">
            <Package className="w-12 h-12 mx-auto mb-3 text-slate-600" />
            <h4 className="font-bold text-sm text-slate-200">No Purchase Bill Selected</h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
              Select a purchase bill from the list on the left to view full inward details, modify quantities or rates, add items, or delete/void the bill.
            </p>
          </div>
        )}
      </div>

      {/* Purchase Bill Print Modal */}
      {showPrintModal && selectedPurchase && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center bg-black/75 backdrop-blur-md p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static">
          <div className="bg-slate-900/95 border border-slate-700/60 rounded-xl shadow-2xl backdrop-blur-xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden print:border-none print:shadow-none print:max-h-none print:max-w-none print:w-full print:bg-white print:rounded-none">
            {/* Header */}
            <div className="p-3 bg-slate-950/80 text-white flex items-center justify-between gap-3 border-b border-slate-700/50 print:hidden backdrop-blur-sm">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-orange-400" />
                <span className="font-bold text-sm">Purchase Bill Voucher: {selectedPurchase.supplierBillNo || selectedPurchase.purchaseNo}</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-lg text-xs shadow transition"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print [Ctrl+P]</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowPrintModal(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Content */}
            <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-white text-slate-900 font-sans print:p-0">
              <div className="border border-slate-900 text-[11px] leading-tight text-black max-w-full">
                <div className="border-b border-slate-900 p-3 text-center bg-slate-50">
                  <h1 className="text-lg font-black uppercase tracking-wider">{company.companyName}</h1>
                  <p className="text-[10px] text-slate-600">{company.addressLine1 || company.addressLine2 || ''}, {company.city} - {company.state} (Code: {company.stateCode})</p>
                  <p className="text-[10px] font-bold font-mono">GSTIN: {company.gstin} | Phone: {company.mobile || company.phone}</p>
                  <div className="mt-1 text-xs font-bold uppercase underline">PURCHASE INWARD VOUCHER / BILL</div>
                </div>

                <div className="grid grid-cols-2 border-b border-slate-900 p-2.5 text-xs bg-slate-50/30">
                  <div>
                    <p className="font-bold">Supplier: {selectedPurchase.supplierName}</p>
                    <p className="text-slate-600">GSTIN: {selectedPurchase.supplierGstin || 'Unregistered'}</p>
                    <p className="text-slate-600">{selectedPurchase.supplierAddress || 'Local / Cash Purchase'}</p>
                  </div>
                  <div className="text-right font-mono">
                    <p><strong>Supplier Bill No:</strong> {selectedPurchase.supplierBillNo}</p>
                    <p><strong>Voucher No:</strong> {selectedPurchase.purchaseNo}</p>
                    <p><strong>Bill Date:</strong> {selectedPurchase.purchaseDate}</p>
                    <p><strong>Purchase Type:</strong> {selectedPurchase.purchaseType || (selectedPurchase.paymentMode === 'Cash' || selectedPurchase.supplierId === 'SUP-CASH' ? 'Cash Purchase' : 'Credit Line')}</p>
                  </div>
                </div>

                <table className="w-full text-xs text-left border-collapse">
                  <thead className="bg-slate-100 border-b border-slate-900 font-bold">
                    <tr>
                      <th className="p-2 w-8 text-center border-r border-slate-900">#</th>
                      <th className="p-2 border-r border-slate-900">Description of Goods</th>
                      <th className="p-2 text-center w-16 border-r border-slate-900">HSN</th>
                      <th className="p-2 text-right w-16 border-r border-slate-900">Qty</th>
                      <th className="p-2 text-right w-20 border-r border-slate-900">Rate</th>
                      <th className="p-2 text-right w-24 border-r border-slate-900">Taxable</th>
                      <th className="p-2 text-right w-24">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-300 font-mono">
                    {selectedPurchase.items.map((it, idx) => (
                      <tr key={idx}>
                        <td className="p-2 text-center border-r border-slate-900">{idx + 1}</td>
                        <td className="p-2 font-sans font-medium border-r border-slate-900">{it.itemName}</td>
                        <td className="p-2 text-center border-r border-slate-900">{it.hsnCode}</td>
                        <td className="p-2 text-right border-r border-slate-900 font-bold">{it.quantity} {it.unit}</td>
                        <td className="p-2 text-right border-r border-slate-900">₹{it.rate.toFixed(2)}</td>
                        <td className="p-2 text-right border-r border-slate-900">₹{it.taxableAmount.toFixed(2)}</td>
                        <td className="p-2 text-right font-bold">₹{it.netAmount.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="border-t border-slate-900 font-bold bg-slate-50 font-mono">
                    <tr>
                      <td colSpan={3} className="p-2 text-right border-r border-slate-900">TOTAL:</td>
                      <td className="p-2 text-right border-r border-slate-900">{selectedPurchase.totalQuantity}</td>
                      <td className="p-2 border-r border-slate-900"></td>
                      <td className="p-2 text-right border-r border-slate-900">₹{selectedPurchase.totalTaxable.toFixed(2)}</td>
                      <td className="p-2 text-right text-black font-black">₹{selectedPurchase.grandTotal.toFixed(2)}</td>
                    </tr>
                  </tfoot>
                </table>

                <div className="p-3 border-t border-slate-900 bg-slate-50 flex items-center justify-between text-xs">
                  <div>
                    <p className="font-bold">Amount in Words:</p>
                    <p className="italic text-slate-700">{numberToWords(selectedPurchase.grandTotal)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-slate-500 mb-6">Authorised Signatory</p>
                    <p className="font-bold">{company.companyName}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
