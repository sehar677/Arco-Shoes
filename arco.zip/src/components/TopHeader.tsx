import React, { useState, useEffect } from 'react';
import {
  Menu,
  QrCode,
  Palette,
  Keyboard,
  ShieldCheck,
  LogOut,
  PanelLeftClose,
  PanelLeftOpen,
  Printer,
  X,
  Sparkles,
  LayoutDashboard,
  ShoppingCart,
  FileText,
  Package,
  Users,
  Building2,
  Receipt,
  RotateCcw,
  BookOpen,
  ClipboardCheck,
  FileSpreadsheet,
  Settings,
  Wallet,
  Lock,
} from 'lucide-react';
import { AppTheme, CompanyInfo, ModuleTab, AdminUser } from '../types';
import { authService } from '../services/authService';
import { rbacService } from '../services/rbacService';

interface TopHeaderProps {
  currentTab: ModuleTab;
  onSelectTab: (tab: ModuleTab) => void;
  company: CompanyInfo;
  isSidebarCollapsed: boolean;
  onToggleSidebarCollapse: () => void;
  onOpenMobileMenu: () => void;
  onOpenMigration?: () => void;
  onOpenShortcuts: () => void;
  onOpenQrModal?: (amount?: number) => void;
  currentTheme: AppTheme;
  onOpenThemeSelector: () => void;
  onLogout?: () => void;
  hasPrintInvoice?: boolean;
  onClosePrintTab?: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  currentTab,
  onSelectTab,
  company,
  isSidebarCollapsed,
  onToggleSidebarCollapse,
  onOpenMobileMenu,
  onOpenMigration,
  onOpenShortcuts,
  onOpenQrModal,
  currentTheme,
  onOpenThemeSelector,
  onLogout,
  hasPrintInvoice = false,
  onClosePrintTab,
}) => {
  const [activeAdmin, setActiveAdmin] = useState<AdminUser>(() => authService.getActiveAdmin());

  useEffect(() => {
    const unsub = authService.onAuthChange(() => {
      setActiveAdmin(authService.getActiveAdmin());
    });
    return unsub;
  }, []);

  const roleInfo = rbacService.getActiveRoleInfo();

  const currentDateStr = new Date().toLocaleDateString('en-IN', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  const getModuleMeta = (tab: ModuleTab) => {
    switch (tab) {
      case 'dashboard':
        return { title: 'Dashboard', subtitle: 'Executive Overview & Analytics', icon: LayoutDashboard };
      case 'sales_invoice':
        return { title: 'Sales', subtitle: 'Retail Billing & Tax POS Counter', icon: ShoppingCart };
      case 'purchase_entry':
        return { title: 'Purchase', subtitle: 'Inward Stock & Purchase Invoice', icon: FileText };
      case 'item_master':
        return { title: 'Catalog', subtitle: 'Product Master & Catalog', icon: Package };
      case 'customer_master':
        return { title: 'Customer', subtitle: 'Customer Registry & Debtors Directory', icon: Users };
      case 'supplier_master':
        return { title: 'Supplier', subtitle: 'Supplier Registry & Vendors Directory', icon: Building2 };
      case 'customer_receipt':
        return { title: 'Receipts', subtitle: 'Customer Voucher Payment Inward', icon: Receipt };
      case 'supplier_payment':
        return { title: 'Payments', subtitle: 'Supplier Voucher Payment Outward', icon: Receipt };
      case 'sales_return':
        return { title: 'Sales Register', subtitle: 'Sales Return & Credit Notes Register', icon: RotateCcw };
      case 'purchase_return':
        return { title: 'Purchase Register', subtitle: 'Purchase Return & Debit Notes Register', icon: RotateCcw };
      case 'day_book':
        return { title: 'Day Book', subtitle: 'Daily Transaction Chronology', icon: BookOpen };
      case 'invoices':
        return { title: 'Customer Bill Reports', subtitle: 'Sales Invoices & Audit Register', icon: FileText };
      case 'bills':
        return { title: 'Supplier Bill Reports', subtitle: 'Inward Bills & Audit Register', icon: FileText };
      case 'customer_ledger':
        return { title: 'Customer Ledger', subtitle: 'Account Balance & History', icon: Users };
      case 'supplier_ledger':
        return { title: 'Supplier Ledger', subtitle: 'Account Balance & History', icon: Building2 };
      case 'cash_ledger':
        return { title: 'Cash Ledger', subtitle: 'Unregistered Supplier Accounts & Cash Transactions', icon: Wallet };
      case 'stock_adjustment':
        return { title: 'Stock Sheet', subtitle: 'Inventory Audit & Ledger', icon: ClipboardCheck };
      case 'gst_reports':
      case 'gst_register':
      case 'business_reports':
        return { title: 'GST Reports', subtitle: 'GSTR-1, GSTR-3B & Tax Summary', icon: FileSpreadsheet };
      case 'company_settings':
        return { title: 'Company Settings', subtitle: 'Configuration & Security', icon: Settings };
      case 'print_preview':
        return { title: 'Tax Invoice Print Preview', subtitle: 'Direct thermal/PDF Print Preview', icon: Printer };
      default:
        return { title: 'ARCO Billing System', subtitle: 'Footwear Showroom System', icon: LayoutDashboard };
    }
  };

  const meta = getModuleMeta(currentTab);
  const PageIcon = meta.icon;

  const getHeaderContainerClasses = () => {
    if (currentTheme === 'default') {
      return 'bg-white/95 border-b border-slate-200 text-slate-900 backdrop-blur-md shadow-sm';
    }
    if (currentTheme === 'midnight') {
      return 'bg-[#091222]/90 border-b border-[#1E293B] text-slate-100 backdrop-blur-md shadow-md';
    }
    if (currentTheme === 'clean_light') {
      return 'bg-white/95 border-b border-slate-200 text-slate-800 backdrop-blur-md shadow-sm';
    }
    if (currentTheme === 'dark') {
      return 'bg-slate-900/80 border-b border-slate-800 text-slate-100 backdrop-blur-md shadow-lg';
    }
    if (currentTheme === 'oxford') {
      return 'bg-[#0B132B]/90 border-b border-[#1C2541] text-slate-100 backdrop-blur-md shadow-lg';
    }
    if (currentTheme === 'linen' || currentTheme === 'cream' || currentTheme === 'cashmere' || currentTheme === 'porcelain') {
      return 'bg-white/90 border-b border-slate-200 text-slate-900 backdrop-blur-md shadow-sm';
    }
    if (currentTheme === 'institutional') {
      return 'bg-[#F8F5EE] text-slate-900 border-b border-[#E6DED0] shadow-sm';
    }
    if (currentTheme === 'black_gold') {
      return 'bg-[#161B22]/95 border-b border-[#30363D] text-[#F0F6FC] backdrop-blur-md shadow-lg';
    }
    if (currentTheme === 'orange_violet') {
      return 'bg-[#081433]/94 border-b border-[#493C62] text-white backdrop-blur-md shadow-lg';
    }
    return 'bg-slate-900/80 border-b border-slate-800 text-white backdrop-blur-md shadow-lg';
  };

  const isLightTheme = currentTheme === 'default' || currentTheme === 'clean_light' || currentTheme === 'linen' || currentTheme === 'cream' || currentTheme === 'cashmere';

  return (
    <header className={`sticky top-0 z-30 px-3 sm:px-6 py-3 flex items-center justify-between gap-3 select-none transition-colors duration-200 ${getHeaderContainerClasses()}`}>
      {/* Left: Mobile Drawer Trigger, Desktop Sidebar Toggle, Page Title / Breadcrumb */}
      <div className="flex items-center gap-3 min-w-0">
        {/* Mobile Hamburger Menu Button */}
        <button
          onClick={onOpenMobileMenu}
          className={`lg:hidden p-2 rounded-xl border transition cursor-pointer ${
            isLightTheme
              ? 'bg-amber-100/80 border-amber-300/80 hover:bg-amber-200 text-slate-900'
              : 'bg-slate-800/40 border-slate-700/50 hover:bg-slate-800 text-slate-200'
          }`}
          title="Open Navigation Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Desktop Collapse Sidebar Toggle Button */}
        <button
          onClick={onToggleSidebarCollapse}
          className={`hidden lg:flex p-2 rounded-xl border transition cursor-pointer ${
            isLightTheme
              ? 'bg-amber-100/60 border-amber-300/60 hover:bg-amber-200/80 text-slate-900'
              : 'bg-slate-800/20 border-slate-700/30 hover:bg-slate-800/40 text-slate-300'
          }`}
          title={isSidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
        >
          {isSidebarCollapsed ? <PanelLeftOpen className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
        </button>

        {/* Breadcrumb / Page Title */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
            currentTheme === 'default'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'bg-amber-500/15 border border-amber-500/30 text-amber-600'
          }`}>
            <PageIcon className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h2 className="font-bold text-sm sm:text-base tracking-tight truncate text-slate-900 dark:text-white">
              {meta.title}
            </h2>
            <p className="text-[10px] opacity-75 font-medium truncate hidden sm:block">
              {meta.subtitle}
            </p>
          </div>
        </div>
      </div>

      {/* Right: Date, QR Code, Shortcuts, Theme Palette, User Security, Logout */}
      <div className="flex items-center gap-2 sm:gap-3 text-xs shrink-0">
        {/* Business Date Pill */}
        <div className={`hidden md:flex flex-col items-end px-3 py-1 rounded-lg border text-[11px] ${
          isLightTheme
            ? 'bg-amber-50/90 border-amber-200/80 text-slate-900'
            : 'bg-slate-900/40 border-slate-700/40 text-slate-200'
        }`}>
          <span className="text-[9px] font-semibold opacity-60 uppercase tracking-wider">Business Date</span>
          <span className="font-mono font-bold text-amber-600">{currentDateStr}</span>
        </div>

        {/* Active Print Preview Tab Indicator if active */}
        {(currentTab === 'print_preview' || hasPrintInvoice) && (
          <div className={`flex items-center rounded-lg border overflow-hidden ${
            isLightTheme
              ? 'border-emerald-300 bg-emerald-50 text-emerald-800'
              : 'border-emerald-500/40 bg-emerald-950/40 text-emerald-200'
          }`}>
            <button
              onClick={() => onSelectTab('print_preview')}
              className="flex items-center gap-1.5 px-2.5 py-1.5 font-bold text-xs transition hover:bg-emerald-100/50"
            >
              <Printer className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
              <span className="hidden sm:inline">Print Preview</span>
            </button>
            {onClosePrintTab && (
              <button
                type="button"
                onClick={onClosePrintTab}
                className="px-1.5 py-1.5 hover:text-rose-600 hover:bg-rose-50 transition border-l border-emerald-300"
                title="Close Print Preview"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}

        {/* Show QR Code Modal Button */}
        {onOpenQrModal && (
          <button
            id="topheader-btn-qr"
            onClick={() => onOpenQrModal()}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border font-bold transition cursor-pointer ${
              isLightTheme
                ? 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-800 border-amber-400/60'
                : 'bg-amber-600/25 hover:bg-amber-600/35 text-amber-400 border border-amber-500/40'
            }`}
            title="Display UPI Payment QR Code"
          >
            <QrCode className="w-4 h-4 text-amber-600" />
            <span className="hidden sm:inline">Show QR</span>
          </button>
        )}

        {/* Select Theme Button */}
        <button
          id="topheader-btn-theme"
          onClick={onOpenThemeSelector}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border font-semibold transition cursor-pointer ${
            isLightTheme
              ? 'bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200'
              : 'bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border-blue-500/40'
          }`}
          title="Select Theme & Color Palette"
        >
          <Palette className="w-4 h-4 text-blue-600" />
          <span className="hidden xl:inline">Theme</span>
        </button>

        {/* Keyboard Shortcuts Guide Button */}
        <button
          id="topheader-btn-shortcuts"
          onClick={onOpenShortcuts}
          className={`hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border transition cursor-pointer ${
            isLightTheme
              ? 'bg-white hover:bg-slate-50 border-slate-300 text-slate-800'
              : 'bg-slate-800/40 hover:bg-slate-800/70 border-slate-700/50 text-slate-300'
          }`}
          title="Keyboard Shortcuts (F1-F10)"
        >
          <Keyboard className="w-4 h-4 text-amber-600" />
          <span className="font-mono text-[10px] bg-black/10 px-1 py-0.5 rounded border border-slate-300">F1-F10</span>
        </button>

        {/* Admin Security Profile Badge */}
        <button
          id="topheader-btn-admin"
          onClick={() => onSelectTab('company_settings')}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition cursor-pointer ${
            isLightTheme
              ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border-emerald-300'
              : 'bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-400 border-emerald-600/40'
          }`}
          title={`Logged in as ${activeAdmin.name || 'Staff User'} (${roleInfo.role}) - Click for Settings / Accounts`}
        >
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span className="hidden md:inline font-mono text-[11px] truncate max-w-[140px]">{activeAdmin.email}</span>
          <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold border hidden sm:inline ${roleInfo.color}`}>
            {roleInfo.badge}
          </span>
        </button>

        {/* Logout Button */}
        {onLogout && (
          <button
            id="topheader-btn-logout"
            onClick={onLogout}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition cursor-pointer ${
              isLightTheme
                ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200'
                : 'bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 border-rose-700/50'
            }`}
            title="Logout"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        )}
      </div>
    </header>
  );
};
