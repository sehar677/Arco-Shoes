# Security Specification: ALL J&K VOCATIONAL INSTRUCTORS

## 1. System Invariants
- **Public Transparency**: Public users (visitors, ITI staff, instructors, citizens) have read-only access to view Training Centers, Vocational Instructors, Scheme targets, Contribution summaries, and Published Notices.
- **Administrative Access Control**: Only authenticated users (Admin / Superadmin, including designated admin email `ClassmateCenter@gmail.com`) can perform mutations (Create, Update, Delete) on ITIs, Instructors, Schemes, Contributions, Notices, and Settings.
- **Data Integrity**:
  - Contribution amounts must be non-negative numeric values (> 0).
  - Target amounts for Schemes must be positive numbers.
  - All resource IDs must adhere to safe identifier characters (`[a-zA-Z0-9_-]+`).
  - No client may spoof administrator roles or inject unvalidated fields.

## 2. The "Dirty Dozen" Threat Payloads
1. **Unauthenticated ITI Deletion**: Anonymous DELETE /trainingCenters/iti-1 -> MUST BE REJECTED.
2. **Negative Contribution Injection**: Unauthenticated or malicious POST /contributions with amount: -50000 -> MUST BE REJECTED.
3. **Ghost Field Mutation**: Attacker injecting unauthorized system fields into trainingCenters -> MUST BE REJECTED.
4. **Notice Publishing by Anonymous Client**: Anonymous POST /notices -> MUST BE REJECTED.
5. **ID Poisoning Attack**: Passing a 2KB string as an ITI ID -> MUST BE REJECTED.
6. **Instructor Overwrite by Public**: Anonymous PUT /instructors/inst-1 -> MUST BE REJECTED.
7. **Scheme Alteration by Public**: Modifying target amount without Admin auth -> MUST BE REJECTED.
8. **Settings Tampering**: Modifying /settings/general target values unauthenticated -> MUST BE REJECTED.
9. **Fake Admin Claim**: Passing token with self-asserted `role: 'admin'` without real auth -> MUST BE REJECTED.
10. **Contribution Timestamp Hijacking**: Client injecting invalid non-string timestamp -> MUST BE REJECTED.
11. **Excessive Payload DOS**: Injecting 10MB string description into Scheme -> MUST BE REJECTED.
12. **Malformed Division Inject**: Injecting arbitrary division name outside J&K divisions -> MUST BE REJECTED.
