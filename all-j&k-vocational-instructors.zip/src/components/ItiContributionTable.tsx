import React, { useState, useMemo } from 'react';
import { Search, ArrowUpDown, ChevronLeft, ChevronRight, Layers, IndianRupee, RotateCcw } from 'lucide-react';
import { ItiAggregatedData, Division, TrainingCenter, Instructor, Scheme, Contribution } from '../types';
import { formatCurrency, formatDate, formatNumber } from '../utils/format';

export interface ItiContributionTableProps {
  data?: ItiAggregatedData[];
  trainingCenters?: TrainingCenter[];
  instructors?: Instructor[];
  schemes?: Scheme[];
  contributions?: Contribution[];
  onSelectIti?: (iti: ItiAggregatedData) => void;
  title?: string;
  subtitle?: string;
}

type SortField = 'sNo' | 'name' | 'division' | 'calculatedInstructorCount' | 'totalContribution' | 'lastContributionDate';
type SortDirection = 'asc' | 'desc';

export const ItiContributionTable: React.FC<ItiContributionTableProps> = ({
  data,
  trainingCenters = [],
  instructors = [],
  schemes = [],
  contributions = [],
  onSelectIti,
  title = 'EVENTS & CONTRIBUTIONS',
  subtitle = 'Consolidated contributions & instructor allocation across all Government ITIs in Jammu & Kashmir',
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDivision, setSelectedDivision] = useState<'All' | Division>('All');
  const [selectedSchemeId, setSelectedSchemeId] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('sNo');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  const selectedScheme = useMemo(() => {
    return schemes.find((s) => s.id === selectedSchemeId);
  }, [schemes, selectedSchemeId]);

  // Compute reactive aggregated data for each ITI based on selectedSchemeId
  const aggregatedData: ItiAggregatedData[] = useMemo(() => {
    // If training centers & contributions are provided, compute per selected scheme
    if (trainingCenters && trainingCenters.length > 0) {
      return trainingCenters.map((tc) => {
        const itiInstructors = instructors.filter(
          (i) => i.itiId === tc.id && (i.approvalStatus === 'Approved' || !i.approvalStatus)
        );
        const calculatedInstructorCount = itiInstructors.length;

        // Filter contributions for this ITI by selected scheme
        const itiContribs = contributions.filter((c) => {
          if (c.itiId !== tc.id) return false;
          if (selectedSchemeId === 'all') return true;
          return c.schemeId === selectedSchemeId || (selectedScheme && c.schemeName === selectedScheme.name);
        });

        const totalContribution = itiContribs.reduce((sum, c) => sum + (c.amount || 0), 0);

        let lastContributionDate = '';
        let contributionRemarks = '';

        if (itiContribs.length > 0) {
          const sortedContribs = [...itiContribs].sort((a, b) => {
            const dateA = a.contributionDate ? new Date(a.contributionDate).getTime() : 0;
            const dateB = b.contributionDate ? new Date(b.contributionDate).getTime() : 0;
            return dateB - dateA;
          });

          if (sortedContribs.length > 0) {
            lastContributionDate = sortedContribs[0].contributionDate || '';

            const nonBlankRemarks = sortedContribs
              .map((c) => (c.remarks || '').trim())
              .filter((r) => r.length > 0);

            if (nonBlankRemarks.length > 0) {
              const uniqueRemarks = Array.from(new Set(nonBlankRemarks));
              contributionRemarks = uniqueRemarks.join('; ');
            }
          }
        }

        return {
          ...tc,
          remarks: contributionRemarks,
          calculatedInstructorCount,
          totalContribution,
          lastContributionDate,
        };
      });
    }

    // Fallback if data prop passed directly
    if (data && data.length > 0) {
      if (selectedSchemeId === 'all' || contributions.length === 0) {
        return data;
      }
      return data.map((tc) => {
        const itiContribs = contributions.filter((c) => {
          if (c.itiId !== tc.id) return false;
          return c.schemeId === selectedSchemeId || (selectedScheme && c.schemeName === selectedScheme.name);
        });
        const totalContribution = itiContribs.reduce((sum, c) => sum + (c.amount || 0), 0);
        let lastContributionDate = '';
        let contributionRemarks = '';

        if (itiContribs.length > 0) {
          const sortedContribs = [...itiContribs].sort((a, b) => {
            const dateA = a.contributionDate ? new Date(a.contributionDate).getTime() : 0;
            const dateB = b.contributionDate ? new Date(b.contributionDate).getTime() : 0;
            return dateB - dateA;
          });

          if (sortedContribs.length > 0) {
            lastContributionDate = sortedContribs[0].contributionDate || '';
            const nonBlankRemarks = sortedContribs
              .map((c) => (c.remarks || '').trim())
              .filter((r) => r.length > 0);
            if (nonBlankRemarks.length > 0) {
              contributionRemarks = Array.from(new Set(nonBlankRemarks)).join('; ');
            }
          }
        }

        return {
          ...tc,
          remarks: contributionRemarks || tc.remarks,
          totalContribution,
          lastContributionDate,
        };
      });
    }

    return [];
  }, [trainingCenters, instructors, contributions, schemes, selectedSchemeId, selectedScheme, data]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const filteredData = useMemo(() => {
    return aggregatedData.filter((iti) => {
      const matchesSearch =
        iti.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        iti.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (iti.remarks && iti.remarks.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesDivision = selectedDivision === 'All' || iti.division === selectedDivision;

      return matchesSearch && matchesDivision;
    });
  }, [aggregatedData, searchTerm, selectedDivision]);

  const sortedData = useMemo(() => {
    return [...filteredData].sort((a, b) => {
      let comparison = 0;
      if (sortField === 'sNo') {
        comparison = a.sNo - b.sNo;
      } else if (sortField === 'name') {
        comparison = a.name.localeCompare(b.name);
      } else if (sortField === 'division') {
        comparison = a.division.localeCompare(b.division);
      } else if (sortField === 'calculatedInstructorCount') {
        comparison = a.calculatedInstructorCount - b.calculatedInstructorCount;
      } else if (sortField === 'totalContribution') {
        comparison = a.totalContribution - b.totalContribution;
      } else if (sortField === 'lastContributionDate') {
        const dateA = a.lastContributionDate ? new Date(a.lastContributionDate).getTime() : 0;
        const dateB = b.lastContributionDate ? new Date(b.lastContributionDate).getTime() : 0;
        comparison = dateA - dateB;
      }
      return sortDirection === 'asc' ? comparison : -comparison;
    });
  }, [filteredData, sortField, sortDirection]);

  // Pagination calculations
  const totalPages = Math.ceil(sortedData.length / pageSize) || 1;
  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedData.slice(start, start + pageSize);
  }, [sortedData, currentPage, pageSize]);

  // Overall Totals (Calculated from complete filtered dataset)
  const summaryTotals = useMemo(() => {
    const totalItis = sortedData.length;
    const totalInstructors = sortedData.reduce((acc, curr) => acc + curr.calculatedInstructorCount, 0);
    const totalContribution = sortedData.reduce((acc, curr) => acc + curr.totalContribution, 0);
    const contributingItis = sortedData.filter((i) => i.totalContribution > 0).length;
    return { totalItis, totalInstructors, totalContribution, contributingItis };
  }, [sortedData]);

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Table Header Section */}
      <div className="p-5 border-b border-slate-200 bg-slate-50/70">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-700"></span>
              <h3 className="text-base sm:text-lg font-black text-[#0F2942] uppercase tracking-wide">
                {title}
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {subtitle}
            </p>
          </div>

          {/* Search, Scheme Dropdown & Division Filter Controls */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Search Input */}
            <div className="relative min-w-[200px] flex-1 sm:flex-initial">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                id="iti-search-input"
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Search ITI name, location..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-800 shadow-2xs"
              />
            </div>

            {/* Event Dropdown Selector */}
            {schemes.length > 0 && (
              <div className="flex items-center gap-1.5 bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-xs shadow-2xs">
                <Layers className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <label htmlFor="iti-table-scheme-filter" className="font-bold text-slate-700 whitespace-nowrap">
                  Event:
                </label>
                <select
                  id="iti-table-scheme-filter"
                  value={selectedSchemeId}
                  onChange={(e) => {
                    setSelectedSchemeId(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="bg-transparent font-bold text-slate-900 focus:outline-hidden cursor-pointer max-w-[200px] sm:max-w-[240px] truncate"
                >
                  <option value="all">All Events (Consolidated)</option>
                  {schemes.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Division Filter Buttons */}
            <div className="flex items-center gap-1 bg-white border border-slate-300 rounded-lg p-0.5 text-xs shadow-2xs">
              <button
                type="button"
                id="filter-div-all"
                onClick={() => {
                  setSelectedDivision('All');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-md font-semibold transition-colors cursor-pointer ${
                  selectedDivision === 'All'
                    ? 'bg-[#0F2942] text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All (50)
              </button>
              <button
                type="button"
                id="filter-div-kashmir"
                onClick={() => {
                  setSelectedDivision('Kashmir Division');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-md font-semibold transition-colors cursor-pointer ${
                  selectedDivision === 'Kashmir Division'
                    ? 'bg-blue-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-blue-900'
                }`}
              >
                Kashmir (1-24)
              </button>
              <button
                type="button"
                id="filter-div-jammu"
                onClick={() => {
                  setSelectedDivision('Jammu Division');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-md font-semibold transition-colors cursor-pointer ${
                  selectedDivision === 'Jammu Division'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-emerald-900'
                }`}
              >
                Jammu (25-50)
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Active Scheme Status Banner */}
      {selectedScheme && selectedSchemeId !== 'all' && (
        <div className="px-5 py-2.5 bg-amber-50/90 border-b border-amber-200/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-amber-900">
            <span className="font-bold text-slate-700">Scheme Filter Active:</span>
            <span className="px-2.5 py-0.5 rounded-md bg-amber-200/80 font-extrabold text-amber-950 border border-amber-300/60 shadow-2xs">
              {selectedScheme.name}
            </span>
            {selectedScheme.targetAmount > 0 && (
              <span className="text-amber-800 text-[11px] font-semibold">
                (Scheme Target: {formatCurrency(selectedScheme.targetAmount)})
              </span>
            )}
          </div>
          <div className="flex items-center gap-4">
            <span className="text-slate-700">
              Scheme Remittance Total:{' '}
              <strong className="text-emerald-800 font-mono font-black text-sm">
                {formatCurrency(summaryTotals.totalContribution)}
              </strong>
            </span>
            <button
              type="button"
              id="reset-scheme-filter-btn"
              onClick={() => {
                setSelectedSchemeId('all');
                setCurrentPage(1);
              }}
              className="text-[11px] font-bold text-amber-800 hover:text-amber-950 flex items-center gap-1 underline cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Show All Schemes</span>
            </button>
          </div>
        </div>
      )}

      {/* Table Container */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-[#0F2942] text-slate-200 uppercase font-bold text-[11px] tracking-wider select-none border-b border-slate-800">
              <th
                onClick={() => handleSort('sNo')}
                className="py-3 px-3.5 cursor-pointer hover:bg-slate-800 transition-colors w-16 text-center"
              >
                <div className="flex items-center justify-center gap-1">
                  <span>S.No</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                onClick={() => handleSort('division')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-800 transition-colors"
              >
                <div className="flex items-center gap-1">
                  <span>Division</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                onClick={() => handleSort('name')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-800 transition-colors min-w-[200px]"
              >
                <div className="flex items-center gap-1">
                  <span>Name of ITI</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                onClick={() => handleSort('calculatedInstructorCount')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-800 transition-colors text-center w-36"
              >
                <div className="flex items-center justify-center gap-1">
                  <span>No. of Instructors</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                onClick={() => handleSort('totalContribution')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-800 transition-colors text-right w-40"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>
                    {selectedSchemeId !== 'all' ? 'Scheme Remittance (₹)' : 'Contribution (₹)'}
                  </span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                onClick={() => handleSort('lastContributionDate')}
                className="py-3 px-4 cursor-pointer hover:bg-slate-800 transition-colors text-center w-40"
              >
                <div className="flex items-center justify-center gap-1">
                  <span>Last Contribution Date</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th className="py-3 px-4 min-w-[150px]">
                <span>Remarks</span>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {paginatedData.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-8 text-center text-slate-500">
                  No ITI records match the current search or filters.
                </td>
              </tr>
            ) : (
              paginatedData.map((iti, idx) => {
                const isKashmir = iti.division === 'Kashmir Division';
                const hasContributed = iti.totalContribution > 0;
                return (
                  <tr
                    key={iti.id}
                    id={`iti-row-${iti.sNo}`}
                    className={`hover:bg-blue-50/50 transition-colors ${
                      idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/40'
                    }`}
                  >
                    <td className="py-2.5 px-3.5 text-center font-bold text-slate-600">
                      {iti.sNo}
                    </td>
                    <td className="py-2.5 px-4">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                          isKashmir
                            ? 'bg-blue-50 text-blue-800 border border-blue-200'
                            : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        }`}
                      >
                        {iti.division}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 font-bold text-slate-900">
                      <div className="flex flex-col">
                        <span>{iti.name}</span>
                        {iti.location && (
                          <span className="text-[10px] text-slate-600 font-normal">
                            {iti.location}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-2.5 px-4 text-center">
                      <span
                        className={`inline-flex items-center justify-center w-7 h-7 rounded-full font-bold text-xs ${
                          iti.calculatedInstructorCount > 0
                            ? 'bg-indigo-100 text-indigo-900 border border-indigo-200'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {iti.calculatedInstructorCount}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono font-bold">
                      <span
                        className={
                          hasContributed ? 'text-emerald-700' : 'text-slate-600 font-normal'
                        }
                      >
                        {formatCurrency(iti.totalContribution)}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-center font-mono text-slate-600">
                      {iti.lastContributionDate ? formatDate(iti.lastContributionDate) : '—'}
                    </td>
                    <td
                      className="py-2.5 px-4 text-slate-600 text-[11px] truncate max-w-xs"
                      title={iti.remarks || undefined}
                    >
                      {iti.remarks || '—'}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>

          {/* Mandatory Summary Row at bottom of table */}
          <tfoot>
            <tr className="bg-slate-100 text-slate-900 font-black border-t-2 border-slate-300 text-xs">
              <td colSpan={2} className="py-3 px-4 uppercase tracking-wider text-slate-700">
                Summary Total:
              </td>
              <td className="py-3 px-4">
                <span className="bg-blue-100 text-blue-900 px-2 py-0.5 rounded font-bold">
                  {summaryTotals.totalItis} ITIs ({summaryTotals.contributingItis} Active)
                </span>
              </td>
              <td className="py-3 px-4 text-center">
                <span className="bg-indigo-100 text-indigo-900 px-2.5 py-1 rounded-full font-extrabold">
                  {formatNumber(summaryTotals.totalInstructors)}
                </span>
              </td>
              <td className="py-3 px-4 text-right font-mono text-emerald-800 text-sm">
                {formatCurrency(summaryTotals.totalContribution)}
              </td>
              <td colSpan={2} className="py-3 px-4 text-slate-600 font-normal text-[11px]">
                {selectedSchemeId !== 'all' && selectedScheme
                  ? `Filtered by: ${selectedScheme.name}`
                  : 'Showing consolidated aggregated totals'}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>

      {/* Pagination & Rows selector */}
      <div className="p-4 border-t border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <span>Rows per page:</span>
          <select
            id="page-size-select"
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="bg-white border border-slate-300 rounded px-2 py-1 text-xs text-slate-800 focus:outline-hidden"
          >
            <option value={10}>10</option>
            <option value={15}>15</option>
            <option value={25}>25</option>
            <option value={50}>50 (All)</option>
          </select>
          <span className="text-slate-400">|</span>
          <span>
            Showing {paginatedData.length > 0 ? (currentPage - 1) * pageSize + 1 : 0} to{' '}
            {Math.min(currentPage * pageSize, sortedData.length)} of {sortedData.length} ITIs
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            id="prev-page-btn"
            disabled={currentPage === 1}
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            className="p-1.5 rounded border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed text-slate-700 cursor-pointer"
            aria-label="Previous Page"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="px-3 py-1 font-semibold text-slate-700">
            Page {currentPage} of {totalPages}
          </span>
          <button
            type="button"
            id="next-page-btn"
            disabled={currentPage === totalPages || totalPages === 0}
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            className="p-1.5 rounded border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed text-slate-700 cursor-pointer"
            aria-label="Next Page"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

