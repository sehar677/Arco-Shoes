import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  TrainingCenter,
  Instructor,
  Scheme,
  Contribution,
  Notice,
  ItiAggregatedData,
  ActivePage,
  AdminTab,
} from '../../types';

export type { AdminTab };
import { AdminOverview } from './AdminOverview';
import { ManageTrainingCenters } from './ManageTrainingCenters';
import { ManageInstructors } from './ManageInstructors';
import { ManageSchemes } from './ManageSchemes';
import { ManageContributions } from './ManageContributions';
import { ManageNotices } from './ManageNotices';
import { AdminReports } from './AdminReports';
import { AdminSettings } from './AdminSettings';
import { syncPendingInstructorsToFirestore } from '../../services/db';
import {
  LayoutDashboard,
  Building2,
  PlusCircle,
  Users,
  Layers,
  IndianRupee,
  Bell,
  FileBarChart,
  Settings,
  LogOut,
  ExternalLink,
  Menu,
  X,
  ShieldCheck,
  Lock,
  Clock,
  ShieldAlert,
  RefreshCw,
  Shield,
} from 'lucide-react';

interface AdminLayoutProps {
  trainingCenters: TrainingCenter[];
  instructors: Instructor[];
  schemes: Scheme[];
  contributions: Contribution[];
  notices: Notice[];
  targetAmount: number;
  employeeTypes?: string[];
  aggregatedItis: ItiAggregatedData[];
  onNavigate: (page: ActivePage) => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  trainingCenters,
  instructors,
  schemes,
  contributions,
  notices,
  targetAmount,
  employeeTypes,
  aggregatedItis,
  onNavigate,
  onNotify,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { currentUser, logout, sessionRemainingSeconds, extendSession } = useAuth();

  useEffect(() => {
    syncPendingInstructorsToFirestore();
  }, []);

  const handleLogout = async () => {
    try {
      await logout();
      onNotify('info', 'Logged out of CPANEL successfully.');
    } catch (err: any) {
      console.warn('Logout notice:', err);
    } finally {
      onNavigate('home');
    }
  };

  const formatSessionTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${String(secs).padStart(2, '0')}`;
  };

  const pendingInstructorsCount = instructors.filter(
    (i) => i.approvalStatus === 'Pending' || i.approvalStatus === 'Pending Review (Awaiting Approval)'
  ).length;

  const navMenuItems: {
    id: AdminTab;
    label: string;
    icon: React.ReactNode;
    badge?: number | string;
    badgeColor?: string;
  }[] = [
    {
      id: 'overview',
      label: 'DASHBOARD OVERVIEW',
      icon: <LayoutDashboard className="w-4 h-4" />,
    },
    {
      id: 'training-centers',
      label: 'MANAGE TRAINING CENTERS',
      icon: <Building2 className="w-4 h-4" />,
      badge: trainingCenters.length,
    },
    {
      id: 'add-training-center',
      label: 'ADD NEW TRAINING CENTER',
      icon: <PlusCircle className="w-4 h-4 text-amber-400" />,
    },
    {
      id: 'instructors',
      label: 'MANAGE INSTRUCTORS',
      icon: <Users className="w-4 h-4" />,
      badge: instructors.length,
    },
    {
      id: 'pending-instructors',
      label: 'PENDING REGISTRATIONS',
      icon: <Clock className="w-4 h-4 text-amber-400" />,
      badge: pendingInstructorsCount > 0 ? `${pendingInstructorsCount} Pending` : undefined,
      badgeColor: pendingInstructorsCount > 0 ? 'bg-amber-500 text-slate-950 font-black animate-pulse' : undefined,
    },
    {
      id: 'add-instructor',
      label: 'ADD SKILL DEVELOPMENT EMPLOYEEE',
      icon: <PlusCircle className="w-4 h-4 text-amber-400" />,
    },
    {
      id: 'schemes',
      label: 'MANAGE EVENTS',
      icon: <Layers className="w-4 h-4" />,
      badge: schemes.length,
    },
    {
      id: 'contributions',
      label: 'MANAGE CONTRIBUTIONS',
      icon: <IndianRupee className="w-4 h-4" />,
      badge: contributions.length,
    },
    {
      id: 'notices',
      label: 'MANAGE NOTICEBOARD',
      icon: <Bell className="w-4 h-4" />,
      badge: notices.length,
    },
    {
      id: 'reports',
      label: 'REPORTS & EXPORTS',
      icon: <FileBarChart className="w-4 h-4" />,
    },
    {
      id: 'settings',
      label: 'SETTINGS & SYNC',
      icon: <Settings className="w-4 h-4" />,
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-slate-100 -mx-4 sm:-mx-8 -my-8">
      {/* Top Administrative Bar for CPANEL */}
      <header className="bg-[#0F2942] text-white border-b border-slate-800 px-4 sm:px-6 py-3 sticky top-0 z-30 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 lg:hidden"
            aria-label="Toggle Navigation"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 font-black flex items-center justify-center">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs sm:text-sm font-black uppercase tracking-wider block">
                ADMINISTRATIVE CPANEL
              </span>
              <span className="text-[10px] text-amber-400 font-semibold block">
                J&amp;K ITI Employee&#39;s United Front Portal
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 sm:gap-3">
          {/* Live Session Timeout Timer (2-Min Inactivity Timeout) */}
          <div
            onClick={extendSession}
            title="Session auto-times out after 2 minutes of inactivity. Interacting with the screen or clicking here resets the 2-minute timer."
            className={`cursor-pointer px-2.5 py-1 rounded-lg border text-xs font-mono font-bold flex items-center gap-1.5 transition-all shadow-xs ${
              sessionRemainingSeconds <= 15
                ? 'bg-rose-950/80 border-rose-500 text-rose-300 animate-pulse'
                : sessionRemainingSeconds <= 30
                ? 'bg-amber-950/80 border-amber-500/70 text-amber-300'
                : 'bg-slate-850 border-slate-700/80 text-emerald-400 hover:border-emerald-500/60'
            }`}
          >
            <Clock className={`w-3.5 h-3.5 ${sessionRemainingSeconds <= 15 ? 'text-rose-400' : 'text-amber-400'}`} />
            <span>
              {sessionRemainingSeconds <= 15 ? 'TIMEOUT IN: ' : 'SESSION: '}
              {formatSessionTime(sessionRemainingSeconds)}
            </span>
            {sessionRemainingSeconds <= 15 && (
              <span className="hidden md:inline-block px-1.5 py-0.2 text-[10px] bg-rose-700 text-white rounded-sm font-sans font-extrabold uppercase">
                Keep Alive
              </span>
            )}
          </div>

          {/* Single Admin Session Status */}
          <div className="hidden lg:inline-flex items-center gap-1 px-2 py-1 rounded-md bg-blue-950/60 border border-blue-800/60 text-[11px] text-blue-300 font-medium" title="Enforced: Only 1 concurrent active administrator session is permitted per credential.">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Single Session Active</span>
          </div>

          <div className="hidden sm:flex flex-col text-right text-xs">
            <span className="text-slate-200 font-bold truncate max-w-[140px] md:max-w-xs">
              {currentUser?.email || 'Admin'}
            </span>
            <span className="text-[10px] text-emerald-400 font-mono">Authenticated Superadmin</span>
          </div>

          <button
            type="button"
            id="cpanel-public-view-btn"
            onClick={() => onNavigate('home')}
            className="px-3 py-1.5 rounded-md bg-blue-900/80 hover:bg-blue-800 text-blue-200 text-xs font-bold transition-colors flex items-center gap-1.5"
            title="View Public Portal"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Public Portal</span>
          </button>

          <button
            type="button"
            id="cpanel-logout-btn"
            onClick={handleLogout}
            className="px-3 py-1.5 rounded-md bg-rose-900/70 hover:bg-rose-800 text-rose-200 text-xs font-bold transition-colors flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </header>

      {/* Main Layout Body (Sidebar + Content) */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Sidebar */}
        <aside
          className={`fixed inset-y-0 left-0 z-40 w-64 bg-[#0a1e32] text-slate-300 transform transition-transform duration-200 ease-in-out lg:static lg:translate-x-0 flex flex-col justify-between border-r border-slate-800 ${
            isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
        >
          {/* Top Mobile Header inside sidebar */}
          <div className="p-4 border-b border-slate-800 flex items-center justify-between lg:hidden">
            <span className="text-xs font-bold uppercase text-white tracking-wider">
              CPANEL MENU
            </span>
            <button
              type="button"
              onClick={() => setIsSidebarOpen(false)}
              className="p-1 rounded text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Items */}
          <div className="p-3 space-y-1 flex-1 overflow-y-auto">
            <div className="px-3 py-2 text-[10px] font-extrabold uppercase tracking-wider text-amber-400/90">
              Department Operations
            </div>
            {navMenuItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`admin-menu-${item.id}`}
                  type="button"
                  onClick={() => {
                    setActiveTab(item.id);
                    setIsSidebarOpen(false);
                  }}
                  className={`w-full px-3 py-2.5 rounded-lg text-xs font-bold flex items-center justify-between transition-colors text-left ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {item.icon}
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span
                      className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                        item.badgeColor
                          ? item.badgeColor
                          : isActive
                          ? 'bg-white/20 text-white'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Sidebar Footer info & Logout */}
          <div className="p-3 border-t border-slate-800 bg-[#071624] space-y-2.5">
            <button
              type="button"
              id="sidebar-logout-btn"
              onClick={handleLogout}
              className="w-full py-2 px-3 rounded-lg bg-rose-950/70 hover:bg-rose-900 border border-rose-800 text-rose-200 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs hover:text-white"
            >
              <LogOut className="w-4 h-4 text-rose-400" />
              <span>LOGOUT OF CPANEL</span>
            </button>
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold text-[11px] px-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Direct Firestore Sync</span>
            </div>
            <p className="text-[10px] text-slate-500 leading-tight px-1">
              All updates sync live to public dashboard &amp; ITI contribution records.
            </p>
          </div>
        </aside>

        {/* Backdrop for mobile */}
        {isSidebarOpen && (
          <div
            className="fixed inset-0 bg-slate-900/50 z-30 lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
          ></div>
        )}

        {/* Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {activeTab === 'overview' && (
            <AdminOverview
              trainingCenters={trainingCenters}
              instructors={instructors}
              schemes={schemes}
              contributions={contributions}
              notices={notices}
              targetAmount={targetAmount}
              aggregatedItis={aggregatedItis}
              onSelectTab={(tab) => setActiveTab(tab as AdminTab)}
            />
          )}

          {(activeTab === 'training-centers' || activeTab === 'add-training-center') && (
            <ManageTrainingCenters
              trainingCenters={trainingCenters}
              initialView={activeTab === 'add-training-center' ? 'add' : 'list'}
              onNotify={onNotify}
            />
          )}

          {(activeTab === 'instructors' ||
            activeTab === 'pending-instructors' ||
            activeTab === 'add-instructor') && (
            <ManageInstructors
              key={activeTab}
              instructors={instructors}
              trainingCenters={trainingCenters}
              employeeTypes={employeeTypes}
              initialTab={activeTab === 'pending-instructors' ? 'Pending' : 'All'}
              initialOpenAddModal={activeTab === 'add-instructor'}
              onNotify={onNotify}
            />
          )}

          {activeTab === 'schemes' && (
            <ManageSchemes
              schemes={schemes}
              contributions={contributions}
              onNotify={onNotify}
            />
          )}

          {activeTab === 'contributions' && (
            <ManageContributions
              contributions={contributions}
              trainingCenters={trainingCenters}
              schemes={schemes}
              onNotify={onNotify}
            />
          )}

          {activeTab === 'notices' && (
            <ManageNotices notices={notices} onNotify={onNotify} />
          )}

          {activeTab === 'reports' && (
            <AdminReports
              aggregatedItis={aggregatedItis}
              schemes={schemes}
              contributions={contributions}
              instructors={instructors}
            />
          )}

          {activeTab === 'settings' && (
            <AdminSettings
              targetAmount={targetAmount}
              employeeTypes={employeeTypes}
              trainingCenters={trainingCenters}
              instructors={instructors}
              schemes={schemes}
              contributions={contributions}
              notices={notices}
              onNotify={onNotify}
            />
          )}
        </main>
      </div>
    </div>
  );
};
