import React from 'react';
import { ActivePage } from '../types';
import { GraduationCap, ShieldCheck, Phone, Mail, MapPin } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: ActivePage) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="w-full bg-[#0F2942] text-slate-300 border-t-4 border-amber-600">
      {/* Top Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Column 1: Brand & Purpose */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-900 border border-amber-500/40 flex items-center justify-center text-amber-400">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white uppercase tracking-wider">
                  J&amp;K ITI EMPLOYEE&#39;S UNITED FRONT
                </h3>
                <p className="text-xs font-semibold text-amber-400">
                  Industrial Training Institutes • Jammu &amp; Kashmir
                </p>
              </div>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Centralized platform for managing Skill Development Employees, Training Centers, Schemes and Fund Contributions across Industrial Training Institutes of Jammu &amp; Kashmir.
            </p>
            <div className="flex items-center gap-2 text-xs text-emerald-400 font-medium">
              <ShieldCheck className="w-4 h-4" />
              <span>Official Departmental Tracking Portal</span>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-4 border-b border-slate-700 pb-2">
              QUICK NAVIGATION
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  type="button"
                  onClick={() => { onNavigate('home'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-amber-300 transition-colors"
                >
                  Home Dashboard
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => { onNavigate('training-centers'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-amber-300 transition-colors"
                >
                  Training Centers (50 ITIs)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => { onNavigate('instructors'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-amber-300 transition-colors"
                >
                  Skill Development Employees Directory
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => { onNavigate('contributions'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-amber-300 transition-colors"
                >
                  Events &amp; Contributions Remittances
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => { onNavigate('noticeboard'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-amber-300 transition-colors"
                >
                  Official Noticeboard &amp; Circulars
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => { onNavigate('about'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-amber-300 transition-colors"
                >
                  About Portal &amp; Objectives
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Coverage */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-4 border-b border-slate-700 pb-2">
              COVERAGE DIVISIONS
            </h4>
            <div className="space-y-3 text-xs">
              <div>
                <p className="font-semibold text-white">Kashmir Division</p>
                <p className="text-slate-400 text-[11px]">24 Government ITIs (Srinagar to Kupwara &amp; Gurez)</p>
              </div>
              <div>
                <p className="font-semibold text-white">Jammu Division</p>
                <p className="text-slate-400 text-[11px]">26 Government ITIs (Jammu to Poonch, Kishtwar &amp; Kathua)</p>
              </div>
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => { onNavigate('login'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="text-xs text-amber-400 hover:underline font-semibold flex items-center gap-1"
                >
                  Administrative CPANEL Login &rarr;
                </button>
              </div>
            </div>
          </div>

          {/* Column 4: Contact / Helpline */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-4 border-b border-slate-700 pb-2">
              DIRECTORATE DESK
            </h4>
            <div className="space-y-2.5 text-xs text-slate-300">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Directorate of Skill Development, Bikram Chowk, Jammu / Bemina, Srinagar, J&amp;K</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <span>+91 194-2490000 / 0191-2450000</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <span>info.skilldev@jk.gov.in</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Copyright Bar */}
      <div className="bg-[#091a2b] border-t border-slate-800 py-4 px-4 sm:px-8 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>© {currentYear} J&amp;K ITI Employee&#39;s United Front. All Rights Reserved.</p>
          <p className="text-[11px] text-slate-400">
            Industrial Training Institutes • Department of Technical Education &amp; Skill Development, J&amp;K
          </p>
        </div>
      </div>
    </footer>
  );
};
